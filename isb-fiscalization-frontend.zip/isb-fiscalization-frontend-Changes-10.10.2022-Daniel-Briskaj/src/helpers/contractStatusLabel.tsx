import Label from 'src/view/materialUI/components/Label';

export const getStatusLabel = contractStatus => {
  const map = {
    ACTIVE: {
      color: 'success',
      text: 'ACTIVE',
    },
    EXPIRED: {
      color: 'error',
      text: 'EXPIRED',
    },
    BUDGET: {
      color: 'warning',
      text: 'BUDGET',
    },
    FORECAST: {
      color: 'primary',
      text: 'FORECAST',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: contractStatus,
    },
  };

  const { text, color }: any = map[contractStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};
