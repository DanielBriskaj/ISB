import { ROLES } from 'src/modules/shared/authentication/authReducer';

const IsAuthorizer = role => {
  switch (role) {
    case ROLES.COST_OWNER_AUTHORIZER:
      return true;
    case ROLES.ACCOUNTING_AUTHORIZER:
      return true;
    case ROLES.PROCUREMENT_AUTHORIZER:
      return true;
    case ROLES.PLANNING_CONTROL_AUTHORIZER:
      return true;
    default:
      return false;
  }
};

export default IsAuthorizer;
