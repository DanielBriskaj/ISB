import jwt_decode from 'jwt-decode';

export const tokenExpiry = () => {
  const token = localStorage.getItem('idToken');
  if (token) {
    const decoded: any = token && jwt_decode(token);
    return decoded.exp;
  }
};
