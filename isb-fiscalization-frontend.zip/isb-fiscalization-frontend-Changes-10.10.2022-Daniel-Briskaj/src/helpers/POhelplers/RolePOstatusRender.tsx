const RolePOstatusRender = (role, action) => {
  if (action === 'Assign') {
    switch (role) {
      case 'COST_OWNER':
        return 'COA';
      case 'COST_OWNER_AUTHORIZER':
        return 'PRI';
      case 'PROCUREMENT_INPUT':
        return 'PRA';
      case 'PROCUREMENT_AUTHORIZER':
        return 'APPROVED';
    }
  } else if (action === 'Reject') {
    switch (role) {
      case 'COST_OWNER_AUTHORIZER':
        return 'NEW';
      case 'PROCUREMENT_INPUT':
        return 'COA';
      case 'PROCUREMENT_AUTHORIZER':
        return 'PRI';
    }
  }
};

export default RolePOstatusRender;

export const ApproveAllStatusRender = role => {
  switch (role) {
    case 'COST_OWNER_AUTHORIZER':
      return { currentStatus: 'COA', newStatus: 'PRI' };
    case 'PROCUREMENT_INPUT':
      return { currentStatus: 'PRI', newStatus: 'PRA' };
    case 'PROCUREMENT_AUTHORIZER':
      return { currentStatus: 'PRA', newStatus: 'APPROVED' };
  }
};
