const StatusArrayRender = role => {
  switch (role) {
    case 'COST_OWNER_AUTHORIZER':
      return ['COA', 'PRI', 'PRA', 'APPROVED', 'COMPLETED'];
    case 'PROCUREMENT_INPUT':
      return ['PRI', 'PRA', 'APPROVED', 'COMPLETED'];
    case 'PROCUREMENT_AUTHORIZER':
      return ['PRA', 'APPROVED', 'COMPLETED'];
  }
};

export default StatusArrayRender;
