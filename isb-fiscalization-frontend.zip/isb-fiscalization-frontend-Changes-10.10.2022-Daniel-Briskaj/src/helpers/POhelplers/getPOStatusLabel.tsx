import Label from 'src/view/materialUI/components/Label';

const getPOStatusLabel = invoiceStatus => {
  const map = {
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    COA: {
      color: 'success',
      text: 'COA',
    },
    PRI: {
      color: 'secondary',
      text: 'PRI',
    },
    PRA: {
      color: 'warning',
      text: 'PRA',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    COMPLETED: {
      color: 'success',
      text: 'COMPLETED',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

export default getPOStatusLabel;
