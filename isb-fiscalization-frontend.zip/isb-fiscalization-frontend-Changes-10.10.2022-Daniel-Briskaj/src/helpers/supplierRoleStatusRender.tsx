const RoleSupplierStatusRender = (role, action) => {
  if (action === 'Assign') {
    switch (role) {
      case 'PROCUREMENT_INPUT':
        return 'IN_APPROVAL';
      case 'PROCUREMENT_AUTHORIZER':
        return 'APPROVED';
    }
  } else if (action === 'Reject') {
    switch (role) {
      case 'PROCUREMENT_AUTHORIZER':
        return 'NEW';
    }
  }
};

export default RoleSupplierStatusRender;

export const RoleContractStatusRender = (role, action) => {
  if (action === 'Assign') {
    switch (role) {
      case 'PROCUREMENT_INPUT':
        return 'IN_APPROVAL';
      case 'PROCUREMENT_AUTHORIZER':
        return 'ACTIVE';
    }
  } else if (action === 'Reject') {
    switch (role) {
      case 'PROCUREMENT_AUTHORIZER':
        return 'NEW';
    }
  }
};
