import React from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

interface props {
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
  duration?: number;
  toastId?: string | number;
}

const notificationThrower = (props: props) => {
  const { message, type, duration = 5000, toastId } = props;
  toast(`${message}`, {
    position: 'bottom-right',
    autoClose: duration,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    type: type,
    toastId: toastId,
  });
};

export default notificationThrower;
