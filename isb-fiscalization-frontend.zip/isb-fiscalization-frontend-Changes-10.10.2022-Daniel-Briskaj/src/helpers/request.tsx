import axios, { AxiosRequestConfig } from 'axios';
import { RequestOptions } from 'src/models/request/RequestOptions';
import { ApiResponse } from 'src/models/request/ApiResponse';
import queryString from 'query-string';
import getConfig from 'src/helpers/config';

const config = getConfig();

const api = axios.create({});

api.interceptors.request.use((requestConfig: AxiosRequestConfig) => {
  const idToken = localStorage.getItem('idToken');

  let headers = {
    Authorization: '',
    'Access-Control-Allow-Origin': '*',
  };

  if (idToken) {
    headers.Authorization = `Bearer ${idToken}`;
  }

  requestConfig.headers = { ...requestConfig.headers, ...headers };

  return requestConfig;
});

class Request {
  static async doRequest(options: RequestOptions): Promise<ApiResponse> {
    try {
      if (options.query) {
        const query = queryString.stringify(options.query, {
          arrayFormat: 'none',
        });

        options.url = options.url + '?' + query;
        delete options.query;
      }
      const response = await api(options);
      return { success: true, payload: response };
    } catch (error: any) {
      return { success: false, payload: error };
    }
  }
}

export default Request;
