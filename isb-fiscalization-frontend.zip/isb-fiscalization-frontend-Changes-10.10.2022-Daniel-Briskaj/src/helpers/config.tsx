const environment = process.env;

export default function () {
  return {
    test: {
      baseUrl: `${environment.REACT_APP_API}`,
      invoiceUrl: `${environment.REACT_APP_INVOICE_API}`,
    },
  };
}
