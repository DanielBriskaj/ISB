import { FormInvoiceData } from 'src/models/data/invoices/InvoiceData';

const MemoDataTransformer = (data: FormInvoiceData) => {
  const newUpdatedObject = data;

  const excludedKeys = ['suplier', 'type', 'status'];

  Object.keys(newUpdatedObject).forEach(key => {
    if (excludedKeys.includes(key)) {
      delete newUpdatedObject[key];
    }
  });
  return newUpdatedObject;
};

export default MemoDataTransformer;
