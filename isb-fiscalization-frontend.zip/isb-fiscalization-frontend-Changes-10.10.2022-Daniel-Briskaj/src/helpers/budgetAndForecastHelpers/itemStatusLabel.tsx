import Label from 'src/view/materialUI/components/Label';

const getItemStatusLabel = ItemStatus => {
  const map = {
    CREATED: {
      color: 'primary',
      text: 'CREATED',
    },
    IN_APPROVAL_BY_COA: {
      color: 'success',
      text: 'IN_APPROVAL_BY_COA',
    },
    IN_APPROVAL_BY_PCI: {
      color: 'warning',
      text: 'IN_APPROVAL_BY_PCI',
    },
    IN_APPROVAL_BY_PCA: {
      color: 'secondary',
      text: 'IN_APPROVAL_BY_PCA',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    DEFAULT: {
      color: 'primary',
      text: ItemStatus,
    },
  };

  const { text, color }: any = map[ItemStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

export default getItemStatusLabel;
