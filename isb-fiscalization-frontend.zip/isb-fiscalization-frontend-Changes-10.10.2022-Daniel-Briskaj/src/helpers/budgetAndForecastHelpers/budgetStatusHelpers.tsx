import { ROLES } from 'src/modules/shared/authentication/authReducer';

export const getNextStatusByRole = role => {
  switch (role) {
    case ROLES.COST_OWNER:
      return 'IN_APPROVAL_BY_COA';
    case ROLES.COST_OWNER_AUTHORIZER:
      return 'IN_APPROVAL_BY_PCI';
    case ROLES.PLANNING_CONTROL_INPUT:
      return 'IN_APPROVAL_BY_PCA';
    case ROLES.PLANNING_CONTROL_AUTHORIZER:
      return 'APPROVED';
  }
};

export const getValidStatusByRole = role => {
  switch (role) {
    case ROLES.COST_OWNER:
      return 'CREATED';
    case ROLES.COST_OWNER_AUTHORIZER:
      return 'IN_APPROVAL_BY_COA';
    case ROLES.PLANNING_CONTROL_INPUT:
      return 'IN_APPROVAL_BY_PCI';
    case ROLES.PLANNING_CONTROL_AUTHORIZER:
      return 'IN_APPROVAL_BY_PCA';
  }
};

export const getPreviousStatusByRole = role => {
  switch (role) {
    case ROLES.COST_OWNER_AUTHORIZER:
      return 'CREATED';
    case ROLES.PLANNING_CONTROL_INPUT:
      return 'IN_APPROVAL_BY_COA';
    case ROLES.PLANNING_CONTROL_AUTHORIZER:
      return 'IN_APPROVAL_BY_PCI';
  }
};
