interface BudgetProps {
  name?: string;
  year?: string;
  dueDate?: Date | string;
  budgetStatus?: string;
}

export const budgetDataTransformer = (data: BudgetProps) => {
  const budgetData: BudgetProps = {};
  Object.keys(data).forEach(key => {
    switch (key) {
      case 'budgetStatus':
        budgetData[key] = 'CLOSED';
        break;
      default:
        budgetData[key] = data[key];
    }
  });
  return budgetData;
};

interface ForecastProps {
  name?: string;
  month?: string;
  year?: string;
  dueDate?: Date | string;
  forecastStatus?: string;
}
export const forecastDataTransformer = (data: ForecastProps) => {
  const forecastData: ForecastProps = {};
  Object.keys(data).forEach(key => {
    switch (key) {
      case 'forecastStatus':
        forecastData[key] = 'CLOSED';
        break;
      default:
        forecastData[key] = data[key];
    }
  });
  return forecastData;
};
