import useSettings from './view/materialUI/hooks/useSettings';
import { createCustomTheme } from './view/materialUI/theme';
import { CssBaseline, ThemeProvider } from '@material-ui/core';
import routes from './routes';
import { useRoutes } from 'react-router-dom';
import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import authSelector from './modules/shared/authentication/authSelector';
import authActions from './modules/shared/authentication/authActions';
import SettingsDrawer from './view/materialUI/components/SettingsDrawer';
import RTL from './view/materialUI/components/RTL';
import statusActions from './modules/shared/statuses/statusesActions';

const Theme = () => {
  const dispatch = useDispatch();
  const authData = useSelector(authSelector.authData);
  const content = useRoutes(routes(authData.isLoggedIn, authData.role));
  const { settings } = useSettings();

  const theme = createCustomTheme({
    direction: 'ltr',
    responsiveFontSizes: true,
    roundedCorners: false,
    theme: 'LIGHT',
  });

  const idToken = localStorage.getItem('idToken');
  useEffect(() => {
    if (idToken) {
      dispatch(authActions.confirmLogin());
    }
    localStorage.setItem(
      'settings',
      JSON.stringify({
        compact: true,
        direction: 'ltr',
        responsiveFontSizes: true,
        roundedCorners: false,
        theme: 'LIGHT',
      }),
    );
  }, [idToken]);

  return (
    <ThemeProvider theme={theme}>
      <RTL direction={settings.direction}>
        <CssBaseline />
        {/* <SettingsDrawer /> */}
        {content}
      </RTL>
    </ThemeProvider>
  );
};

export default Theme;
