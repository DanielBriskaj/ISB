import { Suspense, lazy } from 'react';
import Route from './models/routes/Route';
import LoadingScreen from './view/materialUI/components/LoadingScreen';
import DashboardLayout from './view/dashboard/DashboardLayout';
import { ROLES } from './modules/shared/authentication/authReducer';

const Loadable = Component => props =>
  (
    <Suspense fallback={<LoadingScreen />}>
      <Component {...props} />
    </Suspense>
  );

const AuthorizationRequired = Loadable(
  lazy(() => import('./view/materialUI/pages/AuthorizationRequired')),
);
const NotFound = Loadable(
  lazy(() => import('./view/materialUI/pages/NotFound')),
);
const ServerError = Loadable(
  lazy(() => import('./view/materialUI/pages/ServerError')),
);

const SupplierTable = Loadable(
  lazy(() => import('./view/dashboard/suppliers/SupplierTable')),
);

const AuditTable = Loadable(
  lazy(() => import('./view/dashboard/history/audit/AuditTable')),
);

const BranchesTable = Loadable(
  lazy(() => import('./view/dashboard/menuConfig/branches/BranchTable')),
);

const CostOwnerTable = Loadable(
  lazy(() => import('./view/dashboard/menuConfig/costOwners/CostOwnerTable')),
);

const ContractTable = Loadable(
  lazy(() => import('./view/dashboard/contracts/ContractTable')),
);

const Welcome = Loadable(lazy(() => import('./view/dashboard/Welcome')));

const CostOwnerInvoiceDetails = Loadable(
  lazy(
    () =>
      import(
        './view/dashboard/c-o-authorizerInvoices/COAuthorizerInvoiceDetails'
      ),
  ),
);

const CostOwnerContractTable = Loadable(
  lazy(
    () => import('./view/dashboard/costOwnerContracts/CostOwnerContractTable'),
  ),
);

const PoTable = Loadable(lazy(() => import('./view/dashboard/po/PoTable')));
const PrTable = Loadable(lazy(() => import('./view/dashboard/pr/PrTable')));
const CostOwnerInvoiceTable = Loadable(
  lazy(
    () => import('./view/dashboard/costOwnerInvoices/CostOwnerInvoiceTable'),
  ),
);
const InvoiceTable = Loadable(
  lazy(() => import('./view/dashboard/invoices/InvoiceTable')),
);
const COAuthorizerInvoiceTable = Loadable(
  lazy(
    () =>
      import(
        './view/dashboard/c-o-authorizerInvoices/COAuthorizerInvoiceTable'
      ),
  ),
);
const GlTable = Loadable(
  lazy(() => import('./view/dashboard/menuConfig/gl/GlTable')),
);
const UserTable = Loadable(
  lazy(() => import('./view/dashboard/menuConfig/users/userTable')),
);

const Login = Loadable(
  lazy(() => import('./view/materialUI/pages/authentication/Login')),
);

const UserProfile = Loadable(
  lazy(() => import('./view/dashboard/account/UserProfile')),
);

const BudgetTable = Loadable(
  lazy(() => import('./view/dashboard/budget/budgetTable')),
);
const ForecastTable = Loadable(
  lazy(() => import('./view/dashboard/forecast/forecastTable')),
);
const ReportsTable = Loadable(
  lazy(() => import('./view/dashboard/reports//reportsTable')),
);

const TBOInvoiceTable = Loadable(
  lazy(() => import('./view/dashboard/tboInvoices/TBOInvoiceTable')),
);

const routes = (isLoggedIn, role) => [
  {
    path: '/',
    element: isLoggedIn ? <Welcome path="/" /> : <Login />,
  },
  {
    path: '500',
    element: <ServerError />,
  },
  {
    path: '401',
    element: <AuthorizationRequired />,
  },
  {
    path: '404',
    element: <NotFound />,
  },
  {
    path: 'login',
    element: <Login />,
  },
  {
    path: 'dashboard',
    element: isLoggedIn ? <DashboardLayout /> : <Login />,
    children: [
      {
        path: '/dashboard',
        element:
          role === 'COST_OWNER_AUTHORIZER' ||
          role === 'ACCOUNTING_INPUT' ||
          role === 'ACCOUNTING_AUTHORIZER' ||
          role === 'COST_OWNER' ||
          role === 'PROCUREMENT_INPUT' ||
          role === 'PROCUREMENT_AUTHORIZER' ||
          role === 'PLANNING_CONTROL_AUTHORIZER' ||
          role === 'PLANNING_CONTROL_INPUT' ||
          role === 'TBO_INPUT' ||
          role === 'TBO_AUTHORIZER' ? (
            <Welcome />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/suppliers',
        element:
          role === 'ACCOUNTING_INPUT' ||
          role === 'ACCOUNTING_AUTHORIZER' ||
          role === 'PROCUREMENT_INPUT' ||
          role === 'PROCUREMENT_AUTHORIZER' ? (
            <SupplierTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/cost-owner/contracts',
        element:
          role === 'COST_OWNER' ? (
            <CostOwnerContractTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/cost-owner/invoices',
        element:
          role === 'COST_OWNER' ? (
            <CostOwnerInvoiceTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/c-o-authorizer/invoices',
        element:
          role === 'COST_OWNER_AUTHORIZER' ? (
            <COAuthorizerInvoiceTable />
          ) : (
            <Login />
          ),
      },
      {
        path: '/dashboard/c-o-authorizer/invoices/:id',
        element:
          role === 'COST_OWNER_AUTHORIZER' ? (
            <CostOwnerInvoiceDetails />
          ) : (
            <Login />
          ),
      },
      {
        path: '/dashboard/cost-owner/po',
        element:
          role === 'COST_OWNER' ? <PoTable /> : <AuthorizationRequired />,
      },
      {
        path: '/dashboard/po',
        element:
          role === 'PROCUREMENT_INPUT' ||
          role === 'PROCUREMENT_AUTHORIZER' ||
          role === 'COST_OWNER_AUTHORIZER' ? (
            <PoTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/pr',
        element:
          role === 'COST_OWNER' ||
          role === 'COST_OWNER_AUTHORIZER' ||
          role === 'PROCUREMENT_INPUT' ||
          role === 'PROCUREMENT_AUTHORIZER' ? (
            <PrTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/menuconfig',
        children: [
          {
            path: '/dashboard/menuconfig/branches',
            element:
              role === 'ACCOUNTING_INPUT' ||
              role === 'ACCOUNTING_AUTHORIZER' ? (
                <BranchesTable />
              ) : (
                <AuthorizationRequired />
              ),
          },
          {
            path: '/dashboard/menuconfig/costowners',
            element:
              role === 'ACCOUNTING_INPUT' ||
              role === 'ACCOUNTING_AUTHORIZER' ? (
                <CostOwnerTable />
              ) : (
                <AuthorizationRequired />
              ),
          },
          {
            path: '/dashboard/menuconfig/gl',
            element:
              role === 'ACCOUNTING_INPUT' ||
              role === 'ACCOUNTING_AUTHORIZER' ? (
                <GlTable />
              ) : (
                <AuthorizationRequired />
              ),
          },
          {
            path: '/dashboard/menuconfig/users',
            element:
              role === 'ACCOUNTING_INPUT' ||
              role === 'ACCOUNTING_AUTHORIZER' ? (
                <UserTable />
              ) : (
                <AuthorizationRequired />
              ),
          },
        ],
      },
      {
        path: '/dashboard/contracts',
        element:
          role === 'ACCOUNTING_INPUT' ||
          role === 'ACCOUNTING_AUTHORIZER' ||
          role === 'PROCUREMENT_INPUT' ||
          role === 'PROCUREMENT_AUTHORIZER' ||
          role === 'COST_OWNER_AUTHORIZER' ? (
            <ContractTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/invoices',
        element:
          role === 'ACCOUNTING_INPUT' || role === 'ACCOUNTING_AUTHORIZER' ? (
            <InvoiceTable role={role} />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/social/profile',
        element:
          role === 'COST_OWNER_AUTHORIZER' ||
          role === 'ACCOUNTING_INPUT' ||
          role === 'ACCOUNTING_AUTHORIZER' ||
          role === 'COST_OWNER' ||
          role === 'PROCUREMENT_INPUT' ||
          role === 'PROCUREMENT_AUTHORIZER' ||
          role === 'PLANNING_CONTROL_AUTHORIZER' ||
          role === 'PLANNING_CONTROL_INPUT' ||
          role === 'TBO_INPUT' ||
          role === 'TBO_AUTHORIZER' ? (
            <UserProfile />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/history',
        children: [
          {
            path: '/dashboard/history/audit',
            element:
              role === 'ACCOUNTING_INPUT' ? (
                <AuditTable />
              ) : (
                <AuthorizationRequired />
              ),
          },
        ],
      },
      {
        path: '/dashboard/budget',
        element:
          role === 'PLANNING_CONTROL_INPUT' ||
          role === 'PLANNING_CONTROL_AUTHORIZER' ||
          role === 'COST_OWNER' ||
          role === 'COST_OWNER_AUTHORIZER' ? (
            <BudgetTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/forecast',
        element:
          role === 'PLANNING_CONTROL_INPUT' ||
          role === 'PLANNING_CONTROL_AUTHORIZER' ||
          role === 'COST_OWNER' ||
          role === 'COST_OWNER_AUTHORIZER' ? (
            <ForecastTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/reports',
        element:
          role === 'ACCOUNTING_INPUT' ? (
            <ReportsTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
      {
        path: '/dashboard/tbo-invoices',
        element:
          role === ROLES.TBO_AUTHORIZER || role === ROLES.TBO_INPUT ? (
            <TBOInvoiceTable />
          ) : (
            <AuthorizationRequired />
          ),
      },
    ],
  },
];

export default routes;
