import './App.css';
import { configureStore } from './modules/store';
import { Provider } from 'react-redux';
import Theme from './Theme';

function App() {
  const store = configureStore();
  return (
    <Provider store={store}>
      <Theme />
    </Provider>
  );
}

export default App;
