export const status = {
  NEW: 'PROCUREMENT_INPUT',
  IN_APPROVAL: 'PROCUREMENT_AUTHORIZER',
  APPROVED: '',
};

export const menuConfigStatus = {
  NEW: 'ACCOUNTING_INPUT',
  IN_APPROVAL: 'ACCOUNTING_AUTHORIZER',
  APPROVED: '',
};

export const poStatus = {
  NEW: 'COST_OWNER',
  COA: 'COST_OWNER_AUTHORIZER',
  PRI: 'PROCUREMENT_INPUT',
  PRA: 'PROCUREMENT_AUTHORIZER',
  ASSIGNED: '',
};

export enum BudgetStatus {
  NEW = 'NEW',
  CLOSED = 'CLOSED',
}

export enum ForecastStatus {
  NEW = 'NEW',
  CLOSED = 'CLOSED',
}

export enum ItemStatus {
  CREATED = 'CREATED',
  IN_APPROVAL_BY_COA = 'IN_APPROVAL_BY_COA',
  IN_APPROVAL_BY_PCI = 'IN_APPROVAL_BY_PCI',
  IN_APPROVAL_BY_PCA = 'IN_APPROVAL_BY_PCA',
  APPROVED = 'APPROVED',
}
