export const reportOptions = [
  { value: 'IBS', label: 'Invoices By Supplier' },
  { value: 'IBC', label: 'Invoices By Contracts' },
  { value: 'TEAC', label: 'Total Expenses For Active Contracts' },
];
