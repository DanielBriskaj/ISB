export const approved = [
  { label: 'NEW', value: 'NEW' },
  { label: 'IN APPROVAL', value: 'IN_APPROVAL' },
  { label: 'APPROVED', value: 'APPROVED' },
];
