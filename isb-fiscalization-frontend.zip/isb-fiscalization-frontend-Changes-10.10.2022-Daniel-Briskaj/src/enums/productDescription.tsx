export const productDescription = [
  {
    label: 'ADVERTISING',
    options: [
      {
        label:
          'Advertising material, promotions, catalogues, brochures, mailing services',
        value: 'ADV01',
      },
      { label: 'Managing events and exhibitions', value: 'ADV02' },
      { label: 'Promotional Gadgets', value: 'ADV03' },
    ],
  },
  {
    label: 'COMMERCIAL INFORMATION/FILE SEARCHES',
    options: [
      {
        label:
          'Information (Payment defaults, protests, SIC, land registry searches, chamber of commerce register searches, etc ...)',
        value: 'COM01',
      },
      { label: 'Market Analysis', value: 'COM02' },
    ],
  },
  {
    label: 'CONSULTING AND PROFESSIONAL SERVICES',
    options: [
      {
        label: 'Administrative / tax consulting services',
        value: 'CON01',
      },
      { label: 'Banking consulting services', value: 'CON02' },
      { label: 'Financial consulting services', value: 'CON03' },
      { label: 'Legal / notary consulting services', value: 'CON04' },
      { label: 'Other consulting services', value: 'CON05' },
      { label: 'Marketing /HR /Advertising services', value: 'CON06' },
      { label: 'Organizational / Executive', value: 'CON07' },
      { label: 'Real Estate consulting services', value: 'CON08' },
      { label: 'Real estate surveys / brokerage', value: 'CON09' },
      {
        label: 'Work Supervision / tests / security / design',
        value: 'CON010',
      },
    ],
  },
  {
    label: 'ENTITIES',
    options: [
      { label: 'Entities, associations, charities, etc ...', value: 'ENT01' },
    ],
  },
  {
    label: 'INFORMATION & COMMUNICATION TECHNOLOGY',
    options: [
      {
        label: 'Application systems',
        value: 'ICT01',
      },
      { label: 'Infoproviders', value: 'ICT02' },
      { label: 'Technological infrastructure', value: 'ICT03' },
    ],
  },
  {
    label: 'INSURANCE',
    options: [
      {
        label:
          'Business Insurance (fire buildings and contents, all risks artwork, BBB, Third Party Liability, D & O, ETC...)',
        value: 'INS01',
      },
      { label: 'Customer Marketing Insurance', value: 'INS02' },
      {
        label:
          'Managers and personnel insurance (accidents, illness, life, permanent disability due to illness, CDW vehicles, etc...)',
        value: 'INS03',
      },
    ],
  },
  {
    label: 'OFFICE EQUIPMENT',
    options: [
      {
        label: 'Bill counters, coin counters, sorters, etc..',
        value: 'OEQ01',
      },
      {
        label:
          'Office equipment and accessories excluding hardware (paper shredders, cutters, binders, calculators, ...)',
        value: 'OEQ02',
      },
      {
        label:
          'Office supplies and consumables (printed material, stationery, HW consumables, toner, forms, envelopes, paper and cardboard)',
        value: 'OEQ03',
      },
      { label: 'Photocopierse', value: 'OEQ04' },
    ],
  },
  {
    label: 'PERSONNEL/EMPLOYMENT',
    options: [
      { label: 'Catering', value: 'PER01' },
      { label: 'Clothing and accessories', value: 'PER02' },
      { label: 'Health care, medical equipment and supplies', value: 'PER03' },
      { label: 'Personnel selection', value: 'PER04' },
      { label: 'Publishing', value: 'PER05' },
      { label: 'Temporary work', value: 'PER06' },
      { label: 'Training', value: 'PER07' },
      { label: 'Travel / reservations', value: 'PER08' },
      { label: 'Vehicles and transport', value: 'PER09' },
    ],
  },
  {
    label: 'PHYSICAL SECURITY',
    options: [
      { label: 'Safety equipment supply', value: 'SEC01' },
      { label: '"Security / custody', value: 'SEC02' },
      { label: 'Transport of valuables and cash counting', value: 'SEC03' },
    ],
  },
  {
    label: 'PROVISION OF SERVICES',
    options: [
      { label: 'Electronic cards and other securities', value: 'PRO01' },
      { label: 'Language / translation services', value: 'PRO02' },
    ],
  },
  {
    label: 'LOGISTICS',
    options: [
      { label: 'Document Storage Management', value: 'LOG01' },
      { label: 'Express Courier Service', value: 'LOG02' },
      { label: 'External Postal services', value: 'LOG03' },
      { label: 'Internal Postal services', value: 'LOG04' },
      { label: 'Printing and mailing', value: 'LOG05' },
      { label: 'Warehouse management', value: 'LOG06' },
    ],
  },
  {
    label: 'MISCELLANEOUS SERVICES',
    options: [
      {
        label: 'Call centre, Customer Relationship Management',
        value: 'MSC01',
      },
      { label: 'Data entry', value: 'MSC02' },
      { label: 'Photocopying / printing services', value: 'MSC03' },
      { label: 'Reception / concierge', value: 'MSC04' },
      { label: 'Relocations and porterage', value: 'MSC05' },
    ],
  },
  {
    label: 'REAL ESTATE',
    options: [
      { label: 'Building and ancillary works', value: 'REA01' },
      { label: 'Furniture / furnishings and accessories', value: 'REA02' },
      {
        label: 'Management and cleaning of green areas/ environmental services',
        value: 'REA03',
      },
      { label: 'Oils and fuels', value: 'REA04' },
      { label: 'Systems and facilities', value: 'REA05' },
      { label: 'Utilities', value: 'REA06' },
    ],
  },
];
