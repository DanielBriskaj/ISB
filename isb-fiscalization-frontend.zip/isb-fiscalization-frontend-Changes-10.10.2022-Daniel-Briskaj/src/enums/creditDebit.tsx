export const creditOptions = [
  { value: 'CREDIT', label: 'Credit' },
  { value: 'DEBIT', label: 'Debit' },
  { value: 'CREDIT_MINUS', label: 'Credit With Minus' },
  { value: 'DEBIT_MINUS', label: 'Debit With Minus' },
];
