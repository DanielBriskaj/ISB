export const poStatus = [
  { value: 'NEW', label: 'NEW' },
  { value: 'COA', label: 'COA' },
  { value: 'PRI', label: 'PRI' },
  { value: 'PRA', label: 'PRA' },
  { value: 'APPROVED', label: 'APPROVED' },
];
