export const commodityCategory = [
  { value: '_0A_01_01', label: '0A.01.01 - Water', subcategory: [] },
  { value: '_0A_01_02', label: '0A.01.02 - Electricity', subcategory: [] },
  { value: '_0A_02_01', label: '0A.02.01 - Gas', subcategory: [] },
  { value: '_0A_02_02', label: '0A.02.02 - Diesel fuel', subcategory: [] },
  {
    value: '_0A_03_01',
    label: '0A.03.01 - Cleaning contracts',
    subcategory: [],
  },
  {
    value: '_0A_03_02',
    label: '0A.03.02 - On call cleaning not covered by contracts',
    subcategory: [],
  },
  {
    value: '_0A_03_03',
    label: '0A.03.03 - On call disposal of industrial waste',
    subcategory: [],
  },
  {
    value: '_0A_03_04',
    label: '0A.03.04 - On call maintenance of green areas',
    subcategory: [],
  },
  {
    value: '_0A_03_05',
    label: '0A.03.05 - Contractual maintenance of green areas',
    subcategory: [],
  },

  {
    value: '_0A_04_01',
    label: '0A.04.01 - Lifting facilities',
    subcategory: [
      {
        value: '_0A_04_01_01',
        label:
          '0A.04.01.01 - Supply and construction of lifting facilities - owned properties',
      },
      {
        value: '_0A_04_01_02',
        label:
          '0A.04.01.02 - Supply and construction of lifting facilities - leased properties',
      },
      {
        value: '_0A_04_01_03',
        label:
          '0A.04.01.03 - Maintenance of lifting facilities - Contracts - owned properties',
      },
      {
        value: '_0A_04_01_04',
        label:
          '0A.04.01.04 - Maintenance of lifting facilities - Contracts - leased properties',
      },
      {
        value: '_0A_04_01_05',
        label:
          '0A.04.01.05 - On call - maintenance of lifting facilities - owned properties',
      },
      {
        value: '_0A_04_01_06',
        label:
          '0A.04.01.06 - On call - maintenance of lifting facilities - leased properties',
      },
    ],
  },

  {
    value: '_0A_04_02',
    label: '0A.04.02 - Electrical systems',
    subcategory: [
      {
        value: '_0A_04_02_01',
        label: '0A.04.02.01 - Electrical systems -owned properties',
      },
      {
        value: '_0A_04_02_02',
        label: '0A.04.02.02 - Electrical systems -leased properties',
      },
    ],
  },

  {
    value: '_0A_04_03',
    label: '0A.04.03 - Heating and cooling systems',
    subcategory: [
      {
        value: '_0A_04_03_01',
        label: '0A.04.03.01 - Heating and cooling systems -owned properties',
      },
      {
        value: '_0A_04_03_02',
        label: '0A.04.03.02 - Heating and cooling systems -leased properties',
      },
    ],
  },

  {
    value: '_0A_04_04',
    label: '0A.04.04 - UPS/Power Generators',
    subcategory: [
      {
        value: '_0A_04_04_01',
        label: '0A.04.04.01 - UPS / Power Generators - owned properties',
      },
      {
        value: '_0A_04_04_02',
        label: '0A.04.04.02 - UPS / Power Generators - leased properties',
      },
    ],
  },

  {
    value: '_0A_04_05',
    label: '0A.04.05 - Sanitary systems',
    subcategory: [
      {
        value: '_0A_04_05_01',
        label: '0A.04.05.01 - Sanitary systems -owned properties',
      },
      {
        value: '_0A_04_05_02',
        label: '0A.04.05.02 - Sanitary systems -leased properties',
      },
    ],
  },

  {
    value: '_0A_04_06',
    label: '0A.04.06 - System integrated maintenance',
    subcategory: [
      {
        value: '_0A_04_06_01',
        label:
          '0A.04.06.01 - Integrated maintenance of electrical and heating and cooling systems -owned properties',
      },
      {
        value: '_0A_04_06_02',
        label:
          '0A.04.06.02 - Integrated maintenance of electrical and heating and cooling systems -leased properties',
      },
      {
        value: '_0A_04_06_03',
        label: '0A.04.06.03 - On call systems maintenance - owned properties',
      },
      {
        value: '_0A_04_06_04',
        label: '0A.04.06.04 - On call systems maintenance - leased properties',
      },
    ],
  },

  {
    value: '_0A_04_07',
    label: '0A.04.07 - Operation of heating systems',
    subcategory: [],
  },
  {
    value: '_0A_05_01',
    label: '0A.05.01 - Furniture and furnishings',
    subcategory: [],
  },
  {
    value: '_0A_05_02',
    label: '0A.05.02 - Furniture and furnishings maintenance - contracts',
    subcategory: [],
  },
  {
    value: '_0A_05_03',
    label: '0A.05.03 - On call furniture and furnishings maintenance',
    subcategory: [],
  },

  {
    value: '_0A_06_01',
    label: '0A.06.01 - Masonry and carpentry works false ceilings etc..',
    subcategory: [
      {
        value: '_0A_06_01_01',
        label:
          '0A.06.01.01 - Constructions works/systems extraordinary maintenance leased properties',
      },
      {
        value: '_0A_06_01_02',
        label:
          '0A.06.01.02 - Extraordinary maintenance - owned business properties',
      },
      {
        value: '_0A_06_01_03',
        label:
          '0A.06.01.03 - Extraordinary maintenance - leased business properties',
      },
    ],
  },

  {
    value: '_0A_06_02',
    label: '0A.06.02 - Major building works / General contractor',
    subcategory: [
      {
        value: '_0A_06_02_01',
        label:
          '0A.06.02.01 - Construction of business property for use by the bank',
      },
    ],
  },

  {
    value: '_0A_06_03',
    label: '0A.06.03 - Building maintenance',
    subcategory: [
      { value: '_0A_06_03_01', label: '0A.06.03.01 - Real estate management' },
      {
        value: '_0A_06_03_02',
        label: '0A.06.03.02 - Ordinary maintenance owned properties',
      },
      {
        value: '_0A_06_03_03',
        label: '0A.06.03.03 - Ordinary maintenance leased properties',
      },
      {
        value: '_0A_06_03_04',
        label: '0A.06.03.04 - Maintenance for property restoration',
      },
      {
        value: '_0A_06_03_05',
        label: '0A.06.03.05 - Maintenance for equipment installation',
      },
    ],
  },

  {
    value: '_0A_07_01',
    label: '0A.07.01 - Rental expense on real estate',
    subcategory: [
      {
        value: '_0A_07_01_01',
        label: '0A.07.01.01 - Rental expense on business properties in Italy',
      },
      {
        value: '_0A_07_01_02',
        label: '0A.07.01.02 - Rental expense on business properties abroad',
      },
      {
        value: '_0A_07_01_03',
        label:
          '0A.07.01.03 - Rental expense on non operating properties/company accommodations',
      },
    ],
  },

  {
    value: '_0A_07_02',
    label: '0A.07.02 - Common charges',
    subcategory: [
      {
        value: '_0A_07_02_01',
        label: '0A.07.02.01 - Common charges business properties',
      },
      {
        value: '_0A_07_02_02',
        label:
          '0A.07.02.02 - Common charges non operating properties/company accommodations',
      },
    ],
  },

  {
    value: '_0A_08_01',
    label: '0A.08.01 - Management expenses of real estate leased to clients',
    subcategory: [],
  },

  {
    value: '_0B_01_01',
    label: '0B.01.01 - HW - Mainframe',
    subcategory: [
      { value: '_0B_01_01_01', label: '0B.01.01.01 - Mainframe server' },
      {
        value: '_0B_01_01_98',
        label: '0B.01.01.98 - Mainframe HW maintenance',
      },
      {
        value: '_0B_01_01_99',
        label: '0B.01.01.99 - Other mainframe components',
      },
    ],
  },

  {
    value: '_0B_01_02',
    label: '0B.01.02 - HW - Open',
    subcategory: [
      { value: '_0B_01_02_01', label: '0B.01.02.01 - Unix Server' },
      { value: '_0B_01_02_02', label: '0B.01.02.02 - X86 Server' },
      { value: '_0B_01_02_03', label: '0B.01.02.03 - Converged Systems' },
      { value: '_0B_01_02_98', label: '0B.01.02.98 - Open HW maintenance' },
      { value: '_0B_01_02_99', label: '0B.01.02.99 - Other Open components' },
    ],
  },

  {
    value: '_0B_01_03',
    label: '0B.01.03 - Storage',
    subcategory: [
      { value: '_0B_01_03_01', label: '0B.01.03.01 - Disks' },
      { value: '_0B_01_03_98', label: '0B.01.03.98 - Other storage' },
      { value: '_0B_01_03_99', label: '0B.01.03.99 - Routers and Switch ' },
    ],
  },

  {
    value: '_0B_01_04',
    label: '0B.01.04 - HW - Networking',
    subcategory: [
      { value: '_0B_01_04_01', label: '0B.01.04.01 - Routers and Switch ' },
      { value: '_0B_01_04_02', label: '0B.01.04.02 - Balancers' },
      { value: '_0B_01_04_03', label: '0B.01.04.03 - Firewalls' },
      { value: '_0B_01_04_04', label: '0B.01.04.04 - Telephones' },
      { value: '_0B_01_04_05', label: '0B.01.04.05 - Videoconferencing' },
      {
        value: '_0B_01_04_98',
        label: '0B.01.04.98 - Networking HW maintenance',
      },
      {
        value: '_0B_01_04_99',
        label:
          '0B.01.04.99 - Telephone exchanges and other communication equipment',
      },
    ],
  },

  {
    value: '_0B_01_05',
    label: '0B.01.05 - HW - Peripherals',
    subcategory: [
      { value: '_0B_01_05_01', label: '0B.01.05.01 - Pc Desktop' },
      { value: '_0B_01_05_02', label: '0B.01.05.02 - Notebook PCs' },
      { value: '_0B_01_05_03', label: '0B.01.05.03 - Monitors' },
      { value: '_0B_01_05_04', label: '0B.01.05.04 - Scanners' },
      { value: '_0B_01_05_05', label: '0B.01.05.05 - Presence detectors' },
      { value: '_0B_01_05_06', label: '0B.01.05.06 - Tablets' },
      { value: '_0B_01_05_07', label: '0B.01.05.07 - Printers ' },
      {
        value: '_0B_01_05_08',
        label: '0B.01.05.08 - MFP (Multifunction Printers)',
      },
      {
        value: '_0B_01_05_98',
        label: '0B.01.05.98 - Peripheral HW maintenance',
      },
      { value: '_0B_01_05_99', label: '0B.01.05.99 - Other HW End user' },
    ],
  },

  {
    value: '_0B_01_06',
    label: '0B.01.06 - HW - Money handling',
    subcategory: [
      { value: '_0B_01_06_01', label: '0B.01.06.01 - ATM' },
      { value: '_0B_01_06_02', label: '0B.01.06.02 - ATM maintenance' },
      { value: '_0B_01_06_03', label: '0B.01.06.03 - Cash in – Cash out ATM' },
      {
        value: '_0B_01_06_04',
        label: '0B.01.06.04 - Cash in – Cash out ATM maintenance',
      },
      { value: '_0B_01_06_05', label: '0B.01.06.05 - Self payment systems' },
      { value: '_0B_01_06_06', label: '0B.01.06.06 - Roller cash' },
      {
        value: '_0B_01_06_07',
        label: '0B.01.06.07 - CICO (Cash in - Cash out )',
      },
      {
        value: '_0B_01_06_08',
        label: '0B.01.06.08 - Roller cash and CICO maintenance',
      },
      {
        value: '_0B_01_06_98',
        label: '0B.01.06.98 - Money handling HW maintenance',
      },
      {
        value: '_0B_01_06_99',
        label: '0B.01.06.99 - Other money handling equipment',
      },
    ],
  },

  {
    value: '_0B_01_07',
    label: '0B.01.07 - Banking HW',
    subcategory: [
      { value: '_0B_01_07_01', label: '0B.01.07.01 - Teller printers' },
      { value: '_0B_01_07_02', label: '0B.01.07.02 - Bank scanners' },
      { value: '_0B_01_07_03', label: '0B.01.07.03 - Check readers' },
      {
        value: '_0B_01_07_04',
        label: '0B.01.07.04 - Tablets (Signature / specialised)',
      },
      {
        value: '_0B_01_07_05',
        label:
          '0B.01.07.05 - OTP (One Time Password devices) and other authentication devices and cards',
      },
      {
        value: '_0B_01_07_06',
        label:
          '0B.01.07.06 - Smart Cards and CAP (Chip Authentication Program) Readers',
      },
      { value: '_0B_01_07_98', label: '0B.01.07.98 - Banking HW maintenance' },
      { value: '_0B_01_07_99', label: '0B.01.07.99 - Other banking HW ' },
    ],
  },

  {
    value: '_0B_01_08',
    label: '0B.01.08 - HW - Clients',
    subcategory: [
      {
        value: '_0B_01_08_01',
        label: '0B.01.08.01 - HW for the support of insurance policies',
      },
    ],
  },

  {
    value: '_0B_02_01',
    label: '0B.02.01 - Basic software licenses',
    subcategory: [
      {
        value: '_0B_02_01_01',
        label: '0B.02.01.01 - Infrastructure SW licences',
      },
      {
        value: '_0B_02_01_02',
        label: '0B.02.01.02 - Stand alone SW licenses',
      },
      {
        value: '_0B_02_01_03',
        label: '0B.02.01.03 - Auxiliary system SW licenses',
      },
      { value: '_0B_02_01_04', label: '0B.02.01.04 - TLC SW licences ' },
    ],
  },

  {
    value: '_0B_02_02',
    label: '0B.02.02 - Application software licenses',
    subcategory: [
      { value: '_0B_02_02_01', label: '0B.02.02.01 - Channels area licenses' },
      { value: '_0B_02_02_02', label: '0B.02.02.02 - Credit area licenses' },
      {
        value: '_0B_02_02_03',
        label: '0B.02.02.03 - Reporting Accounting Calculation area licenses',
      },
      {
        value: '_0B_02_02_04',
        label: '0B.02.02.04 - Risk management area licenses',
      },
      {
        value: '_0B_02_02_05',
        label: '0B.02.02.05 - Regulatory Reporting area licenses',
      },
      {
        value: '_0B_02_02_06',
        label: '0B.02.02.06 - Finance area systems licenses',
      },
      { value: '_0B_02_02_07', label: '0B.02.02.07 - Staff systems licenses' },
      {
        value: '_0B_02_02_08',
        label: '0B.02.02.08 - Payment systems licenses',
      },
      {
        value: '_0B_02_02_09',
        label: '0B.02.02.08 - Management information systems licenses',
      },
      {
        value: '_0B_02_02_10',
        label: '0B.02.02.10 - Securities and asset management area licenses',
      },
      { value: '_0B_02_02_11', label: '0B.02.02.11 - Security area licenses' },
      {
        value: '_0B_02_02_99',
        label: '0B.02.02.99 - Other application areas licenses',
      },
    ],
  },

  {
    value: '_0B_03_01',
    label: '0B.03.01 - Telecommunication Services - fixed lines',
    subcategory: [
      {
        value: '_0B_03_01_01',
        label: '0B.03.01.01 - Traditional voice services - fixed lines',
      },
      {
        value: '_0B_03_01_02',
        label: '0B.03.01.02 - Traditional voice services - Toll-Free Numbers',
      },
    ],
  },

  {
    value: '_0B_03_02',
    label: '0B.03.02 - Telecommunication Services - mobile telephony',
    subcategory: [
      {
        value: '_0B_03_02_01',
        label:
          '0B.03.02.01 - Mobile voice services - Periodic fees and Government Tax',
      },
      {
        value: '_0B_03_02_02',
        label: '0B.03.02.02 - Mobile voice services - Traffic',
      },
    ],
  },

  {
    value: '_0B_03_03',
    label: '0B.03.03 - Data Transmission',
    subcategory: [
      { value: '_0B_03_03_01', label: '0B.03.03.01 - VOIP' },
      {
        value: '_0B_03_03_02',
        label: '0B.03.03.02 - Data Transmission lines',
      },
    ],
  },

  {
    value: '_0B_03_04',
    label: '0B.03.04 - Other TLC services',
    subcategory: [],
  },

  {
    value: '_0B_04_01',
    label: '0B.04.01 - SW development and maintenance services',
    subcategory: [
      {
        value: '_0B_04_01_01',
        label: '0B.04.01.01 - System support SW services ',
      },
      { value: '_0B_04_01_02', label: '0B.04.01.02 - Channels area SW ' },
      { value: '_0B_04_01_03', label: '0B.04.01.03 - Credit area SW ' },
      {
        value: '_0B_04_01_04',
        label: '0B.04.01.04 - Reporting Accounting Calculation area SW ',
      },
      {
        value: '_0B_04_01_05',
        label: '0B.04.01.05 - Risk management area SW ',
      },
      {
        value: '_0B_04_01_06',
        label: '0B.04.01.06 - Regulatory Reporting area SW',
      },
      { value: '_0B_04_01_07', label: '0B.04.01.07 - Finance area system SW' },
      { value: '_0B_04_01_08', label: '0B.04.01.08 - Staff system SW' },
      { value: '_0B_04_01_09', label: '0B.04.01.09 - Payment system SW' },
      {
        value: '_0B_04_01_10',
        label: '0B.04.01.10 - Management information systems SW',
      },
      {
        value: '_0B_04_01_11',
        label: '0B.04.01.11 - Securities and asset management area SW',
      },
      { value: '_0B_04_01_12', label: '0B.04.01.12 - Security area SW' },
      { value: '_0B_04_01_13', label: '0B.04.01.13 - Architecture area SW' },
      {
        value: '_0B_04_01_14',
        label: '0B.04.01.14 - TLC Support Services SW',
      },
      {
        value: '_0B_04_01_99',
        label: '0B.04.01.99 - Other application services SW',
      },
    ],
  },

  {
    value: '_0B_04_02',
    label: '0B.04.02 - Support Services',
    subcategory: [
      { value: '_0B_04_02_01', label: '0B.04.02.01 - Help Desk' },
      { value: '_0B_04_02_02', label: '0B.04.02.02 - Operating Management' },
      {
        value: '_0B_04_02_03',
        label: '0B.04.02.03 - Operating Management support',
      },
      { value: '_0B_04_02_04', label: '0B.04.02.04 - Desktop Management' },
      { value: '_0B_04_02_05', label: '0B.04.02.05 - Structured wiring' },
      {
        value: '_0B_04_02_06',
        label: '0B.04.02.06 - Support Services for distributed technologies',
      },
      {
        value: '_0B_04_02_07',
        label: '0B.04.02.07 - SOC - Security Operation Centre',
      },
      {
        value: '_0B_04_02_08',
        label: '0B.04.02.08 - Other system support services',
      },
      {
        value: '_0B_04_02_09',
        label: '0B.04.02.09 - Electronic invoicing services',
      },
    ],
  },

  { value: '_0B_05_01', label: '0B.05.01 - News agencies', subcategory: [] },

  {
    value: '_0B_05_02',
    label: '0B.05.02 - Financial disclosure',
    subcategory: [
      { value: '_0B_05_02_01', label: '0B.05.02.01 - Workstations' },
      { value: '_0B_05_02_02', label: '0B.05.02.02 - Information flows' },
    ],
  },

  { value: '_0B_05_03', label: '0B.05.03 - Stock Exchanges', subcategory: [] },
  { value: '_0B_05_04', label: '0B.05.04 - Rating Agencies', subcategory: [] },

  {
    value: '_0B_05_05',
    label: '0B.05.05 - Other reporting and analysis services',
    subcategory: [
      {
        value: '_0B_05_05_01',
        label: '0B.05.05.01 - Foreign Stock Exchanges Telematic services',
      },
      { value: '_0B_05_05_02', label: '0B.05.05.02 - Other databases' },
      {
        value: '_0B_05_05_03',
        label: '0B.05.05.03 - External databases (guritel etc.)',
      },
      { value: '_0B_05_05_04', label: '0B.05.05.04 - Telematic services' },
      { value: '_0B_05_05_05', label: '0B.05.05.05 - Financial Indices' },
    ],
  },

  {
    value: '_0B_06_01',
    label: '0B.06.01 - Computer expenses',
    subcategory: [],
  },
  {
    value: '_0B_06_02',
    label: '0B.06.02 - Facility management',
    subcategory: [],
  },
  {
    value: '_0B_06_03',
    label: '0B.06.03 - Application maintenance',
    subcategory: [],
  },

  {
    value: '_0C_01_01',
    label: '0C.01.01 - Giveaways and Gifts',
    subcategory: [
      { value: '_0C_01_01_05', label: '0C.01.01.05 - Various gifts' },
    ],
  },

  {
    value: '_0C_01_02',
    label: '0C.01.02 - Gifts',
    subcategory: [
      {
        value: '_0C_01_02_06',
        label: '0C.01.02.06 - Notebooks and calendars',
      },
    ],
  },

  {
    value: '_0C_02_01',
    label: '0C.02.01 - Printing materials (not BTL)',
    subcategory: [
      {
        value: '_0C_02_01_04',
        label:
          '0C.02.01.04 - Printed materials and gadgets (press kits posters gadgets...)',
      },
    ],
  },

  {
    value: '_0C_03_01',
    label: '0C.03.01 - Production',
    subcategory: [
      {
        value: '_0C_03_01_03',
        label: '0C.03.01.03 - Agreement and non creative agency fee ',
      },
    ],
  },

  {
    value: '_0C_04_01',
    label: '0C.04.01 - Creativity',
    subcategory: [
      { value: '_0C_04_01_01', label: '0C.04.01.01 - BTL Creativily' },
      {
        value: '_0C_04_01_02',
        label:
          '0C.04.01.02 - Creative content agency services and agreement fees',
      },
      {
        value: '_0C_04_01_03',
        label: '0C.04.01.03 - Film Production and TV spots - creativity',
      },
      { value: '_0C_04_01_04', label: '0C.04.01.04 - company website' },
      {
        value: '_0C_04_01_05',
        label: '0C.04.01.05 - Creative agency - Realization',
      },
    ],
  },

  {
    value: '_0C_04_02',
    label: '0C.04.02 - Media',
    subcategory: [
      {
        value: '_0C_04_02_01',
        label: '0C.04.02.01 - Agreement and agency fee Media',
      },
      {
        value: '_0C_04_02_02',
        label:
          '0C.04.02.02 - Online and offline spaces planning andpurchasing Independent',
      },
      {
        value: '_0C_04_02_03',
        label:
          '0C.04.02.03 - Online and offline spaces planning andpurchasing Centralised',
      },
    ],
  },

  {
    value: '_0C_04_03',
    label: '0C.04.03 - Production',
    subcategory: [
      {
        value: '_0C_04_03_01',
        label: '0C.04.03.01 - One to One - Direct Marketing',
      },
      {
        value: '_0C_04_03_02',
        label: '0C.04.03.02 - Film Production and TV spots - production',
      },
      {
        value: '_0C_04_03_03',
        label: '0C.04.03.03 - Reporting monitoring advertising and web',
      },
      { value: '_0C_04_03_04', label: '0C.04.03.04 - Services for printing' },
      { value: '_0C_04_03_05', label: '0C.04.03.05 - WEB Services' },
      { value: '_0C_04_03_06', label: '0C.04.03.06 - BTL Printing' },
      {
        value: '_0C_04_03_07',
        label: '0C.04.03.07 - Multimedia and other internal communication',
      },
      {
        value: '_0C_04_03_08',
        label: '0C.04.03.08 - Bank Products intended for retail sale',
      },
    ],
  },

  {
    value: '_0C_05_01',
    label: '0C.05.01 - Directories',
    subcategory: [
      { value: '_0C_05_01_01', label: '0C.05.01.01 - Telephon Directories' },
    ],
  },

  {
    value: '_0C_05_02',
    label: '0C.05.02 - Signage',
    subcategory: [{ value: '_0C_05_02_01', label: '0C.05.02.01 - Signage' }],
  },

  {
    value: '_0C_06_01',
    label: '0C.06.01 - Purchase of Exhibition Space',
    subcategory: [
      {
        value: '_0C_06_01_01',
        label: '0C.06.01.01 - Purchase of exhibition spaces',
      },
    ],
  },

  {
    value: '_0C_06_02',
    label: '0C.06.02 - Mounting',
    subcategory: [
      {
        value: '_0C_06_02_01',
        label: '0C.06.02.01 - Exhibitions mounting - Exhibition stands',
      },
    ],
  },

  {
    value: '_0C_06_03',
    label: '0C.06.03 - Events Production',
    subcategory: [
      { value: '_0C_06_03_01', label: '0C.06.03.01 - Events Production' },
    ],
  },

  {
    value: '_0C_07_01',
    label: '0C.07.01 - Creativity',
    subcategory: [
      {
        value: '_0C_07_01_01',
        label:
          '0C.07.01.01 - Financial legal real estate and other advertising - creativity',
      },
    ],
  },

  {
    value: '_0C_07_02',
    label: '0C.07.02 - Media',
    subcategory: [
      {
        value: '_0C_07_02_01',
        label:
          '0C.07.02.01 - Financial legal real estate and other advertising - media\n',
      },
    ],
  },

  {
    value: '_0C_08_01',
    label: '0C.08.01 - Events',
    subcategory: [
      {
        value: '_0C_08_01_01',
        label: '0C.08.01.01 - Conventions and press conferences',
      },
    ],
  },

  {
    value: '_0C_08_02',
    label: '0C.08.02 - Entertainment expenses',
    subcategory: [
      {
        value: '_0C_08_02_01',
        label: '0C.08.02.01 - Entertainment events and initiatives ',
      },
      {
        value: '_0C_08_02_02',
        label:
          '0C.08.02.02 - Artistic and Cultural Heritage management (exclusive use CONS. SORV.)',
      },
      { value: '_0C_08_02_03', label: '0C.08.02.03 - Hospitality Guesthouse' },
    ],
  },

  {
    value: '_0C_10_01',
    label: '0C.10.01 - Art and Culture',
    subcategory: [
      {
        value: '_0C_10_01_01',
        label:
          '0C.10.01.01 - Initiatives in favor of theaters musical and theatrical performances exhibitions etc.',
      },
    ],
  },

  {
    value: '_0C_10_02',
    label: '0C.10.02 - Trade Associations',
    subcategory: [
      {
        value: '_0C_10_02_01',
        label:
          '0C.10.02.01 - Initiatives on behalf of chambers of commerce artisans association Confindustria Confagricoltura trade associations etc.',
      },
    ],
  },

  {
    value: '_0C_10_03',
    label: '0C.10.03 - Business trade finance',
    subcategory: [
      {
        value: '_0C_10_03_01',
        label:
          '0C.10.03.01 - Business commercial and not related to other categories',
      },
    ],
  },

  {
    value: '_0C_10_04',
    label: '0C.10.04 - Religious',
    subcategory: [
      {
        value: '_0C_10_04_01',
        label:
          '0C.10.04.01 - Support of initiatives in favor of religious organizations',
      },
    ],
  },

  {
    value: '_0C_10_05',
    label: '0C.10.05 - Social',
    subcategory: [
      {
        value: '_0C_10_05_01',
        label:
          '0C.10.05.01 - Support of initiatives in favor of non-profit organizations events related to corporate social responsibility etc.',
      },
    ],
  },

  {
    value: '_0C_10_06',
    label: '0C.10.06 - Sports',
    subcategory: [
      {
        value: '_0C_10_06_01',
        label:
          '0C.10.06.01 - Initiatives in favor of sports clubs and / or support of sport events',
      },
    ],
  },

  {
    value: '_0C_10_07',
    label: '0C.10.07 - Universities and Research',
    subcategory: [
      {
        value: '_0C_10_07_01',
        label:
          '0C.10.07.01 - Supporting initiatives aimed at universities and schools such as research projects scholarships master etc.',
      },
    ],
  },

  {
    value: '_0D_01_01',
    label: '0D.01.01 - Commercial information',
    subcategory: [
      { value: '_0D_01_01_01', label: '0D.01.01.01 - Commercial information' },
      {
        value: '_0D_01_01_02',
        label: '0D.01.01.02 - Commercial Information – CONSAP fee only',
      },
    ],
  },

  {
    value: '_0D_01_02',
    label: '0D.01.02 - File searches',
    subcategory: [
      { value: '_0D_01_02_01', label: '0D.01.02.01 - Commercial information' },
      {
        value: '_0D_01_02_02',
        label: '0D.01.02.02 - Commercial Information – CONSAP fee only',
      },
    ],
  },

  {
    value: '_0D_01_03',
    label: '0D.01.03 - Risk assessment',
    subcategory: [
      {
        value: '_0D_01_03_01',
        label: '0D.01.03.01 - Eurisc and Credit Bureau',
      },
      {
        value: '_0D_01_03_02',
        label: '0D.01.03.02 - Financial statements central register',
      },
    ],
  },

  {
    value: '_0D_02_01',
    label: '0D.02.01 - Research institutes and ICT databases',
    subcategory: [],
  },
  {
    value: '_0D_02_02',
    label: '0D.02.02 - Other costs to access the market',
    subcategory: [],
  },
  {
    value: '_0D_02_03',
    label: '0D.02.03 - Market surveys in Italy (e.g. marketing)',
    subcategory: [],
  },
  {
    value: '_0D_02_04',
    label: '0D.02.04 - Market surveys for foreign banks',
    subcategory: [],
  },

  {
    value: '_0E_01_01',
    label: '0E.01.01 - Safes',
    subcategory: [
      { value: '_0E_01_01_01', label: '0E.01.01.01 - Purchase of safes' },
      {
        value: '_0E_01_01_02',
        label: '0E.01.01.02 - Maintenance of safes - periodic fee',
      },
      {
        value: '_0E_01_01_03',
        label: '0E.01.01.03 - Maintenance of safes - additional fee',
      },
    ],
  },

  {
    value: '_0E_01_02',
    label: '0E.01.02 - Cash dispensers',
    subcategory: [
      { value: '_0E_01_02_01', label: '0E.01.02.01 - Other cash dispensers' },
    ],
  },

  { value: '_0E_01_03', label: '0E.01.03 - Alarm units', subcategory: [] },
  {
    value: '_0E_01_04',
    label: '0E.01.04 - ATM reinforcement structures (Cages)',
    subcategory: [],
  },
  {
    value: '_0E_02_01',
    label: '0E.02.01 - Security systems installation',
    subcategory: [],
  },
  {
    value: '_0E_02_02',
    label: '0E.02.02 - Security systems realization',
    subcategory: [],
  },

  {
    value: '_0E_02_03',
    label: '0E.02.03 - Security systems maintenance',
    subcategory: [
      {
        value: '_0E_02_03_01',
        label: '0E.02.03.01 - Security systems maintenance - fee',
      },
      {
        value: '_0E_02_03_02',
        label: '0E.02.03.02 - Security systems maintenance - extra fee',
      },
    ],
  },

  {
    value: '_0E_03_01',
    label: '0E.03.01 - Surveillance',
    subcategory: [
      {
        value: '_0E_03_01_01',
        label: '0E.03.01.01 - Ordinary surveillance at the branches',
      },
      {
        value: '_0E_03_01_02',
        label: '0E.03.01.02 - Ordinary surveillance at the headquarters',
      },
      { value: '_0E_03_01_03', label: '0E.03.01.03 - Other surveillance' },
    ],
  },

  {
    value: '_0E_03_02',
    label: '0E.03.02 - Reception / concierge',
    subcategory: [],
  },
  {
    value: '_0F_01_01',
    label: '0F.01.01 - Purchase of office equipment and machines',
    subcategory: [],
  },
  {
    value: '_0F_01_02',
    label: '0F.01.02 - Purchase of audiovisual equipment',
    subcategory: [],
  },
  {
    value: '_0F_01_03',
    label: '0F.01.03 - Office equipment and machines maintenance',
    subcategory: [],
  },
  { value: '_0F_01_04', label: '0F.01.04 - Photocopiers', subcategory: [] },
  {
    value: '_0F_02_01',
    label: '0F.02.01 - IT consumables (including toner)',
    subcategory: [],
  },
  {
    value: '_0F_02_02',
    label: '0F.02.02 - Printer and copy paper',
    subcategory: [],
  },
  {
    value: '_0F_02_03',
    label: '0F.02.03 - Forms envelopes and printed material',
    subcategory: [],
  },
  {
    value: '_0F_02_04',
    label: '0F.02.04 - Check books stamped paper etc..',
    subcategory: [],
  },
  {
    value: '_0F_02_05',
    label: '0F.02.05 - Stationery and other office supplies',
    subcategory: [],
  },

  {
    value: '_0G_01_01',
    label: '0G.01.01 - Vehicle rental',
    subcategory: [
      {
        value: '_0G_01_01_01',
        label: '0G.01.01.01 - Car rental for business use',
      },
      {
        value: '_0G_01_01_02',
        label: '0G.01.01.02 - Car rental fees for mixed business-private use',
      },
      {
        value: '_0G_01_01_03',
        label:
          '0G.01.01.03 - Rental - Car services for mixed business-private use',
      },
      {
        value: '_0G_01_01_04',
        label:
          '0G.01.01.04 - Car Rental - Miscellaneous expenses for mixed business-private use',
      },
      {
        value: '_0G_01_01_05',
        label: '0G.01.01.05 - Car rental fees for business use',
      },
      {
        value: '_0G_01_01_06',
        label: '0G.01.01.06 - Rental - Car services for business use',
      },
      {
        value: '_0G_01_01_07',
        label:
          '0G.01.01.07 - Car Rental - Miscellaneous expenses for business use',
      },
      {
        value: '_0G_01_01_08',
        label: '0G.01.01.08 - Car fleet rental with driver',
      },
    ],
  },

  {
    value: '_0G_01_02',
    label: '0G.01.02 - Vehicle maintenance',
    subcategory: [
      {
        value: '_0G_01_02_01',
        label:
          '0G.01.02.01 - Maintenance of cars and motorcycles for business use',
      },
      {
        value: '_0G_01_02_02',
        label: "0G.01.02.02 - Maintenance of owned vehicles'",
      },
      {
        value: '_0G_01_02_03',
        label: '0G.01.02.03 - Maintenance of owned cars for business use',
      },
      {
        value: '_0G_01_02_04',
        label: '0G.01.02.04 - Maintenance of third-party cars for business use',
      },
      {
        value: '_0G_01_02_05',
        label:
          '0G.01.02.05 - Maintenance of owned cars for mixed business-private use',
      },
      {
        value: '_0G_01_02_06',
        label:
          '0G.01.02.06 - Maintenance of third-party cars for mixed business-private use',
      },
    ],
  },

  {
    value: '_0G_01_03',
    label: '0G.01.03 - Car fleet management',
    subcategory: [
      { value: '_0G_01_03_01', label: '0G.01.03.01 - Garages and parking' },
      {
        value: '_0G_01_03_02',
        label: '0G.01.03.02 - Garages and parking mixed business-private use',
      },
      {
        value: '_0G_01_03_03',
        label: '0G.01.03.03 - Garages and parking business use',
      },
      {
        value: '_0G_01_03_04',
        label: '0G.01.03.04 - Vehicles - oil fuel parking',
      },
      {
        value: '_0G_01_03_05',
        label: '0G.01.03.05 - Cars for business use - oil fuel parking',
      },
      {
        value: '_0G_01_03_06',
        label:
          '0G.01.03.06 - Cars for mixed business- private use - oil fuel parking',
      },
      { value: '_0G_01_03_07', label: '0G.01.03.07 - Company garages' },
      {
        value: '_0G_01_03_08',
        label: '0G.01.03.08 - Personal company garage',
      },
      { value: '_0G_01_03_09', label: '0G.01.03.09 - Tolls ' },
      {
        value: '_0G_01_03_10',
        label: '0G.01.03.10 - Telepass agreements -private use',
      },
      {
        value: '_0G_01_03_11',
        label: '0G.01.03.11 - Telepass agreements-  business use',
      },
    ],
  },

  {
    value: '_0G_01_04',
    label: '0G.01.04 - Employee shuttles',
    subcategory: [],
  },
  {
    value: '_0G_01_05',
    label: '0G.01.05 - Cars Vehicles and similar',
    subcategory: [],
  },

  {
    value: '_0G_02_01',
    label: '0G.02.01 - Passenger transport',
    subcategory: [
      { value: '_0G_02_01_01', label: '0G.02.01.01 - Air transport' },
      {
        value: '_0G_02_01_02',
        label: '0G.02.01.02 - Non-deductible Air transport',
      },
      { value: '_0G_02_01_03', label: '0G.02.01.03 - Transport by train' },
      {
        value: '_0G_02_01_04',
        label: '0G.02.01.04 - Non-deductible Transport by train',
      },
    ],
  },

  {
    value: '_0G_02_02',
    label: '0G.02.02 - Travel agency service',
    subcategory: [],
  },
  {
    value: '_0G_02_03',
    label: '0G.02.03 - Non-deductible Hotel services',
    subcategory: [],
  },
  {
    value: '_0G_02_04',
    label: '0G.02.04 - Deductible Hotel services',
    subcategory: [],
  },
  {
    value: '_0G_03_01',
    label: '0G.03.01 - Relocation - contract',
    subcategory: [],
  },
  {
    value: '_0G_03_02',
    label: '0G.03.02 - Relocation - real estate brokerage',
    subcategory: [],
  },
  {
    value: '_0G_03_03',
    label: '0G.03.03 - Travel expenses for relocation',
    subcategory: [],
  },
  {
    value: '_0G_03_99',
    label: '0G.03.99 - Other relocation expenses',
    subcategory: [],
  },
  {
    value: '_0G_05_01',
    label: '0G.05.01 - Courses / lectures',
    subcategory: [],
  },

  {
    value: '_0G_05_02',
    label: '0G.05.02 - Courses / lectures',
    subcategory: [
      { value: '_0G_05_02_01', label: '0G.05.02.01 - Courses' },
      { value: '_0G_05_02_02', label: '0G.05.02.02 - Practical training' },
      {
        value: '_0G_05_02_03',
        label: '0G.05.02.03 - Training - refund of expenses',
      },
      { value: '_0G_05_02_04', label: '0G.05.02.04 - Managerial development' },
      {
        value: '_0G_05_02_05',
        label: '0G.05.02.05 - Managerial and Professional Development',
      },
    ],
  },

  {
    value: '_0G_07_01',
    label: '0G.07.01 - Catering / Canteen',
    subcategory: [],
  },
  { value: '_0G_07_02', label: '0G.07.02 - Meal vouchers', subcategory: [] },
  { value: '_0G_07_03', label: '0G.07.03 - Vending', subcategory: [] },
  {
    value: '_0G_11_01',
    label: '0G.11.01 - Refund of expenses on submission of receipts',
    subcategory: [],
  },
  {
    value: '_0G_11_02',
    label: '0G.11.02 - Refund of expenses - other',
    subcategory: [],
  },
  {
    value: '_0G_11_03',
    label:
      '0G.11.03 - Refund of expenses on submission of receipts - executives',
    subcategory: [],
  },
  {
    value: '_0G_99_01',
    label:
      '0G.99.01 - Refund of expenses on submission of receipts - executives',
    subcategory: [],
  },

  {
    value: '_0H_01_01',
    label: '0H.01.01 - Paper document archiving',
    subcategory: [
      {
        value: '_0H_01_01_01',
        label: '0H.01.01.01 - Archives management - inventory and research',
      },
      {
        value: '_0H_01_01_02',
        label:
          '0H.01.01.02 - Archives management - Software application for searches (ADM)',
      },
    ],
  },

  {
    value: '_0H_01_02',
    label: '0H.01.02 - Logistics operator',
    subcategory: [
      {
        value: '_0H_01_02_01',
        label: '0H.01.02.01 - Transport Services - furnishing accessories',
      },
      {
        value: '_0H_01_02_02',
        label:
          '0H.01.02.02 - Transport Services - transport of marketing material',
      },
      {
        value: '_0H_01_02_03',
        label: '0H.01.02.03 - Management of E-catalog platform (e-procurement)',
      },
      {
        value: '_0H_01_02_04',
        label: '0H.01.02.04 - Help desk (technology archives and real estate)',
      },
    ],
  },

  {
    value: '_0H_01_03',
    label: '0H.01.03 - Express Courier Service',
    subcategory: [
      { value: '_0H_01_03_01', label: '0H.01.03.01 - Courier for Italy' },
      { value: '_0H_01_03_02', label: '0H.01.03.02 - International Courier' },
      {
        value: '_0H_01_03_03',
        label: '0H.01.03.03 - Courier for CREATED PORTAL',
      },
    ],
  },

  {
    value: '_0H_01_04',
    label: '0H.01.04 - Postal service - domestic mail',
    subcategory: [
      {
        value: '_0H_01_04_01',
        label: '0H.01.04.01 - Internal mail (dedicated courier)',
      },
      {
        value: '_0H_01_04_02',
        label: '0H.01.04.02 - Mail monitoring (internal register)',
      },
      { value: '_0H_01_04_03', label: '0H.01.04.03 - mail transport' },
    ],
  },

  {
    value: '_0H_01_05',
    label: '0H.01.05 - Postal service - external mail',
    subcategory: [
      { value: '_0H_01_05_01', label: '0H_01_05_01 - Direct postal expenses' },
      {
        value: '_0H_01_05_02',
        label: '0H_01_05_02 - Courier delivery charges',
      },
      { value: '_0H_01_05_03', label: '0H_01_05_03 - Delivery' },
    ],
  },

  {
    value: '_0H_01_06',
    label: '0H.01.06 - Printing and mailing',
    subcategory: [
      {
        value: '_0H_01_06_01',
        label:
          '0H.01.06.01 - Communications to customers PIN Checks and Printouts',
      },
    ],
  },

  {
    value: '_0H_02_01',
    label: '0H.02.01 - Porterage and shuttle service',
    subcategory: [],
  },
  { value: '_0H_02_02', label: '0H.02.02 - Relocations', subcategory: [] },
  {
    value: '_0H_03_01',
    label: '0H.03.01 - Call centre Customer Relationship Management',
    subcategory: [],
  },
  {
    value: '_0H_03_02',
    label: '0H.03.02 - Photocopying / printing services',
    subcategory: [],
  },

  {
    value: '_0H_03_03',
    label: '0H.03.03 - Back-office processes (e.g. checks)',
    subcategory: [
      {
        value: '_0H_03_03_01',
        label: '0H.03.03.01 - Document treatment: effects',
      },
      {
        value: '_0H_03_03_02',
        label: '0H.03.03.02 - Document treatment: checks',
      },
      {
        value: '_0H_03_03_03',
        label: '0H.03.03.03 - Document treatment: credit transfers',
      },
      {
        value: '_0H_03_03_04',
        label: '0H.03.03.04 - Document treatment: other',
      },
      {
        value: '_0H_03_03_05',
        label: '0H.03.03.05 - Document treatment: statements and taxes',
      },
      {
        value: '_0H_03_03_06',
        label: '0H.03.03.06 - Document treatment: foreign cheques',
      },
      {
        value: '_0H_03_03_07',
        label: '0H.03.03.07 - Other Back-office processes',
      },
    ],
  },

  {
    value: '_0H_03_04',
    label:
      '0H.03.04 - Time stamping and special archiving (e.g. Certified Date)',
    subcategory: [],
  },
  {
    value: '_0H_03_05',
    label: '0H.03.05 - Translation and Language Services',
    subcategory: [],
  },
  {
    value: '_0H_03_06',
    label: '0H.03.06 - Services: security and protection',
    subcategory: [],
  },
  {
    value: '_0H_03_07',
    label: '0H.03.07 - Services: personnel/employment area',
    subcategory: [],
  },
  {
    value: '_0H_03_08',
    label: '0H.03.08 - Credit Recovery Services',
    subcategory: [],
  },
  {
    value: '_0H_03_09',
    label: '0H.03.09 - Salary-backed loan services',
    subcategory: [],
  },

  {
    value: '_0H_03_10',
    label: '0H.03.10 - Internal Communication',
    subcategory: [
      {
        value: '_0H_03_10_01',
        label:
          '0H.03.10.01 - Creativity for Internal Communication initiatives',
      },
      { value: '_0H_03_10_02', label: '0H.03.10.02 - Filming for WEB TV' },
      {
        value: '_0H_03_10_03',
        label: '0H.03.10.03 - Editorial Services -  House organ',
      },
    ],
  },

  {
    value: '_0H_03_11',
    label: '0H.03.11 - Publishing brokerage services',
    subcategory: [],
  },
  {
    value: '_0H_03_12',
    label: '0H.03.12 - Back-office processes (e.g. checks)',
    subcategory: [],
  },
  {
    value: '_0H_04_01',
    label: '0H.04.01 - Counting of own valuables',
    subcategory: [],
  },
  {
    value: '_0H_04_02',
    label: '0H.04.02 - Warehouse management - vault storage',
    subcategory: [],
  },
  {
    value: '_0H_05_01',
    label: '0H.05.01 - Transport of valuables',
    subcategory: [],
  },
  {
    value: '_0H_05_02',
    label: '0H.05.02 - Counting of valuables',
    subcategory: [],
  },
  {
    value: '_0H_06_01',
    label: '0H.06.01 - Marketing Services',
    subcategory: [],
  },
  {
    value: '_0H_06_02',
    label: '0H.06.02 - Credit Recovery Fees',
    subcategory: [],
  },
  {
    value: '_0H_06_03',
    label: '0H.06.03 - Corporate Services',
    subcategory: [],
  },
  {
    value: '_0H_07_01',
    label: '0H.07.01 - Leased auto vehicles management expenses',
    subcategory: [],
  },
  {
    value: '_0H_07_02',
    label: '0H.07.02 - Other leased movable property management expenses',
    subcategory: [],
  },
  {
    value: '_0I_01_01',
    label: '0I.01.01 - Tax consulting services',
    subcategory: [],
  },

  {
    value: '_0I_01_02',
    label: '0I.01.02 - Administrative / tax consulting services',
    subcategory: [
      { value: '_0I_01_02_01', label: '0I.01.02.01 - Auditors' },
      {
        value: '_0I_01_02_02',
        label: '0I.01.02.02 - Other administrative consulting',
      },
    ],
  },

  {
    value: '_0I_03_01',
    label: '0I.03.01 - Work Supervision / tests / safety / design',
    subcategory: [],
  },
  {
    value: '_0I_03_02',
    label: '0I.03.02 - Real Estate Appraisals',
    subcategory: [],
  },
  {
    value: '_0I_03_03',
    label: '0I.03.03 - Real estate brokerage',
    subcategory: [],
  },
  {
    value: '_0I_03_04',
    label: '0I.03.04 - Real Estate Auctions Due Diligence',
    subcategory: [],
  },
  {
    value: '_0I_04_01',
    label: '0I.04.01 - Legal consulting and services',
    subcategory: [],
  },

  {
    value: '_0I_04_02',
    label:
      '0I.04.02 - Professional and consulting services for equity investments',
    subcategory: [
      { value: '_0I_04_02_01', label: '0I.04.02.01 - Equity investments' },
      {
        value: '_0I_04_02_02',
        label: '0I.04.02.02 - Equity investments coordination',
      },
    ],
  },

  {
    value: '_0I_07_01',
    label: '0I.07.01 - Management consulting services',
    subcategory: [],
  },
  {
    value: '_0I_07_02',
    label: '0I.07.02 - Organisation consulting services',
    subcategory: [],
  },
  {
    value: '_0I_90_01',
    label: '0I.90.01 - Administrative and tax assistance',
    subcategory: [],
  },
  {
    value: '_0I_90_02',
    label: '0I.90.02 - Legal and notary assistance',
    subcategory: [],
  },
  {
    value: '_0I_90_99',
    label: '0I.90.99 - Other specialised assistance',
    subcategory: [],
  },

  {
    value: '_0I_99_01',
    label: '0I.99.01 - Mandatory technical consulting services',
    subcategory: [
      { value: '_0I_99_01_01', label: '0I.99.01.01 - Brokerage services' },
      {
        value: '_0I_99_01_02',
        label: '0I.99.01.02 - Other mandatory technical consulting services',
      },
    ],
  },

  {
    value: '_0I_99_02',
    label: '0I.99.02 - Movables appraisals',
    subcategory: [],
  },
  {
    value: '_0I_99_99',
    label: '0I.99.99 - Other consulting services',
    subcategory: [],
  },
  {
    value: '_0L_01_01',
    label:
      "0L.01.01 - Customers' Insurance (obsolete banking products) - market",
    subcategory: [],
  },
  {
    value: '_0L_01_02',
    label:
      "0L.01.02 - Customers' Insurance (obsolete banking products) - intercompany",
    subcategory: [],
  },
  {
    value: '_0L_01_03',
    label: "0L.01.03 - Customers' Insurance - market",
    subcategory: [],
  },
  {
    value: '_0L_01_04',
    label: "0L.01.04 - Customers' Insurance - intercompany",
    subcategory: [],
  },
  {
    value: '_0L_01_05',
    label: "0L.01.05 - Customers' Insurance - leasing",
    subcategory: [],
  },
  {
    value: '_0L_02_01',
    label: '0L.02.01 - Employee Benefits insurance',
    subcategory: [],
  },
  {
    value: '_0L_02_02',
    label: '0L.02.02 - Executives and Managers insurance',
    subcategory: [],
  },
  { value: '_0L_02_03', label: '0L.02.03 - Kasko Insurance', subcategory: [] },
  {
    value: '_0L_02_99',
    label: '0L.02.99 - Other Staff Insurance',
    subcategory: [],
  },
  { value: '_0L_03_01', label: '0L.03.01 - BBB Insurance', subcategory: [] },
  {
    value: '_0L_03_02',
    label: '0L.03.02 - Property Insurance',
    subcategory: [],
  },
  {
    value: '_0L_03_03',
    label: '0L.03.03 - General Liability',
    subcategory: [],
  },
  {
    value: '_0L_03_04',
    label: '0L.03.04 - Directors and Officers Liability',
    subcategory: [],
  },
  {
    value: '_0L_03_05',
    label: '0L.03.05 - Fine Arts All Risks',
    subcategory: [],
  },
  {
    value: '_0L_03_06',
    label: '0L.03.06 - Electronic and Cyber Insurance',
    subcategory: [],
  },
  {
    value: '_0L_03_07',
    label: '0L.03.07 - Professional Liability',
    subcategory: [],
  },
  { value: '_0L_03_08', label: '0L.03.08 - Motor Insurance', subcategory: [] },
  {
    value: '_0L_03_99',
    label: '0L.03.99 - Other Corporate Insurance',
    subcategory: [],
  },
  {
    value: '_0M_02_01',
    label: '0M.02.01 - Miscellaneous mandatory corporate (trade) associations',
    subcategory: [],
  },
  {
    value: '_0M_02_02',
    label: '0M.02.02 - Fees for supervisory and control authorities',
    subcategory: [],
  },
  {
    value: '_0M_02_03',
    label: '0M.02.03 - Italian Banking Association membership fees',
    subcategory: [],
  },
  {
    value: '_0M_02_04',
    label:
      '0M.02.04 - National Guarantee Fund A.62 c.1 Italian Legislative Decree n. 415 dated 23/07/1996',
    subcategory: [],
  },
  {
    value: '_0M_02_05',
    label: '0M.02.05 - National interbank deposit guarantee fund',
    subcategory: [],
  },
  {
    value: '_0M_02_06',
    label: '0M.02.06 - Non-corporate membership fees',
    subcategory: [],
  },
  {
    value: '_0M_02_07',
    label: '0M.02.07 - Ordinary consortium contributions in Italy',
    subcategory: [],
  },
  {
    value: '_0M_04_01',
    label: '0M.04.01 - Periodic Stamp duty current year: Bank drafts',
    subcategory: [],
  },
  {
    value: '_0M_04_02',
    label: '0M.04.02 - Periodic Stamp duty current year: Printed material',
    subcategory: [],
  },
  {
    value: '_0M_04_03',
    label: '0M.04.03 - Non-deductible VAT',
    subcategory: [],
  },
  {
    value: '_0M_04_04',
    label:
      '0M.04.04 - Municipal Property Tax (ICI - Imposta Comunale sugli Immobili)',
    subcategory: [],
  },
  {
    value: '_0M_04_05',
    label: '0M.04.05 - Registry Tax reimbursed to third parties',
    subcategory: [],
  },
  {
    value: '_0M_04_06',
    label:
      '0M.04.06 - Registry Tax reimbursed to third parties for staff accommodation',
    subcategory: [],
  },
  {
    value: '_0M_04_07',
    label: '0M.04.07 - Municipal taxes/duties current year',
    subcategory: [],
  },
  {
    value: '_0M_04_08',
    label: '0M.04.08 - Municipal taxes/duties prior years',
    subcategory: [],
  },
  {
    value: '_0M_04_09',
    label: '0M.04.09 - Indirect taxes to third parties',
    subcategory: [],
  },
  {
    value: '_0M_04_10',
    label: '0M.04.10 - Stamp Duties (only centralised PR)',
    subcategory: [],
  },
  { value: '_0M_04_99', label: '0M.04.99 - Other tributes', subcategory: [] },
  { value: '_0N_01_01', label: '0N.01.01 - POS', subcategory: [] },
  { value: '_0N_01_02', label: '0N.01.02 - POS Maintenance', subcategory: [] },
  {
    value: '_0N_01_03',
    label: '0N.01.03 - Card personalization machines',
    subcategory: [],
  },
  {
    value: '_0N_01_04',
    label: '0N.01.04 - Card personalization machines maintenance',
    subcategory: [],
  },
  {
    value: '_0N_02_01',
    label: '0N.02.01 - Plastic for Cards',
    subcategory: [],
  },
  {
    value: '_0N_03_01',
    label: '0N.03.01 - POS Installation',
    subcategory: [],
  },
  { value: '_0N_03_02', label: '0N.03.02 - POS Logistics', subcategory: [] },
  {
    value: '_0N_03_03',
    label: '0N.02.03 - Other electronic money service',
    subcategory: [],
  },
  {
    value: '_0P_22_01',
    label: '0P.22.01 - ISP - Service - Direzione Crediti',
    subcategory: [],
  },
  {
    value: '_0P_22_02',
    label: '0P.22.02 - ISP - Service - Direzione Partecipazioni',
    subcategory: [],
  },
  {
    value: '_0P_22_03',
    label: '0P.22.03 - ISP - Service - Direzione Relazioni Esterne',
    subcategory: [],
  },
  {
    value: '_0P_22_04',
    label: '0P.22.04 - ISP - Service - Direzione Risk Management',
    subcategory: [],
  },
  {
    value: '_0P_22_05',
    label: '0P.22.05 - ISP - Service - Direzione Ris Umane e Org.',
    subcategory: [],
  },
  {
    value: '_0P_22_06',
    label: '0P.22.06 - ISP - Service - Decisioni Cred. e Polit.Cred.',
    subcategory: [],
  },
  {
    value: '_0Z_01_01',
    label: '0Z.01.01 - Remuneration of Statutory Auditors',
    subcategory: [],
  },
  {
    value: '_0Z_01_02',
    label: '0Z.01.02 - Statutory auditors’ travel expenses',
    subcategory: [],
  },
  {
    value: '_0Z_01_03',
    label: '0Z.01.03 - Statutory auditors’ travel expenses - Refundable Km',
    subcategory: [],
  },
  {
    value: '_0Z_01_04',
    label:
      '0Z.01.04 - Remuneration Supervisory Body under Legislative Decree 231/01',
    subcategory: [],
  },
  {
    value: '_0Z_01_05',
    label: '0Z.01.05 - Chair and Deputy Chair',
    subcategory: [],
  },
  {
    value: '_0Z_01_06',
    label: '0Z.01.06 - Remuneration of directors',
    subcategory: [],
  },
  {
    value: '_0Z_01_07',
    label: '0Z.01.07 - Emoluments of Directors',
    subcategory: [],
  },
  {
    value: '_0Z_01_08',
    label: '0Z.01.08 - Remuneration of Chairman/Deputy Chairman.',
    subcategory: [],
  },
  {
    value: '_0Z_01_09',
    label: '0Z.01.09 - Supervisory Board travel expenses',
    subcategory: [],
  },
  {
    value: '_0Z_01_10',
    label: '0Z.01.10 - Consiglio di Gestione travel expenses',
    subcategory: [],
  },
  {
    value: '_0Z_01_11',
    label: '0Z.01.11 - Management Board travel expenses',
    subcategory: [],
  },
  {
    value: '_0Z_01_12',
    label: '0Z.01.12 - Travel expenses boards members - Refundable Km',
    subcategory: [],
  },
  {
    value: '_0Z_01_13',
    label:
      '0Z.01.13 - Expense reimbursements and fees to other bodies of supervisory and government control',
    subcategory: [],
  },
  { value: '_0Z_03_01', label: '0Z.03.01 - Obituaries', subcategory: [] },
  {
    value: '_0Z_03_02',
    label: '0Z.03.02 - Pecuniary penalties - Fines',
    subcategory: [],
  },
  {
    value: '_0Z_03_99',
    label: '0Z.03.99 - Other petty expenses',
    subcategory: [],
  },
  {
    value: '_0Z_04_01',
    label: '0Z.04.01 - Paintings prints tapestries etc..',
    subcategory: [],
  },
  {
    value: '_0Z_04_02',
    label: '0Z.04.02 - Preservation of works of art',
    subcategory: [],
  },
  {
    value: '_0Z_04_03',
    label: '0Z.04.03 - Artistic Heritage - Other Support Services',
    subcategory: [],
  },
  {
    value: '_0Z_97_01',
    label: '0Z.97.01 - Interest for late payment',
    subcategory: [],
  },
  {
    value: '_0Z_98_01',
    label: '0Z.98.01 - Financial Instruments Trading Commissions',
    subcategory: [],
  },
  {
    value: '_0Z_98_02',
    label: '0Z.98.02 - Currencies Trading Commissions',
    subcategory: [],
  },
  {
    value: '_0Z_98_03',
    label: '0Z.98.03 - Stocks and Bonds custody and administration commissions',
    subcategory: [],
  },
  {
    value: '_0Z_98_04',
    label: '0Z.98.04 - Financial instruments placement commissions',
    subcategory: [],
  },
  {
    value: '_0Z_98_05',
    label: '0Z.98.05 - Proceed and payment services commissions',
    subcategory: [],
  },
  {
    value: '_0Z_98_06',
    label: '0Z.98.06 - Other services commissions',
    subcategory: [],
  },
];
