import { GridField } from 'src/models/data/gridFields/gridFields';

export const branchesFormGridFields = (city, role, data): Array<GridField> => [
  {
    type: 'reactSelect',
    md: 12,
    xs: 12,
    name: 'cityCode',
    label: 'City',
    options: city,
    disabled: role,
    defaultValue: data?.cityCode && {
      label: city?.find(temp => temp?.value === data?.cityCode)?.label,
      value: {
        id: data?.cityCode,
      },
    },
  },
  {
    type: 'number',
    md: 12,
    xs: 12,
    name: 'branchCode',
    label: 'Branch Code',
    disabled: role,
  },
  {
    type: 'textarea',
    md: 12,
    xs: 12,
    name: 'description',
    label: 'Description',
    disabled: role,
  },
];

export const branchesFormGridFields1 = (): Array<GridField> => [
  {
    type: 'label',
    md: 12,
    xs: 12,
    disabled: false,
    value: 'Feedback',
  },
  {
    type: 'textarea',
    md: 12,
    xs: 12,
    disabled: true,
    name: 'authorizerFeedback',
    label: 'Authorizer Feedback',
  },
];
