import { commodityCategory } from 'src/enums/commodityCategory';
import { divisions } from 'src/enums/divisions';
import { GridField, FieldType } from 'src/models/data/gridFields/gridFields';
import { toggleDisable } from 'src/view/materialUI/utils/toggleDisable';

const YNOptions = [
  {
    label: 'Yes',
    value: 'true',
  },
  {
    label: 'No',
    value: 'false',
  },
];

export const prFormGridFields = (
  supplierOptionsAndFunctions,
  currency,
  data,
  authData,
  role,
  isEditModal,
  previousCurrency,
): Array<GridField> => {
  return [
    {
      type: 'label',
      md: 12,
      xs: 12,
      disabled: false,
      value: 'Purchase Request Data',
    },
    {
      type: 'text',
      md: 12,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      name: 'subject',
      label: 'Subject',
    },
    {
      type: 'reactSelect',
      md: 6,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      options: supplierOptionsAndFunctions.supplierMenu,
      label: 'Recommended Suppliers',
      name: 'prSuppliers',
      handleOnMenuScrollToBottom:
        supplierOptionsAndFunctions.handleOnMenuScrollToBottom,
      handleOnInputChange: supplierOptionsAndFunctions.handleOnInputChange,
      handleResetSearch: supplierOptionsAndFunctions?.handleResetSearch,
      defaultValue:
        data.prSuppliers &&
        data?.prSuppliers.map(supplier => {
          return (
            supplier && {
              label: supplier.companyName,
              value: {
                id: supplier['id'],
              },
            }
          );
        }),
      isMulti: true,
      menuHeight: 280,
    },
    {
      type: 'reactSelect',
      md: 6,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      name: 'code',
      label: 'Commodity Category Code',
      options: commodityCategory,
      defaultValue: data.code && {
        label: commodityCategory?.find(temp => temp?.value === data?.code)
          ?.label,
        value: {
          id: data?.code,
        },
      },
      menuHeight: 280,
    },
    {
      type: 'reactSelect',
      md: 3,
      xs: 12,
      disabled: true,
      name: 'unitType',
      label: 'Cost Owner Division',
      options: divisions,
      defaultValue: {
        label: divisions?.find(
          temp => temp?.value === (data?.unitType ? data?.unitType : authData),
        )?.label,
        value: {
          id: data?.unitType ? data?.unitType : authData,
        },
      },
    },
    {
      type: 'text',
      md: 3,
      xs: 12,
      disabled: true,
      name: data?.prStatus ? 'prStatus' : 'approved',
      label: 'Status',
    },
    {
      type: 'date',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      name: 'date',
      label: 'Date',
    },

    {
      type: 'reactSelect',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      options: currency,
      name: 'currency',
      label: 'Currency',
      defaultValue: data?.currency && {
        label: currency?.find(temp => temp?.value === data?.currency)?.label,
        value: {
          id: data?.currency,
        },
      },
      menuHeight: 280,
    },
    {
      type: 'reactSelect',
      options: YNOptions,
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      name: 'procScopeAsses',
      label: 'Procurement Scope Assessment Performed?',
      defaultValue: data?.currency && {
        label: YNOptions?.find(
          temp => temp?.value === (data?.procScopeAsses).toString(),
        )?.label,
        value: {
          id: data?.procScopeAsses,
        },
      },
    },
    {
      type: 'text',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      name: 'place',
      label: 'Place',
    },
    {
      type: 'reactSelect',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, data.prStatus),
      options: currency,
      name: 'previousCurrency',
      label: 'Previous Year Expenditure Currency',
      defaultValue: data?.previousCurrency && {
        label: currency?.find(temp => temp?.value === data?.previousCurrency)
          ?.label,
        value: {
          id: data?.previousCurrency,
        },
      },
      menuHeight: 280,
    },
    {
      type: 'number',
      md: 3,
      xs: 12,
      disabled:
        (isEditModal === false ? false : toggleDisable(role, data.prStatus)) ||
        !previousCurrency,
      name: 'previousValue',
      label: 'Previous Year Expenditure Value',
    },
  ];
};
export const prFormGridFields1 = (
  role,
  prData,
  isEditModal,
): Array<GridField> => {
  return [
    {
      type: 'label',
      md: 12,
      xs: 12,
      disabled: false,
      value: 'Others',
    },
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, prData.prStatus),
      name: 'typeScopeCommitment',
      label: 'Type And Scope Of Commitment',
    },
  ];
};

export const prFormGridFields2 = (): Array<GridField> => {
  return [
    {
      type: 'label',
      md: 12,
      xs: 12,
      disabled: false,
      value: 'Feedback',
    },
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'authorizerFeedback',
      label: 'Authorizer Feedback',
    },
  ];
};
