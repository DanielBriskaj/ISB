import { GridField } from 'src/models/data/gridFields/gridFields';

export const coAuthFormGridFields = (): Array<GridField> => [
  {
    type: 'textarea',
    md: 12,
    xs: 12,
    name: 'reason',
    label: 'Reason',
    disabled: false,
  },
];
