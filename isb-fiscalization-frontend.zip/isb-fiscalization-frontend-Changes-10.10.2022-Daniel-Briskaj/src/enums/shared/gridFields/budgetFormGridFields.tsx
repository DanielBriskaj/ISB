import { GridField } from 'src/models/data/gridFields/gridFields';

const year = new Date().getFullYear();
const yearOptions = [];
for (let i = year; i <= 2030; i++) {
  yearOptions.push({
    label: i,
    value: i,
  });
}

export const budgetFormGridFields = (disabled, data): Array<GridField> => [
  {
    type: 'text',
    md: 3,
    xs: 12,
    name: 'name',
    label: 'Budget Name',
    disabled: disabled,
  },
  {
    type: 'reactSelect',
    md: 3,
    xs: 12,
    options: yearOptions,
    name: 'year',
    label: 'Budget Year',
    disabled: disabled,
    defaultValue: data?.year && {
      label: yearOptions?.find(temp => temp?.value === data?.year)?.label,
      value: {
        id: data?.year,
      },
    },
  },
  {
    type: 'date',
    md: 3,
    xs: 12,
    name: 'dueDate',
    label: 'Due Date',
    disabled: disabled,
  },
  {
    type: 'text',
    md: 3,
    xs: 12,
    name: 'budgetStatus',
    label: 'Budget Status',
    disabled: true,
  },
];

export const deletebudgetFormGridFields = (
  budgetOptionsAndFunctions,
): Array<GridField> => [
  {
    type: 'reactSelect',
    md: 3,
    xs: 12,
    name: 'name',
    label: 'Budget Name',
    options: budgetOptionsAndFunctions.budgetOptions,
    handleOnMenuScrollToBottom: budgetOptionsAndFunctions.handleScrollToBottom,
    disabled: false,
  },
  {
    type: 'text',
    md: 3,
    xs: 12,
    name: 'year',
    label: 'Budget Year',
    disabled: true,
  },
  {
    type: 'date',
    md: 3,
    xs: 12,
    name: 'dueDate',
    label: 'Due Date',
    disabled: true,
  },
  {
    type: 'text',
    md: 3,
    xs: 12,
    name: 'budgetStatus',
    label: 'Budget Status',
    disabled: true,
  },
];

export const importContractFormGridFields = (
  budgetOptionsAndFunctions,
  contractOptionsAndFunctions,
): Array<GridField> => [
  {
    type: 'reactSelect',
    md: 6,
    xs: 12,
    name: 'contract',
    label: 'Contract',
    options: contractOptionsAndFunctions?.contractsOptions,
    handleOnInputChange: contractOptionsAndFunctions?.handleSearchContract,
    handleOnMenuScrollToBottom:
      contractOptionsAndFunctions?.handleContractScrollToBottom,
    handleResetSearch: contractOptionsAndFunctions?.handleResetSearch,
    disabled: false,
  },
  {
    type: 'reactSelect',
    md: 3,
    xs: 12,
    name: 'name',
    label: 'Budget Name',
    options: budgetOptionsAndFunctions.budgetOptions,
    handleOnMenuScrollToBottom: budgetOptionsAndFunctions.handleScrollToBottom,
    disabled: false,
  },
  {
    type: 'text',
    md: 3,
    xs: 12,
    name: 'year',
    label: 'Budget Year',
    disabled: true,
  },
];
