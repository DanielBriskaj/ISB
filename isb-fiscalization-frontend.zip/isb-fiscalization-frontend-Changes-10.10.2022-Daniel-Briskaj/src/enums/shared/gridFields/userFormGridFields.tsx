import { roleOptions } from 'src/enums/roleOptions.';
import { GridField } from 'src/models/data/gridFields/gridFields';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

export const userFormGridFields = (
  costOwners,
  disabled,
  data,
  selectedRole,
): Array<GridField> => {
  return [
    {
      type: 'text',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'name',
      label: 'Name',
    },
    {
      type: 'text',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'surname',
      label: 'Surname',
    },
    {
      type: 'text',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'username',
      label: 'Username',
    },
    {
      type: 'text',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'email',
      label: 'Email',
    },
    {
      type: 'reactSelect',
      md: 12,
      xs: 12,
      disabled: false,
      name: 'role',
      label: 'Role',
      options: roleOptions,
      defaultValue: data?.role && {
        label: `${data?.role}`,
        value: data?.role,
      },
    },
    (selectedRole === ROLES.COST_OWNER ||
      selectedRole === ROLES.COST_OWNER_AUTHORIZER) && {
      type: 'reactSelect',
      md: 12,
      xs: 12,
      disabled: disabled,
      name: 'costOwner',
      label: 'Cost Owner',
      options: costOwners,
      isClearable: true,
      defaultValue: data?.costOwner && {
        label: `${data?.costOwner?.code} - ${data?.costOwner?.ownerName}`,
        value: {
          id: data?.costOwner?.id,
        },
      },
    },

    {
      type: 'checkbox',
      md: 12,
      xs: 12,
      disabled: false,
      name: 'active',
      label: 'Active',
    },
  ];
};
