import { GridField } from 'src/models/data/gridFields/gridFields';

export const costOwnersFormGridFields = (
  divisions,
  role,
  data,
): Array<GridField> => [
  {
    type: 'text',
    md: 12,
    xs: 12,
    disabled: role,
    name: 'ownerName',
    label: 'Name',
  },
  {
    type: 'text',
    md: 12,
    xs: 12,
    disabled: role,
    name: 'code',
    label: 'Code',
  },
  {
    type: 'reactSelect',
    md: 12,
    xs: 12,
    disabled: role,
    name: 'division',
    label: 'Division',
    options: divisions,
    defaultValue: data?.division && {
      label: divisions?.find(temp => temp?.value === data?.division)?.label,
      value: {
        id: data?.division,
      },
    },
  },
  {
    type: 'switch',
    md: 6,
    xs: 12,
    name: 'isAuthorizer',
    label: 'Is Authorizer',
    disabled: role,
  },
];

export const costOwnersFormGridFields1 = (): Array<GridField> => {
  return [
    {
      type: 'label',
      md: 12,
      xs: 12,
      disabled: false,
      value: 'Feedback',
    },
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'authorizerFeedback',
      label: 'Authorizer Feedback',
    },
  ];
};
