import { GridField } from 'src/models/data/gridFields/gridFields';

export const acceptedInvoiceGridFields = (
  currency,
  role,
  data,
): Array<GridField> => [
  {
    type: 'reactSelect',
    md: 12,
    xs: 12,
    disabled: role,
    name: 'currency',
    label: 'Currency',
    options: currency,
    defaultValue: data?.currency && {
      label: currency?.find(temp => temp?.value === data?.currency)?.label,
      value: {
        id: data?.currency,
      },
    },
  },
];

export const acceptedInvoiceGridFields1 = (): Array<GridField> => {
  return [
    {
      type: 'label',
      md: 12,
      xs: 12,
      disabled: false,
      value: 'Feedback',
    },
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'authorizerFeedback',
      label: 'Authorizer Feedback',
    },
  ];
};
