import { GridField, FieldType } from 'src/models/data/gridFields/gridFields';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

const contractStatusOptions = [
  { label: 'ACTIVE', value: 'ACTIVE', isDisabled: true },
  { label: 'EXPIRED', value: 'EXPIRED', isDisabled: true },
  { label: 'BUDGET', value: 'BUDGET' },
  { label: 'FORECAST', value: 'FORECAST' },
  { label: 'NEW', value: 'NEW' },
  { label: 'IN APPROVAL', value: 'IN_APPROVAL', isDisabled: true },
];
const YNOptions = [
  {
    label: 'Yes',
    value: 'true',
  },
  {
    label: 'No',
    value: 'false',
  },
];

const expenditureTypeOptions = [
  { label: 'CAPEX', value: 'CAPEX' },
  { label: 'OPEX', value: 'OPEX' },
];

const fixedOrVariableOptions = [
  { label: 'FIXED', value: 'FIXED' },
  { label: 'VARIABLE', value: 'VARIABLE' },
];

export const contractsFormGridFields = (
  currency,
  productDescription,
  supplierOptionsAndFunctions,
  branchesOptionsAndFunctions,
  costOwnerOptionsAndFunctions,
  data,
  role,
  isFormDisabled,
  contractType,
  costOwnerCode,
  costOwnerId,
  GLOptionsAndFunctions,
  vatDisabled,
): Array<GridField> => {
  const fieldsDisabled =
    role === ROLES.ACCOUNTING_AUTHORIZER ||
    role === ROLES.ACCOUNTING_INPUT ||
    role === ROLES.PROCUREMENT_AUTHORIZER ||
    role === ROLES.COST_OWNER_AUTHORIZER ||
    (role === ROLES.COST_OWNER &&
      contractType !== 'budgetContract' &&
      contractType !== 'forecastContract') ||
    isFormDisabled;

  const contractGridFields: Array<GridField> = [
    {
      type: 'label',
      md: 12,
      xs: 12,
      value: 'Contract Details',
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      options: supplierOptionsAndFunctions.supplierMenu,
      label: 'Supplier',
      name: 'supplier',
      handleOnMenuScrollToBottom:
        supplierOptionsAndFunctions.handleOnMenuScrollToBottom,
      handleOnInputChange: supplierOptionsAndFunctions.handleOnInputChange,
      handleResetSearch: supplierOptionsAndFunctions?.handleResetSearch,
      defaultValue: data?.supplier && {
        label: data?.supplier?.companyName,
        value: {
          id: data?.supplier?.id,
        },
      },
      isMulti: false,
      menuHeight: 300,
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      options: branchesOptionsAndFunctions.branchMenu,
      handleOnMenuScrollToBottom:
        branchesOptionsAndFunctions.handleOnMenuScrollToBottom,
      handleOnInputChange: branchesOptionsAndFunctions.handleOnInputChange,
      handleResetSearch: branchesOptionsAndFunctions?.handleResetSearch,
      label: 'Branch',
      name: 'branch',
      defaultValue: data?.branch && {
        label: data?.branch?.branchCode,
        value: {
          id: data?.branch?.id,
        },
      },
      isMulti: false,
      menuHeight: 300,
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      options: costOwnerOptionsAndFunctions.costOwnerMenu,
      handleOnMenuScrollToBottom:
        costOwnerOptionsAndFunctions.handleOnMenuScrollToBottom,
      handleOnInputChange: costOwnerOptionsAndFunctions.handleOnInputChange,
      handleResetSearch: costOwnerOptionsAndFunctions?.handleResetSearch,
      label: 'Cost Owner',
      name: 'costOwner',
      disabled:
        fieldsDisabled ||
        contractType === 'budgetContract' ||
        contractType === 'forecastContract',
      defaultValue: data?.costOwner
        ? {
            label: `${data?.costOwner?.code} - ${data?.costOwner?.ownerName}`,
            value: {
              id: data?.costOwner?.id,
              code: data?.costOwner?.code,
            },
          }
        : !data?.costOwner &&
          (contractType === 'budgetContract' ||
            contractType === 'forecastContract')
        ? {
            label: costOwnerCode,
            value: {
              id: costOwnerId,
              code: costOwnerCode,
            },
          }
        : {},
      isMulti: false,
      menuHeight: 300,
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'expenditureType',
      label: 'Expenditure Type',
      options: expenditureTypeOptions,
      defaultValue: data?.expenditureType && {
        label: expenditureTypeOptions?.find(
          temp => temp?.value === data?.expenditureType,
        )?.label,
        value: {
          id: data?.expenditureType,
        },
      },
    },
    {
      type: 'text',
      md: 2.4,
      xs: 12,
      name: 'budgetCode',
      label: 'Budget Code',
    },
    {
      type: 'text',
      md: 4.8,
      xs: 12,
      name: 'contractDescription',
      label: 'Contract Description',
    },
    {
      type: 'date',
      md: 2.4,
      xs: 12,
      name: 'startDate',
      label: 'Start Date',
    },
    {
      type: 'date',
      md: 2.4,
      xs: 12,
      name: 'endDate',
      label: 'End Date',
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'currency',
      label: 'Currency',
      options: currency,
      defaultValue: data?.currency && {
        label: currency?.find(temp => temp?.value === data?.currency)?.label,
        value: {
          id: data?.currency,
        },
      },
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'automaticRenewal',
      label: 'Automatic Renewal',
      options: YNOptions,
      defaultValue: data?.supplier && {
        label: YNOptions?.find(
          temp => temp?.value === data?.automaticRenewal?.toString(),
        )?.label,
        value: {
          id: data?.automaticRenewal,
        },
      },
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'exitOption',
      label: 'Exit Option',
      options: YNOptions,
      defaultValue: data?.supplier && {
        label: YNOptions?.find(
          temp => temp?.value === data?.exitOption?.toString(),
        )?.label,
        value: {
          id: data?.exitOption,
        },
      },
    },
    {
      type: 'reactSelect',
      md: 7.2,
      xs: 12,
      options: productDescription,
      label: 'Product Description Categories',
      name: 'productDescription',
      defaultValue: data?.productDescription && {
        label: productDescription
          ?.find(pr =>
            pr?.options?.find(temp => temp?.value === data?.productDescription),
          )
          ?.options?.find(temp => temp?.value === data?.productDescription)
          ?.label,
        value: data?.productDescription,
      },
      isMulti: false,
      menuHeight: 300,
    },
    {
      type: 'label',
      md: 12,
      xs: 12,
      value: 'Others',
    },
    {
      type: 'number',
      md: 2.4,
      xs: 12,
      step: 0.01,
      name: 'contractAmount',
      label: 'Contract Amount',
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'fixedOrVariable',
      label: 'Fixed Or Variable',
      options: fixedOrVariableOptions,
      defaultValue: data?.fixedOrVariable && {
        label: fixedOrVariableOptions?.find(
          temp => temp?.value === data?.fixedOrVariable,
        )?.label,
        value: {
          id: data?.fixedOrVariable,
        },
      },
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'prepayment',
      label: 'Prepayment',
      options: YNOptions,
      defaultValue: data?.supplier && {
        label: YNOptions?.find(
          temp => temp?.value === data?.prepayment?.toString(),
        )?.label,
        value: {
          id: data?.prepayment,
        },
      },
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'isVat',
      label: 'isVAT',
      options: YNOptions,
      defaultValue: data?.supplier && {
        label: YNOptions?.find(temp => temp?.value === data?.isVat?.toString())
          ?.label,
        value: {
          id: data?.isVat,
        },
      },
    },
    {
      type: 'number',
      md: 2.4,
      xs: 12,
      name: 'vat',
      label: 'VAT',
      step: 0.01,
      disabled: fieldsDisabled || vatDisabled,
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'gl',
      label: 'GL',
      options: GLOptionsAndFunctions?.glOptionsMenu,
      handleOnMenuScrollToBottom:
        GLOptionsAndFunctions?.handleOnMenuScrollToBottom,
      handleOnInputChange: GLOptionsAndFunctions?.handleOnInputChange,
      handleResetSearch: GLOptionsAndFunctions?.handleResetSearch,
      defaultValue: data?.gl && {
        label: data?.gl?.description,
        value: {
          id: data?.gl?.id,
        },
      },
      isMulti: false,
      menuHeight: 300,
    },
    {
      type: 'text',
      md: 4.8,
      xs: 12,
      name: 'iban',
      label: 'IBAN',
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'isCriticalContract',
      label: 'Critical Contract',
      options: YNOptions,
      defaultValue: data?.supplier && {
        label: YNOptions?.find(
          temp => temp?.value === data?.isCriticalContract?.toString(),
        )?.label,
        value: {
          id: data?.isCriticalContract,
        },
      },
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'contractStatus',
      label: 'Contract Status',
      disabled:
        fieldsDisabled ||
        contractType === 'budgetContract' ||
        contractType === 'forecastContract',
      options: contractStatusOptions,
      defaultValue: {
        label: contractStatusOptions?.find(
          temp =>
            temp?.value ===
            (data?.contractStatus
              ? data?.contractStatus
              : contractType === 'budgetContract'
              ? contractStatusOptions[2].value
              : contractType === 'forecastContract'
              ? contractStatusOptions[3].value
              : contractStatusOptions[4].value),
        )?.label,
        value: {
          id: data?.contractStatus,
        },
      },
    },
    {
      type: 'text',
      md: 2.4,
      xs: 12,
      name: 'project',
      label: 'Project',
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'resolutionClauses',
      label: 'Resolution Clauses',
      options: YNOptions,
      defaultValue: data?.supplier && {
        label: YNOptions?.find(
          temp => temp?.value === data?.resolutionClauses?.toString(),
        )?.label,
        value: {
          id: data?.resolutionClauses,
        },
      },
    },
    {
      type: 'reactSelect',
      md: 2.4,
      xs: 12,
      name: 'integration',
      label: 'Integration',
      options: YNOptions,
      defaultValue: data?.supplier && {
        label: YNOptions?.find(
          temp => temp?.value === data?.integration?.toString(),
        )?.label,
        value: {
          id: data?.integration,
        },
      },
    },
    {
      type: 'text',

      md: 2.4,
      xs: 12,
      name: 'bankContactPerson',
      label: 'Bank Contact Person',
    },
    ...(Object.keys(data)?.length !== 0
      ? [
          {
            type: 'text' as FieldType,
            disabled: true,
            md: 2.4,
            xs: 12,
            name: 'contractCode',
            label: 'Contract Code',
          },
        ]
      : []),
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled:
        contractType === 'budgetContract' || contractType === 'forecastContract'
          ? isFormDisabled
          : true,
      name: 'authorizerFeedback',
      label:
        contractType === 'budgetContract' || contractType === 'forecastContract'
          ? 'Notes'
          : 'Authorizer Feedback',
    },
  ];

  return contractGridFields.map((contractGridField: GridField) => ({
    ...contractGridField,
    disabled: contractGridField.disabled
      ? contractGridField.disabled
      : fieldsDisabled,
  }));
};
