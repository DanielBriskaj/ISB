import { GridField, FieldType } from 'src/models/data/gridFields/gridFields';

export const glFormGridFields = (role): Array<GridField> => [
  {
    type: 'text',
    md: 12,
    xs: 12,
    name: 'glCode',
    label: 'GL Code',
    disabled: role,
  },
  {
    type: 'text',
    md: 12,
    xs: 12,
    name: 'description',
    label: 'Description',
    disabled: role,
  },
  {
    type: 'text',
    md: 12,
    xs: 12,
    name: 'glAccrual',
    label: 'GL Accrual',
    disabled: role,
  },
];

export const glFormGridFields1 = (): Array<GridField> => {
  return [
    {
      type: 'label',
      md: 12,
      xs: 12,
      disabled: false,
      value: 'Feedback',
    },
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'authorizerFeedback',
      label: 'Authorizer Feedback',
    },
  ];
};
