import { GridField, FieldType } from 'src/models/data/gridFields/gridFields';
import { toggleDisable } from 'src/view/materialUI/utils/toggleDisable';

const poStatus = [
  { value: 'NEW', label: 'NEW' },
  { value: 'COA', label: 'COA' },
  { value: 'PRI', label: 'PRI' },
  { value: 'PRA', label: 'PRA' },
  { value: 'APPROVED', label: 'APPROVED' },
];

export const poFormGridFields1 = (
  poData,
  role,
  isEditModal,
): Array<GridField> => {
  return [
    {
      type: 'label',
      md: 12,
      xs: 12,
      disabled: false,
      value: 'Others',
    },
    {
      type: 'text',
      md: 4,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'deliverAtName',
      label: 'Deliver At Name',
    },
    {
      type: 'text',
      md: 4,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'deliverAtAddress',
      label: 'Deliver At Address',
    },
    {
      type: 'text',
      md: 4,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'deliverAtTelFax',
      label: 'Deliver At TelFax',
    },
    {
      type: 'text',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'deliverAtCel',
      label: 'Deliver At Cel',
    },
    {
      type: 'text',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'deliverAtEmail',
      label: 'Deliver At Email',
    },
    {
      type: 'text',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'transportedVia',
      label: 'Transported Via',
    },
    {
      type: 'text',
      md: 3,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'termsOfTransportation',
      label: 'Terms Of Transportation',
    },
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled:
        isEditModal === false ? false : toggleDisable(role, poData.poStatus),
      name: 'description',
      label: 'Description',
    },
    {
      type: 'textarea',
      md: 12,
      xs: 12,
      disabled: true,
      name: 'authorizerFeedback',
      label: 'Authorizer Feedback',
    },
  ];
};
export const poFormGridFields = (
  supplierOptionsAndFunctions,
  contractOptionsAndFunctions,
  currency,
  data,
  supplierCompanyName,
  role,
  isEditModal,
): Array<GridField> => [
  {
    type: 'label',
    md: 12,
    xs: 12,
    disabled: false,
    value: 'Purchase Order Data',
  },
  {
    type: 'reactSelect',
    md: 6,
    xs: 12,
    disabled:
      isEditModal === false ? false : toggleDisable(role, data.poStatus),
    options: supplierOptionsAndFunctions.supplierMenu,
    label: 'Supplier',
    name: 'supplier',
    handleOnMenuScrollToBottom:
      supplierOptionsAndFunctions.handleOnMenuScrollToBottom,
    handleOnInputChange: supplierOptionsAndFunctions.handleOnInputChange,
    handleResetSearch: supplierOptionsAndFunctions?.handleResetSearch,
    defaultValue: data?.supplier
      ? {
          label: data.supplier?.companyName,
          value: {
            id: data.supplier?.id,
          },
        }
      : 'Supplier',
  },
  {
    type: 'reactSelect',
    md: 6,
    xs: 12,
    disabled:
      isEditModal === false ? false : toggleDisable(role, data.poStatus),
    options: contractOptionsAndFunctions.contractMenu,
    label: 'Contract',
    name: 'contract',
    handleOnMenuScrollToBottom:
      contractOptionsAndFunctions.handleOnMenuScrollToBottom,
    handleOnInputChange: contractOptionsAndFunctions.handleOnInputChange,
    handleResetSearch: contractOptionsAndFunctions?.handleResetSearch,
    defaultValue: data?.contract
      ? {
          label: data?.contract?.contractDescription,
          value: { id: data?.contract?.id },
        }
      : 'Contract',
    selectedValue: contractOptionsAndFunctions.selectedContract,
  },
  {
    type: 'date',
    md: 4,
    xs: 12,
    disabled:
      isEditModal === false ? false : toggleDisable(role, data.poStatus),
    name: 'date',
    label: 'Date',
  },
  {
    type: 'text' as FieldType,
    md: 4,
    xs: 12,
    disabled: true,
    name: 'poStatus',
    label: 'Po Status',
  },
  {
    type: 'reactSelect',
    md: 4,
    xs: 12,
    disabled:
      isEditModal === false ? false : toggleDisable(role, data.poStatus),
    name: 'currency',
    label: 'Currency',
    options: currency,
    defaultValue: data?.currency && {
      label: currency?.find(temp => temp?.value === data?.currency)?.label,
      value: {
        id: data?.currency,
      },
    },
  },
];
