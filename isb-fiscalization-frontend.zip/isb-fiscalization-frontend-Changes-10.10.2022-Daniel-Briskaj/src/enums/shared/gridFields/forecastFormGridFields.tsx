import { GridField } from 'src/models/data/gridFields/gridFields';

const year = new Date().getFullYear();
const yearOptions = [];
for (let i = year; i <= 2030; i++) {
  yearOptions.push({
    label: i,
    value: i,
  });
}
export const monthOptions = [
  { label: 'January', value: 1 },
  { label: 'February', value: 2 },
  { label: 'March', value: 3 },
  { label: 'April', value: 4 },
  { label: 'May', value: 5 },
  { label: 'June', value: 6 },
  { label: 'July', value: 7 },
  { label: 'August', value: 8 },
  { label: 'September', value: 9 },
  { label: 'October', value: 10 },
  { label: 'November', value: 11 },
  { label: 'December', value: 12 },
];
export const forecastFormGridFields = (disabled, data): Array<GridField> => [
  {
    type: 'text',
    md: 2.4,
    xs: 12,
    name: 'name',
    label: 'Forecast Name',
    disabled: disabled,
  },
  {
    type: 'reactSelect',
    md: 2.4,
    xs: 12,
    options: monthOptions,
    name: 'month',
    label: 'Forecast Month',
    disabled: disabled,
    defaultValue: data?.month && {
      label: monthOptions?.find(temp => temp?.value === data?.month)?.label,
      value: {
        id: data?.month,
      },
    },
  },
  {
    type: 'reactSelect',
    md: 2.4,
    xs: 12,
    options: yearOptions,
    name: 'year',
    label: 'Forecast Year',
    disabled: disabled,
    defaultValue: data?.year && {
      label: yearOptions?.find(temp => temp?.value === data?.year)?.label,
      value: {
        id: data?.year,
      },
    },
  },
  {
    type: 'date',
    md: 2.4,
    xs: 12,
    name: 'dueDate',
    label: 'Due Date',
    disabled: disabled,
  },
  {
    type: 'text',
    md: 2.4,
    xs: 12,
    name: 'forecastStatus',
    label: 'Forecast Status',
    disabled: true,
  },
];

export const deleteForecastFormGridFields = (
  forecastOptionsAndFunctions,
): Array<GridField> => [
  {
    type: 'reactSelect',
    md: 2.4,
    xs: 12,
    name: 'name',
    label: 'Forecast Name',
    options: forecastOptionsAndFunctions.forecastOptions,
    disabled: false,
  },
  {
    type: 'text',
    md: 2.4,
    xs: 12,
    name: 'month',
    label: 'Forecast Month',
    disabled: true,
  },
  {
    type: 'text',
    md: 2.4,
    xs: 12,
    name: 'year',
    label: 'Forecast Year',
    disabled: true,
  },
  {
    type: 'date',
    md: 2.4,
    xs: 12,
    name: 'dueDate',
    label: 'Due Date',
    disabled: true,
  },
  {
    type: 'text',
    md: 2.4,
    xs: 12,
    name: 'forecastStatus',
    label: 'Forecast Status',
    disabled: true,
  },
];

export const importContractFormGridFields = (
  forecastOptionsAndFunctions,
  contractOptionsAndFunctions,
): Array<GridField> => [
  {
    type: 'reactSelect',
    md: 4.8,
    xs: 12,
    name: 'contract',
    label: 'Contract',
    options: contractOptionsAndFunctions?.contractsOptions,
    handleOnInputChange: contractOptionsAndFunctions?.handleSearchContract,
    handleOnMenuScrollToBottom:
      contractOptionsAndFunctions?.handleContractScrollToBottom,
    handleResetSearch: contractOptionsAndFunctions?.handleResetSearch,
    disabled: false,
  },
  {
    type: 'reactSelect',
    md: 2.4,
    xs: 12,
    name: 'name',
    label: 'Forecast Name',
    options: forecastOptionsAndFunctions.forecastOptions,
    handleOnMenuScrollToBottom:
      forecastOptionsAndFunctions.handleScrollToBottom,
    disabled: false,
  },
  {
    type: 'text',
    md: 2.4,
    xs: 12,
    name: 'month',
    label: 'Forecast Month',
    disabled: true,
  },
  {
    type: 'text',
    md: 2.4,
    xs: 12,
    name: 'year',
    label: 'Budget Year',
    disabled: true,
  },
];
