import { GridField, FieldType } from 'src/models/data/gridFields/gridFields';
import { toggleDisableMI } from 'src/view/materialUI/utils/toggleDisable';

export const manualInvoicesGridFields = (
  currency,
  data,
  supplierOptionsAndFunctions,
  isEditModal,
  role,
): Array<GridField> => {
  return isEditModal === true && data?.invoiceStatus !== 'DELIVERED'
    ? [
        {
          type: 'reactSelect',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'supplier',
          label: 'Supplier',
          options: supplierOptionsAndFunctions?.suppliersOptions,
          handleOnMenuScrollToBottom:
            supplierOptionsAndFunctions?.handleOnMenuScrollToBottom,
          handleOnInputChange: supplierOptionsAndFunctions?.handleOnInputChange,
          defaultValue:
            isEditModal === true
              ? data?.supplier && {
                  label: data?.supplier?.companyName,
                  value: {
                    id: data?.supplier?.id
                      ? supplierOptionsAndFunctions?.suppliersOptions?.find(
                          item => item?.value?.id === data.supplier?.id,
                        )?.value?.id
                      : data.supplier?.id,
                  },
                }
              : '',
        },

        {
          type: 'text',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'invoiceNumber',
          label: 'Invoice Number',
        },

        {
          type: 'date',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'receivedDate',
          label: 'Received Date',
        },
        {
          type: 'date',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'dueDate',
          label: 'Due Date',
        },
        {
          type: 'text',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'nipt',
          label: 'Nipt',
        },
        {
          type: 'reactSelect',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'currency',
          label: 'Currency',
          options: currency,
          defaultValue:
            isEditModal === true
              ? data?.currency && {
                  label: currency?.find(temp => temp?.value === data?.currency)
                    ?.label,
                  value: {
                    id: data?.currency,
                  },
                }
              : '',
        },
        {
          type: 'text',
          md: 6,
          xs: 12,
          disabled: true,
          name: 'invoiceStatus',
          label: 'Status',
        },
        {
          type: 'number',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'amount',
          label: 'Amount',
        },
        {
          type: 'number',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'vat',
          label: 'VAT',
          step: 0.01,
          defaultValue: data?.contract && data?.contract?.vat,
        },
        {
          type: 'text' as FieldType,
          md: 6,
          xs: 12,
          disabled: true,
          name: 'contract',
          label: 'Contract',
          defaultValue: data?.contract && {
            label: `${data?.contract?.contractCode}-${data?.contract?.contractDescription}`,
            value: {
              id: data?.contract?.id,
            },
          },
        },
        {
          type: 'text' as FieldType,
          md: 6,
          xs: 12,
          disabled: true,
          name: 'po',
          label: 'PO',
          defaultValue: data?.po && {
            label: data?.po?.poNumber,
            value: {
              id: data?.po?.id,
            },
          },
        },
        {
          type: 'textarea',
          md: 12,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'description',
          label: 'Description',
          defaultValue: '',
        },
        {
          type: 'textarea',
          md: 12,
          xs: 12,
          disabled: true,
          name: 'authorizerFeedback',
          label: 'Authorizer Feedback',
        },
      ]
    : [
        {
          type: 'reactSelect',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'supplier',
          label: 'Supplier',
          options: supplierOptionsAndFunctions?.suppliersOptions,
          handleOnMenuScrollToBottom:
            supplierOptionsAndFunctions?.handleOnMenuScrollToBottom,
          handleOnInputChange: supplierOptionsAndFunctions?.handleOnInputChange,
          defaultValue:
            isEditModal === true
              ? data?.supplier && {
                  label: data?.supplier?.companyName,
                  value: {
                    id: data?.supplier?.id
                      ? supplierOptionsAndFunctions?.suppliersOptions?.find(
                          item => item?.value?.id === data.supplier?.id,
                        )?.value?.id
                      : data.supplier?.id,
                  },
                }
              : '',
        },

        {
          type: 'text',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'invoiceNumber',
          label: 'Invoice Number',
        },

        {
          type: 'date',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'receivedDate',
          label: 'Received Date',
        },
        {
          type: 'date',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'dueDate',
          label: 'Due Date',
        },
        {
          type: 'text',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'nipt',
          label: 'Nipt',
        },
        {
          type: 'reactSelect',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'currency',
          label: 'Currency',
          options: currency,
          defaultValue:
            isEditModal === true
              ? data?.currency && {
                  label: currency?.find(temp => temp?.value === data?.currency)
                    ?.label,
                  value: {
                    id: data?.currency,
                  },
                }
              : '',
        },
        {
          type: 'text',
          md: 6,
          xs: 12,
          disabled: true,
          name: 'invoiceStatus',
          label: 'Status',
        },
        {
          type: 'number',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'amount',
          label: 'Amount',
        },
        {
          type: 'number',
          md: 6,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'vat',
          label: 'VAT',
          step: 0.01,
          defaultValue: data?.contract && data?.contract?.vat,
        },
        {
          type: 'textarea',
          md: 12,
          xs: 12,
          disabled:
            isEditModal === false
              ? false
              : toggleDisableMI(role, data?.invoiceStatus),
          name: 'description',
          label: 'Description',
          defaultValue: '',
        },
        {
          type: 'textarea',
          md: 12,
          xs: 12,
          disabled: true,
          name: 'authorizerFeedback',
          label: 'Authorizer Feedback',
        },
      ];
};
