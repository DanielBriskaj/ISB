import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const prItemsFields: Array<HeaderFields> = [
  {
    label: 'Description',
    align: 'center',
    sort: false,
  },
  {
    label: 'Good Category',
    align: 'center',
    sort: false,
  },
  {
    label: 'Quantity',
    align: 'center',
    sort: false,
  },
  {
    label: 'Unit Cost',
    align: 'center',
    sort: false,
  },
  {
    label: 'Delivery Place',
    align: 'center',
    sort: false,
  },
  {
    label: 'Delivery Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Values',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
];
