import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const costOwnersFields: Array<HeaderFields> = [
  {
    label: 'Owner Name',
    align: 'left',
    sort: false,
  },
  {
    label: 'Cost Owner Code',
    align: 'center',
    sort: false,
  },
  {
    label: 'Authorizer',
    align: 'center',
    sort: false,
  },
  {
    label: 'Division',
    align: 'center',
    sort: false,
  },
  {
    label: 'Approved',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: 'Process',
    align: 'center',
    sort: false,
  },
];
