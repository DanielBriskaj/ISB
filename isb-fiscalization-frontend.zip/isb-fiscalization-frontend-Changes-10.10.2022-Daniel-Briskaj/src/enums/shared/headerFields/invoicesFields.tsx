import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const accInputInvoicesFields: Array<HeaderFields> = [
  {
    label: 'EIC',
    align: 'left',
    sort: false,
  },
  {
    label: 'Invoice Number',
    align: 'center',
    sort: false,
  },
  {
    label: 'Received Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Due Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'NIPT',
    align: 'center',
    sort: false,
  },

  {
    label: 'View Invoice',
    align: 'center',
    sort: false,
  },
  {
    label: 'Process',
    align: 'center',
    sort: false,
  },
  {
    label: 'Reject',
    align: 'center',
    sort: false,
  },
];

export const accAuthInvoicesFields: Array<HeaderFields> = [
  {
    label: 'EIC',
    align: 'left',
    sort: false,
  },
  {
    label: 'Invoice Number',
    align: 'center',
    sort: false,
  },
  {
    label: 'Received Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Due Date',
    align: 'center',
    sort: true,
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'NIPT',
    align: 'center',
    sort: false,
  },

  {
    label: 'View Memo',
    align: 'center',
    sort: false,
  },
];

export const acceptedInvoicesFields: Array<HeaderFields> = [
  {
    label: 'Supplier',
    align: 'center',
    sort: false,
  },
  {
    label: 'Invoice Number',
    align: 'center',
    sort: false,
  },
  {
    label: 'Received Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Due Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'NIPT',
    align: 'center',
    sort: false,
  },

  {
    label: 'View Invoice',
    align: 'center',
    sort: false,
  },
  {
    label: 'Pay',
    align: 'center',
    sort: false,
  },
];

export const COAuthorizerInvoicesFields: Array<HeaderFields> = [
  {
    label: 'EIC',
    align: 'left',
    sort: false,
  },
  {
    label: 'Invoice Number',
    align: 'center',
    sort: false,
  },
  {
    label: 'Received Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Due Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
  },
  {
    label: 'NIPT',
    align: 'center',
    sort: false,
  },
  {
    label: 'Approved',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: '',
    align: 'center',
    sort: false,
  },
];
