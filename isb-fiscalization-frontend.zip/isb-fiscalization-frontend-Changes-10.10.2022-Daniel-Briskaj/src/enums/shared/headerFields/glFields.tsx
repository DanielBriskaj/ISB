import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const glFields: Array<HeaderFields> = [
  {
    label: 'GL Code',
    align: 'left',
    sort: false,
  },
  {
    label: 'Description',
    align: 'center',
    sort: false,
  },
  {
    label: 'GL Accrual',
    align: 'center',
    sort: false,
  },
  {
    label: 'Approved',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: 'Process',
    align: 'center',
    sort: false,
  },
];
