import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const poFields: Array<HeaderFields> = [
  {
    label: 'Supplier',
    align: 'left',
    sort: false,
  },
  {
    label: 'Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Purchase Order Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Contract Code',
    align: 'center',
    sort: false,
  },
  {
    label: 'Branch Code',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: '',
    align: 'center',
    sort: false,
  },
];
