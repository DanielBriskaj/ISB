import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const branchesFields: Array<HeaderFields> = [
  {
    label: 'Branch Code',
    align: 'left',
    sort: false,
  },
  {
    label: 'Description',
    align: 'center',
    sort: false,
  },
  {
    label: 'City',
    align: 'center',
    sort: false,
  },
  {
    label: 'Approved',
    align: 'center',
    sort: false,
  },
  {
    label: 'Action',
    align: 'center',
    sort: false,
  },
  {
    label: 'Process',
    align: 'center',
    sort: false,
  },
];
