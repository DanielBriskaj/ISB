interface ColumnProps {
  fieldName: string;
  sx?: any;
  align: 'left' | 'center' | 'right' | 'justify' | 'inherit';
}
const forecastColumns: Array<ColumnProps> = [
  {
    fieldName: '',
    align: 'left',
    sx: { paddingLeft: 3 },
  },
  {
    fieldName: 'Supplier',
    align: 'left',
    sx: { paddingLeft: 1.5 },
  },
  {
    fieldName: 'Cost Owner',
    align: 'center',
    sx: { paddingLeft: 1.5 },
  },
  {
    fieldName: 'Branch',
    align: 'center',
  },
  {
    fieldName: 'Contract Status',
    align: 'center',
  },
  {
    fieldName: 'Contract Code',
    align: 'center',
  },
  {
    fieldName: 'Status',
    align: 'center',
  },
  {
    fieldName: 'Actions',
    align: 'center',
  },
  {
    fieldName: 'Process',
    align: 'center',
  },
];

export default forecastColumns;
