import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const costOwnerInvoicesFields: Array<HeaderFields> = [
  {
    label: 'ID',
    align: 'left',
    sort: false,
  },
  {
    label: 'EIC',
    align: 'center',
    sort: false,
  },
  {
    label: 'Invoice Number',
    align: 'center',
    sort: false,
  },
  {
    label: 'Received Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Due Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
    sx: { paddingRight: 2 },
  },
  {
    label: 'NIPT',
    align: 'center',
    sort: false,
  },
  {
    label: 'Approved',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: 'Process',
    align: 'center',
    sort: false,
  },
];
