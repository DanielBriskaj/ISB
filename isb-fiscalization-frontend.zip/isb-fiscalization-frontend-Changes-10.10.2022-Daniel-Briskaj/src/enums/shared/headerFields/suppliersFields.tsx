import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const suppliersFields: Array<HeaderFields> = [
  {
    label: 'Company Name',
    align: 'center',
    sort: true,
  },
  {
    label: 'City',
    align: 'center',
    sort: false,
  },
  {
    label: 'Supplier Account ID',
    align: 'center',
    sort: false,
  },
  {
    label: 'Full Name',
    align: 'center',
    sort: false,
  },
  {
    label: 'Role',
    align: 'center',
    sort: false,
  },
  {
    label: 'User Code',
    align: 'center',
    sort: false,
  },
  {
    label: 'Approved',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: 'Process',
    align: 'center',
    sort: false,
  },
];
