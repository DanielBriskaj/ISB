import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const costOwnerContractFields: Array<HeaderFields> = [
  {
    label: 'Supplier',
    align: 'left',
    sort: false,
  },
  {
    label: 'Cost Owner',
    align: 'left',
    sort: false,
    sx: { paddingLeft: 3 },
  },
  {
    label: 'Cost Owner Code',
    align: 'center',
    sort: false,
  },
  {
    label: 'Contract Code',
    align: 'center',
    sort: false,
  },
  {
    label: 'Start Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Description',
    align: 'left',
    sort: false,
    sx: { paddingLeft: 3 },
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
  },
  {
    label: 'Currency',
    align: 'center',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
];
