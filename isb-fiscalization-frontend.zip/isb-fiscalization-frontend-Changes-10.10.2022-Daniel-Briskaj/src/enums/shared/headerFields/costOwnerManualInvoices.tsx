import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const costOwnerManualInvoicesFields: Array<HeaderFields> = [
  {
    label: 'Supplier',
    align: 'center',
    sort: false,
  },
  {
    label: 'Invoice Number',
    align: 'center',
    sort: false,
  },
  {
    label: 'Received Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Due Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
    sx: { paddingRight: 2 },
  },
  {
    label: 'Description',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: 'Process',
    align: 'center',
    sort: false,
  },
];
