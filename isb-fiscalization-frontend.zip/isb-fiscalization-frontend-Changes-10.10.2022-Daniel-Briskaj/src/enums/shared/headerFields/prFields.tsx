import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';
export const prFields: Array<HeaderFields> = [
  {
    label: 'Code',
    align: 'left',
    sort: false,
  },
  {
    label: 'Subject',
    align: 'center',
    sort: false,
  },
  {
    label: 'Currency',
    align: 'center',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Date',
    align: 'center',
    sort: false,
  },

  {
    label: 'Place',
    align: 'center',
    sort: false,
  },
  {
    label: 'Previous Currency',
    align: 'center',
    sort: false,
  },
  {
    label: 'Cost Owner Division',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
  {
    label: '',
    align: 'center',
    sort: false,
  },
];
