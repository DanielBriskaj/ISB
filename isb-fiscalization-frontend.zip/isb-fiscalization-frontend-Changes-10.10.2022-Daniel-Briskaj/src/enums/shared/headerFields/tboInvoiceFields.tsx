interface ColumnProps {
  label: string;
  sx?: any;
  align: 'left' | 'center' | 'right' | 'justify' | 'inherit';
  sort: boolean;
}
const tboInvoiceColumns: Array<ColumnProps> = [
  {
    label: 'NIPT',
    align: 'center',
    sx: { paddingLeft: 1.5 },
    sort: false,
  },
  {
    label: 'Invoice Number',
    align: 'center',
    sx: { paddingLeft: 1.5 },
    sort: false,
  },
  {
    label: 'Due Date',
    align: 'center',
    sort: true,
  },
  {
    label: 'Memo Date',
    align: 'center',
    sort: false,
  },
  {
    label: 'Amount',
    align: 'right',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Memo',
    align: 'center',
    sort: false,
  },
  {
    label: 'Pay Invoice',
    align: 'center',
    sort: false,
  },
  {
    label: 'View Memo',
    align: 'center',
    sort: false,
  },
];

export default tboInvoiceColumns;
