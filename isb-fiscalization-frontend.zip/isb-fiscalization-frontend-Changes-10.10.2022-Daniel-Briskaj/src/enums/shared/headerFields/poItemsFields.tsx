import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const poItemsFields: Array<HeaderFields> = [
  {
    label: 'Description',
    align: 'center',
    sort: false,
  },
  {
    label: 'Quantity',
    align: 'center',
    sort: false,
  },
  {
    label: 'Price',
    align: 'center',
    sort: false,
  },
  {
    label: 'Values',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
];
