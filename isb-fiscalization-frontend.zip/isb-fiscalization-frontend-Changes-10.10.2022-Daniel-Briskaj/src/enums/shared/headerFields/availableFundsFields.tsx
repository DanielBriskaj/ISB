import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const availableFundsFields: Array<HeaderFields> = [
  {
    label: 'Project Name',
    align: 'center',
    sort: false,
  },
  {
    label: 'Currency',
    align: 'center',
    sort: false,
  },
  {
    label: 'Budgeted Amount',
    align: 'center',
    sort: false,
  },
  {
    label: 'YTD ',
    align: 'center',
    sort: false,
  },
  {
    label: 'Remaining Amount',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'center',
    sort: false,
  },
];
