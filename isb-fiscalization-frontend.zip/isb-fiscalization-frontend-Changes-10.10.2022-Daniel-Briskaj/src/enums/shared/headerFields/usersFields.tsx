import { HeaderFields } from '../../../models/data/tableInterfaces/TabHeader';

export const usersFields: Array<HeaderFields> = [
  {
    label: 'First Name',
    align: 'left',
    sort: false,
  },
  {
    label: 'Last Name',
    align: 'left',
    sort: false,
  },
  {
    label: 'Username',
    align: 'left',
    sort: false,
  },
  {
    label: 'Role',
    align: 'left',
    sort: false,
  },
  {
    label: 'Division',
    align: 'left',
    sort: false,
  },
  {
    label: 'Status',
    align: 'center',
    sort: false,
  },
  {
    label: 'Actions',
    align: 'left',
    sort: false,
  },
];
