import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';

export const auditFields: Array<HeaderFields> = [
  {
    label: 'Action Name',
    align: 'center',
    sort: true,
  },
  {
    label: 'Action Name Id',
    align: 'center',
    sort: false,
  },
  {
    label: 'Date Time',
    align: 'center',
    sort: false,
  },
  {
    label: 'Username',
    align: 'center',
    sort: false,
  },
  {
    label: 'Action Type',
    align: 'center',
    sort: false,
  },
];
