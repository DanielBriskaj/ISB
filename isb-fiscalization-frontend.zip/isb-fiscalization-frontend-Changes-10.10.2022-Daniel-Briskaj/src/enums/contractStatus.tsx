export const contractStatus = [
  { label: 'ACTIVE', value: 'ACTIVE' },
  { label: 'EXPIRED', value: 'EXPIRED' },
  { label: 'BUDGET', value: 'BUDGET' },
  { label: 'FORECAST', value: 'FORECAST' },
  { label: 'NEW', value: 'NEW' },
  { label: 'IN APPROVAL', value: 'IN_APPROVAL' },
];
