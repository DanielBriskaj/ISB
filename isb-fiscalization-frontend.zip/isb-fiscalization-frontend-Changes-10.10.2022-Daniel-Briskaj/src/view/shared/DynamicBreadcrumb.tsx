import React from 'react';
import {
  Box,
  Breadcrumbs,
  Container,
  Grid,
  Link,
  Typography,
} from '@material-ui/core';
import ChevronRightIcon from '../../icons/ChevronRight';

const DynamicBreadcrumb = ({ pageName, breadcrumbs }) => {
  return (
    <Grid container justifyContent="space-between" spacing={3} padding={5}>
      <Grid item>
        <Typography color="textPrimary" variant="h5">
          {pageName}
        </Typography>
        <Breadcrumbs
          aria-label="breadcrumb"
          separator={<ChevronRightIcon fontSize="small" />}
          sx={{ mt: 1 }}
        >
          {breadcrumbs.map((data, index) => {
            return (
              <Typography
                key={index}
                color={
                  index + 1 !== breadcrumbs.length
                    ? 'textSecondary'
                    : ' textPrimary'
                }
                variant="subtitle2"
              >
                {data}
              </Typography>
            );
          })}
        </Breadcrumbs>
      </Grid>
      <Grid item>
        <Box sx={{ m: -1 }}></Box>
      </Grid>
    </Grid>
  );
};

export default DynamicBreadcrumb;
