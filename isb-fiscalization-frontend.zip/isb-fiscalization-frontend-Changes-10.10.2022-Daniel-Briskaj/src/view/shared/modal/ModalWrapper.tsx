import ModalChild from './ModalChild';
import FormPopupModal from './FormPopupModal';
const ModalWrapper = props => {
  const { children, modalOpen, setModalOpen, type } = props;

  function getChild() {
    if (modalOpen) {
      return (
        <ModalChild child={children} setModalOpen={setModalOpen} type={type} />
      );
    }

    return;
  }

  return <FormPopupModal child={getChild()} />;
};

export default ModalWrapper;
