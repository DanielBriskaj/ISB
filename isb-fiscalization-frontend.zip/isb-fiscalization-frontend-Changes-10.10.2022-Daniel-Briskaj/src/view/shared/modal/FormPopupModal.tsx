import { createPortal } from 'react-dom';

const FormPopupModal = ({ child }) => {
  if (!child) return null;

  return createPortal(
    <div>{child}</div>,
    (document as any).getElementById('modal-root'),
  );
};

export default FormPopupModal;
