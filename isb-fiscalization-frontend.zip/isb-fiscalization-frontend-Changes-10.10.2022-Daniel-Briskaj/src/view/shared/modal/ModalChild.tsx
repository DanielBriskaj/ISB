import { Box } from '@material-ui/core';
import { useDispatch } from 'react-redux';
import contractActions from 'src/modules/contracts/contractActions';

const ModalChild = props => {
  const { child, setModalOpen, type } = props;
  const dispatch = useDispatch();
  return (
    <Box
      position="absolute"
      width="100%"
      top={type === 'deleteModal' ? '50%' : 0}
      left={0}
      display="flex"
      justifyContent="center"
      alignItems="center"
      padding={10}
    >
      <Box
        className="modal"
        onClick={e => {
          if (type !== 'progressModal') {
            setModalOpen(false);
          }
          dispatch(contractActions.clearContractData());
          dispatch(contractActions.setSelectedContract());
        }}
        zIndex={type === 'deleteModal' ? 2000 : 1900}
      />
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        width="90%"
        height="90%"
        position="relative"
      >
        <Box
          position={type === 'deleteModal' ? 'fixed' : 'absolute'}
          top={0}
          left={0}
          width="100%"
          zIndex={2000}
          pb={10}
          sx={
            type === 'deleteModal'
              ? {
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                }
              : {}
          }
        >
          {child}
        </Box>
      </Box>
    </Box>
  );
};

export default ModalChild;
