import { useEffect, useRef } from 'react';

export function usePrevious(value) {
  const ref = useRef();
  useEffect(() => {
    ref.current = value;
  });

  if (ref.current === undefined) {
    return null;
  }
  return ref.current;
}
