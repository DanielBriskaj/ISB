export var enableProcApproval = (function () {
  var enabled = true;
  var disabled = false;

  function enableProcInput(role = '', status = '') {
    var procInputObj = {
      role: 'PROCUREMENT_INPUT',
      status,
    };

    return procInputObj.role === role && procInputObj.status !== 'NEW'
      ? enabled
      : disabled;
  }

  function enableProcAuth(role = '', status = '') {
    var procAuthObj = {
      role: 'PROCUREMENT_AUTHORIZER',
      status,
    };

    return procAuthObj.role === role && procAuthObj.status !== 'IN_APPROVAL'
      ? enabled
      : disabled;
  }

  return {
    enableProcInput: enableProcInput,
    enableProcAuth: enableProcAuth,
  };
})();
