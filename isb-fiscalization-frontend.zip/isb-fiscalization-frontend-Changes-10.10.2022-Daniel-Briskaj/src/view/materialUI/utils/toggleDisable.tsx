const roles = {
  costOwner: 'COST_OWNER',
  costOwnerAuthorizer: 'COST_OWNER_AUTHORIZER',
  procurementInput: 'PROCUREMENT_INPUT',
  procurementAuthorizer: 'PROCUREMENT_AUTHORIZER',
};

const displayToggler = {
  display: 'inherit',
  nonDisplay: 'none',
};

export function toggleDisable(userRole: string, status: string) {
  if (
    (roles.costOwner === userRole && status !== 'NEW') ||
    userRole !== roles.costOwner
  ) {
    return true;
  }
  return false;
}
export function toggleDisableMI(userRole: string, status: string) {
  if (
    (roles.costOwner === userRole ||
      roles.costOwnerAuthorizer === userRole ||
      roles.procurementAuthorizer === userRole ||
      roles.procurementInput === userRole) &&
    status !== 'DELIVERED'
  ) {
    return true;
  }
  return false;
}

export function toggleDisplay(userRole: string, status: string) {
  if (toggleDisable(userRole, status) === true) {
    return displayToggler.nonDisplay;
  }
  return displayToggler.display;
}
export function toggleDisplayMI(userRole: string, status: string) {
  if (toggleDisableMI(userRole, status) === true) {
    return displayToggler.nonDisplay;
  }
  return displayToggler.display;
}
