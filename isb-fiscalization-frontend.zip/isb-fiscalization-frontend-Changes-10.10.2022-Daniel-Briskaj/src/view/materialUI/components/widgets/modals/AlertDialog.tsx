import { Box, Button, Container, Typography } from '@material-ui/core';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { useSelector, useDispatch } from 'react-redux';
import { useForm, FormProvider } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { coAuthRejectSchema } from 'src/modules/shared/yup/coAuthRejectSchema';
import CoAuthForm from '../forms/CoAuthForm';
import budgetActions from 'src/modules/budget/budgetActions';
import forecastActions from 'src/modules/forecast/forecastActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import { useEffect } from 'react';
import forecastSelector from 'src/modules/forecast/forecastSelector';

interface AlertDialogProps {
  setDialogOpen: any;
  setModalOpen?: any;
  handleDelete: any;
  message: string;
  hasFeedback: boolean;
}

const AlertDialog: React.FC<AlertDialogProps> = ({
  setDialogOpen,
  setModalOpen,
  handleDelete,
  message,
  hasFeedback,
}) => {
  const dispatch = useDispatch();
  const authData = useSelector(authSelector.authData);
  const budgetContract = useSelector(budgetSelector.budgetItem);
  const forecastContract = useSelector(forecastSelector.forecastItem);

  const { role } = authData;

  const initialValues = {
    reason: '',
  };

  useEffect(() => {
    if (budgetContract?.authorizerFeedback) {
      form.setValue(`reason`, budgetContract?.authorizerFeedback);
    } else if (forecastContract?.authorizerFeedback) {
      form.setValue(`reason`, forecastContract?.authorizerFeedback);
    }
  }, [budgetContract, forecastContract]);

  useEffect(() => {
    return () => {
      dispatch(budgetActions.clearBudgetItemData());
      dispatch(forecastActions.clearForecastItemData());
    };
  }, []);

  const form = useForm({
    resolver: yupResolver(coAuthRejectSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    handleDelete(data);
  };

  return (
    <>
      <Box display="flex" justifyContent="center" alignItems="center">
        <Box
          sx={{
            backgroundColor: 'background.default',
            py: 3,
            width: '60%',
            height: '100%',
          }}
          justifySelf="center"
        >
          <Container maxWidth="md">
            <Box
              display="flex"
              justifyContent="center"
              alignItems="center"
              flexDirection="column"
            >
              <Typography
                variant="h5"
                sx={{
                  fontSize:
                    role && role === 'COST_OWNER_AUTHORIZER'
                      ? '1.2rem'
                      : 'inherit',
                  mb: 2,
                }}
              >
                {message}
              </Typography>
              {hasFeedback ? (
                <></>
              ) : (
                <Typography variant="subtitle1" sx={{ mb: 1 }}>
                  This action cannot be undone!
                </Typography>
              )}
            </Box>
            {hasFeedback ? (
              <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                  <Box sx={{ mt: 1 }} height="100%">
                    <CoAuthForm />
                  </Box>
                  <Box
                    sx={{ mt: 2 }}
                    display="flex"
                    justifyContent="end"
                    alignContent="end"
                  >
                    <Button
                      color="primary"
                      sx={{
                        m: '0 6px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      type="submit"
                    >
                      Reject
                    </Button>
                    <Button
                      sx={{
                        background: '#666',
                        '&:hover': {
                          background: '#333',
                        },
                        m: '0 8px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      onClick={() => {
                        setModalOpen && setModalOpen(false);
                        setDialogOpen && setDialogOpen(false);
                      }}
                    >
                      Cancel
                    </Button>
                  </Box>
                </form>
              </FormProvider>
            ) : (
              <Box display="flex" justifyContent="end" alignContent="end">
                <Button
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  type="submit"
                  onClick={() => {
                    handleDelete();
                    setDialogOpen && setDialogOpen(false);
                    setModalOpen && setModalOpen(false);
                  }}
                >
                  Yes
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => {
                    setDialogOpen(false);
                  }}
                >
                  No
                </Button>
              </Box>
            )}
          </Container>
        </Box>
      </Box>
    </>
  );
};

export default AlertDialog;
