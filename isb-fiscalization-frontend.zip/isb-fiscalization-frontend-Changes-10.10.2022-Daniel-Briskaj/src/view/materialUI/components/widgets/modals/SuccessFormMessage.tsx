import type { FC } from 'react';
import {
  Avatar,
  Box,
  Button,
  Container,
  Paper,
  Typography,
} from '@material-ui/core';
import { alpha } from '@material-ui/core/styles';
import CheckIcon from 'src/icons/Check';

const SuccessForm = ({ message }) => (
  <Container
    maxWidth="xs"
    sx={{ position: 'absolute', background: 'white', bottom: 10, right: 10 }}
  >
    <Paper
      elevation={12}
      sx={{
        py: 2,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: theme => alpha(theme.palette.success.main, 0.08),
      }}
    >
      <Avatar
        sx={{
          backgroundColor: theme => alpha(theme.palette.success.main, 0.08),
          color: 'success.main',
          mr: 2,
        }}
      >
        <CheckIcon />
      </Avatar>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'column',
        }}
      >
        <Typography sx={{ color: 'success.main', fontSize: '20px' }}>
          {message}
        </Typography>
      </Box>
    </Paper>
  </Container>
);

export default SuccessForm;
