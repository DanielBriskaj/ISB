import { useState } from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useFormContext } from 'react-hook-form';
import Input from './formFields/input';
import SelectInput from './formFields/select';
import ReactSelectInput from './formFields/reactSelect';
import TimezoneSelect, { allTimezones } from 'react-timezone-select';
import { StylesConfig } from 'react-select';
import { THEMES } from 'src/view/materialUI/constants';
import useSettings from '../../hooks/useSettings';
import CheckBox from './formFields/checkBox';
import Switch from './formFields/switch';
import TimeZoneSelector from './formFields/timeZoneSelector';
const GridFields = props => {
  const { data, gridFields } = props;

  const { settings } = useSettings();

  const {
    register,
    setValue,
    formState: { errors },
    getValues,
    control,
  } = useFormContext();

  return (
    <>
      {gridFields.map((gridField, i) => {
        const props = {
          md: gridField.md,
          xs: gridField.xs,
          type: gridField?.type,
          options: gridField?.options,
          name: gridField?.name,
          data: data,
          label: gridField?.label,
          label1: gridField?.label1,
          errors: errors,
          register,
          setValue,
          getValues,
          handleOnInputChange: gridField?.handleOnInputChange,
          handleOnMenuScrollToBottom: gridField?.handleOnMenuScrollToBottom,
          defaultValue: gridField?.defaultValue,
          switchDisabled: gridField?.switchDisabled,
          disabled: gridField?.disabled,
          isMulti: gridField?.isMulti,
          control,
          selectedValue: gridField?.selectedValue,
          step: gridField?.step,
          menuHeight: gridField?.menuHeight,
          handleResetSearch: gridField?.handleResetSearch,
          isClearable: gridField?.isClearable,
        };

        switch (gridField.type) {
          case 'text':
          case 'number':
          case 'date':
          case 'textarea':
            return <Input key={i} {...props} />;
          case 'select':
            return <SelectInput key={i} {...props} />;
          case 'reactSelect':
            return <ReactSelectInput key={i} {...props} />;
          case 'reactTimezoneSelect':
            return <TimeZoneSelector key={i} {...props} />;
          case 'checkbox':
            return <CheckBox key={i} {...props} />;
          case 'switch':
            return <Switch key={i} {...props} />;
          default:
            return (
              <Grid item md={gridField.md} xs={gridField.xs} key={i}>
                <Typography
                  paddingX={1}
                  fontWeight={'bold'}
                  sx={{ m: '1rem 0' }}
                >
                  {gridField.value}
                </Typography>
              </Grid>
            );
        }
      })}
    </>
  );
};

export default GridFields;
