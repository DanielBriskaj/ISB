import {
  Box,
  Card,
  InputAdornment,
  Table,
  TableBody,
  TableRow,
  TableCell,
  TablePagination,
  TextField,
  Button,
  TableFooter,
  CircularProgress,
  Typography,
  InputLabel,
  Select,
  FormControl,
  MenuItem,
} from '@material-ui/core';
import Scrollbar from '../../Scrollbar';
import SearchIcon from '../../../../../icons/Search';
import Calendar from '../../../../../icons/Calendar';
import TabHeader from 'src/view/dashboard/TabHeader';
import { HeaderFields } from 'src/models/data/tableInterfaces/TabHeader';
import { TableProps } from 'src/models/data/tableInterfaces/TabProps';
import { DateRangePicker } from 'react-date-range';
import { useEffect, useState, useRef } from 'react';
import moment from 'moment';
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file

import TableRowRender from 'src/view/dashboard/TableRowRender';
import { useSelector } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { minWidth } from '@material-ui/system';

const DynamicTable = ({
  handleDialogOpen,
  isEditModal,
  isEditable,
  handleProcessOpen,
  headerFields,
  handleModalOpen,
  onPageChange,
  onChangeRowsPerPage,
  handlePopupOpen,
  data,
  loading,
  totalItems,
  currentPage,
  handleDelete,
  handleDirectionSorting,
  handleMultipleDirectionSorting,
  searchArrayOfFunctions,
  limitPerPage,
  selected,
  setSelected,
  buttonData,
  dateState,
  setDateState,
  tableFooterData,
  tableType,
  sortData,
  setApproved,
  approved,
  sortDirection,
  sortedProps,
  StatusFilterComponent,
  query,
}: TableProps) => {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const datePickerRef = useRef(null);
  const authData = useSelector(authSelector.authData);
  const { role } = authData;

  function handleClickOutside(event) {
    if (
      datePickerRef.current &&
      !datePickerRef.current.contains(event.target)
    ) {
      setShowDatePicker(false);
    }
  }

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [datePickerRef]);

  const theProps = {
    tableType,
    handleProcessOpen,
    handleModalOpen,
    handleDialogOpen,
    handlePopupOpen,
    handleDelete,
    selected,
    setSelected,
    buttonData,
    tableFooterData,
    isEditModal,
    isEditable,
  };

  return (
    <Box
      sx={{
        backgroundColor: 'background.default',
        p: 3,
      }}
    >
      <Card sx={{ overflow: 'visible' }}>
        <Box
          sx={{
            alignItems: 'center',
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            m: -1,
            p: 2,
            mb: 1.5,
          }}
        >
          <Box
            sx={{
              m: 1,
              maxWidth: '100%',
              width: 900,
              display: 'flex',
              alignItems: 'center',
            }}
          >
            {dateState && (
              <>
                <Box sx={{ position: 'relative' }}>
                  <TextField
                    fullWidth
                    size="small"
                    variant="outlined"
                    sx={{ mr: 3 }}
                    value={`${moment(dateState.startDate).format(
                      'MMM Do YY',
                    )} - ${moment(dateState.endDate).format('MMM Do YY')}`}
                    onClick={() => setShowDatePicker(!showDatePicker)}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment
                          position="start"
                          sx={{ cursor: 'pointer' }}
                        >
                          <Calendar fontSize="small" />
                        </InputAdornment>
                      ),
                    }}
                    inputProps={{ style: { cursor: 'pointer' } }}
                  />
                  {showDatePicker && (
                    <Box
                      sx={{
                        position: 'absolute',
                        zIndex: 40000,
                        border: '2px solid #ccc',
                        borderRadius: '4px',
                      }}
                    >
                      <DateRangePicker
                        onChange={item => {
                          setDateState(item.selection);
                          setShowDatePicker(false);
                        }}
                        showSelectionPreview={true}
                        moveRangeOnFirstSelection={false}
                        months={2}
                        ranges={[dateState]}
                        editableDateInputs={true}
                        direction="horizontal"
                      />
                    </Box>
                  )}
                </Box>
              </>
            )}
            {searchArrayOfFunctions && (
              <>
                {searchArrayOfFunctions.map((searchOnChange, i) => {
                  return (
                    <TextField
                      key={i}
                      fullWidth
                      size="small"
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SearchIcon fontSize="small" />
                          </InputAdornment>
                        ),
                      }}
                      className={searchOnChange.customClass}
                      placeholder={searchOnChange.placeholder}
                      variant="outlined"
                      onChange={searchOnChange.function}
                      sx={{ mr: 1 }}
                      disabled={searchOnChange?.disabled}
                    />
                  );
                })}
              </>
            )}
            {sortData && (
              <>
                {sortData.map((sort, i) => {
                  return (
                    <Box
                      sx={{
                        m: 1,
                        maxWidth: '100%',
                        width: 240,
                      }}
                      key={i}
                    >
                      <TextField
                        onChange={event =>
                          sort.handleSorting(event.target.value)
                        }
                        fullWidth
                        size="small"
                        label={sort.label}
                        name="sort"
                        select
                        inputProps={{
                          style: {
                            minWidth: 110,
                            padding: '4.5px 14px',
                          },
                        }}
                        InputLabelProps={{ shrink: true }}
                        SelectProps={{
                          native: true,
                          defaultValue: sort.defaultValue,
                        }}
                        variant="outlined"
                        disabled={sort?.disabled}
                      >
                        {sort.sortOptions.map((option, index) => (
                          <option key={index} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </TextField>
                    </Box>
                  );
                })}
              </>
            )}
            {(role === 'ACCOUNTING_INPUT' ||
              role === 'ACCOUNTING_AUTHORIZER' ||
              role === 'PROCUREMENT_INPUT' ||
              role === 'PROCUREMENT_AUTHORIZER') &&
              setApproved &&
              tableType !== 'auditTable' &&
              tableType !== 'invoiceTable' &&
              tableType !== 'acceptedInvoiceTable' &&
              tableType !== 'userTable' && (
                <Box
                  sx={{
                    m: 1,
                    maxWidth: '100%',
                    width: 240,
                  }}
                >
                  <TextField
                    onChange={event => setApproved(event.target.value)}
                    fullWidth
                    size="small"
                    label={'Filter by status'}
                    name="sort"
                    select
                    InputLabelProps={{ shrink: true }}
                    inputProps={{
                      style: {
                        minWidth: 110,
                        padding: '4.5px 14px',
                      },
                    }}
                    SelectProps={{
                      native: true,
                    }}
                    variant="outlined"
                  >
                    <option value={''}>ALL</option>
                    <option value={'NEW'}>NEW</option>
                    <option value={'IN_APPROVAL'}>IN APPROVAL</option>
                    {tableType !== 'contractTable' && (
                      <option value={'APPROVED'}>APPROVED</option>
                    )}
                    {tableType === 'contractTable' && (
                      <option value={'ACTIVE'}>ACTIVE</option>
                    )}
                    {tableType === 'contractTable' && (
                      <option value={'FORECAST'}>FORECAST</option>
                    )}
                    {tableType === 'contractTable' && (
                      <option value={'BUDGET'}>BUDGET</option>
                    )}
                    {tableType === 'contractTable' && (
                      <option value={'EXPIRED'}>EXPIRED</option>
                    )}
                  </TextField>
                </Box>
              )}
            {StatusFilterComponent && StatusFilterComponent}
          </Box>

          <Box>
            {buttonData &&
              buttonData.map((button, i) => {
                return (
                  <Button className="table-button" key={i} {...button}>
                    {button.label}
                  </Button>
                );
              })}
          </Box>
        </Box>
        <Scrollbar className="scrollbar-styling">
          <Box sx={{ minWidth: 800 }}>
            <Table padding="none">
              <TabHeader
                headerFields={headerFields as Array<HeaderFields>}
                handleDirectionSorting={handleDirectionSorting}
                handleMultipleDirectionSorting={handleMultipleDirectionSorting}
                sortedProps={sortedProps}
              />
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell
                      colSpan={headerFields && headerFields.length}
                      sx={{ textAlign: 'center', paddingY: '3rem' }}
                    >
                      <Typography variant="body1">
                        Data is loading...
                      </Typography>
                      <CircularProgress sx={{ marginTop: '1rem' }} />
                    </TableCell>
                  </TableRow>
                ) : data && data.length !== 0 ? (
                  <>
                    {data &&
                      data.map((obj, i) => (
                        <TableRowRender
                          key={i}
                          index={i}
                          object={obj}
                          page={currentPage}
                          rowsPerPage={limitPerPage ? limitPerPage : 10}
                          approved={approved}
                          sortDirection={sortDirection}
                          query={query}
                          {...theProps}
                        />
                      ))}
                  </>
                ) : (
                  <TableRow>
                    <TableCell
                      sx={{
                        textAlign: 'center',
                        fontSize: '1.01rem',
                        fontWeight: '500',
                        color: '#777',
                        padding: '1.15rem 0.9rem',
                      }}
                      colSpan={headerFields.length}
                    >
                      {data && data.length === 0 && dateState
                        ? 'No data for the selected date range. Please select another range!'
                        : 'There are no data for this module!'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>

              {tableFooterData && (
                <TableFooter children={tableFooterData.children} />
              )}
            </Table>
          </Box>
        </Scrollbar>

        {currentPage !== undefined && (
          <TablePagination
            component="div"
            count={totalItems ? totalItems : 1}
            page={currentPage}
            rowsPerPage={limitPerPage ? limitPerPage : 10}
            rowsPerPageOptions={[5, 10, 25]}
            onPageChange={(event, page) => onPageChange(event, page)}
            onRowsPerPageChange={event => onChangeRowsPerPage(event)}
          />
        )}
      </Card>
    </Box>
  );
};

export default DynamicTable;
