import { Box, Grid } from '@material-ui/core';
import GridFields from '../GridFields';
import { coAuthFormGridFields } from 'src/enums/shared/gridFields/coAuthFormGridFields';
import { useSelector } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';

const CoAuthForm = () => {
  var coAuthData = {};
  const authData = useSelector(authSelector.authData);
  const loading = useSelector(statusSelector.loading);

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
          width: '100%',
        }}
      >
        <Grid container spacing={3}>
          <GridFields gridFields={coAuthFormGridFields()} data={coAuthData} />
        </Grid>
      </Box>
    );
  }
};

export default CoAuthForm;
