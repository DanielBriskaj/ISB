import { Box, Grid } from '@material-ui/core';
import glSelector from 'src/modules/GL/glSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import { useSelector } from 'react-redux';
import GridFields from '../GridFields';
import { glFormGridFields } from 'src/enums/shared/gridFields/glFormGridFields';
import { glFormGridFields1 } from 'src/enums/shared/gridFields/glFormGridFields';
import { CircularProgress } from '@material-ui/core';
import authSelector from 'src/modules/shared/authentication/authSelector';

const GlForm = () => {
  const glData = useSelector(glSelector.glData);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
        p: 3,
      }}
    >
      <Grid container spacing={3} sx={{ mb: 2 }}>
        {loading ? (
          <CircularProgress color="inherit" />
        ) : (
          <GridFields
            gridFields={glFormGridFields(role === 'ACCOUNTING_AUTHORIZER')}
            data={glData}
          />
        )}
      </Grid>
      <GridFields gridFields={glFormGridFields1()} data={glData} />
    </Box>
  );
};

export default GlForm;
