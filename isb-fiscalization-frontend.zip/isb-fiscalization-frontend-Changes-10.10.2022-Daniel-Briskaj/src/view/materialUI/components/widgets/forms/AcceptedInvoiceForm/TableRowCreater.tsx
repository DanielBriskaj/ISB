import React, { useState, useEffect } from 'react';
import { Box, Grid, TextField, Button } from '@material-ui/core';
import { useForm } from 'react-hook-form';
import Plus from 'src/icons/Plus';
import DataGridIvoices from './DataGridIvoices';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import { useSelector } from 'react-redux';
import Select from 'react-select';
import ReactSelect from 'src/view/materialUI/components/ReactSelect';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

const TableRowCreater = ({
  glOptionsAndFunctions,
  branchesOptionsAndFunctions,
  setValue,
  getValues,
  creditOptions,
  errors,
}) => {
  const invoice = useSelector(invoiceSelector.invoiceData);
  const [GLTableItems, setGLTableItems] = useState([]);
  const [glValue, setGLValue] = useState(null);
  const [branchValue, setBranchValue] = useState(null);
  const [creditValue, setCreditValue] = useState(null);
  const {
    register: register2,
    setValue: setValue2,
    handleSubmit: handleSubmit2,
    reset: reset2,
    formState: { errors: errors2 },
  } = useForm();

  const authorizationPayload = useSelector(authSelector.authData);

  const onSubmit = data => {
    const GLTableITemId = GLTableItems.length + 1;
    data['id'] = GLTableITemId;
    setGLTableItems([...GLTableItems, data]);
    setGLValue(null);
    setBranchValue(null);
    setCreditValue(null);
    reset2({
      gl: null,
      branch: null,
      debitCredit: null,
      description: null,
      value: 0,
    });
  };

  useEffect(() => {
    invoice?.invoiceGls && setGLTableItems(invoice?.invoiceGls);
  }, [invoice]);

  useEffect(() => {
    setValue('invoiceGls', [...GLTableItems]);
  }, [GLTableItems]);

  return (
    <form>
      <Box
        sx={{
          minHeight: '100%',
          pt: 0,
        }}
      >
        <Grid container spacing={3}>
          {authorizationPayload &&
            authorizationPayload.role &&
            authorizationPayload.role === ROLES.ACCOUNTING_INPUT && (
              <React.Fragment>
                <Grid item md={2} xs={12}>
                  <ReactSelect
                    name="gl"
                    placeholder="GL Code"
                    {...register2('gl', { required: true })}
                    options={glOptionsAndFunctions?.glOptions}
                    errors={errors2}
                    handleSelect={option => {
                      setValue2('gl', option?.value ?? null);
                      setGLValue(option);
                    }}
                    selectedValue={glValue}
                    handleOnInputChange={event => {
                      glOptionsAndFunctions?.handleSearchGl(event);
                    }}
                    handleOnMenuScrollToBottom={event => {
                      glOptionsAndFunctions?.handleGlScrollToBottom(event);
                    }}
                    handleResetSearch={glOptionsAndFunctions?.handleResetSearch}
                  />
                </Grid>
                <Grid item md={2} xs={12}>
                  <ReactSelect
                    name="branch"
                    placeholder="BR Code"
                    {...register2('branch', { required: true })}
                    options={branchesOptionsAndFunctions?.branchesOptions}
                    errors={errors2}
                    handleSelect={option => {
                      setValue2('branch', option?.value ?? null);
                      setBranchValue(option);
                    }}
                    selectedValue={branchValue}
                    handleOnMenuScrollToBottom={event => {
                      branchesOptionsAndFunctions?.handleBranchesScrollToBottom(
                        event,
                      );
                    }}
                    handleOnInputChange={event => {
                      branchesOptionsAndFunctions?.handleSearchBranch(event);
                    }}
                    handleResetSearch={
                      branchesOptionsAndFunctions?.handleResetSearch
                    }
                  />
                </Grid>
                <Grid item md={2} xs={12}>
                  <ReactSelect
                    name="debitCredit"
                    placeholder="Debit/Credit"
                    options={creditOptions}
                    {...register2('debitCredit', { required: true })}
                    errors={errors2}
                    handleSelect={option => {
                      setValue2('debitCredit', option?.value);
                      setCreditValue(option);
                    }}
                    selectedValue={creditValue}
                    handleOnInputChange={event => {}}
                    handleOnMenuScrollToBottom={event => {}}
                  />
                </Grid>
                <Grid item md={3} xs={12}>
                  <TextField
                    label="Description"
                    variant="outlined"
                    size="small"
                    fullWidth
                    {...register2('description', { required: true })}
                  />
                </Grid>
                <Grid item md={1} xs={12}>
                  <TextField
                    label="Value"
                    variant="outlined"
                    defaultValue={0}
                    type={'number'}
                    InputProps={{ inputProps: { min: 0 } }}
                    size="small"
                    fullWidth
                    {...register2('value', { required: true })}
                  />
                </Grid>
                <Grid item md={2} xs={12}>
                  <Button
                    color={'primary'}
                    size="large"
                    variant="outlined"
                    startIcon={<Plus style={{ marginRight: 0 }} />}
                    onClick={handleSubmit2(onSubmit)}
                  >
                    Add Item
                  </Button>
                </Grid>
                <Grid item md={12} xs={12}>
                  {(errors2.gl ||
                    errors2.branch ||
                    errors2.debitCredit ||
                    errors2.description) && (
                    <span style={{ color: 'red' }}>
                      Make sure you have filled all the fields
                    </span>
                  )}
                </Grid>
              </React.Fragment>
            )}
          <Grid item md={12} xs={12}>
            <DataGridIvoices
              getValues={getValues}
              rows={GLTableItems}
              changeState={e => setGLTableItems(e)}
            />
            {errors?.invoiceGls && GLTableItems.length === 0 && (
              <span style={{ color: 'red' }}>
                {errors?.invoiceGls?.message}
              </span>
            )}
          </Grid>
        </Grid>
      </Box>
    </form>
  );
};

export default TableRowCreater;
