import { DataGrid, GridAlignment } from '@material-ui/data-grid';
import { IconButton } from '@material-ui/core';
import Trash from '../../../../../../icons/Trash';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import { useSelector } from 'react-redux';

const DataGridIvoices = ({ rows, changeState, getValues }) => {
  const authorizationPayload = useSelector(authSelector.authData);

  const handeRowDelete = id => {
    const result = rows.filter(rows => rows.id !== id);
    const resultWithNewIds = result.map((data, index) => {
      data['id'] = index + 1;
      return { ...data };
    });
    changeState(resultWithNewIds);
  };
  const handleRowCellEdit = ({ field, id, value }) => {
    const newDataArray = rows.map(data => {
      if (data.id === id) {
        data[field] = value;
        return {
          ...data,
        };
      }
      return {
        ...data,
      };
    });
    changeState(newDataArray);
  };

  let columns = [
    {
      field: 'debitCredit',
      headerName: 'Debit/Credit',
      flex: 2,
      editable: false,
      renderCell: cellValues =>
        cellValues?.value?.debitCredit
          ? cellValues.value.debitCredit
          : cellValues?.value?.label
          ? cellValues?.value?.label
          : null,
    },
    {
      field: 'gl',
      headerName: 'GL Code',
      flex: 2,
      editable: false,
      renderCell: cellValues =>
        cellValues?.value?.glCode
          ? cellValues.value.glCode
          : cellValues?.value?.label
          ? cellValues?.value?.label
          : null,
    },
    {
      field: 'branch',
      headerName: 'BR Code',
      flex: 2,
      editable: false,
      renderCell: cellValues =>
        cellValues?.value?.description
          ? cellValues.value.branchCode
          : cellValues?.value?.label
          ? cellValues?.value?.label
          : null,
    },
    {
      field: 'description',
      headerName: 'Description',
      flex: 5,
      editable: true,
    },
    {
      field: 'value',
      headerName: 'Value',
      flex: 1.2,
      type: 'number',
      headerAlign: 'left' as GridAlignment,
      editable: true,
      align: 'left' as GridAlignment,
    },
    {
      field: 'currency',
      headerName: 'Currency',
      description: 'Currency',
      flex: 1.1,
      editable: false,
      renderCell: cellValues => {
        return <span>{getValues('currency')}</span>;
      },
    },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'Actions',
      flex: 1,
      cellClassName: 'actions',
      renderCell: cellValues => {
        return (
          <IconButton
            onClick={() => {
              handeRowDelete(cellValues.row.id);
            }}
          >
            <Trash fontSize="small" />
          </IconButton>
        );
      },
    },
  ];

  if (
    authorizationPayload &&
    authorizationPayload.role &&
    authorizationPayload.role !== ROLES.ACCOUNTING_INPUT
  ) {
    columns.pop();
    columns = columns.map(column => ({
      ...column,
      editable: false,
    })) as Array<any>;
  }

  return (
    <div style={{ height: 300, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        onCellEditCommit={e => handleRowCellEdit(e)}
        hideFooter={true}
      />
    </div>
  );
};

export default DataGridIvoices;
