import React, { useEffect, useState } from 'react';
import { Box, Grid } from '@material-ui/core';
import GridFields from '../GridFields';
import {
  poFormGridFields,
  poFormGridFields1,
} from 'src/enums/shared/gridFields/poFormGridFields';
import PoItemsTable from 'src/view/dashboard/po/poItems/PoItemsTable';
import WidgetPreviewer from '../../WidgetPreviewer';
import { useSelector, useDispatch } from 'react-redux';
import poSelector from 'src/modules/PO/poSelector';
import optionSelector from 'src/modules/shared/options/optionsSelector';
import optionsActions from 'src/modules/shared/options/optionsActions';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { currency } from 'src/enums/currency';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';
import { useFormContext } from 'react-hook-form';
import { debounce } from 'lodash';
import contractActions from 'src/modules/contracts/contractActions';
import contractSelector from 'src/modules/contracts/contractSelector';
import poActions from 'src/modules/PO/poActions';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

const PoForm = ({ id, isEditModal }) => {
  const [supplierMenu, setSupplierMenu] = useState([]);
  const [supplierPage, setSupplierPage] = useState(0);
  const [companyName, setCompanyName] = useState('');
  const [searchingSupplier, setSearchingSupplier] = useState<boolean>(false);

  const [contractMenu, setContractMenu] = useState([]);
  const [contractPage, setContractPage] = useState(0);
  const [contractDescription, setContractDescription] = useState('');
  const [searchingContract, setSearchingContract] = useState<boolean>(false);

  const loading = useSelector(statusSelector.loading);
  const poData = useSelector(poSelector.poData);
  const contracts = useSelector(contractSelector.contractsDataArray);
  const suppliers = useSelector(optionSelector.suppliersOptions);
  const authData = useSelector(authSelector.authData);

  const { costOwnerId, role } = authData;

  const dispatch = useDispatch();

  const { watch, setValue } = useFormContext();
  const selectedSupplier = watch('supplier');
  const [supplierCompanyName, setSupplierCompanyName] = useState('');
  const [selectedContract, setSelectedContract] = useState<any>();

  useEffect(() => {
    if (contracts?.contracts) {
      setContractMenu(state => [
        ...state,
        ...contracts?.contracts?.map(contract => ({
          label: contract.contractDescription,
          value: { id: contract.id },
        })),
      ]);
    }
  }, [contracts]);

  useEffect(() => {
    if (suppliers?.suppliers) {
      setSupplierMenu(state => [
        ...state,
        ...suppliers?.suppliers?.map(supplier => ({
          label: supplier.companyName,
          value: { id: supplier.id, name: supplier?.companyName },
        })),
      ]);
    }
  }, [suppliers]);

  useEffect(() => {
    if (role === ROLES.COST_OWNER) {
      dispatch(
        optionsActions.readSuppliers({
          companyName: companyName,
          size: 10,
          page: supplierPage,
        }),
      );
    }
  }, [companyName, supplierPage]);

  useEffect(() => {
    if (selectedSupplier?.name) {
      setSupplierCompanyName(selectedSupplier?.name);
      setContractMenu([]);
      setContractPage(0);
      setValue('contract', null);
      setSelectedContract([]);
    }
  }, [selectedSupplier?.id]);

  useEffect(() => {
    if (poData?.supplier) {
      setContractMenu([]);
      setContractPage(0);
      setSupplierCompanyName(poData?.supplier?.companyName);
    }
  }, [poData]);

  const handleSupplierOnMenuScrollToBottom = event => {
    if (supplierPage < suppliers?.totalPages - 1) {
      setSupplierPage(supplierPage + 1);
    }
  };

  const handleSupplierSelect = value => {
    setSearchingSupplier(Boolean(value));
    setCompanyName(value);
    setSupplierMenu([]);
    setSupplierPage(0);
  };

  const resetSearchSupplier = () => {
    if (searchingSupplier) {
      setCompanyName('');
      setSupplierMenu([]);
      setSupplierPage(0);
      setSearchingSupplier(false);
    }
  };

  useEffect(() => {
    if (supplierCompanyName) {
      if (role !== ROLES.COST_OWNER) {
        return;
      } else
        dispatch(
          contractActions.readByCostOwner(costOwnerId, {
            description: contractDescription,
            supplierCompanyName: supplierCompanyName,
            size: 10,
            page: contractPage,
          }),
        );
    }
  }, [costOwnerId, contractDescription, contractPage, supplierCompanyName]);

  useEffect(() => {
    return () => {
      dispatch(contractActions.clearContractsArray());
      dispatch(poActions.clearPoData());
      dispatch(optionsActions.clearOptionsData());
    };
  }, []);

  const handleContractOnMenuScrollToBottom = event => {
    if (contractPage < contracts?.totalPages - 1) {
      setContractPage(contractPage + 1);
    }
  };

  const handleContractSelect = value => {
    setSearchingContract(Boolean(value));
    setContractDescription(value);
    setContractMenu([]);
    setContractPage(0);
  };

  const resetSearchContract = () => {
    if (searchingContract) {
      setContractDescription('');
      setContractMenu([]);
      setContractPage(0);
      setSearchingContract(false);
    }
  };

  const supplierOptionsAndFunctions = {
    supplierMenu,
    handleOnMenuScrollToBottom: handleSupplierOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleSupplierSelect, 300),
    handleResetSearch: resetSearchSupplier,
  };

  const contractOptionsAndFunctions = {
    contractMenu,
    handleOnMenuScrollToBottom: handleContractOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleContractSelect, 300),
    selectedContract,
    handleResetSearch: resetSearchContract,
  };

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          {typeof id === 'number' ? (
            Object.keys(poData).length !== 0 && (
              <GridFields
                gridFields={poFormGridFields(
                  supplierOptionsAndFunctions,
                  contractOptionsAndFunctions,
                  currency,
                  poData,
                  supplierCompanyName,
                  role,
                  isEditModal,
                )}
                data={poData}
              />
            )
          ) : (
            <GridFields
              gridFields={poFormGridFields(
                supplierOptionsAndFunctions,
                contractOptionsAndFunctions,
                currency,
                poData,
                supplierCompanyName,
                role,
                isEditModal,
              )}
              data={poData}
            />
          )}
          <Grid item md={12} xs={12}>
            <WidgetPreviewer
              element={<PoItemsTable />}
              name="Purchase Order Items"
            />
          </Grid>
          <GridFields
            gridFields={poFormGridFields1(poData, role, isEditModal)}
            data={poData}
          />
        </Grid>
      </Box>
    );
  }
};

export default PoForm;
