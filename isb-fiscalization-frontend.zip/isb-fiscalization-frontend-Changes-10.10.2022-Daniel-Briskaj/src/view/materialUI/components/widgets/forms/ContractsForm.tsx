import { useEffect, useState } from 'react';
import { Box, Grid } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import optionSelector from 'src/modules/shared/options/optionsSelector';
import { productDescription } from 'src/enums/productDescription';
import { currency } from 'src/enums/currency';
import GridFields from '../GridFields';
import { contractsFormGridFields } from 'src/enums/shared/gridFields/contractsFormGridFields';
import optionsActions from 'src/modules/shared/options/optionsActions';
import authSelector from 'src/modules/shared/authentication/authSelector';
import LoadingScreen from '../../LoadingScreen';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import { debounce } from 'lodash';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import { glActions } from 'src/modules/GL/glActions';
import glSelector from 'src/modules/GL/glSelector';

const ContractsForm = props => {
  const { isFormDisabled, type, contract } = props;
  const [supplierMenu, setSupplierMenu] = useState([]);
  const [supplierPage, setSupplierPage] = useState(0);
  const [companyName, setCompanyName] = useState('');
  const [searchingSupplier, setSearchingSupplier] = useState(false);

  const [branchMenu, setBranchMenu] = useState([]);
  const [branchPage, setBranchPage] = useState(0);
  const [branchCode, setBranchCode] = useState('');
  const [searchingBranches, setSearchingBranches] = useState(false);

  const [costOwnerMenu, setCostOwnerMenu] = useState([]);
  const [costOwnerPage, setCostOwnerPage] = useState(0);

  const [glOptionsMenu, setGlOptionsMenu] = useState<
    Array<{ value: string; label: string }>
  >([]);
  const [glPage, setGlPage] = useState<number>(0);
  const [glCode, setGlCode] = useState<string>();
  const [searchingGl, setSearchingGl] = useState<boolean>(false);

  const branches = useSelector(optionSelector.branchesOptions);
  const costOwners = useSelector(optionSelector.costOwnersOptions);
  const glArray = useSelector(glSelector.glsDataArray);
  const suppliers = useSelector(optionSelector.suppliersOptions);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const { role, costOwnerCode, costOwnerId } = authData;

  const dispatch = useDispatch();

  useEffect(() => {
    if (branches?.branches) {
      setBranchMenu(state => [
        ...state,
        ...branches?.branches?.map(branch => ({
          label: `${branch?.branchCode} - ${branch?.description}`,
          value: {
            id: branch.id,
          },
        })),
      ]);
    }
  }, [branches]);

  useEffect(() => {
    if (costOwners?.costOwners) {
      const nonAuthCostOwners = costOwners?.costOwners?.filter(
        costOwner => costOwner?.isAuthorizer === false,
      );
      setCostOwnerMenu(state => [
        ...state,
        ...nonAuthCostOwners?.map(costOwner => ({
          label: `${costOwner?.code} - ${costOwner?.ownerName}`,
          value: {
            id: costOwner.id,
            code: costOwner.code,
          },
        })),
      ]);
    }
  }, [costOwners]);

  useEffect(() => {
    if (glArray?.gl) {
      setGlOptionsMenu(state => [
        ...state,
        ...glArray?.gl?.map(gl => ({
          label: `${gl?.glCode} - ${gl?.description}`,
          value: {
            id: gl?.id,
          },
        })),
      ]);
    }
  }, [glArray]);

  useEffect(() => {
    if (suppliers?.suppliers) {
      setSupplierMenu(state => [
        ...state,
        ...suppliers?.suppliers?.map(supplier => ({
          label: supplier.companyName,
          value: {
            id: supplier.id,
          },
        })),
      ]);
    }
  }, [suppliers]);

  useEffect(() => {
    if (role === ROLES.PROCUREMENT_INPUT) {
      dispatch(
        optionsActions.readCostOwners({
          page: costOwnerPage,
          size: 200,
          approved: 'APPROVED',
          sort: `code,asc`,
        }),
      );
    }
  }, [costOwnerPage]);

  const handleCostOwnerOnMenuScrollToBottom = event => {
    if (costOwnerPage < costOwners?.totalPages - 1) {
      setCostOwnerPage(costOwnerPage + 1);
    }
  };

  const handleCostOwnerSelect = () => {};
  const resetSearchCostOwner = () => {};

  useEffect(() => {
    if (role === ROLES.PROCUREMENT_INPUT || role === ROLES.COST_OWNER) {
      dispatch(
        optionsActions.readBranches({
          size: 10,
          page: branchPage,
          approved: 'APPROVED',
          branchCode: branchCode,
          sort: `branchCode,asc`,
        }),
      );
    }
  }, [branchPage, branchCode]);

  useEffect(() => {
    if (role === ROLES.PROCUREMENT_INPUT || role === ROLES.COST_OWNER) {
      dispatch(
        glActions.readGl({
          glCode: glCode,
          size: 10,
          approved: 'APPROVED',
          page: glPage,
          sort: `glCode,asc`,
        }),
      );
    }
  }, [glPage, glCode]);

  const handleBranchOnMenuScrollToBottom = event => {
    if (branchPage < branches?.totalPages - 1) {
      setBranchPage(branchPage + 1);
    }
  };
  const handleBranchSelect = value => {
    setSearchingBranches(Boolean(value));
    setBranchCode(value);
    setBranchMenu([]);
    setBranchPage(0);
  };
  const resetSearchBranch = () => {
    if (searchingBranches) {
      setBranchCode('');
      setBranchMenu([]);
      setBranchPage(0);
      setSearchingBranches(false);
    }
  };

  useEffect(() => {
    if (role === ROLES.PROCUREMENT_INPUT || role === ROLES.COST_OWNER) {
      dispatch(
        optionsActions.readSuppliers({
          companyName: companyName,
          size: 10,
          page: supplierPage,
          sort: `companyName,asc`,
        }),
      );
    }
  }, [companyName, supplierPage]);

  const handleSupplierOnMenuScrollToBottom = event => {
    if (supplierPage < suppliers?.totalPages - 1) {
      setSupplierPage(supplierPage + 1);
    }
  };

  const handleSupplierSelect = value => {
    setSearchingSupplier(Boolean(value));
    setCompanyName(value);
    setSupplierMenu([]);
    setSupplierPage(0);
  };

  const resetSearchSupplier = () => {
    if (searchingSupplier) {
      setCompanyName('');
      setSupplierMenu([]);
      setSupplierPage(0);
      setSearchingSupplier(false);
    }
  };

  const supplierOptionsAndFunctions = {
    supplierMenu,
    handleOnMenuScrollToBottom: handleSupplierOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleSupplierSelect, 500),
    handleResetSearch: resetSearchSupplier,
  };

  const costOwnerOptionsAndFunctions = {
    costOwnerMenu,
    handleOnMenuScrollToBottom: handleCostOwnerOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleCostOwnerSelect, 500),
    handleResetSearch: resetSearchCostOwner,
  };

  const branchesOptionsAndFunctions = {
    branchMenu,
    handleOnMenuScrollToBottom: handleBranchOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleBranchSelect, 500),
    handleResetSearch: resetSearchBranch,
  };

  const handleGlOnMenuScrollToBottom = event => {
    if (glPage < glArray?.totalPages - 1) {
      setGlPage(glPage + 1);
    }
  };

  const handleGlSelect = value => {
    setSearchingGl(Boolean(value));
    setGlCode(value);
    setGlOptionsMenu([]);
    setGlPage(0);
  };
  const resetSearchGl = () => {
    if (searchingGl) {
      setGlCode('');
      setGlOptionsMenu([]);
      setGlPage(0);
      setSearchingGl(false);
    }
  };

  const GLOptionsAndFunctions = {
    glOptionsMenu,
    handleOnMenuScrollToBottom: handleGlOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleGlSelect, 500),
    handleResetSearch: resetSearchGl,
  };

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <GridFields
            gridFields={contractsFormGridFields(
              currency,
              productDescription,
              supplierOptionsAndFunctions,
              branchesOptionsAndFunctions,
              costOwnerOptionsAndFunctions,
              contract,
              role,
              isFormDisabled,
              type,
              costOwnerCode,
              costOwnerId,
              GLOptionsAndFunctions,
              props?.isVat?.toString() === 'false',
            )}
            data={contract}
          />
        </Grid>
      </Box>
    );
  }
};

export default ContractsForm;
