import { Box, Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { importContractFormGridFields } from 'src/enums/shared/gridFields/budgetFormGridFields';
import GridFields from '../../GridFields';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import { debounce } from 'lodash';

const ImportContractForm: React.FC = () => {
  const dispatch = useDispatch();
  const allBudgets = useSelector(budgetSelector.allBudgets);
  const budgetData = useSelector(budgetSelector.budgetData);
  const contractsToImport = useSelector(budgetSelector.contractsToImport);
  const [budgetOptions, setBudgetOptions] = useState([]);
  const [contractsOptions, setContractsOptions] = useState([]);
  const [budgetPage, setBudgetPage] = useState<number>(0);
  const [searchValue, setSearchValue] = useState<string>();
  const [importPage, setImportPage] = useState<number>(0);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  useEffect(() => {
    if (allBudgets?.budgets) {
      setBudgetOptions(state => [
        ...state,
        ...allBudgets?.budgets?.map(budget => ({
          label: budget?.name,
          value: {
            id: budget?.id,
            name: budget?.name,
            year: budget?.year,
          },
        })),
      ]);
    }
  }, [allBudgets]);

  useEffect(() => {
    if (contractsToImport?.contracts) {
      setContractsOptions(state => [
        ...state,
        ...contractsToImport?.contracts?.map(contract => ({
          label: `${contract?.contractCode} - ${contract?.supplier?.companyName} - ${contract?.contractDescription}`,
          value: {
            id: contract?.id,
          },
        })),
      ]);
    }
  }, [contractsToImport]);

  useEffect(() => {
    dispatch(
      budgetActions.getAllBudgets({
        size: 10,
        page: budgetPage,
        budgetStatus: 'NEW',
      }),
    );
  }, [budgetPage]);

  useEffect(() => {
    dispatch(
      budgetActions.contractsToImport({
        isBudget: true,
        value: searchValue,
        size: 10,
        page: importPage,
      }),
    );
  }, [searchValue, importPage]);

  useEffect(() => {
    return () => {
      dispatch(budgetActions.clearBudgetOptions());
    };
  }, []);

  const handleScrollToBottom = event => {
    if (budgetPage < allBudgets?.totalPages - 1) {
      setBudgetPage(budgetPage + 1);
    }
  };

  const handleContractScrollToBottom = event => {
    if (importPage < contractsToImport?.totalPages - 1) {
      setImportPage(importPage + 1);
    }
  };

  const handleSearchContract = value => {
    setIsSearching(Boolean(value));
    setSearchValue(value);
    setContractsOptions([]);
    setImportPage(0);
  };

  const resetSearchContract = () => {
    if (isSearching) {
      setSearchValue('');
      setContractsOptions([]);
      setImportPage(0);
      setIsSearching(false);
    }
  };

  const budgetOptionsAndFunctions = {
    budgetOptions,
    handleScrollToBottom,
  };

  const contractOptionsAndFunctions = {
    contractsOptions,
    handleSearchContract: debounce(handleSearchContract, 500),
    handleContractScrollToBottom,
    handleResetSearch: resetSearchContract,
  };

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
        p: 3,
      }}
    >
      <Grid container spacing={3}>
        <GridFields
          gridFields={importContractFormGridFields(
            budgetOptionsAndFunctions,
            contractOptionsAndFunctions,
          )}
          data={budgetData}
        />
      </Grid>
    </Box>
  );
};

export default ImportContractForm;
