import React, { useEffect, useState } from 'react';
import { Box, Grid } from '@material-ui/core';
import GridFields from '../GridFields';
import PrItemsTable from 'src/view/dashboard/pr/prItems/PrItemsTable';
import WidgetPreviewer from '../../WidgetPreviewer';
import { useSelector, useDispatch } from 'react-redux';
import prSelector from 'src/modules/PR/prSelector';
import optionSelector from 'src/modules/shared/options/optionsSelector';
import optionsActions from 'src/modules/shared/options/optionsActions';
import { currency } from 'src/enums/currency';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';
import {
  prFormGridFields,
  prFormGridFields1,
  prFormGridFields2,
} from 'src/enums/shared/gridFields/prFormGridFields';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { debounce } from 'lodash';
import AvailableFundsTable from 'src/view/dashboard/pr/availableFunds/availableFundsTable';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

const PrForm = props => {
  const { id, isEditModal, previousCurrency } = props;
  const [supplierMenu, setSupplierMenu] = useState([]);
  const [supplierPage, setSupplierPage] = useState(0);
  const [companyName, setCompanyName] = useState('');
  const [searchingSupplier, setSearchingSupplier] = useState<boolean>(false);

  const loading = useSelector(statusSelector.loading);
  const prData = useSelector(prSelector.prData);
  const suppliers = useSelector(optionSelector.suppliersOptions);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const dispatch = useDispatch();

  useEffect(() => {
    if (suppliers?.suppliers) {
      setSupplierMenu(state => [
        ...state,
        ...suppliers?.suppliers?.map(supplier => ({
          label: supplier.companyName,
          value: { id: supplier.id },
        })),
      ]);
    }
  }, [suppliers]);

  useEffect(() => {
    if (role === ROLES.COST_OWNER) {
      dispatch(
        optionsActions.readSuppliers({
          companyName: companyName,
          size: 10,
          page: supplierPage,
        }),
      );
    }
  }, [companyName, supplierPage]);

  const handleSupplierOnMenuScrollToBottom = event => {
    if (supplierPage < suppliers?.totalPages - 1) {
      setSupplierPage(supplierPage + 1);
    }
  };

  const handleSupplierSelect = value => {
    setSearchingSupplier(Boolean(value));
    setCompanyName(value);
    setSupplierMenu([]);
    setSupplierPage(0);
  };

  const resetSearchSupplier = () => {
    if (searchingSupplier) {
      setCompanyName('');
      setSupplierMenu([]);
      setSupplierPage(0);
      setSearchingSupplier(false);
    }
  };

  const supplierOptionsAndFunctions = {
    supplierMenu,
    handleOnMenuScrollToBottom: handleSupplierOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleSupplierSelect, 300),
    handleResetSearch: resetSearchSupplier,
  };
  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          {typeof id === 'number' ? (
            Object.keys(prData).length !== 0 && (
              <GridFields
                gridFields={prFormGridFields(
                  supplierOptionsAndFunctions,
                  currency,
                  prData,
                  authData.division,
                  role,
                  isEditModal,
                  previousCurrency,
                )}
                data={prData}
              />
            )
          ) : (
            <GridFields
              gridFields={prFormGridFields(
                supplierOptionsAndFunctions,
                currency,
                prData,
                authData.division,
                role,
                isEditModal,
                previousCurrency,
              )}
              data={prData}
            />
          )}
          <Grid item md={12} xs={12}>
            <WidgetPreviewer
              element={<PrItemsTable />}
              name="Purchase Request Items"
            />
          </Grid>
          <GridFields
            gridFields={prFormGridFields1(role, prData, isEditModal)}
            data={prData}
          />
          <Grid item md={12} xs={12}>
            <WidgetPreviewer
              element={<AvailableFundsTable />}
              name="Available Funds"
            />
          </Grid>
          <GridFields gridFields={prFormGridFields2()} data={prData} />
        </Grid>
      </Box>
    );
  }
};

export default PrForm;
