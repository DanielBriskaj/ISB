import { Box, Grid } from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import GridFields from '../GridFields';
import authSelector from 'src/modules/shared/authentication/authSelector';
import LoadingScreen from '../../LoadingScreen';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import userSelector from 'src/modules/users/userSelector';
import { userFormGridFields } from 'src/enums/shared/gridFields/userFormGridFields';
import { useEffect, useState } from 'react';
import userActions from 'src/modules/users/userActions';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import costOwnerActions from 'src/modules/costowners/costOwnerActions';
import costOwnerSelector from 'src/modules/costowners/costOwnerSelector';

const UserForm = ({ selectedRole }) => {
  const dispatch = useDispatch();
  const userData = useSelector(userSelector.userData);
  const loading = useSelector(statusSelector.loading);
  const costOwners = useSelector(costOwnerSelector.costOwnersDataArray);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const [costOwnerOptions, setCostOwnersOptions] = useState([
    { label: '- Clear Cost Owner -', value: '' },
  ]);

  useEffect(() => {
    if (role === ROLES.ACCOUNTING_INPUT) {
      dispatch(costOwnerActions.getAssignedCO(false));
    }
  }, []);

  useEffect(() => {
    if (costOwners?.length > 0) {
      setCostOwnersOptions(state => [
        ...state,
        ...costOwners?.map(costOwner => ({
          label: `${costOwner.code} - ${costOwner.ownerName}`,
          value: {
            id: costOwner.id,
          },
        })),
      ]);
    }
  }, [costOwners]);

  useEffect(() => {
    return () => {
      dispatch(userActions.clearUserData());
      dispatch(costOwnerActions.clearCOData());
    };
  }, []);

  if (loading || !userData?.name) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3} sx={{ mb: 2 }}>
          <GridFields
            gridFields={userFormGridFields(
              costOwnerOptions,
              role === 'ACCOUNTING_AUTHORIZER' ||
                (selectedRole !== ROLES.COST_OWNER &&
                  selectedRole !== ROLES.COST_OWNER_AUTHORIZER),
              userData,
              selectedRole,
            )}
            data={userData}
          />
        </Grid>
      </Box>
    );
  }
};

export default UserForm;
