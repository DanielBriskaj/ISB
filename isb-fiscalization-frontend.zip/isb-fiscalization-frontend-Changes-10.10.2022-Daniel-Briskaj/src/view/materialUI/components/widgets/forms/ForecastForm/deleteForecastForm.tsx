import { Box, Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../../LoadingScreen';
import {
  deleteForecastFormGridFields,
  monthOptions,
} from 'src/enums/shared/gridFields/forecastFormGridFields';
import GridFields from '../../GridFields';
import forecastSelector from 'src/modules/forecast/forecastSelector';
import forecastActions from 'src/modules/forecast/forecastActions';

interface ForecastFormProps {
  data: any;
}
const DeleteForecastForm: React.FC<ForecastFormProps> = ({ data }) => {
  const dispatch = useDispatch();
  const loading = useSelector(statusSelector.loading);
  const allForecasts = useSelector(forecastSelector.allForecasts);
  const [forecastOptions, setForecastOptions] = useState([]);
  const [forecastPage, setForecastPage] = useState(0);

  useEffect(() => {
    if (allForecasts?.forecasts) {
      setForecastOptions(state => [
        ...state,
        ...allForecasts?.forecasts?.map(forecast => ({
          label: forecast?.name,
          value: {
            id: forecast?.id,
            name: forecast?.name,
            month: monthOptions?.find(temp => temp?.value === forecast?.month)
              ?.label,
            year: forecast?.year,
            forecastStatus: forecast?.forecastStatus,
            dueDate: forecast?.dueDate,
          },
        })),
      ]);
    }
  }, [allForecasts]);

  useEffect(() => {
    dispatch(
      forecastActions.getAllForecasts({
        size: 10,
        page: forecastPage,
        forecastStatus: 'NEW',
      }),
    );
  }, [forecastPage]);

  useEffect(() => {
    return () => {
      dispatch(forecastActions.clearForecastOptions());
    };
  }, []);

  const handleScrollToBottom = event => {
    if (forecastPage < allForecasts?.totalPages) {
      setForecastPage(forecastPage + 1);
    }
  };

  const forecastOptionsAndFunctions = {
    forecastOptions,
    handleScrollToBottom,
  };

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <GridFields
            gridFields={deleteForecastFormGridFields(
              forecastOptionsAndFunctions,
            )}
            data={data}
          />
        </Grid>
      </Box>
    );
  }
};

export default DeleteForecastForm;
