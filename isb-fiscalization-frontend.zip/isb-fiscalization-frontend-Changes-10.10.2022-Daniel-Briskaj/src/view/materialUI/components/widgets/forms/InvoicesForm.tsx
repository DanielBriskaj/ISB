import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  TextField,
  Typography,
  IconButton,
  Button,
} from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import ReactSelect from '../../ReactSelect';
import Download from 'src/icons/Download';
import { Controller, useFormContext } from 'react-hook-form';
import { ErrorMessage } from '@hookform/error-message';

const InvoicesForm = ({ data, tab }) => {
  const dispatch = useDispatch();
  const costOwners = useSelector(invoiceSelector.costOwnersOptions);
  const [costOwnerOptions, setCostOwnersOptions] = useState([]);
  const [costOwnerPage, setCostOwnerPage] = useState(0);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    dispatch(
      invoiceActions.readCostOwners({
        size: 200,
        page: costOwnerPage,
        approved: 'APPROVED',
      }),
    );
  }, [costOwnerPage]);

  const handleOnMenuScrollToBottom = event => {
    if (costOwnerPage < costOwners?.totalPages - 1) {
      setCostOwnerPage(costOwnerPage + 1);
    }
  };

  useEffect(() => {
    return () => {
      dispatch(invoiceActions.clearCostOwnerOptions());
    };
  }, []);

  useEffect(() => {
    if (costOwners?.costOwners) {
      const nonAuthCostOwners = costOwners?.costOwners?.filter(
        costOwner => costOwner?.isAuthorizer === false,
      );
      setCostOwnersOptions(state => [
        ...state,
        ...nonAuthCostOwners.map(costOwner => ({
          label: `${costOwner.code} - ${costOwner.ownerName}`,
          value: {
            id: costOwner.id,
            code: costOwner.code,
            division: costOwner.division,
            ownerName: costOwner.ownerName,
          },
        })),
      ]);
    }
  }, [costOwners]);

  const dataLabels = {
    eic: 'EIC',
    invoiceNumber: 'Invoice Number',
    receivedDate: 'Recived Date',
    dueDate: 'Due Date',
    status: 'Status',
    amount: 'Amount',
    nipt: 'NIPT',
  };

  useEffect(() => {
    setFormData({
      eic: data.eic,
      invoiceNumber: data.invoiceNumber,
      receivedDate: data.receivedDate,
      dueDate: data.dueDate,
      status: data.status,
      amount: parseFloat(data.amount.replace(/,/g, '')),
      nipt: data.NIPT,
    });
  }, [data]);

  useEffect(() => {
    if (Object.keys(formData).length > 0) {
      Object.keys(formData).map(key => {
        setValue(key, formData[key]);
      });
    }
  }, [formData]);

  const {
    register,
    setValue,
    formState: { errors },
    getValues,
    control,
  } = useFormContext();

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
        p: 3,
      }}
    >
      <Grid container spacing={3}>
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <Typography fontWeight={'bold'}>Invoice Data</Typography>
            <Button
              size="small"
              variant="contained"
              sx={{
                backgroundColor: '#ff0000',
                ':hover': {
                  backgroundColor: '#ff0000',
                  opacity: 0.8,
                },
              }}
              onClick={() =>
                dispatch(invoiceActions.exportPdfFile({ eic: data.eic }))
              }
            >
              <Download />
              PDF
            </Button>
          </Box>
        </Grid>
        {Object.keys(formData).length > 0 &&
          Object.keys(formData).map(key => {
            return (
              <Grid item md={6} xs={12}>
                <Controller
                  render={({ field }) => (
                    <TextField
                      fullWidth
                      {...field}
                      disabled={true}
                      label={dataLabels[key]}
                      size="small"
                      variant="outlined"
                      InputLabelProps={{ shrink: true }}
                    />
                  )}
                  name={key}
                  control={control}
                  defaultValue={formData[key]}
                />
              </Grid>
            );
            // return (
            //   <Grid item md={6} xs={12}>
            //     <TextField
            //       label={dataLabels[key]}
            //       fullWidth
            //       size="small"
            //       name={key}
            //       ref={register}
            //       {...register(`${key}`)}
            //       variant="outlined"
            //       value={formData[key]}
            //       disabled={true}
            //     />
            //   </Grid>
            // );
          })}
        {tab === 'invoices' && (
          <>
            <Grid item md={12} xs={12}>
              <Typography sx={{ fontWeight: 'bold' }}>
                Choose Cost Owner
              </Typography>
            </Grid>
            <Grid item xs={12} md={12}>
              <ReactSelect
                options={costOwnerOptions}
                placeholder="Cost Owners"
                name="costOwner"
                handleSelect={option => {
                  setValue('costOwner', option.value);
                }}
                ref={register}
                {...register('costOwner')}
                defaultValue={costOwnerOptions[0]}
                handleOnMenuScrollToBottom={event => {
                  handleOnMenuScrollToBottom(event);
                }}
                handleOnInputChange={event => {}}
                disabled={false}
              />
              <ErrorMessage
                errors={errors}
                name="costOwner"
                render={({ message }) => (
                  <p
                    style={{
                      color: 'red',
                      marginTop: '0px',
                      padding: '5px 10px 0px 0px',
                    }}
                  >
                    {message}
                  </p>
                )}
              />
            </Grid>
          </>
        )}
      </Grid>
    </Box>
  );
};

export default InvoicesForm;
