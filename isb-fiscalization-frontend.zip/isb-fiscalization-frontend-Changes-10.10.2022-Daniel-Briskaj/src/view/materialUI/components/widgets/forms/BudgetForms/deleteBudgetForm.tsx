import { Box, Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../../LoadingScreen';
import { deletebudgetFormGridFields } from 'src/enums/shared/gridFields/budgetFormGridFields';
import GridFields from '../../GridFields';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';

interface BudgetFormProps {
  data: any;
}
const DeleteBudgetForm: React.FC<BudgetFormProps> = ({ data }) => {
  const dispatch = useDispatch();
  const loading = useSelector(statusSelector.loading);
  const allBudgets = useSelector(budgetSelector.allBudgets);
  const [budgetOptions, setBudgetOptions] = useState([]);
  const [budgetPage, setBudgetPage] = useState(0);

  useEffect(() => {
    if (allBudgets?.budgets) {
      setBudgetOptions(state => [
        ...state,
        ...allBudgets?.budgets?.map(budget => ({
          label: budget?.name,
          value: {
            id: budget?.id,
            name: budget?.name,
            year: budget?.year,
            budgetStatus: budget?.budgetStatus,
            dueDate: budget?.dueDate,
          },
        })),
      ]);
    }
  }, [allBudgets]);

  useEffect(() => {
    dispatch(
      budgetActions.getAllBudgets({
        size: 10,
        page: budgetPage,
        budgetStatus: 'NEW',
      }),
    );
  }, [budgetPage]);

  useEffect(() => {
    return () => {
      dispatch(budgetActions.clearBudgetOptions());
    };
  }, []);

  const handleScrollToBottom = event => {
    if (budgetPage < allBudgets?.totalPages - 1) {
      setBudgetPage(budgetPage + 1);
    }
  };

  const budgetOptionsAndFunctions = {
    budgetOptions,
    handleScrollToBottom,
  };
  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <GridFields
            gridFields={deletebudgetFormGridFields(budgetOptionsAndFunctions)}
            data={data}
          />
        </Grid>
      </Box>
    );
  }
};

export default DeleteBudgetForm;
