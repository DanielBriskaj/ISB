import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  TextField,
  Typography,
  IconButton,
  Button,
} from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import costOwnerInvoiceSelector from 'src/modules/costOwnersInvoices/costOwnerInvoicesSelector';
import costOwnerInvoicesActions from 'src/modules/costOwnersInvoices/costOwnerInvoicesActions';
import poActions from 'src/modules/PO/poActions';
import poSelector from 'src/modules/PO/poSelector';
import ReactSelect from '../../ReactSelect';
import Download from 'src/icons/Download';
import { useFormContext } from 'react-hook-form';
import { ErrorMessage } from '@hookform/error-message';
import optionSelector from 'src/modules/shared/options/optionsSelector';
import optionsActions from 'src/modules/shared/options/optionsActions';
import authSelector from 'src/modules/shared/authentication/authSelector';
import GridFields from '../GridFields';
import { costOwnerInvoiceGridFields } from 'src/enums/shared/gridFields/costOwnerInvoiceGridFields';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';
import contractActions from 'src/modules/contracts/contractActions';
import contractSelector from 'src/modules/contracts/contractSelector';
import { debounce } from 'lodash';

const CostOwnerInvoicesForm = ({ data }) => {
  const dispatch = useDispatch();
  const contracts = useSelector(contractSelector.contractsDataArray);
  const [contractPage, setContractPage] = useState(0);
  const po = useSelector(optionSelector.poOptions);
  const [poPage, setPoPage] = useState(0);
  const [contractsOptions, setContractsOptions] = useState([]);
  const [poOptions, setPoOptions] = useState([]);
  const [contractDescription, setContractDescription] = useState<string>();
  const [searchingContract, setSearchingContract] = useState<boolean>(false);

  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const { costOwnerId } = authData;

  useEffect(() => {
    dispatch(
      contractActions.readByCostOwner(costOwnerId, {
        page: contractPage,
        contractStatus: 'ACTIVE',
        size: 10,
        supplierCompanyName: data.supplierName,
        description: contractDescription,
      }),
    );
  }, [costOwnerId, contractPage, contractDescription]);

  useEffect(() => {
    return () => {
      dispatch(contractActions.clearContractsArray());
      dispatch(optionsActions.clearOptionsData());
    };
  }, []);

  const handleContractOnMenuScrollToBottom = event => {
    if (contractPage < contracts?.totalPages - 1) {
      setContractPage(contractPage + 1);
    }
  };

  const handleContractSelect = value => {
    setSearchingContract(Boolean(value));
    setContractDescription(value);
    setContractsOptions([]);
    setContractPage(0);
  };

  const debounceSearchContract = debounce(handleContractSelect, 300);

  const resetSearchContract = () => {
    if (searchingContract) {
      setContractDescription('');
      setContractsOptions([]);
      setContractPage(0);
      setSearchingContract(false);
    }
  };

  useEffect(() => {
    dispatch(
      optionsActions.fetchPo({
        poStatus: 'APPROVED',
        costOwner: costOwnerId,
        size: 10,
        page: poPage,
      }),
    );
  }, [costOwnerId, poPage]);

  const handlePoOnMenuScrollToBottom = event => {
    if (poPage < po?.totalPages - 1) {
      setPoPage(poPage + 1);
    }
  };

  useEffect(() => {
    if (contracts?.contracts) {
      setContractsOptions(state => [
        ...state,
        ...contracts?.contracts?.map(contract => ({
          label: ` ${contract.contractCode} - ${contract?.contractDescription}`,
          value: {
            id: contract.id,
          },
        })),
      ]);
    }
  }, [contracts]);

  useEffect(() => {
    if (po?.po) {
      setPoOptions(state => [
        ...state,
        ...po?.po?.map(po => ({
          label: po.poNumber,
          value: {
            id: po.id,
          },
        })),
      ]);
    }
  }, [po]);

  const {
    register,
    setValue,
    formState: { errors },
    getValues,
  } = useFormContext();

  useEffect(() => {
    Object.keys(data).map(key => {
      if (key === 'amount') {
        setValue(key, parseFloat(data[key].replace(/,/g, '')));
      } else {
        setValue(key, data[key]);
      }
    });
  }, []);

  const contractOptionsAndFunctions = {
    contractsOptions,
    handleOnMenuScrollToBottom: handleContractOnMenuScrollToBottom,
    handleOnInputChange: debounceSearchContract,
    handleResetSearch: resetSearchContract,
  };

  const poOptionsAndFunctions = {
    poOptions,
    handleOnMenuScrollToBottom: handlePoOnMenuScrollToBottom,
    handleOnInputChange: () => {},
    handleResetSearch: () => {},
  };

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <Grid item md={12} xs={12}>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <Typography fontWeight={'bold'}>Invoice Data</Typography>
              {!data.supplierId ? (
                <Button
                  size="small"
                  variant="contained"
                  sx={{
                    backgroundColor: '#ff0000',
                    ':hover': {
                      backgroundColor: '#ff0000',
                      opacity: 0.8,
                    },
                  }}
                  onClick={() =>
                    dispatch(
                      costOwnerInvoicesActions.downloadPdf({ eic: data.eic }),
                    )
                  }
                >
                  <Download />
                  PDF
                </Button>
              ) : (
                <></>
              )}
            </Box>
          </Grid>
          <GridFields
            gridFields={costOwnerInvoiceGridFields(
              contractOptionsAndFunctions,
              poOptionsAndFunctions,
              data,
            )}
            data={data}
          />
        </Grid>
      </Box>
    );
  }
};

export default CostOwnerInvoicesForm;
