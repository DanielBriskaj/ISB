import { Box, Grid } from '@material-ui/core';
import { city } from 'src/enums/city';
import GridFields from '../GridFields';
import { branchesFormGridFields } from 'src/enums/shared/gridFields/branchesFormGridFields';
import { branchesFormGridFields1 } from 'src/enums/shared/gridFields/branchesFormGridFields';
import { useSelector } from 'react-redux';
import branchSelector from 'src/modules/branches/branchSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';

const BranchesForm = () => {
  const branchData = useSelector(branchSelector.branchData);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const loading = useSelector(statusSelector.loading);

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3} sx={{ mb: 2 }}>
          <GridFields
            gridFields={branchesFormGridFields(
              city,
              role === 'ACCOUNTING_AUTHORIZER',
              branchData,
            )}
            data={branchData}
          />
        </Grid>

        <GridFields gridFields={branchesFormGridFields1()} data={branchData} />
      </Box>
    );
  }
};

export default BranchesForm;
