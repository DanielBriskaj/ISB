import React, { useEffect } from 'react';
import { Box, Grid, Typography } from '@material-ui/core';
import { useSelector } from 'react-redux';
import { useFormContext } from 'react-hook-form';
import authSelector from 'src/modules/shared/authentication/authSelector';
import GridFields from '../GridFields';
import { coaInvoicesGridFields } from 'src/enums/shared/gridFields/coaInvoicesGridFields';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';

const CoaInvoicesForm = ({ data }) => {
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const { costOwnerId } = authData;

  const {
    register,
    setValue,
    formState: { errors },
    getValues,
  } = useFormContext();

  useEffect(() => {
    Object.keys(data).forEach(key => {
      setValue(key, data[key]);
      if (key === 'po') {
        setValue(key, data?.po?.poNumber);
      }
      if (key === 'contract') {
        setValue(
          key,
          `${data?.contract?.contractCode} - ${data?.contract?.contractDescription}`,
        );
      }
      if (key === 'costOwner') {
        setValue(key, data?.costOwner?.ownerName);
      }
    });
  }, [data]);

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <Grid item md={12} xs={12}>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <Typography fontWeight={'bold'}>Invoice Data</Typography>
            </Box>
          </Grid>
          <GridFields gridFields={coaInvoicesGridFields(data)} data={data} />
        </Grid>
      </Box>
    );
  }
};

export default CoaInvoicesForm;
