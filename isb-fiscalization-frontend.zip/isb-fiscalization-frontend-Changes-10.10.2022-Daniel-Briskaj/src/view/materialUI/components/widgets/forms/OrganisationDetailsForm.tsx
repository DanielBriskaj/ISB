import { Box, Button, Grid } from '@material-ui/core';
import supplierSelector from 'src/modules/suppliers/supplierSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import { useSelector } from 'react-redux';
import LoadingScreen from '../../LoadingScreen';
import GridFields from '../GridFields';
import { organisationDetailsGridFields } from 'src/enums/shared/gridFields/organisationDetailsGridFields';
import { city } from 'src/enums/city';
import { states } from 'src/enums/state';
import ArrowRight from 'src/icons/ArrowRight';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { useFormContext } from 'react-hook-form';
import { useState, useEffect } from 'react';

const Form1 = ({ setCurrentTab }) => {
  const loading = useSelector(statusSelector.loading);
  const supplierData = useSelector(supplierSelector.supplierData);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const [errorMsg, setErrorMsg] = useState(false);
  const { formState: errors } = useFormContext();

  useEffect(() => {
    if (Object.keys(errors.errors).length !== 0) {
      setErrorMsg(true);
    }
  }, [errors.errors]);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
        p: 3,
      }}
    >
      <Grid container spacing={3}>
        <GridFields
          gridFields={organisationDetailsGridFields(
            city,
            states,
            role === 'ACCOUNTING_AUTHORIZER' ||
              role === 'PROCUREMENT_AUTHORIZER' ||
              role === 'ACCOUNTING_INPUT',
            supplierData,
          )}
          data={supplierData}
        />
        <Grid item md={9} xs={7} />
        <Grid
          item
          md={3}
          xs={5}
          display="flex"
          justifyContent="end"
          alignContent="center"
        >
          <Button
            sx={{
              background: '#4caf50',
              '&:hover': { background: '#3caf40' },
            }}
            variant="contained"
            onClick={() => {
              setCurrentTab('user');
            }}
          >
            <ArrowRight fontSize="small" />
          </Button>
        </Grid>
      </Grid>
      {errorMsg && (
        <div
          style={{
            color: 'red',
            marginTop: '0px',
            padding: '5px 10px 15px 0px',
          }}
        >
          Fields not completed , check the next page
        </div>
      )}
    </Box>
  );
};

export default Form1;
