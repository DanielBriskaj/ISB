import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  TextField,
  Typography,
  IconButton,
  Button,
} from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { currency } from 'src/enums/currency';
import { useFormContext } from 'react-hook-form';
import { ErrorMessage } from '@hookform/error-message';
import optionSelector from 'src/modules/shared/options/optionsSelector';
import optionsActions from 'src/modules/shared/options/optionsActions';
import authSelector from 'src/modules/shared/authentication/authSelector';
import GridFields from '../GridFields';
import { manualInvoicesGridFields } from 'src/enums/shared/gridFields/manualInvoicesGridFields';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';
import { debounce } from 'lodash';

const ManualInvoiceForm = ({ data, isEditModal }) => {
  const dispatch = useDispatch();
  const suppliers = useSelector(optionSelector.suppliersOptions);
  const [supplierPage, setSupplierPage] = useState(0);
  const [suppliersOptions, setSuppliersOptions] = useState([]);
  const [supplierName, setSupplierName] = useState<string>();
  const [searchingSupplier, setSearchingSupplier] = useState<boolean>(false);

  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);

  const { role } = authData;

  useEffect(() => {
    dispatch(
      optionsActions.readSuppliers({
        size: 10,
        page: supplierPage,
        companyName: supplierName,
      }),
    );
  }, [supplierPage, supplierName]);

  const handleSupplierOnMenuScrollToBottom = event => {
    if (supplierPage < suppliers?.totalPages - 1) {
      setSupplierPage(supplierPage + 1);
    }
  };

  const handleSupplierSelect = value => {
    setSearchingSupplier(Boolean(value));
    setSupplierName(value);
    setSuppliersOptions([]);
    setSupplierPage(0);
  };

  const resetSearchSupplier = () => {
    if (searchingSupplier) {
      setSupplierName('');
      setSuppliersOptions([]);
      setSupplierPage(0);
      setSearchingSupplier(false);
    }
  };

  useEffect(() => {
    if (suppliers?.suppliers) {
      setSuppliersOptions(state => [
        ...state,
        ...suppliers?.suppliers?.map(supplier => ({
          label: supplier.companyName,
          value: {
            id: supplier.id,
          },
        })),
      ]);
    }
  }, [suppliers]);

  const {
    register,
    setValue,
    formState: { errors },
    getValues,
  } = useFormContext();

  useEffect(() => {
    data &&
      Object.keys(data).map(key => {
        setValue(key, data[key]);
      });
  }, []);

  const supplierOptionsAndFunctions = {
    suppliersOptions,
    handleOnMenuScrollToBottom: handleSupplierOnMenuScrollToBottom,
    handleOnInputChange: debounce(handleSupplierSelect, 500),
    handleResetSearch: resetSearchSupplier,
  };

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <Grid item md={12} xs={12}>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <Typography fontWeight={'bold'}>Manual Invoice Data</Typography>
            </Box>
          </Grid>
          <GridFields
            gridFields={manualInvoicesGridFields(
              currency,
              data,
              supplierOptionsAndFunctions,
              isEditModal,
              role,
            )}
            data={data}
          />
        </Grid>
      </Box>
    );
  }
};

export default ManualInvoiceForm;
