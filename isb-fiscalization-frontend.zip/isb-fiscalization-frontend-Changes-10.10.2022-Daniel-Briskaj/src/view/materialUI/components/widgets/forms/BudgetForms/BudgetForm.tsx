import { Box, Grid } from '@material-ui/core';
import React from 'react';
import { useSelector } from 'react-redux';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../../LoadingScreen';
import { budgetFormGridFields } from 'src/enums/shared/gridFields/budgetFormGridFields';
import GridFields from '../../GridFields';

interface BudgetFormProps {
  disabled: boolean;
  data: any;
}
const BudgetForm: React.FC<BudgetFormProps> = ({ disabled, data }) => {
  const loading = useSelector(statusSelector.loading);

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <GridFields
            gridFields={budgetFormGridFields(disabled, data)}
            data={data}
          />
        </Grid>
      </Box>
    );
  }
};

export default BudgetForm;
