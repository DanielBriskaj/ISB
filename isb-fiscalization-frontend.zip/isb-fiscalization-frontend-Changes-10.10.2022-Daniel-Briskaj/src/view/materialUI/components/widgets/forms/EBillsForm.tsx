import React, { useEffect } from 'react';
import { Box, Grid, Typography } from '@material-ui/core';
import { useSelector } from 'react-redux';
import { useFormContext } from 'react-hook-form';
import GridFields from '../GridFields';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import LoadingScreen from '../../LoadingScreen';
import { EBillsGridFields } from 'src/enums/shared/gridFields/costOwnerInvoiceGridFields';

const EBillsForm = ({ data }) => {
  const loading = useSelector(statusSelector.loading);

  const {
    register,
    setValue,
    formState: { errors },
    getValues,
  } = useFormContext();

  useEffect(() => {
    Object.keys(data).forEach(key => {
      setValue(key, data[key]);
      if (key === 'po') {
        setValue(key, data?.po?.poNumber);
      }
      if (key === 'contract') {
        setValue(
          key,
          `${data?.contract?.contractCode} - ${data?.contract?.contractDescription}`,
        );
      }
    });
  }, [data]);

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3}>
          <Grid item md={12} xs={12}>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <Typography fontWeight={'bold'}>Invoice Data</Typography>
            </Box>
          </Grid>
          <GridFields gridFields={EBillsGridFields(data)} data={data} />
        </Grid>
      </Box>
    );
  }
};

export default EBillsForm;
