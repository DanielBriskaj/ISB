import { Box, Grid } from '@material-ui/core';
import { divisions } from 'src/enums/divisions';
import costOwnerSelector from 'src/modules/costowners/costOwnerSelector';
import { useSelector } from 'react-redux';
import GridFields from '../GridFields';
import { costOwnersFormGridFields } from 'src/enums/shared/gridFields/costOwnersFormGridFields';
import { costOwnersFormGridFields1 } from 'src/enums/shared/gridFields/costOwnersFormGridFields';
import { CircularProgress } from '@material-ui/core';
import authSelector from 'src/modules/shared/authentication/authSelector';
import LoadingScreen from '../../LoadingScreen';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';

const CostOwnersForm = () => {
  const costOwnerData = useSelector(costOwnerSelector.costOwnerData);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  if (loading) {
    return <LoadingScreen />;
  } else {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <Grid container spacing={3} sx={{ mb: 2 }}>
          {loading ? (
            <CircularProgress color="inherit" />
          ) : (
            <GridFields
              gridFields={costOwnersFormGridFields(
                divisions.filter(division => division.label !== 'All'),
                role === 'ACCOUNTING_AUTHORIZER',
                costOwnerData,
              )}
              data={costOwnerData}
            />
          )}
        </Grid>
        <GridFields
          gridFields={costOwnersFormGridFields1()}
          data={costOwnerData}
        />
      </Box>
    );
  }
};

export default CostOwnersForm;
