import { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  Select,
  MenuItem,
  TextField,
  Button,
} from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import Download from 'src/icons/Download';
import { useFormContext } from 'react-hook-form';
import { glActions } from 'src/modules/GL/glActions';
import glSelector from 'src/modules/GL/glSelector';
import branchActions from 'src/modules/branches/branchActions';
import branchSelector from 'src/modules/branches/branchSelector';
import TableRowCreater from './TableRowCreater';
import { currency } from 'src/enums/currency';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import GridFields from '../../GridFields';
import { debounce } from 'lodash';
import { acceptedInvoiceGridFields } from 'src/enums/shared/gridFields/acceptedInvoiceGridFields';
import { creditOptions } from 'src/enums/creditDebit';
import moment from 'moment';
import { ErrorMessage } from '@hookform/error-message';

const AcceptedInvoiceForm = ({ data, invoice }) => {
  const dispatch = useDispatch();
  const glArray = useSelector(glSelector.glsDataArray);
  const branchesArray = useSelector(branchSelector.branchesDataArray);
  const [glOptions, setGlOptions] = useState([]);
  const [branchesOptions, setBranchesOptions] = useState([]);
  const [glPage, setGlPage] = useState(0);
  const [glCode, setGlCode] = useState('');
  const [branchesPage, setBranchesPage] = useState(0);
  const [branchCode, setBranchCode] = useState('');
  const [searchingGl, setSearchingGl] = useState(false);
  const [searchingBranches, setSearchingBranches] = useState(false);

  const authorizationPayload = useSelector(authSelector.authData);
  const { role } = authorizationPayload;
  const today = moment(new Date()).format('YYYY-MM-DD');

  useEffect(() => {
    if (glArray?.gl) {
      setGlOptions(state => [
        ...state,
        ...glArray?.gl?.map(gl => ({
          label: `${gl?.glCode} - ${gl?.description}`,
          value: {
            id: gl?.id,
            label: gl?.glCode,
          },
        })),
      ]);
    }
  }, [glArray]);

  useEffect(() => {
    if (branchesArray?.branches) {
      setBranchesOptions(state => [
        ...state,
        ...branchesArray?.branches?.map(branch => ({
          label: `${branch?.branchCode} - ${branch?.description}`,
          value: {
            id: branch?.id,
            label: (branch?.branchCode).toString(),
          },
        })),
      ]);
    }
  }, [branchesArray]);

  useEffect(() => {
    if (role === ROLES.ACCOUNTING_INPUT) {
      dispatch(
        glActions.readGl({
          glCode: glCode,
          size: 10,
          approved: 'APPROVED',
          page: glPage,
          sort: `glCode,asc`,
        }),
      );
    }
  }, [glPage, glCode]);

  useEffect(() => {
    return () => {
      dispatch(glActions.clearGLData());
      dispatch(branchActions.clearBranchData());
    };
  }, []);

  useEffect(() => {
    if (role === ROLES.ACCOUNTING_INPUT) {
      dispatch(
        branchActions.read({
          size: 10,
          page: branchesPage,
          approved: 'APPROVED',
          branchCode: branchCode,
          sort: `branchCode,asc`,
        }),
      );
    }
  }, [branchesPage, branchCode]);

  const handleGlScrollToBottom = event => {
    if (glPage < glArray?.totalPages) {
      setGlPage(glPage + 1);
    }
  };

  const handleBranchesScrollToBottom = event => {
    if (branchesPage < branchesArray?.totalPages) {
      setBranchesPage(branchesPage + 1);
    }
  };

  const handleOnInputChange = value => {
    setSearchingGl(Boolean(value));
    setGlCode(value);
    setGlPage(0);
    setGlOptions([]);
  };
  const handleSearchGl = debounce(handleOnInputChange, 300);

  const handleResetSearch = () => {
    if (searchingGl) {
      setGlCode('');
      setGlPage(0);
      setGlOptions([]);
      setSearchingGl(false);
    }
    if (searchingBranches) {
      setBranchCode('');
      setBranchesPage(0);
      setBranchesOptions([]);
      setSearchingBranches(false);
    }
  };

  const handleBranchesOnInputChange = value => {
    setSearchingBranches(Boolean(value));
    setBranchCode(value);
    setBranchesPage(0);
    setBranchesOptions([]);
  };
  const handleSearchBranch = debounce(handleBranchesOnInputChange, 300);

  const glOptionsAndFunctions = {
    glOptions,
    handleGlScrollToBottom,
    handleSearchGl,
    handleResetSearch,
  };

  const branchesOptionsAndFunctions = {
    branchesOptions,
    handleBranchesScrollToBottom,
    handleSearchBranch,
    handleResetSearch,
  };

  const dataLabels = {
    suplier: 'Supplier',
    invoiceNumber: 'Invoice Number',
    receivedDate: 'Recived Date',
    dueDate: 'Due Date',
    status: 'Status',
    nipt: 'NIPT',
    nivf: 'NIVF',
    valueDate: 'Value Date',
    subject: 'Subject',
    invoiceValue: 'Invoice Value',
    currency: 'Currency',
    preparedBy: 'Prepared By',
    checkedBy: 'Checked By',
    bankName: 'Bank Name',
    iban: 'IBAN',
  };

  const {
    register,
    setValue,
    getValues,
    formState: { errors },
    watch,
  } = useFormContext();

  useEffect(() => {
    Object.keys(invoice).map(key => {
      setValue(key, invoice[key]);
    });
  }, [invoice]);

  const invoiceFields = {
    id: data?.id,
    suplier: data?.supplier?.companyName,
    nipt: data?.nipt,
    invoiceNumber: data?.invoiceNumber,
    receivedDate: data?.receivedDate,
    dueDate: data?.dueDate,
    status: data?.status,
  };

  const memoFields = {
    nivf: getValues('nivf') ?? invoice?.nivf,
    valueDate: getValues('valueDate') ?? new Date().toISOString().slice(0, 10),
    invoiceValue: getValues('invoiceValue') ?? invoice?.invoiceValue,
    currency: getValues('currency') ?? invoice?.currency,
    subject: getValues('subject') ?? invoice?.subject,
  };

  const paymentFields = {
    bankName: data?.bankName,
    iban: data?.iban,
  };

  const tableRowCreatorProps = {
    glOptionsAndFunctions,
    branchesOptionsAndFunctions,
    setValue,
    getValues,
    creditOptions,
    errors,
  };

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
        p: 3,
      }}
    >
      <Grid container spacing={3}>
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <b style={{ fontSize: '18px' }}>Invoice Data</b>
            <Button
              size="small"
              variant="contained"
              sx={{
                backgroundColor: '#ff0000',
                ':hover': {
                  backgroundColor: '#ff0000',
                  opacity: 0.8,
                },
              }}
              onClick={() =>
                dispatch(invoiceActions.exportPdfFile({ eic: data.eic }))
              }
              disabled={!data?.eic}
            >
              <Download />
              Invoice
            </Button>
          </Box>
        </Grid>
        {Object.keys(invoiceFields).map((key, index) => {
          if (key === 'id') {
            return;
          }
          return (
            <Grid key={index} item md={3} xs={12}>
              <TextField
                label={dataLabels[key]}
                fullWidth
                size="small"
                name={key}
                {...register(`${key}`)}
                variant="outlined"
                value={data[key]}
                disabled={true}
              />
            </Grid>
          );
        })}
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              minHeight: '100%',
              pt: 3,
            }}
          >
            <Grid container spacing={3}>
              <Grid item md={12} xs={12}>
                <b style={{ fontSize: '18px' }}>{`${
                  authorizationPayload?.role === ROLES.ACCOUNTING_INPUT
                    ? 'Add '
                    : ''
                }Memo data`}</b>
              </Grid>
            </Grid>
          </Box>
        </Grid>
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              minHeight: '100%',
              pt: 0,
            }}
          >
            <Grid container spacing={3}>
              {Object.keys(memoFields).map((key, index) => {
                if (key === 'id') {
                  return;
                }
                let md: 2 | 3 | 6 =
                  key === 'subject' ? 6 : key === 'currency' ? 2 : 3;
                if (key == 'currency') {
                  return (
                    <Grid key={index} item md={2} xs={12}>
                      <GridFields
                        gridFields={acceptedInvoiceGridFields(
                          currency,
                          authorizationPayload?.role !== ROLES.ACCOUNTING_INPUT,
                          invoice,
                        )}
                      />
                    </Grid>
                  );
                }
                return (
                  <Grid key={index} item md={md} xs={12}>
                    <TextField
                      label={dataLabels[key]}
                      fullWidth
                      type={
                        key === 'valueDate'
                          ? 'date'
                          : key === 'invoiceValue'
                          ? 'number'
                          : 'text'
                      }
                      helperText=""
                      InputProps={{
                        inputProps:
                          key === 'valueDate' ? { min: today } : { min: 0 },
                      }}
                      size="small"
                      name={key}
                      {...register(`${key}`)}
                      variant="outlined"
                      defaultValue={getValues(key)}
                      InputLabelProps={
                        key === 'valueDate' ? { shrink: true } : {}
                      }
                      disabled={
                        key === 'invoiceValue' ||
                        authorizationPayload?.role !== ROLES.ACCOUNTING_INPUT
                      }
                    />
                    <ErrorMessage
                      errors={errors}
                      name={key}
                      render={({ message }) => (
                        <p
                          style={{
                            color: 'red',
                            margin: '0px',
                            padding: '5px 10px 0px 0px',
                          }}
                        >
                          {message}
                        </p>
                      )}
                    />
                  </Grid>
                );
              })}
            </Grid>
          </Box>
        </Grid>
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              minHeight: '100%',
              pt: 3,
            }}
          >
            <Grid container spacing={3}>
              <Grid item md={12} xs={12}>
                <b style={{ fontSize: '18px' }}>{`${
                  authorizationPayload?.role === ROLES.ACCOUNTING_INPUT
                    ? 'Add '
                    : ''
                }Payment Details`}</b>
              </Grid>
            </Grid>
          </Box>
        </Grid>
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              minHeight: '100%',
              pt: 0,
            }}
          >
            <Grid container spacing={3}>
              {Object.keys(paymentFields).map((key, index) => {
                return (
                  <Grid key={index} item md={6} xs={12}>
                    <TextField
                      label={dataLabels[key]}
                      fullWidth
                      type={'text'}
                      helperText=""
                      InputProps={{ inputProps: { min: 0 } }}
                      size="small"
                      name={key}
                      {...register(`${key}`)}
                      variant="outlined"
                      defaultValue={getValues(key)}
                      disabled={
                        authorizationPayload?.role !== ROLES.ACCOUNTING_INPUT
                      }
                    />
                  </Grid>
                );
              })}
            </Grid>
          </Box>
        </Grid>
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              minHeight: '100%',
              pt: 3,
            }}
          >
            <Grid container spacing={3}>
              <Grid item md={12} xs={12}>
                <b style={{ fontSize: '18px' }}>{`${
                  authorizationPayload?.role === ROLES.ACCOUNTING_INPUT
                    ? 'Add '
                    : ''
                }Invoice GL's`}</b>
              </Grid>
            </Grid>
          </Box>
        </Grid>
        <Grid item md={12} xs={12}>
          <TableRowCreater {...tableRowCreatorProps} />
        </Grid>
        <Grid item md={12} xs={12}>
          <Box
            sx={{
              minHeight: '100%',
              pt: 0,
            }}
          >
            <Grid container spacing={3}>
              <Grid item md={12} xs={12}>
                <TextField
                  label={'Authorizer Feedback'}
                  fullWidth
                  type={'textarea'}
                  multiline={true}
                  rows={3}
                  helperText=""
                  size="small"
                  name="authorizerFeedback"
                  {...register(`authorizerFeedback`)}
                  variant="outlined"
                  defaultValue={getValues('authorizerFeedback')}
                  disabled={true}
                />
              </Grid>
            </Grid>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AcceptedInvoiceForm;
