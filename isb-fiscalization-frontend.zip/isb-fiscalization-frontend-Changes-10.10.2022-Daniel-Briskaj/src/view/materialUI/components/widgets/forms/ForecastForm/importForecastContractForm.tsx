import { Box, Grid } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  importContractFormGridFields,
  monthOptions,
} from 'src/enums/shared/gridFields/forecastFormGridFields';
import GridFields from '../../GridFields';
import forecastSelector from 'src/modules/forecast/forecastSelector';
import forecastActions from 'src/modules/forecast/forecastActions';
import { debounce } from 'lodash';

const ImportForecastContractForm: React.FC = () => {
  const dispatch = useDispatch();
  const allForecasts = useSelector(forecastSelector.allForecasts);
  const contractsToImport = useSelector(forecastSelector.contractsToImport);
  const forecastData = useSelector(forecastSelector.forecastData);
  const [forecastOptions, setForecastOptions] = useState([]);
  const [contractsOptions, setContractsOptions] = useState([]);
  const [forecastPage, setForecastPage] = useState<number>(0);
  const [searchValue, setSearchValue] = useState<string>();
  const [importPage, setImportPage] = useState<number>(0);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  useEffect(() => {
    if (allForecasts?.forecasts) {
      setForecastOptions(state => [
        ...state,
        ...allForecasts?.forecasts?.map(forecast => ({
          label: forecast?.name,
          value: {
            id: forecast?.id,
            name: forecast?.name,
            month: monthOptions?.find(temp => temp?.value === forecast?.month)
              ?.label,
            year: forecast?.year,
          },
        })),
      ]);
    }
  }, [allForecasts]);

  useEffect(() => {
    if (contractsToImport?.contracts) {
      setContractsOptions(state => [
        ...state,
        ...contractsToImport?.contracts?.map(contract => ({
          label: `${contract?.contractCode} - ${contract?.supplier?.companyName} - ${contract?.contractDescription}`,
          value: {
            id: contract?.id,
          },
        })),
      ]);
    }
  }, [contractsToImport]);

  useEffect(() => {
    dispatch(
      forecastActions.getAllForecasts({
        size: 10,
        page: forecastPage,
        forecastStatus: 'NEW',
      }),
    );
  }, [forecastPage]);

  useEffect(() => {
    dispatch(
      forecastActions.contractsToImport({
        isBudget: false,
        value: searchValue,
        size: 10,
        page: importPage,
      }),
    );
  }, [importPage, searchValue]);

  useEffect(() => {
    return () => {
      dispatch(forecastActions.clearForecastOptions());
    };
  }, []);

  const handleScrollToBottom = event => {
    if (forecastPage < allForecasts?.totalPages) {
      setForecastPage(forecastPage + 1);
    }
  };

  const handleContractScrollToBottom = event => {
    if (importPage < contractsToImport?.totalPages - 1) {
      setImportPage(importPage + 1);
    }
  };

  const handleSearchContract = value => {
    setIsSearching(Boolean(value));
    setSearchValue(value);
    setContractsOptions([]);
    setImportPage(0);
  };

  const resetSearchContract = () => {
    if (isSearching) {
      setSearchValue('');
      setContractsOptions([]);
      setImportPage(0);
      setIsSearching(false);
    }
  };

  const forecastOptionsAndFunctions = {
    forecastOptions,
    handleScrollToBottom,
  };

  const contractOptionsAndFunctions = {
    contractsOptions,
    handleSearchContract: debounce(handleSearchContract, 500),
    handleContractScrollToBottom,
    handleResetSearch: resetSearchContract,
  };

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
        p: 3,
      }}
    >
      <Grid container spacing={3}>
        <GridFields
          gridFields={importContractFormGridFields(
            forecastOptionsAndFunctions,
            contractOptionsAndFunctions,
          )}
          data={forecastData}
        />
      </Grid>
    </Box>
  );
};

export default ImportForecastContractForm;
