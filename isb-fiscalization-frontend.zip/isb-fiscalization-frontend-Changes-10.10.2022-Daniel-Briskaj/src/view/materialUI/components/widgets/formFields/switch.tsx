import React from 'react';
import {
  Switch as MaterialSwitch,
  Grid,
  FormControl,
  InputLabel,
} from '@material-ui/core';
const Switch = ({
  md,
  xs,
  name,
  data,
  label,
  register,
  setValue,
  getValues,
  disabled,
}) => {
  return (
    <Grid item md={md} xs={xs}>
      <FormControl fullWidth variant="outlined">
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <p>{label}:</p>
          <MaterialSwitch
            sx={{
              opacity: disabled === false ? '1' : '0.7',
            }}
            disabled={disabled}
            ref={register}
            {...register(name)}
            defaultChecked={
              data && Object.keys(data).length !== 0
                ? data[name]
                : getValues(name)
            }
            onChange={e => {
              data[name] = e.target.value;
              setValue(e.target.value);
            }}
            label={label}
            name={name}
            // disabled={ name ==='isApproved' ? true : false}
          />
        </div>
      </FormControl>
    </Grid>
  );
};

export default Switch;
