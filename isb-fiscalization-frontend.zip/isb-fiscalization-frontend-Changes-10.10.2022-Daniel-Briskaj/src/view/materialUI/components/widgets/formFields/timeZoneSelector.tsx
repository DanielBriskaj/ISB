import React, { useState, useEffect } from 'react';
import {
  Switch as MaterialSwitch,
  Grid,
  FormControl,
  InputLabel,
} from '@material-ui/core';
import TimezoneSelect, { allTimezones } from 'react-timezone-select';
import { StylesConfig } from 'react-select';
import useSettings from '../../../hooks/useSettings';
import { THEMES } from 'src/view/materialUI/constants';

const TimeZoneSelector = ({
  md,
  xs,
  setValue,
  name,
  data,
  label,
  register,
  getValues,
  disabled,
}) => {
  const [selectedTimezone, setSelectedTimezone] = useState<string | any>(
    data[name] ?? Intl.DateTimeFormat().resolvedOptions().timeZone,
  );

  useEffect(() => {
    if (selectedTimezone) {
      setValue(name, selectedTimezone.value);
    }
  }, [selectedTimezone]);

  const { settings } = useSettings();

  const colourStyles: StylesConfig = {
    control: (styles, { isFocused, isDisabled }) => ({
      ...styles,
      position: 'relative',
      top: 0,
      boxShadow: 'none',
      backgroundColor: settings.theme,
      borderRadius: '4px',
      borderColor: '#ea600e',
      '&:hover':
        settings.theme === THEMES.DARK
          ? {
              boxShadow: 'none',
              borderColor: 'white',
            }
          : { boxShadow: 'none', borderColor: 'black' },
      '&:focus': {
        borderColor: '#ea600e',
        boxShadow: 'none',
      },
      border:
        settings.theme === THEMES.DARK
          ? isFocused
            ? '1px solid #ea600e'
            : '1px solid rgba(145, 158, 171, 0.24)'
          : isFocused
          ? '1px solid #ea600e'
          : '1px solid #b3b3b3'
          ? isDisabled
            ? '1px solid #cecece'
            : '1px solid #b3b3b3'
          : '',
    }),
    indicatorSeparator: () => ({
      display: 'none',
    }),
    dropdownIndicator: (styles, { isFocused }) => ({
      ...styles,
      color: isFocused ? '#ea600e' : '#b3b3b3',
      '&:hover': {
        color: '#ea600e',
        boxShadow: '#ea600e',
      },
    }),
    singleValue: provided => {
      const color = disabled ? '#cecece' : 'black';
      return { ...provided, color };
    },
    menu: provided => {
      const color = '#09425A';
      const zIndex = 3501;

      return { ...provided, color, zIndex };
    },
    placeholder: (styles, { isFocused }) => ({
      ...styles,
      color: isFocused ? '#ea600e' : '#b3b3b3',
    }),
  };
  return (
    <Grid item md={md} xs={xs}>
      <FormControl fullWidth variant="outlined">
        <TimezoneSelect
          value={selectedTimezone}
          onChange={setSelectedTimezone}
          timezones={{
            ...allTimezones,
            'America/Lima': 'Pittsburgh',
            'Europe/Berlin': 'Frankfurt',
          }}
          styles={colourStyles as any}
          isDisabled={disabled}
        />
      </FormControl>
    </Grid>
  );
};

export default TimeZoneSelector;
