import React, { useState } from 'react';

import {
  Grid,
  TextField,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Box,
  Paper,
} from '@material-ui/core';
import { ErrorMessage } from '@hookform/error-message';
import { Controller } from 'react-hook-form';

const Input = ({
  md,
  xs,
  type,
  name,
  data,
  label,
  errors,
  register,
  setValue,
  disabled,
  control,
  step,
}) => {
  const [inputValue, setInputValue] = useState(null);

  return (
    <Grid item md={md} xs={xs}>
      <Controller
        render={({ field }) => (
          <TextField
            sx={{
              opacity: disabled === false ? '1' : '0.7',
            }}
            fullWidth
            multiline={type === 'textarea' ? true : false}
            rows={type === 'textarea' ? 3 : 0}
            ref={register}
            onChange={event => {
              setValue(name, event.target.value);
              setInputValue(event.target.value);
            }}
            {...field}
            disabled={disabled}
            label={label}
            size="small"
            name={name}
            variant="outlined"
            type={type}
            InputProps={
              type === 'number' ? { inputProps: { min: 0, step: step } } : {}
            }
            InputLabelProps={
              (data && data[name] && field.value) || type === 'date'
                ? { shrink: true }
                : { style: { color: '#766969' } }
            }
          />
        )}
        name={name}
        control={control}
        defaultValue={disabled ? data && data[name] : ''}
      />
      {!inputValue && (
        <ErrorMessage
          errors={errors}
          name={name}
          render={({ message }) => (
            <p
              style={{
                color: 'red',
                margin: '0px',
                padding: '5px 10px 0px 0px',
              }}
            >
              {message}
            </p>
          )}
        />
      )}
    </Grid>
  );
};

export default Input;
