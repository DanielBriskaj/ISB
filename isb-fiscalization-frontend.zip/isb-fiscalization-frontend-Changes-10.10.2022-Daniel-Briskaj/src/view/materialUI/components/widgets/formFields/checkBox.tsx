import React from 'react';
import {
  Grid,
  Typography,
  FormControlLabel,
  Checkbox,
  Box,
  Paper,
} from '@material-ui/core';
import { ErrorMessage } from '@hookform/error-message';

const CheckBox = ({
  name,
  data,
  label,
  label1,
  errors,
  register,
  setValue,
  getValues,
  md,
  xs,
  disabled,
}) => {
  return (
    <Grid item md={md} xs={xs}>
      <Paper
        sx={{
          alignItems: 'flex-start',
          display: 'flex',
          padding: 2,
        }}
        variant="outlined"
      >
        <FormControlLabel
          control={
            <Checkbox
              color="primary"
              onChange={event => {
                data[name] = event.target.checked;
                setValue(name, event.target.checked);
              }}
              defaultValue={
                Object.keys(data).length !== 0 ? data[name] : getValues(name)
              }
              defaultChecked={
                Object.keys(data).length !== 0 ? data[name] : getValues(name)
              }
              inputProps={{ disabled }}
            />
          }
          name={name}
          ref={register}
          {...register(name)}
          label={
            <Box sx={{ ml: 2 }}>
              <Typography
                sx={{
                  color: 'text.primary',
                }}
                variant="subtitle2"
              >
                {label}
              </Typography>
              <Typography
                sx={{
                  color: 'text.secondary',
                }}
                variant="body2"
              >
                {label1}
              </Typography>
            </Box>
          }
        />
      </Paper>
      <ErrorMessage
        errors={errors}
        name={name}
        render={({ message }) => (
          <p
            style={{
              color: 'red',
              margin: '0px',
              padding: '5px 10px 0px 0px',
              borderRadius: '15px',
            }}
          >
            {message}
          </p>
        )}
      />
    </Grid>
  );
};

export default CheckBox;
