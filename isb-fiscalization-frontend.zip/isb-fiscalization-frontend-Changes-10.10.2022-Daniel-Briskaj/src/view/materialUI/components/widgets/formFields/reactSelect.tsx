import React, { useEffect, useState } from 'react';

import { Grid } from '@material-ui/core';
import { ErrorMessage } from '@hookform/error-message';
import ReactSelect from '../../ReactSelect';

const ReactSelectInput = ({
  md,
  xs,
  options,
  name,
  label,
  errors,
  register,
  setValue,
  handleOnInputChange,
  handleOnMenuScrollToBottom,
  defaultValue,
  disabled,
  isMulti,
  selectedValue,
  menuHeight,
  handleResetSearch,
  isClearable,
}) => {
  const [inputValue, setInputValue] = useState(null);
  const [selected, setSelected] = useState(selectedValue);

  useEffect(() => {
    setSelected(selectedValue);
  }, [selectedValue]);

  return (
    <Grid item md={md} xs={xs}>
      <ReactSelect
        selectedValue={selected}
        isMulti={isMulti}
        options={options}
        placeholder={label}
        menuHeight={menuHeight}
        handleSelect={option => {
          if (isMulti) {
            setValue(
              name,
              option.map(el => {
                return el.value;
              }),
            );
            setInputValue(option.value);
          } else {
            setValue(name, option?.value ?? null);
            setInputValue(option?.value);
            setSelected(option);
          }
        }}
        handleOnInputChange={option => {
          if (handleOnInputChange) {
            handleOnInputChange(option);
          }
        }}
        name={name}
        defaultValue={defaultValue}
        handleOnMenuScrollToBottom={event => {
          if (handleOnMenuScrollToBottom) {
            handleOnMenuScrollToBottom(event);
          }
        }}
        disabled={disabled}
        handleResetSearch={() => {
          if (handleResetSearch) {
            handleResetSearch();
          }
        }}
        isClearable={isClearable}
      />
      {!inputValue && (
        <ErrorMessage
          errors={errors}
          name={name}
          render={({ message }) => (
            <p
              style={{
                color: 'red',
                margin: '0px',
                padding: '5px 10px 0px 0px',
                borderRadius: '15px',
              }}
            >
              {message}
            </p>
          )}
        />
      )}
    </Grid>
  );
};

export default ReactSelectInput;
