import React, { useEffect, useState } from 'react';
import {
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@material-ui/core';
import { ErrorMessage } from '@hookform/error-message';
import { Controller } from 'react-hook-form';

const SelectInput = ({
  md,
  xs,
  options,
  name,
  data,
  label,
  errors,
  setValue,
  disabled,
  control,
}) => {
  const [inputValue, setInputValue] = useState(null);

  return (
    <Grid item md={md} xs={xs}>
      <Controller
        render={({ field: { ref: fieldRef, value } }) => (
          <FormControl fullWidth size="small">
            <InputLabel>{label}</InputLabel>
            <Select
              sx={{
                opacity: disabled === false ? '1' : '0.7',
              }}
              MenuProps={{
                style: { zIndex: 3501, borderRadius: '4px' },
              }}
              value={value}
              inputRef={fieldRef}
              inputProps={{ disabled }}
              onChange={event => {
                data[name] = event.target.value;
                setValue(name, event.target.value);
                setInputValue(event.target.value);
              }}
              fullWidth
              name={name}
              label={label}
              size="small"
            >
              {options &&
                options.map((option, i) => {
                  return (
                    <MenuItem value={option.value} key={i}>
                      {option.label}
                    </MenuItem>
                  );
                })}
            </Select>
          </FormControl>
        )}
        name={name}
        control={control}
        defaultValue={data && Object.keys(data).length > 0 && data[name]}
      />

      {!inputValue && (
        <ErrorMessage
          errors={errors}
          name={name}
          render={({ message }) => (
            <p
              style={{
                color: 'red',
                margin: '0px',
                padding: '5px 10px 0px 0px',
              }}
            >
              {message}
            </p>
          )}
        />
      )}
    </Grid>
  );
};

export default SelectInput;
