import { useState, useEffect } from 'react';
import Select, { components, StylesConfig } from 'react-select';
import useSettings from '../hooks/useSettings';
import { THEMES } from '../constants';
import './ReactSelect.css';

const ReactSelect = props => {
  const {
    placeholder,
    handleSelect,
    name,
    defaultValue,
    handleOnInputChange,
    handleOnMenuScrollToBottom,
    disabled,
    options,
    isMulti,
    selectedValue,
    menuHeight,
    isClearable,
    handleResetSearch,
  } = props;
  const [isFocused, setIsFocused] = useState(false);
  const [isSelected, setIsSelected] = useState(false);
  const { settings } = useSettings();

  const colourStyles: StylesConfig = {
    control: (styles, { isFocused, isDisabled }) => ({
      ...styles,
      boxShadow: 'none',
      backgroundColor: settings.theme,
      borderRadius: '4px',
      borderColor: '#ea600e',
      '&:hover':
        settings.theme === THEMES.DARK
          ? {
              boxShadow: 'none',
              borderColor: 'white',
            }
          : { boxShadow: 'none', borderColor: 'black' },
      '&:focus': {
        borderColor: '#ea600e',
        boxShadow: 'none',
      },
      border:
        settings.theme === THEMES.DARK
          ? isFocused
            ? '1px solid #ea600e'
            : '1px solid rgba(145, 158, 171, 0.24)'
          : isFocused
          ? '1px solid #ea600e'
          : '1px solid #b3b3b3'
          ? isDisabled
            ? '1px solid #cecece'
            : '1px solid #b3b3b3'
          : '',
    }),
    indicatorSeparator: () => ({
      display: 'none',
    }),
    dropdownIndicator: (styles, { isFocused }) => ({
      ...styles,
      color: isFocused ? '#ea600e' : '#b3b3b3',
      '&:hover': {
        color: '#ea600e',
        boxShadow: '#ea600e',
      },
    }),
    singleValue: provided => {
      const color = disabled ? '#cecece' : 'black';
      return { ...provided, color };
    },
    menu: provided => {
      const color = '#09425A';
      const zIndex = 3501;

      return { ...provided, color, zIndex };
    },
    placeholder: (styles, { isFocused }) => ({
      ...styles,
      color: isFocused ? '#ea600e' : '#b3b3b3',
    }),
    option: (provided, state) => ({
      ...provided,
      maxWidth: '100%',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
    }),
  };

  const Option = props => {
    return (
      <span title={props.label}>
        <components.Option {...props} />
      </span>
    );
  };

  return (
    <>
      <div className="react-select-container">
        <Select
          value={selectedValue}
          name={name}
          styles={colourStyles}
          options={options}
          isMulti={isMulti}
          isClearable={isClearable}
          placeholder={null}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onChange={option => {
            if (handleSelect) {
              handleSelect(option);
              setIsSelected(true);
            }
            if (!option) {
              setIsSelected(false);
            }
          }}
          onInputChange={(option, event) => {
            if (event && event.action === 'input-change') {
              if (handleOnInputChange) {
                handleOnInputChange(option);
              }
            }
            if (event && event.action === 'menu-close') {
              if (handleResetSearch) {
                handleResetSearch();
              }
            }
          }}
          onMenuScrollToBottom={event => {
            if (handleOnMenuScrollToBottom) {
              handleOnMenuScrollToBottom(event);
            }
          }}
          defaultValue={defaultValue}
          maxMenuHeight={menuHeight ? menuHeight : 200}
          isDisabled={disabled}
          isOptionDisabled={option => option.isDisabled}
          components={{ Option }}
          classNamePrefix={`react-select`}
        />
        <span
          className={`custom-placeholder ${
            isFocused ||
            defaultValue?.value ||
            (isMulti &&
              Array.isArray(defaultValue) &&
              defaultValue[0]?.value) ||
            isSelected
              ? 'is-focused'
              : ''
          } ${disabled ? 'is-disabled' : ''}`}
        >
          {placeholder}
        </span>
      </div>
    </>
  );
};

export default ReactSelect;
