import { useEffect } from 'react';
import type { FC } from 'react';
import NProgress from 'nprogress';
import { Backdrop, CircularProgress } from '@material-ui/core';

const LoadingScreen: FC = () => {
  useEffect(() => {
    NProgress.start();

    return (): void => {
      NProgress.done();
    };
  }, []);

  return (
    <Backdrop sx={{ color: '#fff', zIndex: 400000 }} open={true}>
      <CircularProgress color="inherit" />
    </Backdrop>
  );
};

export default LoadingScreen;
