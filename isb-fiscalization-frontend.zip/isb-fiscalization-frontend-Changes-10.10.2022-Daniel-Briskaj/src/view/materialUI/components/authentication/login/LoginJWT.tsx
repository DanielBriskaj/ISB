import type { FC } from 'react';
import { useEffect, useState } from 'react';
import { Alert, Box, Button, TextField } from '@material-ui/core';
import { useFormContext } from 'react-hook-form';
import { ErrorMessage } from '@hookform/error-message';

const LoginJWT = props => {
  const {
    register,
    setError,
    setValue,
    formState: { errors },
    getValues,
    clearErrors,
  } = useFormContext();
  const [isEditing, setIsEditing] = useState(false);
  return (
    <>
      <TextField
        autoFocus
        fullWidth
        label="Username"
        margin="normal"
        name="username"
        variant="outlined"
        ref={register}
        {...register('username')}
        onChange={event => {
          setValue('username', event.target.value);
          clearErrors('username');
          setIsEditing(true);
        }}
      />
      {errors && errors.username && (
        <ErrorMessage
          errors={errors}
          name="username"
          render={({ message }) => (
            <p
              style={{
                color: 'red',
                marginTop: '0px',
                padding: '5px 10px 0px 0px',
              }}
            >
              {message}
            </p>
          )}
        />
      )}

      <TextField
        fullWidth
        label="Password"
        margin="normal"
        name="password"
        type="password"
        variant="outlined"
        ref={register}
        {...register('password')}
        onChange={event => {
          setValue('password', event.target.value);
          clearErrors('password');
          setIsEditing(true);
        }}
      />

      <ErrorMessage
        errors={errors}
        name="password"
        render={({ message }) => (
          <p
            style={{
              color: 'red',
              marginTop: '0px',
              padding: '5px 10px 0px 0px',
            }}
          >
            {message}
          </p>
        )}
      />
      <Box sx={{ mt: 2 }}>
        <Button
          color="primary"
          fullWidth
          size="large"
          type="submit"
          variant="contained"
        >
          Log In
        </Button>

        {props.error && props.error.message?.length !== 0 && !isEditing && (
          <p
            style={{
              color: 'red',
              marginTop: '0px',
              padding: '5px 10px 0px 0px',
            }}
          >
            The credentials you provided are wrong. Try again!
          </p>
        )}
      </Box>
    </>
  );
};

export default LoginJWT;
