import { useEffect } from 'react';
import type { FC } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import {
  Box,
  Card,
  CardContent,
  Container,
  Divider,
  Link,
  Typography,
} from '@material-ui/core';
import LoginJWT from '../../components/authentication/login/LoginJWT';
import { useForm, FormProvider } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { authSchema } from 'src/modules/shared/yup/authSchema';
import { useDispatch, useSelector } from 'react-redux';
import authActions from 'src/modules/shared/authentication/authActions';
import authSelector from 'src/modules/shared/authentication/authSelector';
import LoadingScreen from '../../components/LoadingScreen';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';

const Login: FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const jwt = localStorage.getItem('idToken');
  const loading = useSelector(statusSelector.loading);
  const error = useSelector(statusSelector.error);

  const initialValues = {
    username: '',
    password: '',
  };

  const form = useForm({
    resolver: yupResolver(authSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    dispatch(authActions.login(data));
  };

  useEffect(() => {
    if (jwt) {
      navigate('/dashboard', { replace: true });
    }
  }, [jwt]);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <>
      {/* <Helmet>
        <title>Login | Material Kit Pro</title>
      </Helmet> */}
      <Box
        sx={{
          backgroundColor: 'background.default',
          display: 'flex',
          flexDirection: 'column',
          minHeight: '100vh',
        }}
      >
        <Container maxWidth="sm" sx={{ py: '80px' }}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              mb: 8,
            }}
          ></Box>
          <Card>
            <CardContent
              sx={{
                display: 'flex',
                flexDirection: 'column',
                p: 4,
              }}
            >
              <Box
                sx={{
                  alignItems: 'center',
                  display: 'flex',
                  justifyContent: 'space-between',
                }}
              >
                <div>
                  <Typography color="textPrimary" gutterBottom variant="h4">
                    Log in
                  </Typography>
                </div>
                <Box
                  sx={{
                    height: 32,
                    '& > img': {
                      maxHeight: '100%',
                      width: 'auto',
                    },
                  }}
                ></Box>
              </Box>
              <Box
                sx={{
                  flexGrow: 1,
                  mt: 3,
                }}
              >
                <FormProvider {...form}>
                  <form noValidate onSubmit={form.handleSubmit(onSubmit)}>
                    <LoginJWT error={error} />
                  </form>
                </FormProvider>
              </Box>
              <Divider sx={{ my: 3 }} />
            </CardContent>
          </Card>
        </Container>
      </Box>
    </>
  );
};

export default Login;
