import {
  Box,
  Button,
  Card,
  IconButton,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Tabs,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getStatusLabel } from 'src/helpers/contractStatusLabel';
import PencilAltIcon from '../../../icons/PencilAlt';
import forecastActions from 'src/modules/forecast/forecastActions';
import forecastSelector from 'src/modules/forecast/forecastSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import Scrollbar from 'src/view/materialUI/components/Scrollbar';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import ContractFormPopup from '../contracts/ContractFormPopup';
import ForecastButtons from './forecastButtons';
import ForecastFilters from './forecastFilters';
import ForecastFormPopup from './forecastFormPopup';
import ArrowRightIcon from '../../../icons/ArrowRight';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import getSubRows from './forecastSubRows';
import forecastColumns from 'src/enums/shared/headerFields/forecastFields';
import getItemStatusLabel from 'src/helpers/budgetAndForecastHelpers/itemStatusLabel';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import { ItemStatus } from 'src/enums/status';
import DeleteForecastFormPopup from './deleteForecastFormPopup';
import ImportContractForecastFormPopup from './importForecastContractFormPopup';
import { getPreviousStatusByRole } from 'src/helpers/budgetAndForecastHelpers/budgetStatusHelpers';
import notificationThrower from 'src/helpers/notificationThrower';

const ForecastTable: React.FC = () => {
  const loading = useSelector(forecastSelector.loading);
  const dispatch = useDispatch();

  const [tableData, setTableData] = useState([]);
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [contractModalOpen, setContractModalOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [currentTab, setCurrentTab] = useState<'NEW' | 'CLOSED'>('NEW');
  const [contractInfo, setContractInfo] = useState({
    id: null,
    contractStatus: null,
    itemStatus: null,
  });
  const [closingForecast, setClosingForecast] = useState(false);

  const authData = useSelector(authSelector.authData);
  const { costOwnerId, role, division } = authData;
  const forecastItems = useSelector(forecastSelector.forecastItemsArray);
  const subForecastItems = useSelector(forecastSelector.subForecastItems);
  const [supplierName, setSupplierName] = useState();
  const [contractCode, setContractCode] = useState();
  const [itemStatus, setItemStatus] = useState();
  const [costOwnerName, setCostOwnerName] = useState();
  const [openRows, setOpenRows] = useState({});
  const forecastID = useSelector(forecastSelector.forecastId);

  const query: any = {};
  query.supplierCompanyName = supplierName;
  query.contractCode = contractCode;
  query.forecastStatus = currentTab;
  query.page = currentPage;
  query.size = rowsPerPage;
  query.costOwnerName = costOwnerName;
  query.forecastItemStatus = itemStatus;
  query.division = division;
  useEffect(() => {
    if (role === ROLES.COST_OWNER) {
      dispatch(forecastActions.getItemsByCO({ id: costOwnerId, query: query }));
    } else {
      if (role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId) {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong',
        });
      } else {
        dispatch(forecastActions.getForecastItems(query));
      }
    }
  }, [
    currentPage,
    rowsPerPage,
    contractCode,
    supplierName,
    costOwnerName,
    currentTab,
    itemStatus,
  ]);

  const expandRow = id => {
    if (openRows[id] !== undefined) {
      if (!openRows[id]) {
        dispatch(forecastActions.getForecastSubItems(id));
      }
      setOpenRows(oldState => {
        return { ...oldState, [id]: !openRows[id] };
      });
    } else {
      dispatch(forecastActions.getForecastSubItems(id));

      setOpenRows(oldState => {
        return { ...oldState, [id]: true };
      });
    }
  };

  useEffect(() => {
    if (forecastItems?.forecastItems) {
      setTableData(forecastItems?.forecastItems);
      setTotalItems(forecastItems?.totalItems);
    } else {
      setTableData([]);
    }
  }, [forecastItems]);

  const style: any = {
    maxWidth: '150px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
  };

  const handleRowClick = id => {
    if (selectedRow === null) {
      setSelectedRow(id);
    } else {
      if (selectedRow === id) {
        setSelectedRow(null);
      } else {
        setSelectedRow(id);
      }
    }
  };

  const onPageChange = (event, page) => {
    setCurrentPage(page);
  };
  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setRowsPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const handleReject = id => {
    dispatch(forecastActions.getSingleForecastItem(id));
    setDialogOpen(true);
    setContractInfo({
      id: id,
      contractStatus: null,
      itemStatus: null,
    });
  };

  const handleFinishReject = data => {
    const itemData = {
      id: contractInfo?.id,
      authorizerFeedback: data?.reason,
      forecastItemStatus: getPreviousStatusByRole(role),
    };
    dispatch(
      forecastActions.rejectForecastItem({
        data: itemData,
        role: role,
        query: query,
      }),
    );
    setDialogOpen(false);
  };

  const modalWrapperData = [
    {
      children: (
        <ForecastFormPopup
          setModalOpen={setModalOpen}
          closingForecast={closingForecast}
          setClosingForecast={setClosingForecast}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'progressModal',
    },
    {
      children: (
        <ContractFormPopup
          setModalOpen={setContractModalOpen}
          contractId={contractInfo?.id}
          type="forecastContract"
          isFormDisabled={
            role !== ROLES.COST_OWNER ||
            (contractInfo &&
              (contractInfo?.contractStatus === 'ACTIVE' ||
                contractInfo?.itemStatus !== ItemStatus.CREATED))
              ? true
              : false
          }
          costOwnerId={costOwnerId}
          forecastID={forecastID}
          query={query}
        />
      ),
      modalOpen: contractModalOpen,
      setModalOpen: setContractModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setDialogOpen={setDialogOpen}
          message={`Why are you choosing to reject this forecast item?`}
          hasFeedback={true}
          handleDelete={handleFinishReject}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
    {
      children: <DeleteForecastFormPopup setModalOpen={setDeleteOpen} />,
      modalOpen: deleteOpen,
      setModalOpen: setDeleteOpen,
      type: 'editModal',
    },
    {
      children: (
        <ImportContractForecastFormPopup setModalOpen={setImportOpen} />
      ),
      modalOpen: importOpen,
      setModalOpen: setImportOpen,
      type: 'editModal',
    },
  ];

  const forecastTableTabs = [
    { label: 'In Progress', value: 'NEW' },
    { label: 'Completed', value: 'CLOSED' },
  ];
  const handleTabsChange = (event, value): void => {
    setCurrentTab(value);
    setTableData([]);
    setCurrentPage(0);
  };
  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
      }}
    >
      {role === ROLES.PLANNING_CONTROL_INPUT ||
      role === ROLES.PLANNING_CONTROL_AUTHORIZER ? (
        <Box sx={{ mt: 3 }}>
          <Tabs
            indicatorColor="primary"
            onChange={handleTabsChange}
            scrollButtons="auto"
            textColor="primary"
            value={currentTab}
            variant="scrollable"
          >
            {forecastTableTabs.map(tab => (
              <Tab key={tab.value} label={tab.label} value={tab.value} />
            ))}
          </Tabs>
        </Box>
      ) : (
        <></>
      )}
      <WidgetPreviewer
        element={
          <Box
            sx={{
              backgroundColor: 'background.default',
              p: 3,
            }}
          >
            <Card sx={{ overflow: 'visible' }}>
              <Box
                sx={{
                  alignItems: 'center',
                  display: 'flex',
                  flexWrap: 'wrap',
                  justifyContent: 'space-between',
                  m: -1,
                  p: 2,
                  mb: 1.5,
                }}
              >
                <ForecastFilters
                  setContractCode={setContractCode}
                  setCurrentPage={setCurrentPage}
                  setSupplierName={setSupplierName}
                  setCostOwnerName={setCostOwnerName}
                  role={role}
                  setItemStatus={setItemStatus}
                  costOwnerId={costOwnerId}
                />
                {currentTab !== 'CLOSED' && (
                  <ForecastButtons
                    setModalOpen={setModalOpen}
                    setContractModalOpen={setContractModalOpen}
                    role={role}
                    selectedRow={selectedRow}
                    setContractId={setContractInfo}
                    costOwnerId={costOwnerId}
                    totalItems={totalItems}
                    query={query}
                    setClosingForecast={setClosingForecast}
                    setDeleteOpen={setDeleteOpen}
                    setImportOpen={setImportOpen}
                  />
                )}
              </Box>
              <Scrollbar>
                <Box sx={{ minWidth: 800 }}>
                  <Table padding="none">
                    <TableHead>
                      <TableRow>
                        {(role === ROLES.COST_OWNER || currentTab === 'CLOSED'
                          ? forecastColumns.filter(
                              field => field.fieldName !== 'Process',
                            )
                          : forecastColumns
                        )?.map((column, index) => {
                          return (
                            <TableCell
                              key={index}
                              sx={column?.sx}
                              align={column?.align}
                            >
                              {column?.fieldName}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {loading ? (
                        <TableRow>
                          <TableCell
                            sx={{
                              textAlign: 'center',
                              fontSize: '1.01rem',
                              fontWeight: '500',
                              color: '#777',
                              padding: '1.15rem 0.9rem',
                            }}
                            colSpan={forecastColumns?.length}
                          >
                            Data is loading ...
                          </TableCell>
                        </TableRow>
                      ) : tableData?.length === 0 ? (
                        <TableRow>
                          <TableCell
                            sx={{
                              textAlign: 'center',
                              fontSize: '1.01rem',
                              fontWeight: '500',
                              color: '#777',
                              padding: '1.15rem 0.9rem',
                            }}
                            colSpan={forecastColumns?.length}
                          >
                            There are no data for this module!
                          </TableCell>
                        </TableRow>
                      ) : (
                        tableData?.map((row, index) => {
                          return (
                            <>
                              <TableRow
                                hover
                                sx={
                                  row?.id === selectedRow
                                    ? {
                                        backgroundColor: 'lavender',
                                        height: '50px',
                                      }
                                    : { height: '50px' }
                                }
                                key={row?.id}
                                onClick={() => {
                                  handleRowClick(row?.id);
                                }}
                              >
                                <TableCell align="center" width={50}>
                                  <IconButton
                                    sx={{
                                      transform:
                                        openRows[row?.id] && 'rotate(90deg)',
                                      transition: 'all 200ms',
                                    }}
                                    onClick={() => {
                                      expandRow(row?.id);
                                    }}
                                  >
                                    <ArrowRightIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    paddingLeft: 1.5,
                                    maxWidth: '150px',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                  }}
                                >
                                  {row?.supplier?.companyName}
                                </TableCell>
                                <TableCell
                                  align="center"
                                  sx={{
                                    paddingLeft: 1.5,
                                    maxWidth: '150px',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                  }}
                                >
                                  {row?.costOwner?.ownerName}
                                </TableCell>
                                <TableCell align="center" width={50}>
                                  {row?.branch?.branchCode}
                                </TableCell>
                                <TableCell align="center" sx={style}>
                                  {getStatusLabel(row?.contractStatus)}
                                </TableCell>
                                <TableCell align="center" sx={style}>
                                  {row?.contractCode}
                                </TableCell>
                                <TableCell align="center" sx={style}>
                                  {getItemStatusLabel(row?.forecastItemStatus)}
                                </TableCell>
                                <TableCell align="center" width={100}>
                                  <IconButton
                                    onClick={() => {
                                      setContractModalOpen(true);
                                      setContractInfo({
                                        id: row?.id,
                                        contractStatus: row?.contractStatus,
                                        itemStatus: row?.forecastItemStatus,
                                      });
                                    }}
                                  >
                                    <PencilAltIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                                {role === ROLES.COST_OWNER ||
                                currentTab === 'CLOSED' ? (
                                  <TableCell></TableCell>
                                ) : (
                                  <TableCell align="center" width={100}>
                                    <Button
                                      onClick={() => handleReject(row?.id)}
                                      disabled={
                                        (role === ROLES.COST_OWNER_AUTHORIZER &&
                                          row?.forecastItemStatus !==
                                            ItemStatus.IN_APPROVAL_BY_COA) ||
                                        (role ===
                                          ROLES.PLANNING_CONTROL_INPUT &&
                                          row?.forecastItemStatus !==
                                            ItemStatus.IN_APPROVAL_BY_PCI) ||
                                        (role ===
                                          ROLES.PLANNING_CONTROL_AUTHORIZER &&
                                          row?.forecastItemStatus !==
                                            ItemStatus.IN_APPROVAL_BY_PCA)
                                      }
                                    >
                                      Reject
                                    </Button>
                                  </TableCell>
                                )}
                              </TableRow>
                              {openRows[row?.id] && !subForecastItems[row?.id] && (
                                <TableRow>
                                  <TableCell
                                    sx={{
                                      textAlign: 'center',
                                      fontSize: '1.01rem',
                                      fontWeight: '500',
                                      color: '#777',
                                      padding: '1.15rem 0.9rem',
                                    }}
                                    colSpan={forecastColumns?.length}
                                  >
                                    Loading ...
                                  </TableCell>
                                </TableRow>
                              )}
                              {openRows[row?.id] &&
                                subForecastItems[row?.id] &&
                                getSubRows(
                                  subForecastItems[row?.id],
                                  selectedRow,
                                  handleRowClick,
                                  style,
                                  setContractModalOpen,
                                  setContractInfo,
                                  forecastColumns,
                                )}
                            </>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </Box>
              </Scrollbar>
              {totalItems > 0 && (
                <TablePagination
                  component="div"
                  count={totalItems ? totalItems : 1}
                  page={currentPage}
                  rowsPerPage={rowsPerPage}
                  rowsPerPageOptions={[5, 10, 25]}
                  onPageChange={(event, page) => onPageChange(event, page)}
                  onRowsPerPageChange={event => onChangeRowsPerPage(event)}
                />
              )}
            </Card>
          </Box>
        }
        name="Forecast And Planning"
      />
      {modalWrapperData &&
        modalWrapperData.map((modalData, index) => {
          return <ModalWrapper key={index} {...modalData} />;
        })}
    </Box>
  );
};
export default ForecastTable;
