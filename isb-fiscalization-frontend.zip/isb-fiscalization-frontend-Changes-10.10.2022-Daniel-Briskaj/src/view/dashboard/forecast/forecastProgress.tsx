import { Grid, Typography, Box, Button } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ForecastStatus } from 'src/enums/status';
import forecastActions from 'src/modules/forecast/forecastActions';
import forecastSelector from 'src/modules/forecast/forecastSelector';
import LinearProgressWithLabel from 'src/view/materialUI/components/ProgressBarWithLabel';

interface ForecastFormProps {
  setModalOpen: any;
}
const ForecastProgress: React.FC<ForecastFormProps> = ({ setModalOpen }) => {
  const dispatch = useDispatch();

  const failedItems = useSelector(forecastSelector.failedItems);
  const forecastContracts = useSelector(forecastSelector.forecastContracts);
  const parentContract = forecastContracts?.parentAndNormal;
  const subContracts = forecastContracts?.children;
  const forecastData = useSelector(forecastSelector.forecastData);
  const progress = useSelector(forecastSelector.progress);
  const [failedAmount, setFailedAmount] = useState<any>(0);

  const totalItems = parentContract?.length + subContracts?.length;
  useEffect(() => {
    setFailedAmount(failedAmount + failedItems.length);
  }, [failedItems]);

  useEffect(() => {
    if (parentContract?.length > 0 && forecastData) {
      const id = forecastData.id;
      dispatch(
        forecastActions.sendForecastItems(parentContract, subContracts, id),
      );
    }
  }, [parentContract, subContracts, forecastData]);

  const handleDoneForecast = () => {
    setModalOpen(false);
    dispatch(forecastActions.clearForecastData());
    dispatch(forecastActions.getForecastId({ type: 'newForecast' }));
    dispatch(
      forecastActions.getForecastItems({ forecastStatus: ForecastStatus.NEW }),
    );
  };
  return (
    <>
      <Grid container spacing={3}>
        <Grid item>
          <Typography
            color="textPrimary"
            variant="h5"
            paddingLeft={1}
            marginBottom={2}
          >
            Creating Forecast
          </Typography>
        </Grid>
      </Grid>
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <LinearProgressWithLabel value={progress} color="primary" />
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            mt: 1,
          }}
        >
          <span>
            {progress < 99
              ? 'Please wait while the process is completed...'
              : 'Forecast Items Added Successfully'}
          </span>
          <span>
            Failed {failedAmount} out of {totalItems}
          </span>
        </Box>
      </Box>
      <Box
        sx={{ mt: 2 }}
        display="flex"
        justifyContent="end"
        alignContent="end"
      >
        <Button
          color="primary"
          sx={{
            m: '0 6px',
            p: '6px 10px',
            fontSize: '14px',
          }}
          variant="contained"
          onClick={handleDoneForecast}
          disabled={progress < 99}
        >
          Continue
        </Button>
      </Box>
    </>
  );
};
export default ForecastProgress;
