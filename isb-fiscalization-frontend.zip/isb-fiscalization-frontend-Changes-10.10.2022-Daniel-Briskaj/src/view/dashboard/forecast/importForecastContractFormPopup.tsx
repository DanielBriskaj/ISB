import { yupResolver } from '@hookform/resolvers/yup';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import Close from 'src/icons/X';
import forecastActions from 'src/modules/forecast/forecastActions';
import forecastSelector from 'src/modules/forecast/forecastSelector';
import { forecastSchema } from 'src/modules/shared/yup/forecastSchema';
import DeleteForecastForm from 'src/view/materialUI/components/widgets/forms/ForecastForm/deleteForecastForm';
import ImportForecastContractForm from 'src/view/materialUI/components/widgets/forms/ForecastForm/importForecastContractForm';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';

interface ImportForecastContractFormProps {
  setModalOpen: any;
}
interface ForecastProps {
  name: any;
  month: string;
  year: string;
  contract: any;
}
const ImportContractForecastFormPopup: React.FC<
  ImportForecastContractFormProps
> = ({ setModalOpen }) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const forecastData = useSelector(forecastSelector.forecastData);

  const [dialogOpen, setDialogOpen] = useState(false);

  const initialValues: ForecastProps = {
    name: '',
    year: '',
    month: '',
    contract: null,
  };

  const form = useForm({
    resolver: yupResolver(forecastSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const selectedForecast = form.watch(`name`);
  const selectedContract = form.watch(`contract`);

  const handleImportSingleContract = () => {
    const data = {
      contractId: selectedContract?.id,
      id: selectedForecast?.id,
    };

    dispatch(forecastActions.importSingleContract(data));
    setModalOpen(false);
  };

  useEffect(() => {
    if (Object.keys(selectedForecast)?.length > 0) {
      Object.keys(selectedForecast).forEach(key => {
        if (key === 'name') {
          return;
        } else {
          form.setValue(key as keyof ForecastProps, selectedForecast[key]);
        }
      });
    }
  }, [selectedForecast]);

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Import New Contract
              </Typography>
            </Grid>
            <Grid item>
              <Close
                onClick={() => {
                  setModalOpen(false);
                }}
              />
            </Grid>
          </Grid>

          <FormProvider {...form}>
            <form>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <ImportForecastContractForm />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={handleImportSingleContract}
                  disabled={!selectedForecast || !selectedContract}
                >
                  Import
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 8px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};
export default ImportContractForecastFormPopup;
