import { Box, TextField, InputAdornment } from '@material-ui/core';
import { debounce } from 'lodash';
import React from 'react';
import SearchIcon from 'src/icons/Search';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

interface ForecastFilterProps {
  setCurrentPage: React.Dispatch<React.SetStateAction<number>>;
  setSupplierName: React.Dispatch<React.SetStateAction<string>>;
  setContractCode: React.Dispatch<React.SetStateAction<string>>;
  setCostOwnerName: React.Dispatch<React.SetStateAction<string>>;
  role: string;
  setItemStatus: React.Dispatch<React.SetStateAction<string>>;
  costOwnerId: number;
}
const ForecastFilters: React.FC<ForecastFilterProps> = ({
  setContractCode,
  setCurrentPage,
  setSupplierName,
  setCostOwnerName,
  role,
  setItemStatus,
  costOwnerId,
}) => {
  const handleSupplierSearch = e => {
    setSupplierName(e.target.value);
    setCurrentPage(0);
  };
  const debounceSupplierSearch = debounce(handleSupplierSearch, 500);

  const handleContractSearch = e => {
    setContractCode(e.target.value);
    setCurrentPage(0);
  };
  const debounceContractSearch = debounce(handleContractSearch, 500);

  const handleCostOwnerSearch = e => {
    setCostOwnerName(e.target.value);
    setCurrentPage(0);
  };
  const debounceCostOwnerSearch = debounce(handleCostOwnerSearch, 500);

  const handleStatusSearch = e => {
    setItemStatus(e.target.value);
    setCurrentPage(0);
  };

  return (
    <Box sx={{ m: 1, display: 'flex', alignItems: 'center' }}>
      <TextField
        fullWidth
        className="search-input"
        size="small"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon fontSize="small" />
            </InputAdornment>
          ),
        }}
        placeholder="Supplier Company Name"
        variant="outlined"
        sx={{ mr: 1 }}
        onChange={debounceSupplierSearch}
        disabled={
          (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
          !costOwnerId
        }
      />
      <TextField
        fullWidth
        className="search-input"
        size="small"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon fontSize="small" />
            </InputAdornment>
          ),
        }}
        placeholder="Contract Code"
        variant="outlined"
        sx={{ mr: 1 }}
        onChange={debounceContractSearch}
        disabled={
          (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
          !costOwnerId
        }
      />
      {role === ROLES.PLANNING_CONTROL_INPUT ||
      role === ROLES.PLANNING_CONTROL_AUTHORIZER ? (
        <>
          <TextField
            fullWidth
            className="search-input"
            size="small"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
            placeholder="Cost Owner Name"
            variant="outlined"
            sx={{ mr: 1 }}
            onChange={debounceCostOwnerSearch}
          />
          <Box
            sx={{
              m: 1,
              maxWidth: '100%',
              width: 240,
            }}
          >
            <TextField
              onChange={handleStatusSearch}
              fullWidth
              size="small"
              label={'Filter by status'}
              name="sort"
              select
              InputLabelProps={{ shrink: true }}
              inputProps={{
                style: {
                  minWidth: 110,
                  padding: '4.5px 14px',
                },
              }}
              SelectProps={{
                native: true,
              }}
              variant="outlined"
            >
              <option value={''}>ALL</option>
              <option value={'CREATED'}>CREATED</option>
              <option value={'IN_APPROVAL_BY_COA'}>IN APPROVAL BY COA</option>
              <option value={'IN_APPROVAL_BY_PCI'}>IN APPROVAL BY PCI</option>
              <option value={'IN_APPROVAL_BY_PCA'}>IN APPROVAL BY PCA</option>
              <option value={'APPROVED'}>APPROVED</option>
            </TextField>
          </Box>
        </>
      ) : (
        <></>
      )}
    </Box>
  );
};

export default ForecastFilters;
