import { yupResolver } from '@hookform/resolvers/yup';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { ForecastStatus } from 'src/enums/status';
import { forecastDataTransformer } from 'src/helpers/budgetAndForecastHelpers/dataTransformer';
import Close from 'src/icons/X';
import forecastActions from 'src/modules/forecast/forecastActions';
import forecastSelector from 'src/modules/forecast/forecastSelector';
import { forecastSchema } from 'src/modules/shared/yup/forecastSchema';
import ForecastForm from 'src/view/materialUI/components/widgets/forms/ForecastForm/ForecastForm';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import ForecastProgress from './forecastProgress';

interface ForecastFormProps {
  setModalOpen: any;
  closingForecast: boolean;
  setClosingForecast: any;
}
interface ForecastProps {
  name: string;
  month: string;
  year: string;
  dueDate: Date | string;
  forecastStatus: string;
}
const ForecastFormPopup: React.FC<ForecastFormProps> = ({
  setModalOpen,
  closingForecast,
  setClosingForecast,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const forecastCreatedData = useSelector(forecastSelector.forecastCreated);
  const [forecastCreated, setForecastCreated] = useState(false);
  const forecastData = useSelector(forecastSelector.forecastData);
  const forecastID = useSelector(forecastSelector.forecastId);
  const initialValues: ForecastProps = {
    name: '',
    month: '',
    year: '',
    dueDate: '',
    forecastStatus: ForecastStatus.NEW,
  };

  const form = useForm({
    resolver: yupResolver(forecastSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    if (closingForecast) {
      const transformedData = forecastDataTransformer(data);
      dispatch(
        forecastActions.updateForecast({
          id: forecastID,
          data: transformedData,
        }),
      );
      setModalOpen(false);
      setForecastCreated(false);
      dispatch(forecastActions.clearForecastData());
    } else {
      dispatch(forecastActions.createForecast({ data }));
      setForecastCreated(true);
    }
  };

  useEffect(() => {
    if (Object.keys(forecastData)?.length > 0) {
      Object.keys(forecastData).forEach(key => {
        form.setValue(key as keyof ForecastProps, forecastData[key]);
      });
    }
  }, [forecastData]);

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          {!forecastCreatedData && (
            <>
              <Grid container justifyContent="space-between" spacing={3}>
                <Grid item>
                  <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                    Forecast Planning
                  </Typography>
                </Grid>
                <Grid item>
                  <Close
                    onClick={() => {
                      setModalOpen(false);
                    }}
                  />
                </Grid>
              </Grid>

              <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                  <Divider />
                  <Box sx={{ mt: 3 }} height="100%">
                    <ForecastForm
                      disabled={closingForecast}
                      data={forecastData}
                    />
                  </Box>
                  <Box
                    sx={{ mt: 2 }}
                    display="flex"
                    justifyContent="end"
                    alignContent="end"
                  >
                    <Button
                      color="primary"
                      sx={{
                        m: '0 6px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      type="submit"
                    >
                      {closingForecast ? 'Finalize' : 'Initialize'}
                    </Button>
                    <Button
                      sx={{
                        background: '#666',
                        '&:hover': {
                          background: '#333',
                        },
                        m: '0 8px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      onClick={() => setModalOpen(false)}
                    >
                      Cancel
                    </Button>
                  </Box>
                </form>
              </FormProvider>
            </>
          )}
          {forecastCreated && forecastCreatedData && (
            <ForecastProgress setModalOpen={setModalOpen} />
          )}
        </Container>
      </Box>
    </>
  );
};
export default ForecastFormPopup;
