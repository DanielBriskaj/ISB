import { TableRow, TableCell, IconButton } from '@material-ui/core';
import { getStatusLabel } from 'src/helpers/contractStatusLabel';
import PencilAltIcon from '../../../icons/PencilAlt';

const getSubRows = (
  items,
  selectedRow,
  handleRowClick,
  style,
  setContractModalOpen,
  setContractInfo,
  columns,
) => {
  return items.length > 0 ? (
    items?.map(subItem => {
      return (
        <TableRow
          hover
          sx={
            subItem?.id === selectedRow
              ? {
                  backgroundColor: 'lavender',
                  height: '40px',
                }
              : { height: '40px' }
          }
          onClick={() => {
            handleRowClick(subItem?.id);
          }}
          key={subItem?.id}
          selected={subItem?.id === selectedRow ? false : true}
        >
          <TableCell align="center"></TableCell>
          <TableCell
            align="left"
            sx={{
              paddingLeft: 3,
              maxWidth: '150px',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
          >
            {subItem?.supplier?.companyName}
          </TableCell>
          <TableCell align="center" sx={style}>
            {subItem?.costOwner?.ownerName}
          </TableCell>
          <TableCell align="center" width={50}>
            {subItem?.branch?.branchCode}
          </TableCell>
          <TableCell align="center" sx={style}>
            {getStatusLabel(subItem?.contractStatus)}
          </TableCell>
          <TableCell align="center" sx={style}>
            {subItem?.contractCode}
          </TableCell>
          <TableCell align="center" sx={style}></TableCell>
          <TableCell align="center" width={100}>
            <IconButton
              onClick={() => {
                setContractModalOpen(true);
                setContractInfo({
                  id: subItem?.id,
                  contractStatus: 'ACTIVE',
                  itemStatus: subItem?.forecastItemStatus,
                });
              }}
            >
              <PencilAltIcon fontSize="small" />
            </IconButton>
          </TableCell>
          <TableCell></TableCell>
        </TableRow>
      );
    })
  ) : (
    <TableRow>
      <TableCell
        sx={{
          textAlign: 'center',
          fontSize: '1.01rem',
          fontWeight: '500',
          color: '#777',
          padding: '1.15rem 0.9rem',
        }}
        colSpan={columns?.length}
      >
        No subcontracts
      </TableCell>
    </TableRow>
  );
};

export default getSubRows;
