import { useEffect, useRef, useState } from 'react';
import { Box, Grid, TextField } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { Helmet } from 'react-helmet-async';

import poSelector from 'src/modules/PO/poSelector';
import DynamicTable from '../../materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from '../../materialUI/components/WidgetPreviewer';
import poActions from 'src/modules/PO/poActions';
import { poFields } from 'src/enums/shared/headerFields/poFields';
import PoFormPopup from './PoFormPopup';
import Plus from 'src/icons/Plus';

import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import authSelector from 'src/modules/shared/authentication/authSelector';
import RolePOstatusRender, {
  ApproveAllStatusRender,
} from 'src/helpers/POhelplers/RolePOstatusRender';
import StatusArrayRender from 'src/helpers/POhelplers/statusArrayRender';
import { debounce } from 'lodash';
import ReactSelect from 'src/view/materialUI/components/ReactSelect';
import { useForm } from 'react-hook-form';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import notificationThrower from 'src/helpers/notificationThrower';

type POStatusInput =
  | ''
  | 'NEW'
  | 'COA'
  | 'PRI'
  | 'PRA'
  | 'APPROVED'
  | 'COMPLETED';
const POStatusOptions = [
  { value: '', label: 'ALL' },
  { value: 'NEW', label: 'NEW' },
  { value: 'COA', label: 'COA' },
  { value: 'PRI', label: 'PRI' },
  { value: 'PRA', label: 'PRA' },
  { value: 'APPROVED', label: 'APPROVED' },
  { value: 'COMPLETED', label: 'COMPLETED' },
];

const PoTable = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [poId, setPoId] = useState(null);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [sortDirection, setSortDirection] = useState('desc');
  const [rejectedPoDesc, setRejectedPoDesc] = useState(null);
  const [statusFilter, setStatusFilter] = useState<POStatusInput>('');
  const [supplierCompanyName, setSupplierCompanyName] = useState<string>();
  const [costOwnerOptions, setCostOwnerOptions] = useState([]);
  const [costOwnerPage, setCostOwnerPage] = useState(0);
  const [selectedCostOwner, setSelectedCostOwner] = useState({ id: null });

  const dispatch = useDispatch();

  const posData = useSelector(poSelector.purchaseOrderData);
  const costOwnersData = useSelector(invoiceSelector?.costOwnersOptions);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const { role, division, costOwnerId } = authData;

  const {
    register,
    setValue,
    formState: { errors },
    watch,
  } = useForm();

  const sortOptions = [
    { label: 'ASC', value: 'asc' },
    { label: 'DESC', value: 'desc' },
  ];

  const poStatus = StatusArrayRender(role);
  const query: any = {};
  query.poStatus = statusFilter;
  query.size = limitPerPage;
  query.page = currentPage;
  query.coaDivision = division;
  query.sort = `id,${sortDirection}`;
  query.supplierCompanyName = supplierCompanyName;
  query.costOwnerId = selectedCostOwner?.id;

  useEffect(() => {
    if (
      (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
      !costOwnerId
    ) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong',
      });
    } else {
      dispatch(poActions.fetchPO(query));
    }
  }, [
    sortDirection,
    limitPerPage,
    currentPage,
    statusFilter,
    supplierCompanyName,
    selectedCostOwner,
  ]);

  useEffect(() => {
    if (
      role === ROLES.PROCUREMENT_AUTHORIZER ||
      role === ROLES.PROCUREMENT_INPUT
    ) {
      dispatch(
        invoiceActions.readCostOwners({
          size: 200,
          page: costOwnerPage,
          approved: 'APPROVED',
        }),
      );
    }
  }, [costOwnerPage]);

  const handleOnMenuScrollToBottom = event => {
    if (costOwnerPage < costOwnersData?.totalPages - 1) {
      setCostOwnerPage(costOwnerPage + 1);
    }
  };

  useEffect(() => {
    if (posData?.po) {
      setTableData(
        posData?.po?.map(po => ({
          companyName: po?.supplier?.companyName,
          id: po?.id,
          date: po?.date,
          poStatus: po?.poStatus,
          contractCode: po?.contract?.contractCode,
          branchCode: po?.contract?.branch?.branchCode,
        })),
      );
    }
    setTotalItems(posData?.totalItems);
  }, [posData]);

  useEffect(() => {
    if (costOwnersData?.costOwners) {
      const nonAuthCostOwners = costOwnersData?.costOwners?.filter(
        costOwner => costOwner?.isAuthorizer === false,
      );
      setCostOwnerOptions(state => [
        ...state,
        ...nonAuthCostOwners.map(costOwner => ({
          label: `${costOwner.code} - ${costOwner.ownerName}`,
          value: {
            id: costOwner.id,
          },
        })),
      ]);
    }
  }, [costOwnersData]);

  useEffect(() => {
    return () => {
      dispatch(invoiceActions.clearCostOwnerOptions());
    };
  }, []);

  function handleModalOpen(id?) {
    if (typeof id === 'number') {
      setPoId(id);
    } else {
      dispatch(poActions.clearPoData());
      setPoId(null);
    }
    setModalOpen(!modalOpen);
  }

  function handleDialogOpen(id?) {
    if (id) {
      setPoId(id);
    }
    setDialogOpen(true);
  }

  const handleDelete = () => {
    dispatch(poActions.deletePO(poId?.id, query));
  };

  const handleReject = data => {
    const payload: any = {};
    payload.data = {
      poStatus: RolePOstatusRender(role, 'Reject'),
      authorizerFeedback: data?.reason,
    };
    payload.id = poId;

    dispatch(poActions.changeStatusPO(query, payload, role, 'Rejected'));
    setDialogOpen(false);
    setModalOpen(false);
  };

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const handleSorting = sortDirection => {
    setSortDirection(sortDirection);
    setCurrentPage(0);
  };

  const handleApproveAll = () => {
    const status = ApproveAllStatusRender(role);
    dispatch(poActions.batchUpdate(status, query));
  };

  const poButtonData = [
    {
      label: 'Add PO',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleModalOpen,
      disabled: !costOwnerId,
    },
    {
      label:
        role === ROLES.PROCUREMENT_INPUT
          ? 'Send All For Approval'
          : 'Approve All',
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleApproveAll,
      disabled: role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId,
    },
  ];

  const filterButtons = () => {
    if (role === ROLES.COST_OWNER) {
      return poButtonData.filter(item => item.label === 'Add PO');
    } else {
      return poButtonData.filter(item => item.label !== 'Add PO');
    }
  };

  const poSortingData = [
    {
      label: 'Sort Direction',
      sortOptions: sortOptions,
      handleSorting: handleSorting,
      defaultValue: sortDirection,
      disabled:
        (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
        !costOwnerId,
    },
  ];

  const getFilterComponent = () => {
    return (
      <>
        <Box
          sx={{
            m: 1,
            maxWidth: '100%',
            width: 240,
            display: 'flex',
            justifySelf: 'flex-start',
          }}
        >
          <TextField
            onChange={event => {
              setStatusFilter(event.target.value as POStatusInput);
              setCurrentPage(0);
            }}
            fullWidth
            size="small"
            label={'Filter by status'}
            name="filterByStatus"
            select
            InputLabelProps={{ shrink: true }}
            inputProps={{
              style: {
                minWidth: 110,
                padding: '4.5px 14px',
              },
            }}
            SelectProps={{
              native: true,
            }}
            variant="outlined"
            disabled={
              (role === ROLES.COST_OWNER ||
                role === ROLES.COST_OWNER_AUTHORIZER) &&
              !costOwnerId
            }
          >
            {POStatusOptions.map(
              (POStatusOption: { value: string; label: string }) => {
                return (
                  <option
                    selected={statusFilter === POStatusOption.value}
                    value={POStatusOption.value}
                  >
                    {POStatusOption.label}
                  </option>
                );
              },
            )}
          </TextField>
        </Box>
        {(role === ROLES.PROCUREMENT_INPUT ||
          role === ROLES.PROCUREMENT_AUTHORIZER) && (
          <Box
            sx={{
              m: 1,
              maxWidth: '100%',
              width: 240,
              display: 'flex',
              justifySelf: 'flex-start',
            }}
            className="table-select-container"
          >
            <Grid item md={12} xs={12}>
              <ReactSelect
                options={costOwnerOptions}
                name={`costOwner`}
                placeholder="Cost Owner"
                errors={errors}
                menuHeight={300}
                isClearable={true}
                handleSelect={option => {
                  setCurrentPage(0);
                  setValue('costOwner', option?.value ?? null);
                  setSelectedCostOwner(option?.value ?? null);
                }}
                handleOnMenuScrollToBottom={event =>
                  handleOnMenuScrollToBottom(event)
                }
              />
            </Grid>
          </Box>
        )}
      </>
    );
  };

  const supplierCompanyNameSearchOnChange = event => {
    setSupplierCompanyName(event.target.value);
    setCurrentPage(0);
  };
  const handleSupplierCompanyNameSearch = debounce(
    supplierCompanyNameSearchOnChange,
    300,
  );

  const searchFunctionArray = [
    {
      placeholder: 'Supplier Company Name',
      function: handleSupplierCompanyNameSearch,
      customClass: 'search-input',
      disabled:
        (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
        !costOwnerId,
    },
  ];

  const modalWrapperData = [
    {
      children: (
        <PoFormPopup
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          poId={poId}
          query={query}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setDialogOpen={setDialogOpen}
          handleDelete={poId?.type === 'delete' ? handleDelete : handleReject}
          message={
            poId?.type === 'delete'
              ? `Are you sure you want to delete this PO ?`
              : `Why are you choosing to reject this PO ?`
          }
          hasFeedback={poId?.type === 'delete' ? false : true}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];
  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
        }}
      >
        <Box>
          <WidgetPreviewer
            element={
              <DynamicTable
                tableType="poTable"
                headerFields={poFields}
                data={tableData}
                loading={loading}
                buttonData={role && filterButtons()}
                handleModalOpen={handleModalOpen}
                handleDialogOpen={handleDialogOpen}
                handleDelete={handleDelete}
                currentPage={currentPage}
                totalItems={totalItems}
                limitPerPage={limitPerPage}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                sortData={poSortingData}
                sortDirection={sortDirection}
                query={query}
                StatusFilterComponent={getFilterComponent()}
                searchArrayOfFunctions={searchFunctionArray}
              />
            }
            name="Purchase Order Table"
          />
        </Box>
        {modalWrapperData &&
          modalWrapperData.map(modalData => {
            return <ModalWrapper {...modalData} />;
          })}
      </Box>
    </>
  );
};

export default PoTable;
