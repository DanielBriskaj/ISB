import React, { useEffect } from 'react';
import {
  Box,
  Container,
  Grid,
  Divider,
  Button,
  Typography,
} from '@material-ui/core';
import Close from 'src/icons/X';
import { useForm, FormProvider } from 'react-hook-form';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import { yupResolver } from '@hookform/resolvers/yup';
import { useSelector, useDispatch } from 'react-redux';
import PoForm from 'src/view/materialUI/components/widgets/forms/PoForm';
import { poSchema } from 'src/modules/shared/yup/poSchema';
import poActions from 'src/modules/PO/poActions';
import poSelector from 'src/modules/PO/poSelector';
import moment from 'moment';
import { PurchaseOrderData } from 'src/models/data/po/PoData';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { toggleDisplay } from 'src/view/materialUI/utils/toggleDisable';
import RolePOstatusRender from 'src/helpers/POhelplers/RolePOstatusRender';
import { poStatus } from 'src/enums/status';
import IsAuthorizer from 'src/helpers/isAuthorizer';

const PoFormPopup = ({ setModalOpen, setDialogOpen, poId, query }) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const poData = useSelector(poSelector.poData);
  const authData = useSelector(authSelector.authData);
  const { costOwnerId, role } = authData;
  let isEditModal: boolean;

  const initialValues: PurchaseOrderData = {
    authorizerFeedback: '',
    date: '',
    deliverAtName: '',
    deliverAtAddress: '',
    deliverAtTelFax: '',
    deliverAtCel: '',
    deliverAtEmail: '',
    transportedVia: '',
    termsOfTransportation: '',
    poStatus: 'NEW',
    contract: { id: null },
    costOwner: { id: costOwnerId },
    supplier: { id: null },
    poItems: [],
    currency: '',
    description: '',
  };

  const form = useForm({
    resolver: yupResolver(poSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    if (poId && typeof poId === 'number') {
      if (data?.contract?.id === null) {
        data.contract = null;
      }
      dispatch(poActions.updatePO(poId, data, query));
      setModalOpen(false);
    } else {
      dispatch(poActions.createPO(data, query));
      setModalOpen(false);
    }
  };

  useEffect(() => {
    if (typeof poId === 'number') {
      dispatch(poActions.getById(poId));
    }
  }, [dispatch, poId]);

  useEffect(() => {
    form.reset();
    if (poId !== null && poData) {
      Object.keys(poData).forEach(key => {
        if (poData[key] !== null) {
          if (Array.isArray(poData[key])) {
            poData[key].forEach((poListItem, index) => {
              Object.keys(poListItem).forEach(k => {
                form.setValue(`poItems.${index}.${k}`, poListItem[k]);
              });
            });
          } else if (typeof poData[key] === 'object') {
            Object.keys(poData[key]).forEach(objKey => {
              if (key === 'supplier' && objKey === 'id') {
                form.setValue(
                  `${key}.${objKey}` as keyof PurchaseOrderData,
                  poData[key][objKey],
                );
              }
              if (key === 'contract' && objKey === 'id') {
                form.setValue(
                  `${key}.${objKey}` as keyof PurchaseOrderData,
                  poData[key][objKey],
                );
              }
            });
          } else {
            form.setValue(key as keyof PurchaseOrderData, poData[key]);
          }
        }
      });
    }

    if (Object.keys(poData).length === 0) {
      form.setValue('date', moment(new Date()).format('YYYY-MM-DD'));
    }
  }, [poData]);

  const assignPo = async () => {
    const payload: any = {};
    payload.data = { poStatus: RolePOstatusRender(role, 'Assign') };
    payload.id = poId;

    dispatch(poActions.changeStatusPO(query, payload, role, 'Assigned'));
  };

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Purchase Order
              </Typography>
            </Grid>
            <Grid item>
              <Close
                onClick={() => {
                  setModalOpen(false);
                }}
              />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <PoForm
                  id={poId}
                  isEditModal={
                    poId !== null ? (isEditModal = true) : (isEditModal = false)
                  }
                />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role === 'COST_OWNER' && (
                  <>
                    <Button
                      color="primary"
                      sx={{
                        m: '0 6px',
                        p: '6px 10px',
                        fontSize: '14px',
                        display:
                          poId === null
                            ? 'inherit'
                            : toggleDisplay(role, poData.poStatus),
                      }}
                      variant="contained"
                      type="submit"
                    >
                      Save
                    </Button>
                    <Button
                      sx={{
                        background: '#666',
                        '&:hover': {
                          background: '#333',
                        },
                        m: '0 8px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      type="button"
                      onClick={() => setModalOpen(false)}
                    >
                      Cancel
                    </Button>
                  </>
                )}
                {role !== 'COST_OWNER' && role === poStatus[poData.poStatus] ? (
                  <>
                    <Button
                      color="primary"
                      sx={{
                        m: '0 6px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      type="button"
                      onClick={() => {
                        assignPo();
                        setModalOpen(false);
                      }}
                    >
                      Approve
                    </Button>
                    <Button
                      sx={{
                        background: '#666',
                        '&:hover': {
                          background: '#333',
                        },
                        m: '0 8px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      type="button"
                      onClick={() => {
                        setDialogOpen(true);
                      }}
                    >
                      Reject
                    </Button>
                  </>
                ) : (
                  role !== 'COST_OWNER' && (
                    <>
                      <Button
                        sx={{
                          background: '#666',
                          '&:hover': {
                            background: '#333',
                          },
                          m: '0 8px',
                          p: '6px 10px',
                          fontSize: '14px',
                        }}
                        variant="contained"
                        onClick={() => {
                          setModalOpen(false);
                        }}
                      >
                        Cancel
                      </Button>
                    </>
                  )
                )}
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default PoFormPopup;
