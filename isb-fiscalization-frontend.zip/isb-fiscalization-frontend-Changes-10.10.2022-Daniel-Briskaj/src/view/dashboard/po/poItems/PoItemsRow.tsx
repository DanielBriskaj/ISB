import {
  TableCell,
  TableRow,
  IconButton,
  TextField,
  FormControl,
  MenuItem,
  Select,
} from '@material-ui/core';
import Trash from '../../../../icons/Trash';
import { useFormContext, useFieldArray } from 'react-hook-form';
import { useState, useEffect, useRef } from 'react';
import { currency } from 'src/enums/currency';
import { ErrorMessage } from '@hookform/error-message';
import { prependOnceListener } from 'process';
import numberWithCommas from 'src/helpers/numberWithCommas';

const PoItemsRow = ({
  poItem,
  index,
  setValuesArray,
  valuesArray,
  handleDelete,
  page,
  rowsPerPage,
  isEditModal,
  isEditable,
}) => {
  const { register, formState: errors, setValue, getValues } = useFormContext();
  const { fields, append, prepend, remove, swap, move, insert } = useFieldArray(
    {
      name: 'poItems', // unique name for your Field Array
      // keyName: "id", default to "id", you can change the key name
    },
  );

  const [price, setPrice] = useState(0);
  const [quantity, setQuantity] = useState(0);
  const [stateValue, setStateValue] = useState(0);

  function round(num) {
    var m = Number((Math.abs(num) * 100).toPrecision(15));
    return (Math.round(m) / 100) * Math.sign(num);
  }

  useEffect(() => {
    if (getValues(`poItems.${index}.price`)) {
      setPrice(getValues(`poItems.${index}.price`));
    }
    if (getValues(`poItems.${index}.quantity`)) {
      setQuantity(getValues(`poItems.${index}.quantity`));
    }
  }, []);

  useEffect(() => {
    setStateValue(price * quantity);
  }, [price, quantity]);

  useEffect(() => {
    setValuesArray(values => [
      ...values.slice(0, index),
      stateValue,
      ...values.slice(index + 1),
    ]);
  }, [stateValue]);

  return (
    <TableRow hover key={poItem.id}>
      {Object.keys(poItem).map(key => {
        if (key === 'id') {
          return;
        }
        if (key === 'addRow') {
          return;
        }
        if (key === 'isFocused') {
          return;
        }
        if (key === 'value') {
          return;
        }
        return (
          <TableCell
            key={poItem['id'] + '_' + key}
            sx={{ paddingRight: 1.5, paddingY: 1 }}
            align={
              key === 'currency' || key === 'quantity' || key === 'price'
                ? 'center'
                : 'left'
            }
          >
            <TextField
              key={poItem['id']}
              ref={register}
              {...register(`poItems.${index}.${key}`)}
              onChange={event => {
                if (key === 'quantity') {
                  setQuantity(+event.target.value);
                }
                if (key === 'price') {
                  setPrice(+event.target.value);
                }
                setValue(`poItems.${index}.${key}`, event.target.value);
              }}
              autoFocus={key === 'description' && poItem.isFocused}
              fullWidth
              defaultValue={
                key === 'description' || key === 'quantity' ? ' ' : '0.00'
              }
              size="small"
              name={`poItems.${index}.${key}`}
              variant="standard"
              type={key === 'description' ? 'text' : 'number'}
              InputProps={
                key === 'description'
                  ? {
                      disableUnderline: true,
                      inputProps: { style: { textAlign: 'center' } },
                    }
                  : {
                      inputProps: {
                        style: { textAlign: 'center' },
                        min: 0,
                        step: key === 'quantity' ? 1 : 0.01,
                      },
                      disableUnderline: true,
                    }
              }
              disabled={isEditable ? false : true}
            />
            {errors.errors && (
              <ErrorMessage
                errors={errors.errors}
                name={`poItems.${index}.${key}`}
                render={({ message }) => (
                  <p
                    style={{
                      color: 'red',
                      marginTop: '0px',
                      padding: '5px 10px 15px 0px',
                    }}
                  >
                    {message}
                  </p>
                )}
              />
            )}
          </TableCell>
        );
      })}
      <TableCell sx={{ paddingX: 5, paddingY: 1 }} align="center">
        {numberWithCommas(round(stateValue).toFixed(2))}
      </TableCell>
      <TableCell align="center">
        <IconButton
          disabled={!isEditable}
          onClick={() => {
            const index = valuesArray.indexOf(stateValue);
            setValuesArray(values => [...values.splice(index + 1)]);
            remove(index);
            handleDelete(index);
          }}
        >
          <Trash fontSize="small" />
        </IconButton>
      </TableCell>
    </TableRow>
  );
};

export default PoItemsRow;
