import { useEffect, useState, useCallback } from 'react';
import type { FC } from 'react';
import { Box, TableCell, TableHead, TableRow } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { Helmet } from 'react-helmet-async';

import poSelector from 'src/modules/PO/poSelector';
import DynamicTable from '../../../materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from '../../../materialUI/components/WidgetPreviewer';
import poActions from 'src/modules/PO/poActions';
import { poItemsFields } from 'src/enums/shared/headerFields/poItemsFields';
import { debounce } from 'lodash';
import FormPopupModal from 'src/view/shared/modal/FormPopupModal';
import ModalChild from 'src/view/shared/modal/ModalChild';
import SuccessForm from 'src/view/materialUI/components/widgets/modals/SuccessFormMessage';
import Plus from 'src/icons/Plus';
import { states } from 'src/enums/state';
import numberWithCommas from 'src/helpers/numberWithCommas';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import authSelector from 'src/modules/shared/authentication/authSelector';

const PoItemsTable: FC = () => {
  const poData = useSelector(poSelector.poData);
  const authData = useSelector(authSelector.authData);
  const { role } = authData;
  const [modalOpen, setModalOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [poId, setPoId] = useState(null);
  const dispatch = useDispatch();
  const [valuesArray, setValuesArray] = useState([]);

  const addRowItem = {
    description: '',
    quantity: '',
    price: '',
  };

  let isEditModal: boolean;
  let isEditable: boolean;

  if (Object.keys(poData).length !== 0) {
    isEditModal = true;
  } else isEditModal = false;

  if (
    (Object.keys(poData).length !== 0 && poData.poStatus !== 'NEW') ||
    role !== ROLES.COST_OWNER
  ) {
    isEditable = false;
  } else isEditable = true;

  function addRow() {
    setTableData(state => [...state, { ...addRowItem, isFocused: true }]);
  }

  function round(num) {
    var m = Number((Math.abs(num) * 100).toPrecision(15));
    return (Math.round(m) / 100) * Math.sign(num);
  }

  function handleDelete(index) {
    var array = [...tableData]; // make a separate copy of the array
    array.splice(index, 1);
    setTableData(array);
  }

  useEffect(() => {
    if (Array.isArray(poData['poItems']) && poData['poItems'].length > 0) {
      setTableData(poData['poItems']);
    }
  }, [poData]);

  const tableFooterData = {
    children: (
      <TableRow>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}>
          Total Values :{' '}
          {numberWithCommas(
            round(valuesArray.reduce((a, v) => (a = a + v), 0)).toFixed(2),
          )}
        </TableCell>
      </TableRow>
    ),
    setValuesArray,
    valuesArray,
  };

  const poButtonData =
    isEditModal && isEditable === false
      ? [{}]
      : [
          {
            label: 'Add Item',
            startIcon: <Plus />,
            color: 'primary',
            size: 'large',
            variant: 'contained',
            sx: { mr: 1 },
            onClick: addRow,
          },
        ];

  return (
    <>
      {/* <Helmet>
        <title>Browse: Tables | Material Kit Pro</title>
      </Helmet> */}

      <DynamicTable
        tableType="poItemsTable"
        headerFields={poItemsFields}
        data={tableData}
        buttonData={poButtonData}
        tableFooterData={tableFooterData}
        handleDelete={handleDelete}
        isEditModal={isEditModal}
        isEditable={isEditable}
      />
    </>
  );
};

export default PoItemsTable;
