import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import PencilAltIcon from '../../../icons/PencilAlt';
import Download from '../../../icons/Download';
import Trash from 'src/icons/Trash';
import authSelector from 'src/modules/shared/authentication/authSelector';
import poActions from 'src/modules/PO/poActions';
import RolePOstatusRender from 'src/helpers/POhelplers/RolePOstatusRender';
import { poStatus } from 'src/enums/status';
import getPOStatusLabel from 'src/helpers/POhelplers/getPOStatusLabel';

const PoRow = props => {
  const { po, handleModalOpen, handleDelete, handleDialogOpen, query } = props;

  const authData = useSelector(authSelector.authData);
  const { role } = authData;
  const dispatch = useDispatch();

  const exportPoData = async () => {
    dispatch(poActions.exportExelFile(po.id));
  };

  const assignPo = async () => {
    const payload: any = {};
    payload.data = { poStatus: RolePOstatusRender(role, 'Assign') };
    payload.id = po.id;

    dispatch(poActions.changeStatusPO(query, payload, role, 'Assigned'));
  };

  return (
    <TableRow hover key={po.id}>
      {po &&
        Object.keys(po).map(key => {
          if (key === 'id') {
            return;
          }
          if (key === 'poStatus') {
            return (
              <TableCell align="center" key={key}>
                {po[key] && getPOStatusLabel(po[key])}
              </TableCell>
            );
          }
          return (
            <TableCell
              key={key}
              sx={
                key === 'companyName' ? { paddingLeft: 3 } : { paddingLeft: 0 }
              }
              align={
                key === 'date' ||
                key === 'invoiceNumber' ||
                key === 'contractCode' ||
                key === 'branchCode'
                  ? 'center'
                  : 'left'
              }
            >
              {po[key] && po[key]}
            </TableCell>
          );
        })}
      <TableCell align="center">
        {role === 'COST_OWNER' && (
          <>
            {' '}
            <IconButton
              onClick={() => handleModalOpen(po.id)}
              disabled={po.poStatus ? false : true}
            >
              <PencilAltIcon fontSize="small" />
            </IconButton>
            <IconButton
              onClick={() => handleDialogOpen({ id: po.id, type: 'delete' })}
            >
              <Trash fontSize="small" />
            </IconButton>
          </>
        )}
        {role !== 'COST_OWNER' && (
          <IconButton
            onClick={() => handleModalOpen(po.id)}
            disabled={po.poStatus ? false : true}
          >
            <PencilAltIcon fontSize="small" />
          </IconButton>
        )}
        <IconButton
          disabled={
            po.poStatus === 'APPROVED' || po.poStatus === 'COMPLETED'
              ? false
              : true
          }
          onClick={() => exportPoData()}
        >
          <Download />
        </IconButton>
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => assignPo()}
          disabled={role !== poStatus[po.poStatus]}
        >
          {role === 'COST_OWNER_AUTHORIZER' || role === 'PROCUREMENT_AUTHORIZER'
            ? 'Approve'
            : 'Send For Approval'}
        </Button>
        {role !== 'COST_OWNER' && (
          <Button
            onClick={() => {
              handleDialogOpen(po.id);
            }}
            disabled={role !== poStatus[po.poStatus]}
          >
            Reject
          </Button>
        )}
      </TableCell>
    </TableRow>
  );
};

export default PoRow;
