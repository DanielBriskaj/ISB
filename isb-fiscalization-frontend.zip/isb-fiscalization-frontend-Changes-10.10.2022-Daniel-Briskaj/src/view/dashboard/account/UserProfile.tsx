import { useState, useEffect } from 'react';
import type { ChangeEvent, FC } from 'react';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Button,
  Card,
  CardActions,
  CardHeader,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableRow,
  TextField,
  Typography,
  Select,
  MenuItem,
  Box,
} from '@material-ui/core';
import HomeIcon from '@material-ui/icons/Home';
import DynamicBreadcrumb from '../../shared/DynamicBreadcrumb';
import authSelector from 'src/modules/shared/authentication/authSelector';

const UserProfile = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [data, setData] = useState({
    name: null,
    surname: null,
    username: null,
    role: null,
  });

  const authedUser = useSelector(authSelector.authData);

  useEffect(() => {
    setData({
      name: authedUser.name,
      surname: authedUser.surname,
      role: authedUser.role,
      username: authedUser.username,
    });
  }, [authedUser]);

  return (
    <Box
      sx={{
        backgroundColor: 'white',
        minHeight: '100%',
      }}
    >
      <DynamicBreadcrumb
        pageName={'Your Profile'}
        breadcrumbs={['Account', 'Your Profile']}
      />
      <Box paddingLeft={5} paddingRight={5} boxShadow={'#f4f5f7'}>
        <Card>
          <CardHeader title="Profile info" />
          <Divider />
          <Box
            sx={{
              padding: '20px',
              backgroundColor: '#f4f5f7',
            }}
          >
            <Table>
              <TableBody
                sx={{
                  border: '1px solid rgba(224, 224, 224, 1)',
                  backgroundColor: '#ffffff',
                  mt: 3,
                  borderRadius: '4px 4px 0 0',
                }}
              >
                <TableRow>
                  <TableCell>
                    <Typography color="textPrimary" variant="subtitle2">
                      Username
                    </Typography>
                  </TableCell>
                  <TableCell>{data.username}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>
                    <Typography color="textPrimary" variant="subtitle2">
                      Name
                    </Typography>
                  </TableCell>
                  <TableCell>{data.name}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>
                    <Typography color="textPrimary" variant="subtitle2">
                      Surname
                    </Typography>
                  </TableCell>
                  <TableCell>{data.surname}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>
                    <Typography color="textPrimary" variant="subtitle2">
                      Role
                    </Typography>
                  </TableCell>
                  <TableCell>{data.role}</TableCell>
                </TableRow>
              </TableBody>
            </Table>

            <CardActions
              sx={{
                mt: '10px',
              }}
            >
              <Button
                color="primary"
                startIcon={<HomeIcon fontSize="small" />}
                variant="text"
                onClick={() => navigate('/dashboard', { replace: true })}
              >
                Back to Dashboard
              </Button>
            </CardActions>
          </Box>
        </Card>
      </Box>
    </Box>
  );
};

export default UserProfile;
