import { useEffect } from 'react';
import {
  Button,
  Container,
  Grid,
  Divider,
  Typography,
  Box,
} from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import Close from 'src/icons/X';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import { useForm, FormProvider } from 'react-hook-form';
import CoaInvoicesForm from 'src/view/materialUI/components/widgets/forms/CoaInvoicesForm';
import costOwnerInvoicesActions from '../../../modules/COAuthorizerInvoices/COAuthorizerInvoicesActions';
import { CoaInvoicesData } from 'src/models/data/invoices/InvoiceData';
import { coaInvoicesSchema } from 'src/modules/shared/yup/coaInvoicesSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';

const COAuthorizerInvoiceDetails = ({
  setModalOpen,
  data,
  handleDialogOpen,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();

  const invoiceData = useSelector(invoiceSelector?.invoiceData);

  useEffect(() => {
    dispatch(invoiceActions.getById(data?.id));
  }, [data.id]);

  useEffect(() => {
    return () => {
      dispatch(invoiceActions.clearSingleInvoice());
    };
  }, []);

  const initialValues: CoaInvoicesData = {
    invoiceNumber: '',
    eic: '',
    receivedDate: '',
    dueDate: '',
    nipt: '',
    amount: 0,
    invoiceStatus: 'SEND_SUBMIT',
    description: '',
    isManual: false,
    currency: '',
    vat: 0,
    contract: null,
    po: null,
    costOwner: null,
    authorizerFeedback: '',
  };

  const form = useForm({
    resolver: yupResolver(coaInvoicesSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = submitData => {
    if (submitData) {
      const action = 'Assign';
      dispatch(
        costOwnerInvoicesActions.invoiceUpdate(
          { invoiceStatus: 'ACCEPTED' },
          submitData.id,
          action,
        ),
      );
      setModalOpen(false);
    }
  };

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          py: 4,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid
            container
            justifyContent="space-between"
            alignItems="center"
            spacing={3}
            sx={{ mb: 2 }}
          >
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Invoice Details
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen && setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box
                sx={{
                  mt: 3,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <CoaInvoicesForm data={invoiceData} />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  variant="contained"
                  type="submit"
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                >
                  Approve
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => {
                    handleDialogOpen({
                      id: invoiceData?.id,
                      isManual: invoiceData?.isManual,
                      poId: invoiceData?.po?.id,
                    });
                  }}
                >
                  Reject
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default COAuthorizerInvoiceDetails;
