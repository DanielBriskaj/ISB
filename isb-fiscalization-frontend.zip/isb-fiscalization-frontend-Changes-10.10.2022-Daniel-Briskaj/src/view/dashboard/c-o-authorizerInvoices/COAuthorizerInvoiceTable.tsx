import { useEffect, useState, useCallback, useRef } from 'react';
import { Box } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import DynamicTable from 'src/view/materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import costOwnerAuthorizerInvoiceSelector from 'src/modules/COAuthorizerInvoices/COAuthorizerInvoicesSelector';
import costOwnerInvoicesActions from 'src/modules/COAuthorizerInvoices/COAuthorizerInvoicesActions';
import COAuthorizerInvoiceDetails from './COAuthorizerInvoiceDetails';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import { COAuthorizerInvoicesFields } from 'src/enums/shared/headerFields/invoicesFields';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import numberWithCommas from 'src/helpers/numberWithCommas';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import notificationThrower from 'src/helpers/notificationThrower';

const COAuthorizerInvoiceTable = () => {
  const navigate = useNavigate();

  const [tableData, setTableData] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [selectedInvoice, setSelectedInvoice] = useState({});
  const [invoiceId, setInvoiceId] = useState(null);

  const dispatch = useDispatch();

  const loading = useSelector(statusSelector.loading);
  const invoicesState = useSelector(
    costOwnerAuthorizerInvoiceSelector.invoicesDataArray,
  );
  const authData = useSelector(authSelector.authData);
  const { costOwnerId, division } = authData;

  const deleteTime = (str: string) =>
    str &&
    str.replace(/^([0-1]?\d|2[0-3])(?::([0-5]?\d))?(?::([0-5]?\d))?$/g, '');

  function handleModalOpen(bool) {
    setModalOpen(bool);
  }

  const handleApproveAll = () => {
    const status = { currentStatus: 'SEND_SUBMIT', newStatus: 'ACCEPTED' };
    dispatch(
      invoiceActions.batchUpdate(status, {
        codeOwnerId: costOwnerId,
        invoiceStatus: 'SEND_SUBMIT',
        coaDivision: division,
        size: 10,
        page: 0,
      }),
    );
  };

  const invoiceButtonData = [
    {
      buttonFunction: selected => {
        setModalOpen(!modalOpen);
        setSelectedInvoice(selected);
      },
    },
    {
      buttonFunction: id => {
        navigate(`/dashboard/c-o-authorizer/invoices/${id}`, { replace: true });
      },
    },
    {
      label: 'Approve All',
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleApproveAll,
      disabled: !costOwnerId,
    },
  ];

  useEffect(() => {
    if (!costOwnerId) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong',
      });
    } else {
      dispatch(
        costOwnerInvoicesActions.readCostOwnerAuthorizerInvoices({
          codeOwnerId: costOwnerId,
          invoiceStatus: 'SEND_SUBMIT',
          coaDivision: division,
          size: limitPerPage,
          page: currentPage,
        }),
      );
    }
  }, [division, limitPerPage, currentPage]);

  useEffect(() => {
    if (
      invoicesState &&
      Object.keys(invoicesState).length === 0 &&
      Object.getPrototypeOf(invoicesState) === Object.prototype
    ) {
    } else {
      if (invoicesState.invoices) {
        setTableData(
          invoicesState.invoices.map(invoice => ({
            eic: invoice.eic,
            invoiceNumber: invoice.invoiceNumber,
            receivedDate: deleteTime(invoice.receivedDate),
            dueDate: invoice.dueDate,
            status: invoice.invoiceStatus,
            amount: numberWithCommas(invoice?.amount.toFixed(2)),
            nipt: invoice.nipt,
            id: invoice.id,
            approved: invoice.approved,
            isManual: invoice?.isManual,
            poId: invoice?.po?.id,
          })),
        );
        setTotalItems(invoicesState.totalItems);
      }
    }
  }, [invoicesState]);

  function handleDialogOpen(id?) {
    if (id) {
      setInvoiceId(id);
    }
    setDialogOpen(true);
  }

  const rejectInvoice = data => {
    const action = 'Reject';
    dispatch(
      costOwnerInvoicesActions.invoiceUpdate(
        {
          invoiceStatus: invoiceId?.isManual ? 'DELIVERED' : 'ASSIGNED',
          authorizerFeedback: data?.reason,
        },
        invoiceId?.id,
        action,
        invoiceId?.poId,
      ),
    );
    setModalOpen(false);
    setDialogOpen(false);
  };

  const modalWrapperData = [
    {
      children: (
        <COAuthorizerInvoiceDetails
          setModalOpen={handleModalOpen}
          handleDialogOpen={handleDialogOpen}
          data={selectedInvoice}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          handleDelete={rejectInvoice}
          message={`Why do you want to reject this Invoice ?`}
          hasFeedback={true}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
      }}
    >
      <Box>
        <WidgetPreviewer
          element={
            <DynamicTable
              tableType="COInvoiceTable"
              headerFields={COAuthorizerInvoicesFields}
              data={tableData}
              loading={loading}
              buttonData={invoiceButtonData}
              onPageChange={onPageChange}
              onChangeRowsPerPage={onChangeRowsPerPage}
              totalItems={totalItems}
              currentPage={currentPage}
              limitPerPage={limitPerPage}
              handleDialogOpen={handleDialogOpen}
            />
          }
          name="Cost Owner Authorizer Invoice Table"
        />
      </Box>
      {modalWrapperData &&
        modalWrapperData.map(modalData => {
          return <ModalWrapper {...modalData} />;
        })}
    </Box>
  );
};

export default COAuthorizerInvoiceTable;
