import React from 'react';
import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import Label from 'src/view/materialUI/components/Label';
import PencilAltIcon from '../../../icons/PencilAlt';
import Download from 'src/icons/Download';
import { useDispatch } from 'react-redux';
import costOwnerInvoicesActions from 'src/modules/COAuthorizerInvoices/COAuthorizerInvoicesActions';

const getStatusLabel = invoiceStatus => {
  const map = {
    ASSIGNED: {
      color: 'warning',
      text: 'ASSIGNED',
    },
    ACCEPTED: {
      color: 'success',
      text: 'ACCEPTED',
    },
    SEND_SUBMIT: {
      color: 'primary',
      text: 'SEND_SUBMIT',
    },
    REQUEST_PAYMENT: {
      color: 'secondary',
      text: 'REQUEST_PAYMENT',
    },
    NEW: {
      color: 'success',
      text: 'NEW',
    },
    APPROVED: {
      color: 'primary',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const COInvoiceRow = ({
  invoice,
  buttonData,
  page,
  rowsPerPage,
  handleDialogOpen,
}) => {
  const dispatch = useDispatch();

  return (
    <TableRow key={invoice.eic} hover>
      {Object.keys(invoice).map(key => {
        if (key === 'id' || key === 'isManual' || key === 'poId') {
          return;
        }
        if (key === 'status' || key === 'approved') {
          return (
            <TableCell align="center" key={key}>
              {invoice[key] && getStatusLabel(invoice[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            key={key}
            sx={key === 'eic' ? { paddingLeft: 3 } : { paddingLeft: 0 }}
            align={
              key === 'invoiceNumber' ||
              key === 'receivedDate' ||
              key === 'dueDate' ||
              key === 'status' ||
              key === 'nipt'
                ? 'center'
                : key === 'amount'
                ? 'right'
                : 'left'
            }
          >
            {invoice[key] && invoice[key]}
          </TableCell>
        );
      })}

      <TableCell align="center">
        <IconButton onClick={() => buttonData[0].buttonFunction(invoice)}>
          <PencilAltIcon fontSize="small" />
        </IconButton>
        <IconButton
          onClick={() =>
            dispatch(costOwnerInvoicesActions.downloadPdf({ eic: invoice.eic }))
          }
          disabled={invoice?.isManual}
        >
          <Download />
        </IconButton>
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => {
            const action = 'Assign';
            dispatch(
              costOwnerInvoicesActions.invoiceUpdate(
                { invoiceStatus: 'ACCEPTED' },
                invoice.id,
                action,
              ),
            );
          }}
        >
          Approve
        </Button>
        <Button
          onClick={() => {
            handleDialogOpen({
              id: invoice?.id,
              isManual: invoice?.isManual,
              poId: invoice?.poId,
            });
          }}
        >
          Reject
        </Button>
      </TableCell>
    </TableRow>
  );
};

export default COInvoiceRow;
