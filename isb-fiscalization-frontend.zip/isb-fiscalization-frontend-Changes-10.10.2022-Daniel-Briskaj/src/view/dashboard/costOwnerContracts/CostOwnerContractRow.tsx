import { TableCell, TableRow, IconButton } from '@material-ui/core';
import PencilAltIcon from '../../../icons/PencilAlt';
import Label from 'src/view/materialUI/components/Label';
import Upload from 'src/icons/Upload';

const getStatusLabel = contractStatus => {
  const map = {
    ACTIVE: {
      color: 'success',
      text: 'ACTIVE',
    },
    CREATED: {
      color: 'success',
      text: 'CREATED',
    },
    EXPIRED: {
      color: 'error',
      text: 'EXPIRED',
    },
    BUDGET: {
      color: 'error',
      text: 'BUDGET',
    },
    FORECAST: {
      color: 'error',
      text: 'FORECAST',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: contractStatus,
    },
  };

  const { text, color }: any = map[contractStatus] || map.DEFAULT;

  return text ? (
    <Label color={color}>{text}</Label>
  ) : (
    <Label color={color}></Label>
  );
};

const CostOwnerContractRow = ({
  contract,
  handleModalOpen,
  handlePopupOpen,
  page,
  rowsPerPage,
}) => {
  return (
    <>
      <TableRow key={contract.id}>
        {Object.keys(contract).map(key => {
          if (key === 'id') {
            return;
          }
          if (key === 'status') {
            return (
              <TableCell align="center" key={key}>
                {contract[key] && getStatusLabel(contract[key])}
              </TableCell>
            );
          }
          return (
            <TableCell
              key={key}
              style={{ paddingTop: '1rem', paddingBottom: '1rem' }}
              sx={
                key === 'supplier' ||
                key === 'costOwner' ||
                key === 'description'
                  ? {
                      paddingLeft: 3,
                      maxWidth: '200px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }
                  : { paddingLeft: 0 }
              }
              align={
                key === 'costOwnerCode' ||
                key === 'branch' ||
                key === 'startDate' ||
                key === 'status' ||
                key === 'contractCode' ||
                key === 'currency'
                  ? 'center'
                  : key === 'amount'
                  ? 'right'
                  : 'left'
              }
            >
              {contract[key] && contract[key]}
            </TableCell>
          );
        })}
        <TableCell align="center">
          <IconButton
            onClick={() => handleModalOpen({ id: contract.id, contract: true })}
          >
            <PencilAltIcon fontSize="small" />
          </IconButton>
          <IconButton onClick={() => handlePopupOpen(contract.id)}>
            <Upload fontSize="small" />
          </IconButton>
        </TableCell>
      </TableRow>
    </>
  );
};

export default CostOwnerContractRow;
