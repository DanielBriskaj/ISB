import { useEffect, useState, useCallback, useRef } from 'react';
import { Box } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { Helmet } from 'react-helmet-async';

import DynamicTable from '../../materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from '../../materialUI/components/WidgetPreviewer';
import { debounce } from 'lodash';
import contractActions from 'src/modules/contracts/contractActions';
import contractSelector from 'src/modules/contracts/contractSelector';
import { contractFields } from 'src/enums/shared/headerFields/contractFields';
import authSelector from 'src/modules/shared/authentication/authSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import { usePrevious } from 'src/view/materialUI/hooks/usePrevious';
import UploadFilePopup from '../contracts/UploadFilesPopup';
import ContractFormPopup from '../contracts/ContractFormPopup';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import { costOwnerContractFields } from 'src/enums/shared/headerFields/costOwnerContractFields';
import numberWithCommas from 'src/helpers/numberWithCommas';

enum CONTRACT_STATUS {
  ACTIVE = 'ACTIVE',
}

const CostOwnerContractTable = () => {
  const [supplierCompanyName, setSupplierCompanyName] = useState('');
  const [contractDescription, setContractDescription] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const [tableData, setTableData] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [popupOpen, setPopupOpen] = useState(false);
  const [contractId, setContractId] = useState(null);
  const [isContract, setIsContract] = useState(true);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [totalItems, setTotalItems] = useState(0);
  const dispatch = useDispatch();

  const contractsState = useSelector(contractSelector.contractsDataArray);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const initialRenderRef = useRef(false);

  const costOwnerId = authData.costOwnerId;

  const [searchFunctionArray, setSearchFunctionArray] = useState([]);

  useEffect(() => {
    if (initialRenderRef.current) {
      dispatch(
        contractActions.readByCostOwner(costOwnerId, {
          supplierCompanyName: supplierCompanyName,
          description: contractDescription,
          size: limitPerPage,
          page: currentPage,
          contractStatus: CONTRACT_STATUS.ACTIVE,
        }),
      );
    } else {
      initialRenderRef.current = true;
    }
  }, [limitPerPage, currentPage]);

  useEffect(() => {
    setCurrentPage(0);
    dispatch(
      contractActions.readByCostOwner(costOwnerId, {
        supplierCompanyName: supplierCompanyName,
        description: contractDescription,
        size: limitPerPage,
        page: 0,
        contractStatus: CONTRACT_STATUS.ACTIVE,
      }),
    );
  }, [supplierCompanyName, costOwnerId, contractDescription]);

  useEffect(() => {
    if (
      contractsState &&
      Object.keys(contractsState).length === 0 &&
      Object.getPrototypeOf(contractsState) === Object.prototype
    ) {
    } else {
      if (contractsState.contracts) {
        setTableData(
          contractsState.contracts.map(contract => ({
            id: contract.id,
            supplier: contract.supplier?.companyName,
            costOwner: contract.costOwner?.ownerName,
            costOwnerCode: contract.costOwner?.code,
            contractCode: contract.contractCode,
            startDate: contract.startDate,
            description: contract.contractDescription,
            amount: numberWithCommas(contract.contractAmount.toFixed(2)),
            currency: contract?.currency,
            status: contract?.contractStatus,
          })),
        );
        setTotalItems(contractsState.totalItems);
      }
    }
  }, [contractsState]);

  const supplierCompanyNameSearchOnChange = event => {
    setSupplierCompanyName(event.target.value);
  };
  const handleSupplierCompanyNameSearch = useCallback(
    debounce(supplierCompanyNameSearchOnChange, 300),
    [],
  );

  const contractDescriptionSearchOnChange = event => {
    setContractDescription(event.target.value);
  };
  const handleContractDescriptionSearch = useCallback(
    debounce(contractDescriptionSearchOnChange, 300),
    [],
  );

  useEffect(() => {
    setSearchFunctionArray([
      {
        placeholder: 'Contract Description',
        function: handleContractDescriptionSearch,
        customClass: 'search-input',
        disabled: !costOwnerId,
      },
      {
        placeholder: 'Supplier Company Name',
        function: handleSupplierCompanyNameSearch,
        customClass: 'search-input',
        disabled: !costOwnerId,
      },
    ]);
  }, []);

  useEffect(() => {
    return () => {
      dispatch(contractActions.clearContractsArray());
    };
  }, []);

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  function handleModalOpen(obj?) {
    if (obj.contract === true) {
      setIsContract(true);
    }
    if (obj.id) {
      setContractId(obj.id);
    }
    setModalOpen(!modalOpen);
  }

  function handlePopupOpen(id?) {
    if (id) {
      setContractId(id);
    }
    setPopupOpen(!popupOpen);
  }

  const modalWrapperData = [
    {
      children: (
        <UploadFilePopup
          setModalOpen={setPopupOpen}
          contractId={contractId}
          contract={contractsState}
        />
      ),
      modalOpen: popupOpen,
      setModalOpen: setPopupOpen,
      type: 'editModal',
    },
    {
      children: (
        <ContractFormPopup
          setModalOpen={setModalOpen}
          contractId={contractId}
          isContract={isContract}
          page={currentPage}
          rowsPerPage={limitPerPage}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
  ];
  return (
    <>
      {/* <Helmet>
    <title>Browse: Tables | Material Kit Pro</title>
  </Helmet> */}
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
        }}
      >
        <Box>
          <WidgetPreviewer
            element={
              <DynamicTable
                tableType="costOwnerContractTable"
                headerFields={costOwnerContractFields}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                data={tableData}
                loading={loading}
                totalItems={totalItems}
                currentPage={currentPage}
                searchArrayOfFunctions={searchFunctionArray}
                limitPerPage={limitPerPage}
                handleModalOpen={handleModalOpen}
                handlePopupOpen={handlePopupOpen}
              />
            }
            name="Cost Owner Contracts"
          />
        </Box>
        {modalWrapperData &&
          modalWrapperData.map(modalData => {
            return <ModalWrapper {...modalData} />;
          })}
      </Box>
    </>
  );
};

export default CostOwnerContractTable;
