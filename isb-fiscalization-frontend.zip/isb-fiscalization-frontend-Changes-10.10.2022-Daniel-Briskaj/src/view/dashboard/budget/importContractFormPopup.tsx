import { yupResolver } from '@hookform/resolvers/yup';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import React, { useEffect } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import Close from 'src/icons/X';
import budgetActions from 'src/modules/budget/budgetActions';
import { budgetSchema } from 'src/modules/shared/yup/budgetSchema';
import ImportContractForm from 'src/view/materialUI/components/widgets/forms/BudgetForms/importContractForm';
import useSettings from 'src/view/materialUI/hooks/useSettings';

interface ImportContractFormProps {
  setModalOpen: any;
}
interface BudgetProps {
  name: any;
  year: string;
  contract: any;
}
const ImportContractFormPopup: React.FC<ImportContractFormProps> = ({
  setModalOpen,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();

  const initialValues: BudgetProps = {
    name: '',
    year: '',
    contract: null,
  };

  const form = useForm({
    resolver: yupResolver(budgetSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const handleImportSingleContract = () => {
    const data = {
      contractId: selectedContract?.id,
      id: selectedBudget?.id,
    };

    dispatch(budgetActions.importSingleContract(data));
    setModalOpen(false);
  };

  const selectedBudget = form.watch(`name`);
  const selectedContract = form.watch(`contract`);

  useEffect(() => {
    if (Object.keys(selectedBudget)?.length > 0) {
      Object.keys(selectedBudget).forEach(key => {
        if (key === 'name') {
          return;
        } else {
          form.setValue(key as keyof BudgetProps, selectedBudget[key]);
        }
      });
    }
  }, [selectedBudget]);

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Import New Contract
              </Typography>
            </Grid>
            <Grid item>
              <Close
                onClick={() => {
                  setModalOpen(false);
                }}
              />
            </Grid>
          </Grid>

          <FormProvider {...form}>
            <form>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <ImportContractForm />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={handleImportSingleContract}
                  disabled={!selectedBudget || !selectedContract}
                >
                  Import
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 8px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};
export default ImportContractFormPopup;
