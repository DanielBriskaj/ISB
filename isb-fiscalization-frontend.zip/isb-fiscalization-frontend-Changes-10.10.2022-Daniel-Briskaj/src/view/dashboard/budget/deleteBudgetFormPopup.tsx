import { yupResolver } from '@hookform/resolvers/yup';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import Close from 'src/icons/X';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import { budgetSchema } from 'src/modules/shared/yup/budgetSchema';
import DeleteBudgetForm from 'src/view/materialUI/components/widgets/forms/BudgetForms/deleteBudgetForm';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';

interface DeleteBudgetFormProps {
  setModalOpen: any;
}
interface BudgetProps {
  name: any;
  year: string;
  dueDate: Date | string;
  budgetStatus: string;
}
const DeleteBudgetFormPopup: React.FC<DeleteBudgetFormProps> = ({
  setModalOpen,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const budgetData = useSelector(budgetSelector.budgetData);

  const [dialogOpen, setDialogOpen] = useState(false);

  const initialValues: BudgetProps = {
    name: '',
    year: '',
    dueDate: '',
    budgetStatus: '',
  };

  const form = useForm({
    resolver: yupResolver(budgetSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const handleDeleteBudget = () => {
    dispatch(budgetActions.deleteBudget(selectedBudget?.id));
    setModalOpen(false);
  };

  const selectedBudget = form.watch(`name`);

  useEffect(() => {
    if (Object.keys(selectedBudget)?.length > 0) {
      Object.keys(selectedBudget).forEach(key => {
        if (key === 'name') {
          return;
        } else {
          form.setValue(key as keyof BudgetProps, selectedBudget[key]);
        }
      });
    }
  }, [selectedBudget]);

  const modalWrapperData = [
    {
      children: (
        <AlertDialog
          setDialogOpen={setDialogOpen}
          handleDelete={handleDeleteBudget}
          message={`Are you sure you want to delete ${selectedBudget?.name} ?`}
          hasFeedback={false}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];
  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Delete Budget
              </Typography>
            </Grid>
            <Grid item>
              <Close
                onClick={() => {
                  setModalOpen(false);
                }}
              />
            </Grid>
          </Grid>

          <FormProvider {...form}>
            <form>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <DeleteBudgetForm data={budgetData} />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setDialogOpen(true)}
                  disabled={!selectedBudget}
                >
                  Delete
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 8px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
        {modalWrapperData &&
          modalWrapperData.map((modalData, index) => {
            return <ModalWrapper key={index} {...modalData} />;
          })}
      </Box>
    </>
  );
};
export default DeleteBudgetFormPopup;
