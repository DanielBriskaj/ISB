import { Grid, Typography, Box, Button } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { BudgetStatus } from 'src/enums/status';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import LinearProgressWithLabel from 'src/view/materialUI/components/ProgressBarWithLabel';

interface BudgetFormProps {
  setModalOpen: any;
}
const BudgetProgress: React.FC<BudgetFormProps> = ({ setModalOpen }) => {
  const dispatch = useDispatch();

  const failedItems = useSelector(budgetSelector.failedItems);
  const budgetContracts = useSelector(budgetSelector.budgetContracts);
  const parentContract = budgetContracts?.parentAndNormal;
  const subContracts = budgetContracts?.children;
  const budgetData = useSelector(budgetSelector.budgetData);
  const progress = useSelector(budgetSelector.progress);
  const [failedAmount, setFailedAmount] = useState<any>(0);

  const totalItems = parentContract?.length + subContracts?.length;
  useEffect(() => {
    setFailedAmount(failedAmount + failedItems.length);
  }, [failedItems]);

  useEffect(() => {
    if (parentContract?.length > 0 && budgetData) {
      const id = budgetData.id;
      dispatch(budgetActions.sendBudgetItems(parentContract, subContracts, id));
    }
  }, [parentContract, subContracts, budgetData]);

  const handleDoneBudget = () => {
    setModalOpen(false);
    dispatch(budgetActions.clearBudgetData());
    dispatch(budgetActions.getBudgetId({ type: 'newBudget' }));
    dispatch(budgetActions.getBudgetItems({ budgetStatus: BudgetStatus.NEW }));
  };
  return (
    <>
      <Grid container spacing={3}>
        <Grid item>
          <Typography
            color="textPrimary"
            variant="h5"
            paddingLeft={1}
            marginBottom={2}
          >
            Creating Budget
          </Typography>
        </Grid>
      </Grid>
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
          p: 3,
        }}
      >
        <LinearProgressWithLabel value={progress} color="primary" />
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            mt: 1,
          }}
        >
          <span>
            {progress < 99
              ? 'Please wait while the process is completed...'
              : 'Budget Items Added Successfully'}
          </span>
          <span>
            Failed {failedAmount} out of {totalItems}
          </span>
        </Box>
      </Box>
      <Box
        sx={{ mt: 2 }}
        display="flex"
        justifyContent="end"
        alignContent="end"
      >
        <Button
          color="primary"
          sx={{
            m: '0 6px',
            p: '6px 10px',
            fontSize: '14px',
          }}
          variant="contained"
          onClick={handleDoneBudget}
          disabled={progress < 99}
        >
          Continue
        </Button>
      </Box>
    </>
  );
};
export default BudgetProgress;
