import { Box, Button, ClickAwayListener, Popper } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  getNextStatusByRole,
  getValidStatusByRole,
} from 'src/helpers/budgetAndForecastHelpers/budgetStatusHelpers';
import notificationThrower from 'src/helpers/notificationThrower';
import ArrowExpand from 'src/icons/ChevronDown';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

interface BudgetButtonsProps {
  setModalOpen: any;
  role: string;
  selectedRow: number;
  setContractModalOpen: any;
  setContractId: any;
  costOwnerId: number;
  totalItems: number;
  query: any;
  setClosingBudget: any;
  setDeleteOpen: any;
  setImportOpen: any;
}

const BudgetButtons: React.FC<BudgetButtonsProps> = ({
  setModalOpen,
  role,
  selectedRow,
  setContractModalOpen,
  setContractId,
  costOwnerId,
  totalItems,
  query,
  setClosingBudget,
  setDeleteOpen,
  setImportOpen,
}) => {
  const dispatch = useDispatch();

  const [contractAnchor, setContractAnchor] = useState(null);
  const [budgetAnchor, setBudgetAnchor] = useState(null);

  const budgetID = useSelector(budgetSelector.budgetId);

  const handleContractClick = event => {
    setContractAnchor(contractAnchor ? null : event.currentTarget);
  };
  const contractBtnOpen = Boolean(contractAnchor);
  const contractPoperId = contractBtnOpen ? 'contract-popper' : undefined;

  const handleBudgetClick = event => {
    setBudgetAnchor(budgetAnchor ? null : event.currentTarget);
  };
  const budgetBtnOpen = Boolean(budgetAnchor);
  const budgetPoperId = budgetBtnOpen ? 'budget-popper' : undefined;

  const handleApproveAll = async () => {
    dispatch(
      budgetActions.updateItemStatus({
        budgetItemStatus: getNextStatusByRole(role),
        totalItems: totalItems,
        validBudgetStatus: getValidStatusByRole(role),
        role: role,
        costOwnerId: costOwnerId,
        query: query,
      }),
    );
  };

  const handleCloneContract = () => {
    if (selectedRow) {
      dispatch(budgetActions.cloneBudgetContract(selectedRow, costOwnerId));
      setContractAnchor(null);
    } else {
      notificationThrower({
        type: 'info',
        message: 'Please Select A Contract To Clone',
      });
    }
  };

  const handleNewContract = () => {
    if (budgetID) {
      setContractModalOpen(true);
      setContractId(null);
    } else {
      notificationThrower({
        type: 'error',
        message: 'No Active Budget Initialized',
      });
    }
    setContractAnchor(null);
  };

  const handleFinalize = () => {
    if (budgetID) {
      dispatch(budgetActions.getBudgetById(budgetID));
      setModalOpen(true);
      setClosingBudget(true);
    } else {
      notificationThrower({
        type: 'error',
        message: 'No Active Budget Initialized',
      });
    }
  };

  const handleNewBudget = () => {
    if (budgetID) {
      setModalOpen(false);
      notificationThrower({
        type: 'warning',
        message: 'An Active Budget Already Exists',
      });
    } else {
      setModalOpen(true);
    }
    setBudgetAnchor(null);
  };

  const handleDeleteBudget = () => {
    setDeleteOpen(true);
    setBudgetAnchor(null);
  };

  useEffect(() => {
    dispatch(budgetActions.getBudgetId({ type: 'newBudget' }));
  }, []);

  return (
    <Box>
      {role === ROLES.PLANNING_CONTROL_INPUT ? (
        <Button
          color="secondary"
          size="large"
          variant="contained"
          sx={{ mr: 1 }}
          className="table-button"
          onClick={handleBudgetClick}
          endIcon={<ArrowExpand />}
        >
          Actions
        </Button>
      ) : role === ROLES.COST_OWNER ? (
        <>
          <Button
            color="secondary"
            size="large"
            variant="contained"
            sx={{ mr: 1 }}
            className="table-button"
            onClick={handleContractClick}
            endIcon={<ArrowExpand />}
            disabled={!costOwnerId}
          >
            Contract
          </Button>
        </>
      ) : role === ROLES.PLANNING_CONTROL_AUTHORIZER ? (
        <Button
          color="secondary"
          size="large"
          variant="contained"
          sx={{ mr: 1 }}
          className="table-button"
          onClick={handleFinalize}
        >
          Finalize Budget
        </Button>
      ) : (
        ''
      )}
      <Button
        color="primary"
        size="large"
        variant="contained"
        sx={{ mr: 1 }}
        className="table-button"
        onClick={handleApproveAll}
        disabled={
          (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
          !costOwnerId
        }
      >
        {role === ROLES.PLANNING_CONTROL_AUTHORIZER
          ? 'Approve All'
          : 'Send All For Approval'}
      </Button>

      <Popper
        id={contractPoperId}
        open={contractBtnOpen}
        anchorEl={contractAnchor}
      >
        <ClickAwayListener onClickAway={handleContractClick}>
          <Box
            sx={{ m: 1, display: 'flex', flexDirection: 'column', gap: '5px' }}
          >
            <Button
              color="secondary"
              size="large"
              variant="contained"
              sx={{ mr: 1 }}
              className="table-button"
              onClick={handleNewContract}
            >
              New Contract
            </Button>
            <Button
              color="secondary"
              size="large"
              variant="contained"
              sx={{ mr: 1 }}
              className="table-button"
              onClick={handleCloneContract}
            >
              Clone Contract
            </Button>
          </Box>
        </ClickAwayListener>
      </Popper>

      <Popper id={budgetPoperId} open={budgetBtnOpen} anchorEl={budgetAnchor}>
        <ClickAwayListener onClickAway={handleBudgetClick}>
          <Box
            sx={{ m: 1, display: 'flex', flexDirection: 'column', gap: '5px' }}
          >
            <Button
              color="secondary"
              size="large"
              variant="contained"
              sx={{ mr: 1 }}
              className="table-button"
              onClick={handleNewBudget}
            >
              New Budget
            </Button>
            <Button
              color="secondary"
              size="large"
              variant="contained"
              sx={{ mr: 1 }}
              className="table-button"
              onClick={handleDeleteBudget}
            >
              Delete Budget
            </Button>
            <Button
              color="secondary"
              size="large"
              variant="contained"
              sx={{ mr: 1 }}
              className="table-button"
              onClick={() => setImportOpen(true)}
            >
              Import Contract
            </Button>
          </Box>
        </ClickAwayListener>
      </Popper>
    </Box>
  );
};
export default BudgetButtons;
