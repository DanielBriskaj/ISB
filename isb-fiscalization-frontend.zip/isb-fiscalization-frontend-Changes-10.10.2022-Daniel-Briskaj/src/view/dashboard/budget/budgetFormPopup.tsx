import { yupResolver } from '@hookform/resolvers/yup';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { BudgetStatus } from 'src/enums/status';
import { budgetDataTransformer } from 'src/helpers/budgetAndForecastHelpers/dataTransformer';
import Close from 'src/icons/X';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import { budgetSchema } from 'src/modules/shared/yup/budgetSchema';
import BudgetForm from 'src/view/materialUI/components/widgets/forms/BudgetForms/BudgetForm';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import BudgetProgress from './budgetProgress';

interface BudgetFormProps {
  setModalOpen: any;
  closingBudget: boolean;
  setClosingBudget: any;
}
interface BudgetProps {
  name: string;
  year: string;
  dueDate: Date | string;
  budgetStatus: string;
}
const BudgetFormPopup: React.FC<BudgetFormProps> = ({
  setModalOpen,
  closingBudget,
  setClosingBudget,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const budgetCreatedData = useSelector(budgetSelector.budgetCreated);
  const [budgetCreated, setBudgetCreated] = useState(false);
  const budgetData = useSelector(budgetSelector.budgetData);
  const budgetID = useSelector(budgetSelector.budgetId);
  const initialValues: BudgetProps = {
    name: '',
    year: '',
    dueDate: '',
    budgetStatus: BudgetStatus.NEW,
  };

  const form = useForm({
    resolver: yupResolver(budgetSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    if (closingBudget) {
      const transformedData = budgetDataTransformer(data);
      dispatch(
        budgetActions.updateBudget({ id: budgetID, data: transformedData }),
      );
      setModalOpen(false);
      setClosingBudget(false);
      dispatch(budgetActions.clearBudgetData());
    } else {
      dispatch(budgetActions.createBudget({ data }));
      setBudgetCreated(true);
    }
  };

  useEffect(() => {
    if (Object.keys(budgetData)?.length > 0) {
      Object.keys(budgetData).forEach(key => {
        form.setValue(key as keyof BudgetProps, budgetData[key]);
      });
    }
  }, [budgetData]);

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          {!budgetCreatedData && (
            <>
              <Grid container justifyContent="space-between" spacing={3}>
                <Grid item>
                  <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                    Budget Planning
                  </Typography>
                </Grid>
                <Grid item>
                  <Close
                    onClick={() => {
                      setModalOpen(false);
                    }}
                  />
                </Grid>
              </Grid>

              <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                  <Divider />
                  <Box sx={{ mt: 3 }} height="100%">
                    <BudgetForm disabled={closingBudget} data={budgetData} />
                  </Box>
                  <Box
                    sx={{ mt: 2 }}
                    display="flex"
                    justifyContent="end"
                    alignContent="end"
                  >
                    <Button
                      color="primary"
                      sx={{
                        m: '0 6px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      type="submit"
                    >
                      {closingBudget ? 'Finalize' : 'Initialize'}
                    </Button>
                    <Button
                      sx={{
                        background: '#666',
                        '&:hover': {
                          background: '#333',
                        },
                        m: '0 8px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      onClick={() => setModalOpen(false)}
                    >
                      Cancel
                    </Button>
                  </Box>
                </form>
              </FormProvider>
            </>
          )}
          {budgetCreated && budgetCreatedData && (
            <BudgetProgress setModalOpen={setModalOpen} />
          )}
        </Container>
      </Box>
    </>
  );
};
export default BudgetFormPopup;
