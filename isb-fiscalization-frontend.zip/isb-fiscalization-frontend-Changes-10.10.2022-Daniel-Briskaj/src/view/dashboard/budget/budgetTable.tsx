import {
  Box,
  Button,
  Card,
  IconButton,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Tabs,
} from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getStatusLabel } from 'src/helpers/contractStatusLabel';
import PencilAltIcon from '../../../icons/PencilAlt';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import Scrollbar from 'src/view/materialUI/components/Scrollbar';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import ContractFormPopup from '../contracts/ContractFormPopup';
import BudgetButtons from './budgetButtons';
import BudgetFilters from './budgetFilters';
import BudgetFormPopup from './budgetFormPopup';
import ArrowRightIcon from '../../../icons/ArrowRight';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import getItemStatusLabel from 'src/helpers/budgetAndForecastHelpers/itemStatusLabel';
import getSubRows from './budgetSubRows';
import budgetColumns from 'src/enums/shared/headerFields/budgetFields';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import { ItemStatus } from 'src/enums/status';
import DeleteBudgetFormPopup from './deleteBudgetFormPopup';
import ImportContractFormPopup from './importContractFormPopup';
import { getPreviousStatusByRole } from 'src/helpers/budgetAndForecastHelpers/budgetStatusHelpers';
import notificationThrower from 'src/helpers/notificationThrower';

const BudgetTable: React.FC = () => {
  const loading = useSelector(budgetSelector.loading);
  const dispatch = useDispatch();

  const [tableData, setTableData] = useState([]);
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [contractModalOpen, setContractModalOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [currentTab, setCurrentTab] = useState<'NEW' | 'CLOSED'>('NEW');
  const [contractInfo, setContractInfo] = useState({
    id: null,
    contractStatus: null,
    itemStatus: null,
  });
  const [closingBudget, setClosingBudget] = useState(false);

  const authData = useSelector(authSelector.authData);
  const { costOwnerId, role, division } = authData;
  const budgetItems = useSelector(budgetSelector.budgetItemsArray);
  const subBudgetItems = useSelector(budgetSelector.subBudgetItems);
  const [supplierName, setSupplierName] = useState();
  const [contractCode, setContractCode] = useState();
  const [itemStatus, setItemStatus] = useState();
  const [costOwnerName, setCostOwnerName] = useState();
  const [openRows, setOpenRows] = useState({});
  const budgetID = useSelector(budgetSelector.budgetId);

  const query: any = {};
  query.supplierCompanyName = supplierName;
  query.contractCode = contractCode;
  query.budgetStatus = currentTab;
  query.page = currentPage;
  query.size = rowsPerPage;
  query.budgetItemStatus = itemStatus;
  query.costOwnerName = costOwnerName;
  query.division = division;

  useEffect(() => {
    if (role === ROLES.COST_OWNER) {
      dispatch(budgetActions.getItemsByCO({ id: costOwnerId, query: query }));
    } else {
      if (role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId) {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong',
        });
      } else {
        dispatch(budgetActions.getBudgetItems(query));
      }
    }
  }, [
    currentPage,
    rowsPerPage,
    contractCode,
    supplierName,
    costOwnerName,
    currentTab,
    itemStatus,
  ]);

  const expandRow = id => {
    if (openRows[id] !== undefined) {
      if (!openRows[id]) {
        dispatch(budgetActions.getBudgetSubItems(id));
      }
      setOpenRows(oldState => {
        return { ...oldState, [id]: !openRows[id] };
      });
    } else {
      dispatch(budgetActions.getBudgetSubItems(id));

      setOpenRows(oldState => {
        return { ...oldState, [id]: true };
      });
    }
  };

  useEffect(() => {
    if (budgetItems?.contracts) {
      setTableData(budgetItems?.contracts);
      setTotalItems(budgetItems?.totalItems);
    } else {
      setTableData([]);
    }
  }, [budgetItems]);

  const style: any = {
    maxWidth: '150px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
  };

  const handleRowClick = id => {
    if (selectedRow === null) {
      setSelectedRow(id);
    } else {
      if (selectedRow === id) {
        setSelectedRow(null);
      } else {
        setSelectedRow(id);
      }
    }
  };

  const onPageChange = (event, page) => {
    setCurrentPage(page);
  };
  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setRowsPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const handleReject = id => {
    dispatch(budgetActions.getSingleBudgetItem(id));
    setDialogOpen(true);
    setContractInfo({
      id: id,
      contractStatus: null,
      itemStatus: null,
    });
  };

  const handleFinishReject = data => {
    const itemData = {
      id: contractInfo?.id,
      authorizerFeedback: data?.reason,
      budgetItemStatus: getPreviousStatusByRole(role),
    };
    dispatch(
      budgetActions.rejectBudgetItem({
        data: itemData,
        role: role,
        query: query,
      }),
    );
    setDialogOpen(false);
  };

  const modalWrapperData = [
    {
      children: (
        <BudgetFormPopup
          setModalOpen={setModalOpen}
          closingBudget={closingBudget}
          setClosingBudget={setClosingBudget}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'progressModal',
    },
    {
      children: <DeleteBudgetFormPopup setModalOpen={setDeleteOpen} />,
      modalOpen: deleteOpen,
      setModalOpen: setDeleteOpen,
      type: 'editModal',
    },
    {
      children: <ImportContractFormPopup setModalOpen={setImportOpen} />,
      modalOpen: importOpen,
      setModalOpen: setImportOpen,
      type: 'editModal',
    },
    {
      children: (
        <ContractFormPopup
          setModalOpen={setContractModalOpen}
          contractId={contractInfo?.id}
          type="budgetContract"
          isFormDisabled={
            role !== ROLES.COST_OWNER ||
            (contractInfo &&
              (contractInfo?.contractStatus === 'ACTIVE' ||
                contractInfo?.itemStatus !== ItemStatus.CREATED))
              ? true
              : false
          }
          costOwnerId={costOwnerId}
          budgetID={budgetID}
          query={query}
        />
      ),
      modalOpen: contractModalOpen,
      setModalOpen: setContractModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setDialogOpen={setDialogOpen}
          message={`Why are you choosing to reject this budget item?`}
          hasFeedback={true}
          handleDelete={handleFinishReject}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  const budgetTableTabs = [
    { label: 'In Progress', value: 'NEW' },
    { label: 'Completed', value: 'CLOSED' },
  ];
  const handleTabsChange = (event, value): void => {
    setCurrentTab(value);
    setTableData([]);
    setCurrentPage(0);
  };
  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
      }}
    >
      {role === ROLES.PLANNING_CONTROL_INPUT ||
      role === ROLES.PLANNING_CONTROL_AUTHORIZER ? (
        <Box sx={{ mt: 3 }}>
          <Tabs
            indicatorColor="primary"
            onChange={handleTabsChange}
            scrollButtons="auto"
            textColor="primary"
            value={currentTab}
            variant="scrollable"
          >
            {budgetTableTabs.map(tab => (
              <Tab key={tab.value} label={tab.label} value={tab.value} />
            ))}
          </Tabs>
        </Box>
      ) : (
        <></>
      )}
      <WidgetPreviewer
        element={
          <Box
            sx={{
              backgroundColor: 'background.default',
              p: 3,
            }}
          >
            <Card sx={{ overflow: 'visible' }}>
              <Box
                sx={{
                  alignItems: 'center',
                  display: 'flex',
                  flexWrap: 'wrap',
                  justifyContent: 'space-between',
                  m: -1,
                  p: 2,
                  mb: 1.5,
                }}
              >
                <BudgetFilters
                  setContractCode={setContractCode}
                  setCurrentPage={setCurrentPage}
                  setSupplierName={setSupplierName}
                  setCostOwnerName={setCostOwnerName}
                  role={role}
                  setItemStatus={setItemStatus}
                  costOwnerId={costOwnerId}
                />
                {currentTab !== 'CLOSED' && (
                  <BudgetButtons
                    setModalOpen={setModalOpen}
                    setContractModalOpen={setContractModalOpen}
                    role={role}
                    selectedRow={selectedRow}
                    setContractId={setContractInfo}
                    costOwnerId={costOwnerId}
                    totalItems={totalItems}
                    query={query}
                    setClosingBudget={setClosingBudget}
                    setDeleteOpen={setDeleteOpen}
                    setImportOpen={setImportOpen}
                  />
                )}
              </Box>
              <Scrollbar>
                <Box sx={{ minWidth: 800 }}>
                  <Table padding="none">
                    <TableHead>
                      <TableRow>
                        {(role === ROLES.COST_OWNER || currentTab === 'CLOSED'
                          ? budgetColumns.filter(
                              field => field.fieldName !== 'Process',
                            )
                          : budgetColumns
                        )?.map((column, index) => {
                          return (
                            <TableCell
                              key={index}
                              sx={column?.sx}
                              align={column?.align}
                            >
                              {column?.fieldName}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {loading ? (
                        <TableRow>
                          <TableCell
                            sx={{
                              textAlign: 'center',
                              fontSize: '1.01rem',
                              fontWeight: '500',
                              color: '#777',
                              padding: '1.15rem 0.9rem',
                            }}
                            colSpan={budgetColumns?.length}
                          >
                            Data is loading ...
                          </TableCell>
                        </TableRow>
                      ) : tableData?.length === 0 ? (
                        <TableRow>
                          <TableCell
                            sx={{
                              textAlign: 'center',
                              fontSize: '1.01rem',
                              fontWeight: '500',
                              color: '#777',
                              padding: '1.15rem 0.9rem',
                            }}
                            colSpan={budgetColumns?.length}
                          >
                            There are no data for this module!
                          </TableCell>
                        </TableRow>
                      ) : (
                        tableData?.map((row, index) => {
                          return (
                            <>
                              <TableRow
                                hover
                                sx={
                                  row?.id === selectedRow
                                    ? {
                                        backgroundColor: 'lavender',
                                        height: '50px',
                                      }
                                    : { height: '50px' }
                                }
                                key={row?.id}
                                onClick={() => {
                                  handleRowClick(row?.id);
                                }}
                              >
                                <TableCell align="center" width={50}>
                                  <IconButton
                                    sx={{
                                      transform:
                                        openRows[row?.id] && 'rotate(90deg)',
                                      transition: 'all 200ms',
                                    }}
                                    onClick={() => {
                                      expandRow(row?.id);
                                    }}
                                  >
                                    <ArrowRightIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                                <TableCell
                                  align="left"
                                  sx={{
                                    paddingLeft: 1.5,
                                    maxWidth: '150px',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                  }}
                                >
                                  {row?.supplier?.companyName}
                                </TableCell>
                                <TableCell
                                  align="center"
                                  sx={{
                                    paddingLeft: 1.5,
                                    maxWidth: '150px',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                  }}
                                >
                                  {row?.costOwner?.ownerName}
                                </TableCell>
                                <TableCell align="center" width={50}>
                                  {row?.branch?.branchCode}
                                </TableCell>
                                <TableCell align="center" sx={style}>
                                  {getStatusLabel(row?.contractStatus)}
                                </TableCell>
                                <TableCell align="center" sx={style}>
                                  {row?.contractCode}
                                </TableCell>
                                <TableCell align="center" sx={style}>
                                  {getItemStatusLabel(row?.budgetItemStatus)}
                                </TableCell>
                                <TableCell align="center" width={100}>
                                  <IconButton
                                    onClick={() => {
                                      setContractModalOpen(true);
                                      setContractInfo({
                                        id: row?.id,
                                        contractStatus: row?.contractStatus,
                                        itemStatus: row?.budgetItemStatus,
                                      });
                                    }}
                                  >
                                    <PencilAltIcon fontSize="small" />
                                  </IconButton>
                                </TableCell>
                                {role === ROLES.COST_OWNER ||
                                currentTab === 'CLOSED' ? (
                                  <TableCell></TableCell>
                                ) : (
                                  <TableCell align="center" width={100}>
                                    <Button
                                      onClick={() => handleReject(row?.id)}
                                      disabled={
                                        (role === ROLES.COST_OWNER_AUTHORIZER &&
                                          row?.budgetItemStatus !==
                                            ItemStatus.IN_APPROVAL_BY_COA) ||
                                        (role ===
                                          ROLES.PLANNING_CONTROL_INPUT &&
                                          row?.budgetItemStatus !==
                                            ItemStatus.IN_APPROVAL_BY_PCI) ||
                                        (role ===
                                          ROLES.PLANNING_CONTROL_AUTHORIZER &&
                                          row?.budgetItemStatus !==
                                            ItemStatus.IN_APPROVAL_BY_PCA)
                                      }
                                    >
                                      Reject
                                    </Button>
                                  </TableCell>
                                )}
                              </TableRow>
                              {openRows[row?.id] && !subBudgetItems[row?.id] && (
                                <TableRow>
                                  <TableCell
                                    sx={{
                                      textAlign: 'center',
                                      fontSize: '1.01rem',
                                      fontWeight: '500',
                                      color: '#777',
                                      padding: '1.15rem 0.9rem',
                                    }}
                                    colSpan={budgetColumns?.length}
                                  >
                                    Loading ...
                                  </TableCell>
                                </TableRow>
                              )}
                              {openRows[row?.id] &&
                                subBudgetItems[row?.id] &&
                                getSubRows(
                                  subBudgetItems[row?.id],
                                  selectedRow,
                                  handleRowClick,
                                  style,
                                  setContractModalOpen,
                                  setContractInfo,
                                  budgetColumns,
                                )}
                            </>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </Box>
              </Scrollbar>
              {totalItems > 0 && (
                <TablePagination
                  component="div"
                  count={totalItems ? totalItems : 1}
                  page={currentPage}
                  rowsPerPage={rowsPerPage}
                  rowsPerPageOptions={[5, 10, 25]}
                  onPageChange={(event, page) => onPageChange(event, page)}
                  onRowsPerPageChange={event => onChangeRowsPerPage(event)}
                />
              )}
            </Card>
          </Box>
        }
        name="Budget And Planning"
      />
      {modalWrapperData &&
        modalWrapperData.map((modalData, index) => {
          return <ModalWrapper key={index} {...modalData} />;
        })}
    </Box>
  );
};
export default BudgetTable;
