import { useState, useEffect } from 'react';
import { TableCell, TableRow, IconButton, Switch } from '@material-ui/core';
import Label from 'src/view/materialUI/components/Label';
import { useDispatch, useSelector } from 'react-redux';
import contractActions from 'src/modules/contracts/contractActions';
import contractSelector from 'src/modules/contracts/contractSelector';
import Trash from 'src/icons/Trash';

const getStatusLabel = auditStatus => {
  const map = {
    CREATE: {
      color: 'success',
      text: 'CREATE',
    },
    DELETE: {
      color: 'error',
      text: 'DELETE',
    },
    UPDATE: {
      color: 'primary',
      text: 'UPDATE',
    },
    READ: {
      color: 'secondary',
      text: 'READ',
    },
    DEFAULT: {
      color: 'warning',
      text: auditStatus,
    },
  };

  const { text, color } = map[auditStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const AuditRow = ({ audit, page, rowsPerPage }) => {
  return (
    <>
      <TableRow key={audit.id} hover>
        {Object.keys(audit).map(key => {
          if (key === 'id') {
            return;
          }
          if (key === 'actionType') {
            return (
              <TableCell align="center" key={key} padding="normal">
                {audit[key] && getStatusLabel(audit[key])}
              </TableCell>
            );
          }
          return (
            <TableCell
              key={key}
              style={{ padding: '1rem 0' }}
              sx={key === 'id' ? { paddingLeft: 3 } : { paddingLeft: 0 }}
              align={
                key === 'actionType' ||
                key === 'actionName' ||
                key === 'idActionName' ||
                key === 'username' ||
                key === 'dateTime'
                  ? 'center'
                  : 'left'
              }
            >
              {audit[key] && audit[key]}
            </TableCell>
          );
        })}
      </TableRow>
    </>
  );
};

export default AuditRow;
