import auditSelector from 'src/modules/audit/auditSelector';
import auditActions from 'src/modules/audit/auditActions';
import { FC, useRef } from 'react';
import { useEffect, useState, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Box,
  Breadcrumbs,
  Container,
  Grid,
  Typography,
} from '@material-ui/core';
import { debounce } from 'lodash';
import useSettings from '../../../materialUI/hooks/useSettings';
import DynamicTable from '../../../materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import ChevronRightIcon from '../../../../icons/ChevronRight';
import { auditFields } from 'src/enums/shared/headerFields/auditFields';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import Download from 'src/icons/Download';

const AuditTable: FC = () => {
  const { settings } = useSettings();
  const [tableData, setTableData] = useState([]);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [actionName, setActionName] = useState('');
  const [sortDirection, setSortDirect] = useState<'asc' | 'desc'>('desc');
  const [searchFunctionArray, setSearchFunctionArray] = useState([]);

  const dispatch = useDispatch();

  const auditData = useSelector(auditSelector.auditDataArray);
  const loading = useSelector(statusSelector.loading);
  const initialRenderRef = useRef(false);

  useEffect(() => {
    if (initialRenderRef.current) {
      dispatch(
        auditActions.fetchAudits({
          sort: `actionName,${sortDirection}`,
          actionName: actionName,
          size: limitPerPage,
          page: currentPage,
        }),
      );
    } else {
      initialRenderRef.current = true;
    }
  }, [limitPerPage, currentPage]);

  useEffect(() => {
    setCurrentPage(0);
    dispatch(
      auditActions.fetchAudits({
        sort: `actionName,${sortDirection}`,
        actionName: actionName,
        size: limitPerPage,
        page: 0,
      }),
    );
  }, [sortDirection, actionName]);

  function formatDateTime(dateStr: string | Date) {
    let date = new Date(dateStr);
    const dateParts = {
      year: date.getFullYear().toString(),
      month: (date.getMonth() + 1).toString(),
      day: date.getDay().toString(),
      hours: date.getHours().toString(),
      minutes: date.getMinutes().toString(),
      seconds: date.getSeconds().toString(),
    };
    let formattedDate = `${dateParts.day}-${dateParts.month}-${dateParts.year} ${dateParts.hours}:${dateParts.minutes}:${dateParts.seconds}`;
    return formattedDate;
  }

  const formatString = (str: string, edgeCaseString: string) => {
    let firstLetter = str.slice(0, 1).toUpperCase();
    let remainingString = str.slice(1);
    const formattedString =
      str === edgeCaseString
        ? str.toUpperCase()
        : `${firstLetter}${remainingString}`;
    return formattedString;
  };

  const searchOnChange = event => {
    setActionName(
      event.target && typeof event.target.value === 'string'
        ? formatString(event.target.value, 'po')
        : '',
    );
    setCurrentPage(0);
  };
  const handleSearch = useCallback(debounce(searchOnChange, 700), []);

  const exportAudit = () => {
    dispatch(auditActions.exportAudit());
  };

  useEffect(() => {
    setSearchFunctionArray([
      {
        placeholder: 'Search by Action Name',
        function: handleSearch,
        customClass: 'search-input',
      },
    ]);
  }, [handleSearch]);

  useEffect(() => {
    if (auditData.audits && auditData.audits.length > 0) {
      setTableData(
        auditData.audits.map(audit => ({
          actionName: audit.actionName,
          idActionName: audit.idActionName,
          dateTime: formatDateTime(audit.dateTime),
          username: audit.username,
          actionType: audit.actionType,
        })),
      );
      setTotalItems(auditData.totalItems);
    }
  }, [auditData]);

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  function handleDirectionSorting(sortDirection) {
    setSortDirect(sortDirection);
    // setCurrentPage(0);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const auditButtonData = [
    {
      label: 'Export',
      startIcon: <Download />,
      size: 'large',
      variant: 'contained',
      sx: {
        mr: 1,
        backgroundColor: '#f44336',
        '&:hover': { backgroundColor: '#f44331' },
      },
      onClick: exportAudit,
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'white',
          minHeight: '100%',
          py: 8,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5">
                Audit
              </Typography>
              <Breadcrumbs
                aria-label="breadcrumb"
                separator={<ChevronRightIcon fontSize="small" />}
                sx={{ mt: 1 }}
              >
                <Typography color="textPrimary" variant="subtitle2">
                  Dashboard
                </Typography>
                <Typography color="textPrimary" variant="subtitle2">
                  History
                </Typography>
                <Typography color="textSecondary" variant="subtitle2">
                  Audit
                </Typography>
              </Breadcrumbs>
            </Grid>
            <Grid item>
              <Box sx={{ m: -1 }}></Box>
            </Grid>
          </Grid>
          <Box sx={{ mt: 3 }}>
            <WidgetPreviewer
              element={
                <DynamicTable
                  tableType="auditTable"
                  headerFields={auditFields}
                  onPageChange={onPageChange}
                  onChangeRowsPerPage={onChangeRowsPerPage}
                  handleDirectionSorting={handleDirectionSorting}
                  searchArrayOfFunctions={searchFunctionArray}
                  data={tableData}
                  loading={loading}
                  totalItems={totalItems}
                  currentPage={currentPage}
                  limitPerPage={limitPerPage}
                  buttonData={auditButtonData}
                />
              }
              name="Audit Table"
            />
          </Box>
        </Container>
      </Box>
    </>
  );
};

export default AuditTable;
