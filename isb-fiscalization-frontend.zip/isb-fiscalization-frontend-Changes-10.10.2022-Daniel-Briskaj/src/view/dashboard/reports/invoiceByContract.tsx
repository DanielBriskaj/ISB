import { Box, Button, Grid, TextField } from '@material-ui/core';
import { DataGrid, GridColumns, GridOverlay } from '@material-ui/data-grid';
import { debounce } from 'lodash';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import Download from 'src/icons/Download';
import ReactSelect from 'src/view/materialUI/components/ReactSelect';
import contractActions from 'src/modules/contracts/contractActions';
import contractSelector from 'src/modules/contracts/contractSelector';
import notificationThrower from 'src/helpers/notificationThrower';
import numberWithCommas from 'src/helpers/numberWithCommas';

const InvoiceByContract: React.FC = () => {
  const dispatch = useDispatch();

  const {
    register,
    setValue,
    formState: { errors },
    watch,
  } = useForm();

  const contracts = useSelector(contractSelector.contractsDataArray);
  const invoices = useSelector(invoiceSelector.invoicesDataArray);
  const loading = useSelector(invoiceSelector.loading);
  const [contractOptions, setContractOptions] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [contractPage, setContractPage] = useState(0);
  const [contractDescription, setContractDescription] = useState('');
  const [searchingContract, setSearchingContract] = useState<boolean>(false);
  const [pageSize, setPageSize] = useState(10);
  const [tablePage, setTablePage] = useState(0);

  const selectedContract = watch(`contract`);
  const startDate = watch(`startDate`);
  const endDate = watch(`endDate`);

  useEffect(() => {
    dispatch(
      contractActions.read({
        size: 10,
        page: contractPage,
        description: contractDescription,
      }),
    );
  }, [contractPage, contractDescription]);

  useEffect(() => {
    dispatch(
      invoiceActions.read({
        size: pageSize,
        page: tablePage,
        contractId: selectedContract?.id,
        startDate: startDate
          ? moment(startDate).format('DD-MM-YYYY')
          : undefined,
        endDate: endDate ? moment(endDate).format('DD-MM-YYYY') : undefined,
      }),
    );
  }, [selectedContract, pageSize, tablePage, startDate, endDate]);

  useEffect(() => {
    if (contracts?.contracts) {
      setContractOptions(state => [
        ...state,
        ...contracts?.contracts?.map(contract => ({
          label: `${contract?.contractCode} - ${contract?.contractDescription}`,
          value: {
            id: contract?.id,
            code: contract?.contractCode,
          },
        })),
      ]);
    }
  }, [contracts]);

  useEffect(() => {
    if (invoices?.invoices) {
      setTableData(
        invoices?.invoices?.map(invoice => ({
          id: invoice?.id,
          supplier: invoice?.supplier
            ? invoice?.supplier?.companyName
            : invoice?.contract?.supplier?.companyName,
          costOwnerCode: invoice?.costOwner?.code,
          contractCode: invoice?.contract?.contractCode,
          receivedDate: invoice?.receivedDate,
          invoiceNumber: invoice?.invoiceNumber,
          amount: numberWithCommas(invoice?.amount.toFixed(2)),
        })),
      );
    }
  }, [invoices]);

  const columns: GridColumns = [
    {
      field: 'supplier',
      headerName: 'Supplier',
      flex: 2,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'costOwnerCode',
      headerName: 'Cost Owner Code',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'contractCode',
      headerName: 'Contract Code',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'receivedDate',
      headerName: 'Received Date',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'invoiceNumber',
      headerName: 'Invoice Number',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'amount',
      headerName: 'Amount',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
  ];

  const handleOnMenuScrollToBottom = event => {
    if (contractPage < contracts?.totalPages - 1) {
      setContractPage(contractPage + 1);
    }
  };

  const handleOnInputChange = value => {
    setSearchingContract(Boolean(value));
    setContractDescription(value);
    setContractOptions([]);
    setContractPage(0);
  };

  const handleSearchContract = debounce(handleOnInputChange, 500);

  const resetSearchContract = () => {
    if (searchingContract) {
      setContractDescription('');
      setContractOptions([]);
      setContractPage(0);
      setSearchingContract(false);
    }
  };

  const handleExportInvoices = () => {
    if (!selectedContract) {
      notificationThrower({
        type: 'info',
        message: 'Please Select A Contract To Start Exporting',
      });
    } else {
      dispatch(
        invoiceActions.exportByContract(
          {
            contractId: selectedContract?.id,
            startDate: startDate
              ? moment(startDate).format('DD-MM-YYYY')
              : undefined,
            endDate: endDate ? moment(endDate).format('DD-MM-YYYY') : undefined,
          },
          selectedContract?.code,
        ),
      );
    }
  };

  return (
    <>
      <div
        style={{
          marginTop: '2rem',
          width: '100%',
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <form style={{ width: '100%', display: 'flex', gap: '20px' }}>
          <Grid item xs={12} md={5}>
            <ReactSelect
              name="contract"
              placeholder="Contract"
              isClearable={true}
              options={contractOptions}
              errors={errors}
              handleSelect={option => {
                setTablePage(0);
                setValue('contract', option?.value ?? null);
              }}
              handleOnInputChange={event => handleSearchContract(event)}
              handleOnMenuScrollToBottom={event =>
                handleOnMenuScrollToBottom(event)
              }
              handleResetSearch={resetSearchContract}
            />
          </Grid>
          <TextField
            name="startDate"
            type="date"
            label="Start Date"
            size="small"
            variant="outlined"
            onChange={e => {
              setTablePage(0);
              setValue(`startDate`, e?.target?.value);
            }}
            InputLabelProps={{ shrink: true }}
            inputProps={{
              style: { padding: '7.5px 14px' },
            }}
          />
          <TextField
            name="endDate"
            type="date"
            label="End Date"
            size="small"
            variant="outlined"
            onChange={e => {
              setTablePage(0);
              setValue(`endDate`, e?.target?.value);
            }}
            InputLabelProps={{ shrink: true }}
            inputProps={{
              style: { padding: '7.5px 14px' },
            }}
          />
        </form>
        <Box>
          <Button
            size="large"
            variant="contained"
            sx={{ mr: 1 }}
            className="table-button"
            onClick={handleExportInvoices}
            startIcon={<Download />}
            style={{ backgroundColor: '#4CAF50' }}
          >
            Export
          </Button>
        </Box>
      </div>

      <div
        style={{
          width: '100%',
          marginTop: '2rem',
        }}
      >
        <DataGrid
          autoHeight
          disableSelectionOnClick
          loading={loading}
          columns={columns}
          rows={tableData}
          pageSize={pageSize}
          onPageSizeChange={newPageSize => setPageSize(newPageSize)}
          rowsPerPageOptions={[5, 10, 25]}
          pagination
          paginationMode="server"
          rowCount={invoices?.totalItems}
          page={tablePage}
          onPageChange={newPage => setTablePage(newPage)}
          components={{
            NoRowsOverlay: () => (
              <GridOverlay>
                There are no data for the selected filters!
              </GridOverlay>
            ),
          }}
        />
      </div>
    </>
  );
};

export default InvoiceByContract;
