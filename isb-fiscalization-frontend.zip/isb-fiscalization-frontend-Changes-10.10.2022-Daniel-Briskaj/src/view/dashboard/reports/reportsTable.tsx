import { Box, Card, Grid } from '@material-ui/core';
import React from 'react';
import { useForm } from 'react-hook-form';
import { reportOptions } from 'src/enums/reportsOptions';
import ReactSelect from 'src/view/materialUI/components/ReactSelect';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import TotalExpensesActiveContracts from './totalExpensesActiveContracts';
import InvoiceByContract from './invoiceByContract';
import InvoiceBySupplier from './invoiceBySupplier';

const ReportsTable: React.FC = () => {
  const { setValue, watch } = useForm();

  const selectedReport = watch(`report`);

  const handleShowTable = report => {
    switch (report) {
      case 'IBS':
        return <InvoiceBySupplier />;
      case 'IBC':
        return <InvoiceByContract />;
      case 'TEAC':
        return <TotalExpensesActiveContracts />;
    }
  };

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
      }}
    >
      <WidgetPreviewer
        element={
          <Box
            sx={{
              backgroundColor: 'background.default',
              p: 3,
            }}
          >
            <Card sx={{ overflow: 'visible' }}>
              <Box
                sx={{
                  alignItems: 'center',
                  display: 'flex',
                  flexWrap: 'wrap',
                  justifyContent: 'space-between',
                  m: -1,
                  p: 2,
                  mb: 1.5,
                }}
              >
                <form style={{ width: '100%' }}>
                  <Grid item xs={12} md={3}>
                    <ReactSelect
                      placeholder="Select Report"
                      name="report"
                      options={reportOptions}
                      handleSelect={option => {
                        setValue('report', option.value);
                      }}
                    />
                  </Grid>
                </form>
                {handleShowTable(selectedReport)}
              </Box>
            </Card>
          </Box>
        }
        name="Reports"
      />
    </Box>
  );
};
export default ReportsTable;
