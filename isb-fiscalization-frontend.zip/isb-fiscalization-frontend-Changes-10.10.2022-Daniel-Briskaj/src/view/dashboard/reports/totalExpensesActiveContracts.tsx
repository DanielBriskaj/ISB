import { Box, Button, Grid, TextField, Tooltip } from '@material-ui/core';
import { DataGrid, GridColumns, GridOverlay } from '@material-ui/data-grid';
import { debounce } from 'lodash';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import supplierActions from 'src/modules/suppliers/supplierActions';
import supplierSelector from 'src/modules/suppliers/supplierSelector';
import Download from 'src/icons/Download';
import ReactSelect from 'src/view/materialUI/components/ReactSelect';
import contractSelector from 'src/modules/contracts/contractSelector';
import contractActions from 'src/modules/contracts/contractActions';
import { contractStatus } from 'src/enums/contractStatus';
import numberWithCommas from 'src/helpers/numberWithCommas';

const TotalExpensesActiveContracts: React.FC = () => {
  const dispatch = useDispatch();

  const {
    register,
    setValue,
    formState: { errors },
    watch,
  } = useForm();

  const suppliers = useSelector(supplierSelector.suppliersDataArray);
  const contracts = useSelector(contractSelector.contractsDataArray);
  const loading = useSelector(contractSelector.loading);

  const [supplierOptions, setSupplierOptions] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [supplierPage, setSupplierPage] = useState(0);
  const [supplierName, setSupplierName] = useState('');
  const [searchingSupplier, setSearchingSupplier] = useState<boolean>(false);
  const [pageSize, setPageSize] = useState(10);
  const [tablePage, setTablePage] = useState(0);

  const selectedSupplier = watch(`supplier`);

  useEffect(() => {
    dispatch(
      supplierActions.read({
        size: 10,
        page: supplierPage,
        companyName: supplierName,
      }),
    );
  }, [supplierName, supplierPage]);

  useEffect(() => {
    dispatch(
      contractActions.read({
        size: pageSize,
        page: tablePage,
        supplierCompanyName: selectedSupplier?.name,
        contractStatus: 'ACTIVE',
      }),
    );
  }, [selectedSupplier, pageSize, tablePage]);

  useEffect(() => {
    if (suppliers?.suppliers) {
      setSupplierOptions(state => [
        ...state,
        ...suppliers?.suppliers?.map(supplier => ({
          label: supplier.companyName,
          value: {
            id: supplier?.id,
            name: supplier?.companyName,
          },
        })),
      ]);
    }
  }, [suppliers]);

  useEffect(() => {
    if (contracts?.contracts) {
      setTableData(
        contracts?.contracts?.map(contract => ({
          id: contract?.id,
          supplier: contract?.supplier?.companyName,
          costOwner: contract?.costOwner?.ownerName,
          costOwnerDivision: contract?.costOwner?.division,
          contractCode: contract?.contractCode,
          startDate: contract?.startDate,
          description: contract?.contractDescription,
          amount: numberWithCommas(contract?.contractAmount.toFixed(2)),
        })),
      );
    }
  }, [contracts]);

  const columns: GridColumns = [
    {
      field: 'supplier',
      headerName: 'Supplier',
      flex: 2,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span className="table-cell-trucate">{params.value}</span>
        </Tooltip>
      ),
    },
    {
      field: 'costOwner',
      headerName: 'Cost Owner',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span className="table-cell-trucate">{params.value}</span>
        </Tooltip>
      ),
    },
    {
      field: 'costOwnerDivision',
      headerName: 'Cost Owner Division',
      align: 'center',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span className="table-cell-trucate">{params.value}</span>
        </Tooltip>
      ),
    },
    {
      field: 'contractCode',
      headerName: 'Contract Code',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span className="table-cell-trucate">{params.value}</span>
        </Tooltip>
      ),
    },
    {
      field: 'startDate',
      headerName: 'Start Date',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span className="table-cell-trucate">{params.value}</span>
        </Tooltip>
      ),
    },
    {
      field: 'description',
      headerName: 'Description',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span className="table-cell-trucate">{params.value}</span>
        </Tooltip>
      ),
    },
    {
      field: 'amount',
      headerName: 'Amount',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
      renderCell: (params: any) => (
        <Tooltip title={params.value}>
          <span className="table-cell-trucate">{params.value}</span>
        </Tooltip>
      ),
    },
  ];

  const handleOnMenuScrollToBottom = event => {
    if (supplierPage < suppliers?.totalPages - 1) {
      setSupplierPage(supplierPage + 1);
    }
  };

  const handleOnInputChange = value => {
    setSearchingSupplier(Boolean(value));
    setSupplierName(value);
    setSupplierOptions([]);
    setSupplierPage(0);
  };

  const handleSearchSupplier = debounce(handleOnInputChange, 500);

  const resetSearchSupplier = () => {
    if (searchingSupplier) {
      setSupplierName('');
      setSupplierOptions([]);
      setSupplierPage(0);
      setSearchingSupplier(false);
    }
  };

  const handleExportContracts = () => {
    dispatch(
      contractActions.exportActiveContractsPaidAmount({
        supplierId: selectedSupplier?.id,
        contractStatus: 'ACTIVE',
      }),
    );
  };

  return (
    <>
      <div
        style={{
          marginTop: '2rem',
          width: '100%',
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <form style={{ width: '100%', display: 'flex', gap: '20px' }}>
          <Grid item xs={12} md={3}>
            <ReactSelect
              name="supplier"
              placeholder="Supplier"
              isClearable={true}
              options={supplierOptions}
              errors={errors}
              handleSelect={option => {
                setTablePage(0);
                setValue('supplier', option?.value ?? null);
              }}
              handleOnInputChange={event => handleSearchSupplier(event)}
              handleOnMenuScrollToBottom={event =>
                handleOnMenuScrollToBottom(event)
              }
              handleResetSearch={resetSearchSupplier}
            />
          </Grid>
          <Grid item xs={12} md={1}>
            <ReactSelect
              name="status"
              placeholder="Status"
              options={contractStatus}
              errors={errors}
              disabled={true}
              defaultValue={contractStatus[0]}
            />
          </Grid>
        </form>
        <Box>
          <Button
            color="primary"
            size="large"
            variant="contained"
            sx={{ mr: 1 }}
            className="table-button"
            onClick={handleExportContracts}
            startIcon={<Download />}
            style={{ backgroundColor: '#4CAF50' }}
          >
            Export
          </Button>
        </Box>
      </div>

      <div
        style={{
          width: '100%',
          marginTop: '2rem',
        }}
      >
        <DataGrid
          autoHeight
          disableSelectionOnClick
          loading={loading}
          columns={columns}
          rows={tableData}
          pageSize={pageSize}
          onPageSizeChange={newPageSize => setPageSize(newPageSize)}
          rowsPerPageOptions={[5, 10, 25]}
          pagination
          paginationMode="server"
          rowCount={contracts?.totalItems}
          page={tablePage}
          onPageChange={newPage => setTablePage(newPage)}
          components={{
            NoRowsOverlay: () => (
              <GridOverlay>
                There are no data for the selected filters!
              </GridOverlay>
            ),
          }}
        />
      </div>
    </>
  );
};

export default TotalExpensesActiveContracts;
