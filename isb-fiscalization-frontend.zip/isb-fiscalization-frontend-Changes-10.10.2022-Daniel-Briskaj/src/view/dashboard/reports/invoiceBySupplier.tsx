import { Box, Button, Grid, TextField } from '@material-ui/core';
import { DataGrid, GridColumns, GridOverlay } from '@material-ui/data-grid';
import { debounce } from 'lodash';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import supplierActions from 'src/modules/suppliers/supplierActions';
import supplierSelector from 'src/modules/suppliers/supplierSelector';
import moment from 'moment';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import Download from 'src/icons/Download';
import ReactSelect from 'src/view/materialUI/components/ReactSelect';
import notificationThrower from 'src/helpers/notificationThrower';
import numberWithCommas from 'src/helpers/numberWithCommas';

const InvoiceBySupplier: React.FC = () => {
  const dispatch = useDispatch();

  const {
    register,
    setValue,
    formState: { errors },
    watch,
  } = useForm();

  const suppliers = useSelector(supplierSelector.suppliersDataArray);
  const invoices = useSelector(invoiceSelector.invoicesDataArray);
  const loading = useSelector(invoiceSelector.loading);
  const [supplierOptions, setSupplierOptions] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [supplierPage, setSupplierPage] = useState(0);
  const [supplierName, setSupplierName] = useState('');
  const [searchingSupplier, setSearchingSupplier] = useState<boolean>(false);
  const [pageSize, setPageSize] = useState(10);
  const [tablePage, setTablePage] = useState(0);

  const selectedSupplier = watch(`supplier`);
  const startDate = watch(`startDate`);
  const endDate = watch(`endDate`);

  useEffect(() => {
    dispatch(
      supplierActions.read({
        size: 10,
        page: supplierPage,
        companyName: supplierName,
      }),
    );
  }, [supplierName, supplierPage]);

  useEffect(() => {
    dispatch(
      invoiceActions.read({
        size: pageSize,
        page: tablePage,
        supplierId: selectedSupplier?.id,
        startDate: startDate
          ? moment(startDate).format('DD-MM-YYYY')
          : undefined,
        endDate: endDate ? moment(endDate).format('DD-MM-YYYY') : undefined,
      }),
    );
  }, [selectedSupplier, pageSize, tablePage, startDate, endDate]);

  useEffect(() => {
    if (suppliers?.suppliers) {
      setSupplierOptions(state => [
        ...state,
        ...suppliers?.suppliers?.map(supplier => ({
          label: supplier.companyName,
          value: {
            id: supplier.id,
            name: supplier.companyName,
          },
        })),
      ]);
    }
  }, [suppliers]);

  useEffect(() => {
    if (invoices?.invoices) {
      setTableData(
        invoices?.invoices?.map(invoice => ({
          id: invoice?.id,
          supplier: invoice?.supplier
            ? invoice?.supplier?.companyName
            : invoice?.contract?.supplier?.companyName,
          costOwnerCode: invoice?.costOwner?.code,
          contractCode: invoice?.contract?.contractCode,
          receivedDate: invoice?.receivedDate,
          invoiceNumber: invoice?.invoiceNumber,
          amount: numberWithCommas(invoice?.amount.toFixed(2)),
        })),
      );
    }
  }, [invoices]);

  const columns: GridColumns = [
    {
      field: 'supplier',
      headerName: 'Supplier',
      flex: 2,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'costOwnerCode',
      headerName: 'Cost Owner Code',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'contractCode',
      headerName: 'Contract Code',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'receivedDate',
      headerName: 'Received Date',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'invoiceNumber',
      headerName: 'Invoice Number',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
    {
      field: 'amount',
      headerName: 'Amount',
      flex: 1,
      sortable: false,
      headerClassName: 'lastcolumnSeparator',
    },
  ];

  const handleOnMenuScrollToBottom = event => {
    if (supplierPage < suppliers?.totalPages - 1) {
      setSupplierPage(supplierPage + 1);
    }
  };

  const handleOnInputChange = value => {
    setSearchingSupplier(Boolean(value));
    setSupplierName(value);
    setSupplierOptions([]);
    setSupplierPage(0);
  };

  const handleSearchSupplier = debounce(handleOnInputChange, 500);

  const resetSearchSupplier = () => {
    if (searchingSupplier) {
      setSupplierName('');
      setSupplierOptions([]);
      setSupplierPage(0);
      setSearchingSupplier(false);
    }
  };

  const handleExportInvoices = () => {
    if (!selectedSupplier) {
      notificationThrower({
        type: 'info',
        message: 'Please Select A Supplier To Start Exporting',
      });
    } else {
      dispatch(
        invoiceActions.exportBySupplier(
          {
            supplierId: selectedSupplier?.id,
            startDate: startDate
              ? moment(startDate).format('DD-MM-YYYY')
              : undefined,
            endDate: endDate ? moment(endDate).format('DD-MM-YYYY') : undefined,
          },
          selectedSupplier?.name,
        ),
      );
    }
  };

  return (
    <>
      <div
        style={{
          marginTop: '2rem',
          width: '100%',
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <form style={{ width: '100%', display: 'flex', gap: '20px' }}>
          <Grid item xs={12} md={3}>
            <ReactSelect
              name="supplier"
              placeholder="Supplier"
              isClearable={true}
              options={supplierOptions}
              errors={errors}
              handleSelect={option => {
                setTablePage(0);
                setValue('supplier', option?.value ?? null);
              }}
              handleOnInputChange={event => handleSearchSupplier(event)}
              handleOnMenuScrollToBottom={event =>
                handleOnMenuScrollToBottom(event)
              }
              handleResetSearch={resetSearchSupplier}
            />
          </Grid>
          <TextField
            name="startDate"
            type="date"
            label="Start Date"
            size="small"
            variant="outlined"
            onChange={e => {
              setTablePage(0);
              setValue(`startDate`, e?.target?.value);
            }}
            InputLabelProps={{ shrink: true }}
            inputProps={{
              style: { padding: '7.5px 14px' },
            }}
          />
          <TextField
            name="endDate"
            type="date"
            label="End Date"
            size="small"
            variant="outlined"
            onChange={e => {
              setTablePage(0);
              setValue(`endDate`, e?.target?.value);
            }}
            InputLabelProps={{ shrink: true }}
            inputProps={{
              style: { padding: '7.5px 14px' },
            }}
          />
        </form>
        <Box>
          <Button
            color="primary"
            size="large"
            variant="contained"
            sx={{ mr: 1 }}
            className="table-button"
            onClick={handleExportInvoices}
            startIcon={<Download />}
            style={{ backgroundColor: '#4CAF50' }}
          >
            Export
          </Button>
        </Box>
      </div>

      <div
        style={{
          width: '100%',
          marginTop: '2rem',
        }}
      >
        <DataGrid
          autoHeight
          disableSelectionOnClick
          loading={loading}
          columns={columns}
          rows={tableData}
          pageSize={pageSize}
          onPageSizeChange={newPageSize => setPageSize(newPageSize)}
          rowsPerPageOptions={[5, 10, 25]}
          pagination
          paginationMode="server"
          rowCount={invoices?.totalItems}
          page={tablePage}
          onPageChange={newPage => setTablePage(newPage)}
          components={{
            NoRowsOverlay: () => (
              <GridOverlay>
                There are no data for the selected filters!
              </GridOverlay>
            ),
          }}
        />
      </div>
    </>
  );
};

export default InvoiceBySupplier;
