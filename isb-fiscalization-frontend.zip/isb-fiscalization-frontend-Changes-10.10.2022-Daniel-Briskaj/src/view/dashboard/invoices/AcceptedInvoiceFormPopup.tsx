import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import Close from 'src/icons/X';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import AcceptedInvoiceForm from 'src/view/materialUI/components/widgets/forms/AcceptedInvoiceForm/AcceptedInvoiceForm';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import { FormInvoiceData } from 'src/models/data/invoices/InvoiceData';
import { invoicesSchema } from 'src/modules/shared/yup/invoicesSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm, FormProvider } from 'react-hook-form';
import { useSelector, useDispatch } from 'react-redux';
import MemoDataTransformer from 'src/helpers/MemoDataTransformer';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import { INVOICE_STATUS } from 'src/modules/invoices/invoiceReducer';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import { invoiceMemoSchema } from 'src/modules/shared/yup/invoiceMemoSchema';

const AcceptedInvoiceFormPopup = ({
  setModalOpen,
  data,
  tab,
  page,
  rowsPerPage,
  query,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const invoice = useSelector(invoiceSelector.invoiceData);
  const loading = useSelector(invoiceSelector.loading);

  const authorizationPayload = useSelector(authSelector.authData);
  const { role } = authorizationPayload;

  const [dialogOpen, setDialogOpen] = useState(false);
  const [isCoa, setIsCoa] = useState(false);

  const renderControlButtons = () => {
    if (authorizationPayload && authorizationPayload.role) {
      switch (authorizationPayload.role) {
        case ROLES.ACCOUNTING_INPUT:
          return (
            <React.Fragment>
              <Button
                color="primary"
                sx={{
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                type="submit"
              >
                Save
              </Button>
              <Button
                color="secondary"
                sx={{
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={form.handleSubmit(handleRequestPayment)}
              >
                Request Payment
              </Button>
              <Button
                color="secondary"
                sx={{
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={() => {
                  setIsCoa(true);
                  setDialogOpen(true);
                }}
              >
                Reject Invoice
              </Button>
              <Button
                sx={{
                  background: '#666',
                  '&:hover': {
                    background: '#333',
                  },
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={() => setModalOpen(false)}
              >
                Cancel
              </Button>
            </React.Fragment>
          );

        case ROLES.ACCOUNTING_AUTHORIZER:
          return (
            <React.Fragment>
              <Button
                color="primary"
                sx={{
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={form.handleSubmit(handleRequestPayment)}
              >
                Accept Payment
              </Button>
              <Button
                color="secondary"
                variant="contained"
                onClick={() => {
                  setDialogOpen(true);
                }}
              >
                Reject Payment
              </Button>
              <Button
                sx={{
                  background: '#666',
                  '&:hover': {
                    background: '#333',
                  },
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={() => setModalOpen(false)}
              >
                Cancel
              </Button>
            </React.Fragment>
          );

        case ROLES.TBO_INPUT:
          return (
            <React.Fragment>
              <Button
                color="primary"
                sx={{
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={() => onChangeStatus('Assigned')}
              >
                Pay
              </Button>
              <Button
                color="secondary"
                variant="contained"
                onClick={() => {
                  setDialogOpen(true);
                }}
              >
                Reject
              </Button>
              <Button
                sx={{
                  background: '#666',
                  '&:hover': {
                    background: '#333',
                  },
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={() => setModalOpen(false)}
              >
                Cancel
              </Button>
            </React.Fragment>
          );
        case ROLES.TBO_AUTHORIZER:
          return (
            <React.Fragment>
              <Button
                sx={{
                  background: '#666',
                  '&:hover': {
                    background: '#333',
                  },
                  m: '0 6px',
                  p: '6px 10px',
                  fontSize: '14px',
                }}
                variant="contained"
                onClick={() => setModalOpen(false)}
              >
                Cancel
              </Button>
            </React.Fragment>
          );
      }
    } else {
      return (
        <React.Fragment>
          <Button
            color="primary"
            sx={{
              m: '0 6px',
              p: '6px 10px',
              fontSize: '14px',
            }}
            variant="contained"
            type="submit"
          >
            Save
          </Button>
          <Button
            sx={{
              background: '#666',
              '&:hover': {
                background: '#333',
              },
              m: '0 6px',
              p: '6px 10px',
              fontSize: '14px',
            }}
            variant="contained"
            onClick={() => setModalOpen(false)}
          >
            Cancel
          </Button>
        </React.Fragment>
      );
    }
  };

  useEffect(() => {
    dispatch(invoiceActions.getById(data.id));
  }, []);

  const initialValues: FormInvoiceData = {
    date: new Date().toISOString().slice(0, 10),
    valueDate: new Date().toISOString().slice(0, 10),
  };

  const memoSchema = invoiceMemoSchema(data?.isManual);

  const form = useForm({
    resolver: yupResolver(memoSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  useEffect(() => {
    if (invoice) {
      form.reset({ ...initialValues, ...invoice });
    }
  }, [invoice]);

  useEffect(() => {
    return () => {
      dispatch(invoiceActions.clearSingleInvoice());
    };
  }, []);

  const onSubmit = formData => {
    if (formData) {
      const transData = MemoDataTransformer(formData);
      const query = {
        page,
        size: rowsPerPage,
        invoiceStatus:
          role === 'ACCOUNTING_INPUT'
            ? INVOICE_STATUS.ACCEPTED
            : INVOICE_STATUS.ASSIGNED,
      };
      dispatch(
        invoiceActions.invoiceUpdateMemoData(
          formData.id,
          transData,
          true,
          query,
        ),
      );
      setModalOpen(false);
    } else {
      throw new Error('There are no data for the specific invoice');
    }
  };

  const handleRequestPayment = formData => {
    const transData = MemoDataTransformer(formData);
    dispatch(
      invoiceActions.invoiceUpdateMemoData(
        formData?.id,
        {
          ...transData,
          invoiceStatus: getUpdatedStatus('Assigned'),
          authorizerFeedback: null,
        },
        true,
        query,
        true,
      ),
    );
    setModalOpen(false);
  };

  const onChangeStatus = (action, userData?) => {
    dispatch(
      invoiceActions.changeStatus(
        data?.id,
        {
          authorizerFeedback: userData?.reason,
          invoiceStatus: getUpdatedStatus(action),
        },
        query,
        role,
        action,
      ),
    );

    setModalOpen(false);
  };

  const getUpdatedStatus = action => {
    if (action === 'Assigned') {
      switch (role) {
        case ROLES.ACCOUNTING_INPUT:
          return INVOICE_STATUS.REQUEST_PAYMENT;
        case ROLES.ACCOUNTING_AUTHORIZER:
          return INVOICE_STATUS.APPROVED_PAYMENT;
        case ROLES.TBO_INPUT:
          return INVOICE_STATUS.PAID;
      }
    } else if (action === 'Rejected') {
      switch (role) {
        case ROLES.ACCOUNTING_INPUT:
          return INVOICE_STATUS.SEND_SUBMIT;
        case ROLES.ACCOUNTING_AUTHORIZER:
          return INVOICE_STATUS.ACCEPTED;
        case ROLES.TBO_INPUT:
          return INVOICE_STATUS.ACCEPTED;
      }
    }
  };

  return (
    <>
      {invoice?.id && (
        <Box
          sx={{
            backgroundColor: 'background.default',
            minHeight: '100%',
            py: 4,
          }}
          height="100%"
        >
          <Container maxWidth={settings.compact ? 'xl' : false}>
            <Grid
              container
              justifyContent="space-between"
              alignItems="center"
              spacing={3}
            >
              <Grid item>
                <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                  Pay Invoice
                </Typography>
              </Grid>
              <Grid item>
                <Close onClick={() => setModalOpen(false)} />
              </Grid>
            </Grid>
            <FormProvider {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <Divider />
                <Box
                  sx={{
                    mt: 3,
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                  height="100%"
                >
                  <AcceptedInvoiceForm data={data} invoice={invoice} />
                </Box>
                <Box
                  sx={{ mt: 2 }}
                  display="flex"
                  justifyContent="end"
                  alignContent="end"
                >
                  {renderControlButtons()}
                </Box>
              </form>
            </FormProvider>
          </Container>
          <ModalWrapper
            children={
              <AlertDialog
                setDialogOpen={setDialogOpen}
                handleDelete={data => {
                  onChangeStatus('Rejected', data);
                }}
                message={`Why do you want to reject this Invoice?`}
                hasFeedback={true}
              />
            }
            modalOpen={dialogOpen}
            setModalOpen={setDialogOpen}
            type="deleteModal"
          />
        </Box>
      )}
    </>
  );
};

export default AcceptedInvoiceFormPopup;
