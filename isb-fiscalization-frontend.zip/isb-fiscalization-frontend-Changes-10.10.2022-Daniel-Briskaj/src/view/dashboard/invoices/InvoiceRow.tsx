import React, { useEffect } from 'react';
import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import Label from 'src/view/materialUI/components/Label';
import PencilAltIcon from '../../../icons/PencilAlt';
import ArrowRightIcon from 'src/icons/ArrowRight';
import Download from 'src/icons/Download';
import { useDispatch, useSelector } from 'react-redux';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

export const getStatusLabel = invoiceStatus => {
  const map = {
    ASSIGNED: {
      color: 'warning',
      text: 'ASSIGNED',
    },
    ACCEPTED: {
      color: 'success',
      text: 'ACCEPTED',
    },
    SEND_SUBMIT: {
      color: 'primary',
      text: 'SEND_SUBMIT',
    },
    REQUEST_PAYMENT: {
      color: 'secondary',
      text: 'REQUEST_PAYMENT',
    },
    DELIVERED: {
      color: 'primary',
      text: 'DELIVERED',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    PAID: {
      color: 'success',
      text: 'PAID',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const InvoiceRow = ({ invoice, buttonData, page, rowsPerPage }) => {
  const dispatch = useDispatch();
  const currentTab = useSelector(invoiceSelector.currentTab);
  const authData = useSelector(authSelector.authData);
  const { role } = authData;

  const handleDownloadPDF = () => {
    if (role === ROLES.ACCOUNTING_AUTHORIZER) {
      dispatch(
        invoiceActions.exportMemo({
          id: invoice?.id,
          invoiceNumber: invoice?.invoiceNumber,
        }),
      );
    } else {
      dispatch(invoiceActions.exportPdfFile({ eic: invoice.eic }));
    }
  };
  return (
    <TableRow key={invoice.eic} hover>
      {Object.keys(invoice).map(key => {
        if (key === 'id') {
          return;
        }

        if (key === 'eic') {
          return (
            <TableCell sx={{ paddingLeft: '1rem', width: '20%' }}>
              {invoice[key]}
            </TableCell>
          );
        }
        if (key === 'status' || key === 'approved') {
          return (
            <TableCell align="center" key={key}>
              {invoice[key] && getStatusLabel(invoice[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            key={key}
            align={
              key === 'invoiceNumber' ||
              key === 'receivedDate' ||
              key === 'dueDate' ||
              key === 'status' ||
              key === 'suplier' ||
              key === 'NIPT'
                ? 'center'
                : key === 'amount'
                ? 'right'
                : 'left'
            }
          >
            {invoice[key] && invoice[key]}
          </TableCell>
        );
      })}

      <TableCell align="center">
        <IconButton
          disabled={
            (role === ROLES.ACCOUNTING_AUTHORIZER &&
              (invoice.status === 'APPROVED_PAYMENT' ||
                invoice?.status === 'PAID')) ||
            role === ROLES.ACCOUNTING_INPUT
              ? false
              : true
          }
          onClick={handleDownloadPDF}
        >
          <Download />
        </IconButton>
      </TableCell>
      {authData && authData.role && authData.role === ROLES.ACCOUNTING_INPUT && (
        <React.Fragment>
          <TableCell align="center">
            <Button onClick={() => buttonData[0].buttonFunction(invoice)}>
              Process
            </Button>
          </TableCell>
          <TableCell align="center">
            <Button onClick={() => buttonData[1].buttonFunction(invoice)}>
              Reject
            </Button>
          </TableCell>
        </React.Fragment>
      )}
    </TableRow>
  );
};

export default InvoiceRow;
