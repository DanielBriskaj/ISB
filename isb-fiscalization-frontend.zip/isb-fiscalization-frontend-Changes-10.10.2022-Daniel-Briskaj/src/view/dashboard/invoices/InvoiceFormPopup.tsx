import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import Close from 'src/icons/X';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import InvoicesForm from 'src/view/materialUI/components/widgets/forms/InvoicesForm';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import { FormInvoiceData } from 'src/models/data/invoices/InvoiceData';
import { invoicesSchema } from 'src/modules/shared/yup/invoicesSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm, FormProvider } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';

import moment from 'moment';

const InvoiceFormPopup = ({ setModalOpen, data, tab, dateState, query }) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();

  const initialValues: FormInvoiceData = {
    amount: 0,
    dueDate: '',
    eic: '',
    importedInvoiceNumber: '',
    invoiceNumber: '',
    nipt: '',
    receivedDate: '',
    status: '',
    type: '',
    approved: 'NEW',
    costOwner: {
      code: '',
      division: 'OPD',
      ownerName: '',
      id: 0,
      isAuthorizer: false,
    },
  };

  const form = useForm({
    resolver: yupResolver(invoicesSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    if (data) {
      tab === 'invoices' &&
        dispatch(invoiceActions.assignCostOwners(data, query));
      setModalOpen(false);
    } else {
      throw new Error('Invoice wast not successfully assigned');
    }
  };

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid
            container
            justifyContent="space-between"
            alignItems="center"
            spacing={3}
          >
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                {tab === 'invoices' ? 'Assign' : 'Pay Invoice'}
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box
                sx={{
                  mt: 3,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
                height="100%"
              >
                <InvoicesForm data={data} tab={tab} />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  type="submit"
                >
                  {tab === 'invoices' ? 'Save' : 'Pay Invoice'}
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default InvoiceFormPopup;
