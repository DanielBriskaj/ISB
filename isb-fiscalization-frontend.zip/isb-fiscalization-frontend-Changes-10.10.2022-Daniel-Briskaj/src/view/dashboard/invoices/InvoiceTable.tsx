import { useEffect, useState } from 'react';
import { Box, Tab, Tabs, TextField } from '@material-ui/core';
import type { ChangeEvent } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import DynamicTable from 'src/view/materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import {
  acceptedInvoicesFields,
  accInputInvoicesFields,
  accAuthInvoicesFields,
} from 'src/enums/shared/headerFields/invoicesFields';
import moment from 'moment';
import InvoiceFormPopup from './InvoiceFormPopup';
import AcceptedInvoiceFormPopup from './AcceptedInvoiceFormPopup';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { INVOICE_STATUS } from 'src/modules/invoices/invoiceReducer';
import numberWithCommas from 'src/helpers/numberWithCommas';

type InvoiceStatusInput =
  | ''
  | 'DELIVERED'
  | 'SEND_SUBMIT'
  | 'APPROVED_PAYMENT'
  | 'ACCEPTED'
  | 'ASSIGNED'
  | 'REQUEST_PAYMENT'
  | 'PAID';

const invoiceStatusOptions = [
  { value: '', label: 'ALL' },
  { value: 'ASSIGNED', label: 'ASSIGNED' },
  { value: 'DELIVERED', label: 'DELIVERED' },
  { value: 'SEND_SUBMIT', label: 'SEND SUBMIT' },
  { value: 'ACCEPTED', label: 'ACCEPTED' },
  { value: 'REQUEST_PAYMENT', label: 'REQUEST PAYMENT' },
  { value: 'APPROVED_PAYMENT', label: 'APPROVED PAYMENT' },
  { value: 'PAID', label: 'PAID' },
];

const accountingInpuTabs = [
  { label: 'Invoices', value: 'invoices' },
  { label: 'Pay invoices', value: 'pay_invoices' },
];

const InvoiceTable = ({ role }) => {
  const yesterday = new Date();
  yesterday.setDate(new Date().getDate() - 7);
  const [dateState, setDateState] = useState({
    startDate: yesterday,
    endDate: new Date(),
    key: 'selection',
  });

  const [tableData, setTableData] = useState([]);
  const [acceptedTableData, setAcceptedTableData] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState({});
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [invoiceLimitPerPage, setInvoiceLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [invoiceCurrentPage, setInvoiceCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [invoiceTotalItems, setInvoiceTotalItems] = useState(0);
  const [approved, setApproved] = useState<InvoiceStatusInput>('');
  const [sortDirection, setSortDirect] = useState<'asc' | 'desc'>('desc');

  const dispatch = useDispatch();

  const currentTab = useSelector(invoiceSelector.currentTab);
  const loading = useSelector(statusSelector.loading);
  const invoicesState = useSelector(invoiceSelector.invoicesDataArray);
  const eBillsState = useSelector(invoiceSelector.eBillsDataArray);
  const acceptedInvoicesState = useSelector(
    invoiceSelector.acceptedInvoicesData,
  );

  const authorizationPayload = useSelector(authSelector.authData);

  function handleModalOpen(bool) {
    setModalOpen(bool);
  }
  const handleTabsChange = (event: ChangeEvent<{}>, value: string): void => {
    dispatch(invoiceActions.setCurrentTab(value));
  };

  const deleteTime = (str: string) =>
    str?.replace(/^([0-1]?\d|2[0-3])(?::([0-5]?\d))?(?::([0-5]?\d))?$/g, '');

  const ebillQuery = {
    startDate: moment(dateState.startDate).format('YYYY-MM-DD'),
    endDate: moment(dateState.endDate).format('YYYY-MM-DD'),
    type: 'BUYER',
    size: invoiceLimitPerPage,
    page: invoiceCurrentPage,
  };

  const invoiceQuery = {
    invoiceStatus:
      authorizationPayload &&
      authorizationPayload.role &&
      authorizationPayload.role === ROLES.ACCOUNTING_AUTHORIZER
        ? INVOICE_STATUS.REQUEST_PAYMENT
        : INVOICE_STATUS.ACCEPTED,
    size: limitPerPage,
    page: currentPage,
  };

  useEffect(() => {
    if (currentTab === 'invoices' && role !== 'ACCOUNTING_AUTHORIZER') {
      dispatch(
        invoiceActions.read(ebillQuery, {
          fiscalization: role && role === 'ACCOUNTING_INPUT',
        }),
      );
    } else if (currentTab === 'invoices' && role === 'ACCOUNTING_AUTHORIZER') {
      dispatch(
        invoiceActions.read({
          size: invoiceLimitPerPage,
          page: invoiceCurrentPage,
          invoiceStatus: approved,
          sort: ['dueDate', sortDirection],
        }),
      );
    } else {
      dispatch(invoiceActions.readAcceptInBnt(invoiceQuery));
    }
  }, [
    dateState,
    currentTab,
    limitPerPage,
    currentPage,
    invoiceLimitPerPage,
    invoiceCurrentPage,
    approved,
    sortDirection,
  ]);

  useEffect(() => {
    if (invoicesState?.invoices) {
      setTableData(
        invoicesState?.invoices?.map(invoice => ({
          id: invoice?.id,
          eic: invoice?.eic,
          invoiceNumber: invoice?.invoiceNumber,
          receivedDate:
            invoice && invoice.receivedDate
              ? deleteTime(invoice.receivedDate)
              : '',
          dueDate: invoice?.dueDate,
          amount: numberWithCommas(invoice?.amount.toFixed(2)),
          status: invoice?.status || invoice?.invoiceStatus,
          NIPT: invoice?.NIPT || invoice?.nipt,
        })),
      );
      setInvoiceTotalItems(invoicesState?.totalItems);
    }
    if (eBillsState?.ebills) {
      setTableData(
        eBillsState?.ebills?.map(invoice => ({
          eic: invoice?.eic,
          invoiceNumber: invoice?.invoiceNumber,
          receivedDate:
            invoice && invoice.receivedDate
              ? deleteTime(invoice.receivedDate)
              : '',
          dueDate: invoice?.dueDate,
          amount: numberWithCommas(invoice?.amount.toFixed(2)),
          status: invoice?.status || invoice?.invoiceStatus,
          NIPT: invoice?.NIPT || invoice?.nipt,
        })),
      );
      setInvoiceTotalItems(eBillsState?.totalItems);
    }

    if (acceptedInvoicesState?.invoices) {
      setAcceptedTableData(
        acceptedInvoicesState?.invoices.map(invoice => ({
          id: invoice.id,
          eic: invoice.eic,
          suplier: invoice?.supplier?.companyName,
          invoiceNumber: invoice?.invoiceNumber,
          receivedDate:
            invoice && invoice.receivedDate
              ? deleteTime(invoice.receivedDate)
              : '',
          dueDate: invoice?.dueDate,
          amount: numberWithCommas(invoice?.amount.toFixed(2)),
          status: invoice?.status || invoice?.invoiceStatus,
          nipt: invoice?.NIPT || invoice?.nipt,
          isManual: invoice?.isManual,
        })),
      );
      setTotalItems(acceptedInvoicesState?.totalItems);
    }
  }, [invoicesState, acceptedInvoicesState, eBillsState]);

  useEffect(() => {
    return () => {
      dispatch(invoiceActions.clearInvoiceData());
    };
  }, []);

  const handleDelete = invoice => {
    dispatch(invoiceActions.invoiceUpdateStatus(invoice, ebillQuery));
  };

  const handleApproveAll = () => {
    const status = {
      currentStatus: 'REQUEST_PAYMENT',
      newStatus: 'APPROVED_PAYMENT',
    };
    dispatch(
      invoiceActions.batchUpdate(status, {
        invoiceStatus: INVOICE_STATUS.REQUEST_PAYMENT,
        page: 0,
        size: 10,
      }),
    );
  };

  const invoiceButtonData = [
    {
      buttonFunction: selected => {
        setModalOpen(true);
        setSelectedInvoice(selected);
      },
    },
    {
      buttonFunction: selected => {
        setDialogOpen(true);
        setSelectedInvoice(selected);
      },
    },
  ];
  const payInvoiceButtonData = [
    {
      buttonFunction: selected => {
        setModalOpen(true);
        setSelectedInvoice(selected);
      },
    },
    {
      buttonFunction: selected => {
        setDialogOpen(true);
        setSelectedInvoice(selected);
      },
    },
    role === ROLES.ACCOUNTING_AUTHORIZER && {
      label: 'Approve All',
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleApproveAll,
    },
  ];
  const modalWrapperData = [
    {
      children:
        currentTab === 'invoices' ? (
          <InvoiceFormPopup
            setModalOpen={handleModalOpen}
            data={selectedInvoice}
            tab={currentTab}
            dateState={dateState}
            query={ebillQuery}
          />
        ) : (
          <AcceptedInvoiceFormPopup
            setModalOpen={handleModalOpen}
            data={selectedInvoice}
            tab={currentTab}
            page={currentPage}
            rowsPerPage={limitPerPage}
            query={invoiceQuery}
          />
        ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          handleDelete={() => handleDelete(selectedInvoice)}
          message={`Are you sure you want to continue?`}
          hasFeedback={false}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  function onPageChange(event, page) {
    if (currentTab === 'invoices') {
      setInvoiceCurrentPage(page);
    } else {
      setCurrentPage(page);
    }
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    if (currentTab === 'invoices') {
      setInvoiceLimitPerPage(newLimitPerPage);
      setInvoiceCurrentPage(defaultPage);
    } else {
      setLimitPerPage(newLimitPerPage);
      setCurrentPage(defaultPage);
    }
  };

  const getFilterComponent = () => {
    return (
      <Box
        sx={{
          m: 1,
          maxWidth: '100%',
          width: 240,
          display: 'flex',
          justifySelf: 'flex-start',
        }}
      >
        <TextField
          onChange={event => {
            setApproved(event.target.value as InvoiceStatusInput);
            setInvoiceCurrentPage(0);
          }}
          fullWidth
          size="small"
          label={'Filter by status'}
          name="filterByStatus"
          select
          InputLabelProps={{ shrink: true }}
          inputProps={{
            style: {
              minWidth: 110,
              padding: '4.5px 14px',
            },
          }}
          SelectProps={{
            native: true,
          }}
          variant="outlined"
        >
          {invoiceStatusOptions.map(
            (invoiceStatus: { value: string; label: string }) => {
              return (
                <option
                  selected={approved === invoiceStatus.value}
                  value={invoiceStatus.value}
                >
                  {invoiceStatus.label}
                </option>
              );
            },
          )}
        </TextField>
      </Box>
    );
  };

  function handleDirectionSorting(sortDirection) {
    setSortDirect(sortDirection);
    setCurrentPage(0);
  }

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
      }}
    >
      <Box sx={{ mt: 3 }}>
        <Tabs
          indicatorColor="primary"
          onChange={handleTabsChange}
          scrollButtons="auto"
          textColor="primary"
          value={currentTab}
          variant="scrollable"
        >
          {accountingInpuTabs.map(tab => (
            <Tab key={tab.value} label={tab.label} value={tab.value} />
          ))}
        </Tabs>
      </Box>
      <Box>
        <WidgetPreviewer
          element={
            currentTab === 'invoices' ? (
              <DynamicTable
                tableType="invoiceTable"
                headerFields={
                  role === ROLES.ACCOUNTING_INPUT
                    ? accInputInvoicesFields
                    : accAuthInvoicesFields
                }
                data={tableData}
                loading={loading}
                buttonData={invoiceButtonData}
                dateState={role !== 'ACCOUNTING_AUTHORIZER' ? dateState : ''}
                setDateState={setDateState}
                limitPerPage={invoiceLimitPerPage}
                totalItems={invoiceTotalItems}
                currentPage={invoiceCurrentPage}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                StatusFilterComponent={
                  role === ROLES.ACCOUNTING_AUTHORIZER && getFilterComponent()
                }
                handleDirectionSorting={handleDirectionSorting}
              />
            ) : (
              <DynamicTable
                tableType="acceptedInvoiceTable"
                headerFields={acceptedInvoicesFields}
                data={acceptedTableData}
                loading={loading}
                buttonData={payInvoiceButtonData}
                limitPerPage={limitPerPage}
                totalItems={totalItems}
                currentPage={currentPage}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
              />
            )
          }
          name="Invoice Table"
        />
      </Box>
      {modalWrapperData &&
        modalWrapperData.map((modalData, index) => {
          return <ModalWrapper key={index} {...modalData} />;
        })}
    </Box>
  );
};

export default InvoiceTable;
