import React from 'react';
import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import Label from 'src/view/materialUI/components/Label';
import PencilAltIcon from '../../../icons/PencilAlt';
import ArrowRightIcon from 'src/icons/ArrowRight';
import Download from 'src/icons/Download';
import { useDispatch, useSelector } from 'react-redux';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';

const getStatusLabel = invoiceStatus => {
  const map = {
    ASSIGNED: {
      color: 'warning',
      text: 'ASSIGNED',
    },
    ACCEPTED: {
      color: 'success',
      text: 'ACCEPTED',
    },
    SEND_SUBMIT: {
      color: 'primary',
      text: 'SEND_SUBMIT',
    },
    REQUEST_PAYMENT: {
      color: 'secondary',
      text: 'REQUEST_PAYMENT',
    },
    DELIVERED: {
      color: 'primary',
      text: 'DELIVERED',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const AcceptedInvoiceRow = ({ invoice, buttonData, page, rowsPerPage }) => {
  const dispatch = useDispatch();
  const currentTab = useSelector(invoiceSelector.currentTab);
  return (
    <TableRow key={invoice.eic} hover>
      {Object.keys(invoice).map(key => {
        if (key === 'id' || key === 'eic' || key === 'isManual') {
          return;
        }
        if (key === 'status' || key === 'approved') {
          return (
            <TableCell align="center" key={key}>
              {invoice[key] && getStatusLabel(invoice[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            key={key}
            align={
              key === 'invoiceNumber' ||
              key === 'receivedDate' ||
              key === 'dueDate' ||
              key === 'status' ||
              key === 'type' ||
              key === 'suplier' ||
              key === 'nipt'
                ? 'center'
                : key === 'amount'
                ? 'right'
                : 'left'
            }
          >
            {invoice[key] && invoice[key]}
          </TableCell>
        );
      })}

      <TableCell align="center">
        <IconButton
          onClick={() =>
            dispatch(invoiceActions.exportPdfFile({ eic: invoice.eic }))
          }
          disabled={invoice?.isManual}
        >
          <Download />
        </IconButton>
      </TableCell>
      <TableCell align="center">
        <Button onClick={() => buttonData[0].buttonFunction(invoice)}>
          Process
        </Button>
      </TableCell>
      {currentTab === 'invoices' && (
        <TableCell align="center">
          <Button onClick={() => buttonData[1].buttonFunction(invoice)}>
            Reject
          </Button>
        </TableCell>
      )}
    </TableRow>
  );
};

export default AcceptedInvoiceRow;
