import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import DashboardNavbar from './DashboardNavbar';
import DashboardSidebar from './DashboardSidebar';

const Welcome = ({ path }) => {
  const [isSidebarMobileOpen, setIsSidebarMobileOpen] =
    useState<boolean>(false);
  const navigate = useNavigate();

  useEffect(() => {
    navigate('/dashboard', { replace: true });
  }, []);

  return (
    <>
      {path === '/' && (
        <>
          <DashboardNavbar
            openMobile={isSidebarMobileOpen}
            onSidebarMobileOpen={setIsSidebarMobileOpen}
          />
          <DashboardSidebar
            onMobileClose={(): void => setIsSidebarMobileOpen(true)}
            openMobile={isSidebarMobileOpen}
          />
        </>
      )}
      <div
        style={{
          color: '#b3b3b3',
          paddingLeft: !isSidebarMobileOpen && path === '/' ? 280 : 0,
          paddingBottom: path !== '/' && '84px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          height: '100%',
          alignItems: 'center',
        }}
      >
        <p style={{ fontSize: '50px', fontWeight: 700, marginBottom: '0px' }}>
          Welcome
        </p>
        <p style={{ fontSize: '20px', fontWeight: 500, marginTop: '10px' }}>
          Select one of the menus on the dashboard!
        </p>
      </div>
    </>
  );
};

export default Welcome;
