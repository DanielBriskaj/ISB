import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import PencilAltIcon from 'src/icons/PencilAlt';
import Trash from 'src/icons/Trash';
import Label from 'src/view/materialUI/components/Label';
import { useSelector, useDispatch } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { glActions } from 'src/modules/GL/glActions';
import { menuConfigStatus } from 'src/enums/status';

const GlRow = ({
  gl,
  handleModalOpen,
  handleDelete,
  handleDialogOpen,
  page,
  rowsPerPage,
  approved,
}) => {
  const getStatusLabel = glStatus => {
    const map = {
      NEW: {
        color: 'primary',
        text: 'NEW',
      },
      APPROVED: {
        color: 'success',
        text: 'APPROVED',
      },
      IN_APPROVAL: {
        color: 'secondary',
        text: 'IN_APPROVAL',
      },
      DEFAULT: {
        color: 'primary',
        text: glStatus,
      },
    };

    const { text, color }: any = map[glStatus] || map.DEFAULT;

    return (
      <Label sx={{ p: '8px' }} color={color}>
        {text}
      </Label>
    );
  };

  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const dispatch = useDispatch();
  const assignGl = () => {
    if (role === 'ACCOUNTING_INPUT' && gl.approved === 'NEW') {
      const payload: any = {};
      payload.data = {
        glStatus: 'IN_APPROVAL',
      };
      payload.id = gl.id;
      payload.page = page;
      payload.rowsPerPage = rowsPerPage;
      payload.approved = approved;
      dispatch(glActions.updateStatus(payload, role, 'Assigned'));
    }

    if (role === 'ACCOUNTING_AUTHORIZER' && gl.approved === 'IN_APPROVAL') {
      const payload: any = {};
      payload.data = {
        glStatus: 'APPROVED',
      };
      payload.id = gl.id;
      payload.page = page;
      payload.rowsPerPage = rowsPerPage;
      payload.approved = approved;
      dispatch(glActions.updateStatus(payload, role, 'Assigned'));
    }
  };

  return (
    <TableRow hover key={gl.id}>
      {Object.keys(gl).map(key => {
        if (key === 'id') {
          return;
        }
        if (key === 'approved') {
          return (
            <TableCell key={key} align={'center'}>
              {gl[key] && getStatusLabel(gl[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            key={key}
            sx={
              key === 'glCode'
                ? { paddingLeft: 3 }
                : key === 'glAccrual'
                ? {
                    whiteSpace: 'nowrap',
                    maxWidth: '150px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }
                : { paddingLeft: 0 }
            }
            align={key === 'glCode' ? 'left' : 'center'}
          >
            {gl[key]}
          </TableCell>
        );
      })}
      <TableCell align="center">
        <IconButton onClick={() => handleModalOpen(gl.id)}>
          <PencilAltIcon fontSize="small" />
        </IconButton>
        {role === 'ACCOUNTING_INPUT' && (
          <IconButton
            onClick={() => {
              handleDialogOpen(gl.id);
            }}
          >
            <Trash fontSize="small" />
          </IconButton>
        )}
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => assignGl()}
          disabled={role !== menuConfigStatus[gl.approved]}
        >
          {role === 'ACCOUNTING_AUTHORIZER' ? 'Approve' : 'Send for Approval'}
        </Button>
      </TableCell>
    </TableRow>
  );
};

export default GlRow;
