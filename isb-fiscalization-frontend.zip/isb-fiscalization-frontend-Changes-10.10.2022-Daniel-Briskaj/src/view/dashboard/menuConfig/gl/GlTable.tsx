import { useState, useEffect, useCallback, useRef } from 'react';
import type { FC } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import {
  Box,
  Breadcrumbs,
  Container,
  Grid,
  Link,
  Typography,
} from '@material-ui/core';
import { debounce } from 'lodash';
import ChevronRightIcon from '../../../../icons/ChevronRight';
import Plus from '../../../../icons/Plus';
import useSettings from '../../../materialUI/hooks/useSettings';
import { useSelector, useDispatch } from 'react-redux';
import glSelector from 'src/modules/GL/glSelector';
import { glActions } from 'src/modules/GL/glActions';
import DynamicTable from 'src/view/materialUI/components/widgets/tables/DynamicTable';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import { glFields } from 'src/enums/shared/headerFields/glFields';
import GlFormPopup from './GlFormPopup';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';

const GlTable: FC = () => {
  const { settings } = useSettings();
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [glId, setGlId] = useState(null);
  const [glCode, setGlCode] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [approved, setApproved] = useState<
    '' | 'NEW' | 'IN_APPROVAL' | 'ACTIVE' | 'APPROVED'
  >('');
  const [searchFunctionArray, setSearchFunctionArray] = useState([]);
  const dispatch = useDispatch();

  const glData = useSelector(glSelector.glData);
  const glsState = useSelector(glSelector.glsDataArray);
  const loading = useSelector(glSelector.loading);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const initialRenderRef = useRef(false);

  useEffect(() => {
    if (initialRenderRef.current) {
      dispatch(
        glActions.readGl({
          size: limitPerPage,
          page: currentPage,
          glCode,
          approved,
        }),
      );
    } else {
      initialRenderRef.current = true;
    }
  }, [limitPerPage, currentPage]);

  useEffect(() => {
    setCurrentPage(0);
    dispatch(
      glActions.readGl({
        size: limitPerPage,
        page: 0,
        glCode,
        approved,
      }),
    );
  }, [approved, glCode]);

  useEffect(() => {
    if (
      glsState.length === 0 &&
      Object.keys(glsState).length === 0 &&
      Object.getPrototypeOf(glsState) === Object.prototype
    ) {
    } else {
      if (glsState.gl) {
        setTableData(
          glsState.gl.map(gl => ({
            id: gl?.id,
            glCode: gl?.glCode,
            description: gl?.description,
            glAccrual: gl?.glAccrual,
            approved: gl.approved,
          })),
        );
        setTotalItems(glsState.totalItems);
      }
    }
  }, [glsState]);

  const searchOnChange = event => {
    setGlCode(event.target.value);
    setCurrentPage(0);
  };
  const handleSearch = useCallback(debounce(searchOnChange, 700), []);

  useEffect(() => {
    setSearchFunctionArray([
      {
        placeholder: 'Search by GL Code',
        function: handleSearch,
        customClass: 'search-input',
      },
    ]);
  }, [handleSearch]);

  function handleModalOpen(id?) {
    if (id) {
      setGlId(id);
    }
    setModalOpen(!modalOpen);
  }

  function handleDialogOpen(id?) {
    if (id) {
      setGlId(id);
    }
    setDialogOpen(true);
  }

  const handleDelete = id => {
    dispatch(
      glActions.deleteGl({
        id,
        page: currentPage,
        rowsPerPage: limitPerPage,
        approved,
      }),
    );
  };

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const glButtonData = [
    {
      label: 'Add GL',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: {},
      onClick: handleModalOpen,
    },
  ];

  const modalWrapperData = [
    {
      children: (
        <GlFormPopup
          setModalOpen={setModalOpen}
          glId={glId}
          setDialogOpen={setDialogOpen}
          page={currentPage}
          rowsPerPage={limitPerPage}
          approved={approved}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          handleDelete={() => handleDelete(glId)}
          message={`Are you sure you want to continue?`}
          hasFeedback={false}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  return (
    <>
      {/* <Helmet>
        <title>Dashboard: Customer List | Material Kit Pro</title>
      </Helmet> */}
      <Box
        sx={{
          backgroundColor: 'white',
          minHeight: '100%',
          py: 8,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5">
                GL
              </Typography>
              <Breadcrumbs
                aria-label="breadcrumb"
                separator={<ChevronRightIcon fontSize="small" />}
                sx={{ mt: 1 }}
              >
                <Typography color="textPrimary" variant="subtitle2">
                  Dashboard
                </Typography>
                <Typography color="textPrimary" variant="subtitle2">
                  Menu Config
                </Typography>
                <Typography color="textSecondary" variant="subtitle2">
                  GL
                </Typography>
              </Breadcrumbs>
            </Grid>
            <Grid item>
              <Box sx={{ m: -1 }}></Box>
            </Grid>
          </Grid>
          <Box sx={{ mt: 3 }}>
            <WidgetPreviewer
              element={
                <DynamicTable
                  tableType="glTable"
                  headerFields={glFields}
                  handleModalOpen={handleModalOpen}
                  data={tableData}
                  loading={loading}
                  handleDelete={handleDelete}
                  handleDialogOpen={handleDialogOpen}
                  onPageChange={onPageChange}
                  onChangeRowsPerPage={onChangeRowsPerPage}
                  searchArrayOfFunctions={searchFunctionArray}
                  totalItems={totalItems}
                  currentPage={currentPage}
                  limitPerPage={limitPerPage}
                  approved={approved}
                  buttonData={
                    role === 'ACCOUNTING_AUTHORIZER'
                      ? glButtonData.filter(item => item.label !== 'Add GL')
                      : glButtonData
                  }
                  setApproved={setApproved}
                />
              }
              name="GL Table"
            />
          </Box>
          {modalWrapperData &&
            modalWrapperData.map(modalData => {
              return <ModalWrapper {...modalData} />;
            })}
        </Container>
      </Box>
    </>
  );
};

export default GlTable;
