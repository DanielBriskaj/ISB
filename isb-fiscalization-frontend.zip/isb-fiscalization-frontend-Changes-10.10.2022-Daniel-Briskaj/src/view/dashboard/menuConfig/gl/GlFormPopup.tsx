import { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  Divider,
  Switch,
} from '@material-ui/core';
import useSettings from '../../../materialUI/hooks/useSettings';
import { useForm, FormProvider } from 'react-hook-form';
import GlForm from 'src/view/materialUI/components/widgets/forms/glForm';
import Close from 'src/icons/X';
import { yupResolver } from '@hookform/resolvers/yup';
import { glSchema } from 'src/modules/shared/yup/glSchema';
import { GLDATA } from 'src/models/data/gl/GlData';
import { glActions } from 'src/modules/GL/glActions';
import { useDispatch, useSelector, batch } from 'react-redux';
import glSelector from 'src/modules/GL/glSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import { CircularProgress } from '@material-ui/core';
import statusActions from 'src/modules/shared/statuses/statusesActions';
import authSelector from 'src/modules/shared/authentication/authSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';

const GlFormPopup = props => {
  const { setModalOpen, glId, page, rowsPerPage, approved } = props;
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const glData = useSelector(glSelector.glData);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const [dialogOpen, setDialogOpen] = useState(false);

  const initialValues: GLDATA = {
    glCode: '',
    description: '',
    glAccrual: '',
    approved: 'NEW',
  };

  const form = useForm({
    resolver: yupResolver(glSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    if (typeof glId === 'number') {
      dispatch(
        glActions.updateGl(
          { data, page, rowsPerPage, approved, rawGLData: glData },
          glId,
        ),
      );
      setModalOpen(false);
    } else {
      dispatch(glActions.createGl({ data, page, rowsPerPage, approved }));
      setModalOpen(false);
    }
  };

  useEffect(() => {
    if (typeof glId === 'number') {
      dispatch(glActions.getById(glId));
    }
  }, [dispatch, glId]);

  useEffect(() => {
    if (
      (glData &&
        Object.keys(glData).length === 0 &&
        Object.getPrototypeOf(glData) === Object.prototype) ||
      typeof glId !== 'number'
    ) {
      form.reset();
    } else {
      glData &&
        Object.keys(glData).forEach(key => {
          form.setValue(key as keyof GLDATA, glData[key]);
        });
    }
  }, [glData]);

  useEffect(() => {
    return () => {
      dispatch(glActions.clearGLData());
    };
  }, []);

  const assignGl = () => {
    if (role === 'ACCOUNTING_AUTHORIZER' && glData.approved === 'IN_APPROVAL') {
      const payload: any = {};
      payload.data = {
        glStatus: 'APPROVED',
      };
      payload.id = glData.id;
      payload.page = page;
      payload.rowsPerPage = rowsPerPage;
      payload.approved = approved;
      dispatch(glActions.updateStatus(payload, role, 'Assigned'));
    }
    setModalOpen(false);
  };

  const rejectGl = (data?) => {
    const payload: any = {};
    payload.data = {
      glStatus: 'NEW',
      authorizerFeedback: data?.reason,
    };

    payload.id = glId;
    payload.page = page;
    payload.rowsPerPage = rowsPerPage;
    payload.approved = approved;
    dispatch(glActions.updateStatus(payload, role, 'Rejected'));
    setModalOpen(false);
    setDialogOpen(false);
  };

  const accInputFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'submit',
      onClick: () => {},
      label: 'Save',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setModalOpen(false),
      label: 'Cancel',
    },
  ];

  const accAuthFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'button',
      onClick: assignGl,
      label: 'Approve',
      disabled: glData.approved !== 'IN_APPROVAL',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setDialogOpen(true),
      label: 'Reject',
      disabled: glData.approved !== 'IN_APPROVAL',
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                GL
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <GlForm />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role === 'ACCOUNTING_AUTHORIZER' && (
                  <>
                    {accAuthFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                          disabled={button.disabled}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {role === 'ACCOUNTING_INPUT' && (
                  <>
                    {accInputFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {/* <Button
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  type="submit"
                >
                  Save
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button> */}
              </Box>
            </form>
          </FormProvider>
        </Container>
        <ModalWrapper
          children={
            <AlertDialog
              setDialogOpen={setDialogOpen}
              handleDelete={data => {
                rejectGl(data);
              }}
              message={`Why do you want to reject this GL ?`}
              hasFeedback={true}
            />
          }
          modalOpen={dialogOpen}
          setModalOpen={setDialogOpen}
          type="deleteModal"
        />
      </Box>
    </>
  );
};

export default GlFormPopup;
