import { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  Divider,
  Switch,
} from '@material-ui/core';
import useSettings from '../../../materialUI/hooks/useSettings';
import { useForm, FormProvider } from 'react-hook-form';
import CostOwnersForm from 'src/view/materialUI/components/widgets/forms/CostOwnersForm';
import Close from 'src/icons/X';
import { yupResolver } from '@hookform/resolvers/yup';
import { costOwnerSchema } from 'src/modules/shared/yup/costOwnersSchema';
import { CostOwnerData } from 'src/models/data/costOwners/CostOwnerData';
import costOwnerActions from 'src/modules/costowners/costOwnerActions';
import { useDispatch, useSelector } from 'react-redux';
import costOwnerSelector from 'src/modules/costowners/costOwnerSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';

const CostOwnerFormPopup = props => {
  const { setModalOpen, costOwnerId, approved } = props;
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const costOwnerData = useSelector(costOwnerSelector.costOwnerData);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const [dialogOpen, setDialogOpen] = useState(false);

  const initialValues: CostOwnerData = {
    code: '',
    division: '',
    ownerName: '',
    isAuthorizer: false,
    approved: 'NEW',
  };

  const form = useForm({
    resolver: yupResolver(costOwnerSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    if (typeof costOwnerId === 'number') {
      dispatch(
        costOwnerActions.update({
          data,
          id: costOwnerId,
          page: props.page,
          rowsPerPage: props.rowsPerPage,
          approved,
          rawCostOwnerData: costOwnerData,
        }),
      );
      setModalOpen(false);
    } else {
      dispatch(
        costOwnerActions.create({
          data,
          page: props.page,
          rowsPerPage: props.rowsPerPage,
          approved,
        }),
      );
      setModalOpen(false);
    }
  };

  useEffect(() => {
    if (typeof costOwnerId === 'number') {
      dispatch(costOwnerActions.getById(costOwnerId));
    }
  }, [dispatch, costOwnerId]);

  useEffect(() => {
    if (
      (costOwnerData &&
        Object.keys(costOwnerData).length === 0 &&
        Object.getPrototypeOf(costOwnerData) === Object.prototype) ||
      typeof costOwnerId !== 'number'
    ) {
      form.reset();
    } else {
      Object.keys(costOwnerData).forEach(key => {
        form.setValue(key as keyof CostOwnerData, costOwnerData[key]);
      });
    }
  }, [costOwnerData]);

  const assignCostOwner = () => {
    if (
      role === 'ACCOUNTING_AUTHORIZER' &&
      costOwnerData.approved === 'IN_APPROVAL'
    ) {
      const payload: any = {};
      payload.data = {
        costOwnerStatus: 'APPROVED',
      };

      payload.id = costOwnerId;
      payload.page = props.page;
      payload.rowsPerPage = props.rowsPerPage;
      payload.approved = approved;

      dispatch(costOwnerActions.updateStatus(payload, role, 'Assigned'));
      setModalOpen(false);
    }
  };

  const rejectCostOwner = (data?) => {
    const payload: any = {};
    payload.data = {
      costOwnerStatus: 'NEW',
      authorizerFeedback: data?.reason,
    };

    payload.id = costOwnerId;
    payload.page = props.page;
    payload.rowsPerPage = props.rowsPerPage;
    payload.approved = approved;
    dispatch(costOwnerActions.updateStatus(payload, role, 'Rejected'));
    setModalOpen(false);
    setDialogOpen(false);
  };

  const accInputFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'submit',
      onClick: () => {},
      label: 'Save',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setModalOpen(false),
      label: 'Cancel',
    },
  ];

  const accAuthFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'button',
      onClick: assignCostOwner,
      label: 'Approve',
      disabled: costOwnerData.approved !== 'IN_APPROVAL',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setDialogOpen(true),
      label: 'Reject',
      disabled: costOwnerData.approved !== 'IN_APPROVAL',
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Cost Owner
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <CostOwnersForm />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role === 'ACCOUNTING_AUTHORIZER' && (
                  <>
                    {accAuthFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                          disabled={button.disabled}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {role === 'ACCOUNTING_INPUT' && (
                  <>
                    {accInputFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {/* <Button
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  type="submit"
                >
                  Save
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button> */}
              </Box>
            </form>
          </FormProvider>
        </Container>
        <ModalWrapper
          children={
            <AlertDialog
              setDialogOpen={setDialogOpen}
              handleDelete={data => {
                rejectCostOwner(data);
              }}
              message={`Why do you want to reject this Cost Owner ?`}
              hasFeedback={true}
            />
          }
          modalOpen={dialogOpen}
          setModalOpen={setDialogOpen}
          type="deleteModal"
        />
      </Box>
    </>
  );
};

export default CostOwnerFormPopup;
