import { useState, useEffect, useRef } from 'react';
import type { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import {
  Box,
  Breadcrumbs,
  Container,
  Grid,
  Typography,
} from '@material-ui/core';
import ChevronRightIcon from '../../../../icons/ChevronRight';
import Plus from '../../../../icons/Plus';
import useSettings from '../../../materialUI/hooks/useSettings';
import { useSelector, useDispatch } from 'react-redux';
import costOwnerSelector from 'src/modules/costowners/costOwnerSelector';
import costOwnerActions from 'src/modules/costowners/costOwnerActions';
import DynamicTable from 'src/view/materialUI/components/widgets/tables/DynamicTable';
import { costOwnersFields } from 'src/enums/shared/headerFields/costOwnersFields';
import CostOwnerForm from './CostOwnerFormPopup';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import { divisions } from 'src/enums/divisions';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import authSelector from 'src/modules/shared/authentication/authSelector';

const CostOwnerTable: FC = () => {
  const { settings } = useSettings();
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [costOwnerId, setCostOwnerId] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [division, setDivision] = useState('');
  const [approved, setApproved] = useState<
    '' | 'NEW' | 'IN_APPROVAL' | 'ACTIVE' | 'APPROVED'
  >('');
  const dispatch = useDispatch();

  const costOwnersState = useSelector(costOwnerSelector.costOwnersDataArray);
  const costOwnerData = useSelector(costOwnerSelector.costOwnerData);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const initialRenderRef = useRef(false);

  useEffect(() => {
    if (initialRenderRef.current) {
      dispatch(
        costOwnerActions.read({
          size: limitPerPage,
          page: currentPage,
          division: division,
          approved,
        }),
      );
    } else {
      initialRenderRef.current = true;
    }
  }, [currentPage, limitPerPage]);

  useEffect(() => {
    setCurrentPage(0);
    dispatch(
      costOwnerActions.read({
        size: limitPerPage,
        page: 0,
        division: division,
        approved,
      }),
    );
  }, [division, approved]);

  useEffect(() => {
    if (
      costOwnersState.length === 0 &&
      Object.keys(costOwnersState).length === 0 &&
      Object.getPrototypeOf(costOwnersState) === Object.prototype
    ) {
    } else {
      if (costOwnersState.costOwners) {
        setTableData(
          costOwnersState.costOwners.map(costOwner => ({
            ownerName: costOwner.ownerName,
            code: costOwner.code,
            isAuthorizer: costOwner.isAuthorizer,
            division: costOwner.division,
            approved: costOwner.approved,
            id: costOwner.id,
          })),
        );
        setTotalItems(costOwnersState.totalItems);
      }
    }
  }, [costOwnersState]);

  function handleModalOpen(id?) {
    if (id) {
      setCostOwnerId(id);
    }
    setModalOpen(!modalOpen);
  }

  function handleDialogOpen(id?) {
    if (id) {
      setCostOwnerId(id);
    }
    setDialogOpen(true);
  }

  const handleDelete = id => {
    dispatch(
      costOwnerActions.delete({
        id,
        page: currentPage,
        rowsPerPage: limitPerPage,
        approved,
      }),
    );
  };

  const handleSorting = (sortBy: any) => {
    setDivision(sortBy);
    setCurrentPage(0);
  };

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const costOwnerButtonData = [
    {
      label: 'Add Cost Owner',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: {},
      onClick: handleModalOpen,
    },
  ];

  const costOwnerSortingData = [
    {
      label: 'Filter by division',
      sortOptions: divisions,
      handleSorting: handleSorting,
      defaultValue: ' ',
    },
  ];

  const modalWrapperData = [
    {
      children: (
        <CostOwnerForm
          setModalOpen={setModalOpen}
          costOwnerId={costOwnerId}
          setDialogOpen={setDialogOpen}
          page={currentPage}
          rowsPerPage={limitPerPage}
          approved={approved}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          handleDelete={() => handleDelete(costOwnerId)}
          message={`Are you sure you want to continue?`}
          hasFeedback={false}
          // id={costOwnerId}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  return (
    <>
      {/* <Helmet>
        <title>Dashboard: Customer List | Material Kit Pro</title>
      </Helmet> */}
      <Box
        sx={{
          backgroundColor: 'white',
          minHeight: '100%',
          py: 8,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5">
                Cost Owners
              </Typography>
              <Breadcrumbs
                aria-label="breadcrumb"
                separator={<ChevronRightIcon fontSize="small" />}
                sx={{ mt: 1 }}
              >
                <Typography color="textPrimary" variant="subtitle2">
                  Dashboard
                </Typography>
                <Typography color="textPrimary" variant="subtitle2">
                  Menu Config
                </Typography>
                <Typography color="textSecondary" variant="subtitle2">
                  Cost Owners
                </Typography>
              </Breadcrumbs>
            </Grid>
            <Grid item>
              <Box sx={{ m: -1 }}></Box>
            </Grid>
          </Grid>
          <Box sx={{ mt: 3 }}>
            <WidgetPreviewer
              element={
                <DynamicTable
                  tableType="costOwnerTable"
                  headerFields={costOwnersFields}
                  handleModalOpen={handleModalOpen}
                  data={tableData}
                  loading={loading}
                  handleDelete={handleDelete}
                  handleDialogOpen={handleDialogOpen}
                  sortData={costOwnerSortingData}
                  onPageChange={onPageChange}
                  onChangeRowsPerPage={onChangeRowsPerPage}
                  totalItems={totalItems}
                  currentPage={currentPage}
                  limitPerPage={limitPerPage}
                  buttonData={
                    role === 'ACCOUNTING_AUTHORIZER'
                      ? costOwnerButtonData.filter(
                          item => item.label !== 'Add Cost Owner',
                        )
                      : costOwnerButtonData
                  }
                  setApproved={setApproved}
                  approved={approved}
                />
              }
              name="Cost Owners Table"
            />
          </Box>
        </Container>
        {modalWrapperData &&
          modalWrapperData.map(modalData => {
            return <ModalWrapper {...modalData} />;
          })}
      </Box>
    </>
  );
};

export default CostOwnerTable;
