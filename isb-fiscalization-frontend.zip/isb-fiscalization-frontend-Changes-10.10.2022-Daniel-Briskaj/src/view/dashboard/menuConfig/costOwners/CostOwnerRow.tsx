import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import PencilAltIcon from 'src/icons/PencilAlt';
import Trash from 'src/icons/Trash';
import { Switch } from '@material-ui/core';
import Label from 'src/view/materialUI/components/Label';
import { menuConfigStatus } from 'src/enums/status';
import { useSelector, useDispatch } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import costOwnerActions from 'src/modules/costowners/costOwnerActions';

const getStatusLabel = invoiceStatus => {
  const map = {
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const CostOwnerRow = ({
  costOwner,
  handleModalOpen,
  handleDelete,
  handleDialogOpen,
  page,
  rowsPerPage,
  approved,
}) => {
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const dispatch = useDispatch();

  const assignCostOwner = () => {
    if (role === 'ACCOUNTING_INPUT' && costOwner.approved === 'NEW') {
      const payload: any = {};
      payload.data = {
        costOwnerStatus: 'IN_APPROVAL',
      };
      payload.id = costOwner.id;
      payload.page = page;
      payload.rowsPerPage = rowsPerPage;
      payload.approved = approved;
      dispatch(costOwnerActions.updateStatus(payload, role, 'Assigned'));
    }

    if (
      role === 'ACCOUNTING_AUTHORIZER' &&
      costOwner.approved === 'IN_APPROVAL'
    ) {
      const payload: any = {};
      payload.data = {
        costOwnerStatus: 'APPROVED',
      };
      payload.id = costOwner.id;
      payload.page = page;
      payload.rowsPerPage = rowsPerPage;
      payload.approved = approved;
      dispatch(costOwnerActions.updateStatus(payload, role, 'Assigned'));
    }
  };
  return (
    <TableRow hover key={costOwner.id}>
      {Object.keys(costOwner).map(key => {
        if (key === 'id') {
          return;
        }
        if (key === 'approved') {
          return (
            <TableCell align="center" key={key}>
              {costOwner[key] && getStatusLabel(costOwner[key])}
            </TableCell>
          );
        }
        if (key === 'isAuthorizer') {
          return (
            <TableCell key={key} align={'center'}>
              <Switch checked={costOwner[key] && costOwner[key]} disabled />
            </TableCell>
          );
        }
        return (
          <TableCell
            key={key}
            sx={key === 'ownerName' ? { paddingLeft: 3 } : { paddingLeft: 0 }}
            align={key === 'division' || key === 'code' ? 'center' : 'left'}
          >
            {costOwner[key] && costOwner[key]}
          </TableCell>
        );
      })}
      <TableCell align="center">
        <IconButton onClick={() => handleModalOpen(costOwner.id)}>
          <PencilAltIcon fontSize="small" />
        </IconButton>
        {role === 'ACCOUNTING_INPUT' && (
          <IconButton onClick={() => handleDialogOpen(costOwner.id)}>
            <Trash fontSize="small" />
          </IconButton>
        )}
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => assignCostOwner()}
          disabled={role !== menuConfigStatus[costOwner.approved]}
        >
          {role === 'ACCOUNTING_AUTHORIZER' ? 'Approve' : 'Send for Approval'}
        </Button>
      </TableCell>
    </TableRow>
  );
};

export default CostOwnerRow;
