import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import PencilAltIcon from 'src/icons/PencilAlt';
import Trash from 'src/icons/Trash';
import Label from 'src/view/materialUI/components/Label';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { useDispatch, useSelector } from 'react-redux';
import { menuConfigStatus } from 'src/enums/status';
import branchActions from 'src/modules/branches/branchActions';

const getStatusLabel = invoiceStatus => {
  const map = {
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const BranchRow = ({
  branch,
  handleModalOpen,
  handleDelete,
  handleDialogOpen,
  page,
  rowsPerPage,
  approved,
}) => {
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const dispatch = useDispatch();
  const assignBranch = () => {
    if (role === 'ACCOUNTING_INPUT' && branch.approved === 'NEW') {
      const payload: any = {};
      payload.data = {
        branchStatus: 'IN_APPROVAL',
      };
      payload.id = branch.id;
      payload.page = page;
      payload.rowsPerPage = rowsPerPage;
      payload.approved = approved;

      dispatch(branchActions.updateStatus(payload, role, 'Assigned'));
    }

    if (role === 'ACCOUNTING_AUTHORIZER' && branch.approved === 'IN_APPROVAL') {
      const payload: any = {};
      payload.data = {
        branchStatus: 'APPROVED',
      };
      payload.id = branch.id;
      payload.page = page;
      payload.rowsPerPage = rowsPerPage;
      payload.approved = approved;

      dispatch(branchActions.updateStatus(payload, role, 'Assigned'));
    }
  };
  return (
    <TableRow hover key={branch.id}>
      {Object.keys(branch).map(key => {
        if (key === 'id') {
          return;
        }
        if (key === 'approved') {
          return (
            <TableCell align="center" key={key}>
              {branch[key] && getStatusLabel(branch[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            key={key}
            sx={key === 'branchCode' ? { paddingLeft: 3 } : { paddingLeft: 0 }}
            align={
              key === 'cityCode' || key === 'description' ? 'center' : 'left'
            }
          >
            {branch[key] && branch[key]}
          </TableCell>
        );
      })}
      <TableCell align="center">
        <IconButton onClick={() => handleModalOpen(branch.id)}>
          <PencilAltIcon fontSize="small" />
        </IconButton>
        {role === 'ACCOUNTING_INPUT' && (
          <IconButton onClick={() => handleDialogOpen(branch.id)}>
            <Trash fontSize="small" />
          </IconButton>
        )}
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => assignBranch()}
          disabled={role !== menuConfigStatus[branch.approved]}
        >
          {role === 'ACCOUNTING_AUTHORIZER' ? 'Approve' : 'Send for Approval'}
        </Button>
      </TableCell>
    </TableRow>
  );
};

export default BranchRow;
