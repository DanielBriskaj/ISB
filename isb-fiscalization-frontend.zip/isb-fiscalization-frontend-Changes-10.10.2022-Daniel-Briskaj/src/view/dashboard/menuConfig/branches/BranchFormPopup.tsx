import { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Divider,
  Grid,
  Button,
  Typography,
} from '@material-ui/core';
import BranchesForm from 'src/view/materialUI/components/widgets/forms/BranchesForm';
import Close from 'src/icons/X';
import { useForm, FormProvider } from 'react-hook-form';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import { BranchData } from 'src/models/data/branches/BranchesData';
import { yupResolver } from '@hookform/resolvers/yup';
import { branchesSchema } from 'src/modules/shared/yup/branchesSchema';
import { useSelector, useDispatch } from 'react-redux';
import branchSelector from 'src/modules/branches/branchSelector';
import branchActions from 'src/modules/branches/branchActions';
import { useNavigate } from 'react-router';
import authSelector from 'src/modules/shared/authentication/authSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';

const BranchForm = props => {
  const { setModalOpen, branchId, approved } = props;
  const { settings } = useSettings();
  const branchData = useSelector(branchSelector.branchData);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const [dialogOpen, setDialogOpen] = useState(false);

  const initialValues: BranchData = {
    branchCode: 0,
    cityCode: '',
    description: '',
    approved: 'NEW',
  };

  const form = useForm({
    resolver: yupResolver(branchesSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  useEffect(() => {
    if (typeof branchId === 'number') {
      dispatch(branchActions.getById(branchId));
    }
  }, [dispatch, branchId]);

  useEffect(() => {
    if (
      (branchData &&
        Object.keys(branchData).length === 0 &&
        Object.getPrototypeOf(branchData) === Object.prototype) ||
      typeof branchId !== 'number'
    ) {
      form.reset();
    } else {
      Object.keys(branchData).forEach(key => {
        form.setValue(key as keyof BranchData, branchData[key]);
      });
    }
  }, [branchData]);

  const onSubmit = data => {
    if (typeof branchId === 'number') {
      dispatch(
        branchActions.update({
          id: branchId,
          data,
          page: props.page,
          rowsPerPage: props.rowsPerPage,
          approved,
          rawBranchData: branchData,
        }),
      );
      setModalOpen(false);
    } else {
      dispatch(
        branchActions.create({
          data,
          page: props.page,
          rowsPerPage: props.rowsPerPage,
          approved,
        }),
      );
      setModalOpen(false);
    }
  };

  const assignBranch = () => {
    if (
      role === 'ACCOUNTING_AUTHORIZER' &&
      branchData.approved === 'IN_APPROVAL'
    ) {
      const payload: any = {};
      payload.data = {
        branchStatus: 'APPROVED',
      };

      payload.id = branchId;
      payload.page = props.page;
      payload.rowsPerPage = props.rowsPerPage;
      payload.approved = approved;

      dispatch(branchActions.updateStatus(payload, role, 'Assigned'));
      setModalOpen(false);
    }
  };

  const rejectBranch = (data?) => {
    const payload: any = {};
    payload.data = {
      branchStatus: 'NEW',
      authorizerFeedback: data?.reason,
    };

    payload.id = branchId;
    payload.page = props.page;
    payload.rowsPerPage = props.rowsPerPage;
    payload.approved = approved;

    dispatch(branchActions.updateStatus(payload, role, 'Rejected'));

    setModalOpen(false);
    setDialogOpen(false);
  };

  const accAuthFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'button',
      onClick: assignBranch,
      label: 'Approve',
      disabled: branchData.approved !== 'IN_APPROVAL',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setDialogOpen(true),
      label: 'Reject',
      disabled: branchData.approved !== 'IN_APPROVAL',
    },
  ];

  const accInputFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'submit',
      // onClick: () => {},
      label: 'Save',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setModalOpen(false),
      label: 'Cancel',
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Branch
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <BranchesForm />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role === 'ACCOUNTING_AUTHORIZER' && (
                  <>
                    {accAuthFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                          disabled={button.disabled}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {role === 'ACCOUNTING_INPUT' && (
                  <>
                    {accInputFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
              </Box>
            </form>
          </FormProvider>
        </Container>
        <ModalWrapper
          children={
            <AlertDialog
              setDialogOpen={setDialogOpen}
              handleDelete={data => {
                rejectBranch(data);
              }}
              message={`Why do you want to reject this Branch ?`}
              hasFeedback={true}
            />
          }
          modalOpen={dialogOpen}
          setModalOpen={setDialogOpen}
          type="deleteModal"
        />
      </Box>
    </>
  );
};

export default BranchForm;
