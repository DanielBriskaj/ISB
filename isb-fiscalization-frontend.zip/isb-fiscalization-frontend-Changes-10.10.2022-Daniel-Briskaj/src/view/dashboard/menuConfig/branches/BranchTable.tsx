import { useState, useEffect, useRef } from 'react';
import type { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import {
  Box,
  Breadcrumbs,
  Container,
  Grid,
  Typography,
} from '@material-ui/core';
import ChevronRightIcon from '../../../../icons/ChevronRight';
import Plus from '../../../../icons/Plus';
import useSettings from '../../../materialUI/hooks/useSettings';
import { useSelector, useDispatch } from 'react-redux';
import branchSelector from 'src/modules/branches/branchSelector';
import branchActions from 'src/modules/branches/branchActions';
import DynamicTable from 'src/view/materialUI/components/widgets/tables/DynamicTable';
import { branchesFields } from 'src/enums/shared/headerFields/branchesFields';
import BranchForm from './BranchFormPopup';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import authSelector from 'src/modules/shared/authentication/authSelector';

const BranchTable: FC = () => {
  const { settings } = useSettings();
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [branchId, setBranchId] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const dispatch = useDispatch();

  const branchesState = useSelector(branchSelector.branchesDataArray);
  const branchData = useSelector(branchSelector.branchData);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const [approved, setApproved] = useState<
    '' | 'NEW' | 'IN_APPROVAL' | 'ACTIVE' | 'APPROVED'
  >('');
  const role = authData.role;
  const initialRenderRef = useRef(false);

  useEffect(() => {
    if (branchesState.length === 0) {
    } else {
      if (branchesState.branches) {
        setTableData(
          branchesState.branches.map(branch => ({
            branchCode: branch.branchCode,
            description: branch.description,
            cityCode: branch.cityCode,
            approved: branch.approved,
            id: branch.id,
          })),
        );
        setTotalItems(branchesState.totalItems);
      }
    }
  }, [branchesState]);

  useEffect(() => {
    if (initialRenderRef.current) {
      dispatch(
        branchActions.read({ size: limitPerPage, page: currentPage, approved }),
      );
    } else {
      initialRenderRef.current = true;
    }
  }, [limitPerPage, currentPage]);

  useEffect(() => {
    setCurrentPage(0);
    dispatch(branchActions.read({ size: limitPerPage, page: 0, approved }));
  }, [approved]);

  useEffect(() => {
    return () => {
      dispatch(branchActions.clearBranchData());
    };
  }, []);

  function handleModalOpen(id?) {
    if (id) {
      setBranchId(id);
    }
    setModalOpen(true);
  }

  const handleDelete = id => {
    dispatch(
      branchActions.delete({
        id,
        page: currentPage,
        rowsPerPage: limitPerPage,
        approved,
      }),
    );
  };

  function handleDialogOpen(id?) {
    if (id) {
      setBranchId(id);
    }
    setDialogOpen(true);
  }

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const branchButtonData = [
    {
      label: 'Add Branch',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: {},
      onClick: handleModalOpen,
    },
  ];

  const modalWrapperData = [
    {
      children: (
        <BranchForm
          setModalOpen={setModalOpen}
          branchId={branchId}
          page={currentPage}
          rowsPerPage={limitPerPage}
          approved={approved}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setDialogOpen={setDialogOpen}
          setModalOpen={setModalOpen}
          handleDelete={() => handleDelete(branchId)}
          message={`Are you sure you want to continue?`}
          hasFeedback={false}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  return (
    <>
      {/* <Helmet>
        <title>Dashboard: Customer List | Material Kit Pro</title>
      </Helmet> */}
      <Box
        sx={{
          backgroundColor: 'white',
          minHeight: '100%',
          py: 8,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5">
                Branches
              </Typography>
              <Breadcrumbs
                aria-label="breadcrumb"
                separator={<ChevronRightIcon fontSize="small" />}
                sx={{ mt: 1 }}
              >
                <Typography color="textPrimary" variant="subtitle2">
                  Dashboard
                </Typography>
                <Typography color="textPrimary" variant="subtitle2">
                  Menu Config
                </Typography>
                <Typography color="textSecondary" variant="subtitle2">
                  Branches
                </Typography>
              </Breadcrumbs>
            </Grid>
            <Grid item>
              <Box sx={{ m: -1 }}></Box>
            </Grid>
          </Grid>
          <Box sx={{ mt: 3 }}>
            <WidgetPreviewer
              element={
                <DynamicTable
                  tableType="branchTable"
                  headerFields={branchesFields}
                  handleModalOpen={handleModalOpen}
                  handleDialogOpen={handleDialogOpen}
                  data={tableData}
                  loading={loading}
                  handleDelete={handleDelete}
                  onPageChange={onPageChange}
                  onChangeRowsPerPage={onChangeRowsPerPage}
                  totalItems={totalItems}
                  currentPage={currentPage}
                  limitPerPage={limitPerPage}
                  buttonData={
                    role === 'ACCOUNTING_AUTHORIZER'
                      ? branchButtonData.filter(
                          item => item.label !== 'Add Branch',
                        )
                      : branchButtonData
                  }
                  setApproved={setApproved}
                  approved={approved}
                />
              }
              name="Branches Table"
            />
          </Box>
          {modalWrapperData &&
            modalWrapperData.map(modalData => {
              return <ModalWrapper {...modalData} />;
            })}
        </Container>
      </Box>
    </>
  );
};

export default BranchTable;
