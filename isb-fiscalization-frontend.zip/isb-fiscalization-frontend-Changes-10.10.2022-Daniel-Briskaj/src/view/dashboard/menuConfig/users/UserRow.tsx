import React from 'react';
import { IconButton, TableCell, TableRow } from '@material-ui/core';
import PencilAltIcon from 'src/icons/PencilAlt';
import Label from 'src/view/materialUI/components/Label';

const getUserStatusLabel = ItemStatus => {
  const map = {
    true: {
      color: 'success',
      text: 'ACTIVE',
    },
    inactive: {
      color: 'error',
      text: 'INACTIVE',
    },
    DEFAULT: {
      color: 'primary',
      text: ItemStatus,
    },
  };

  const { text, color }: any = map[ItemStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const UserRow = ({ user, page, rowsPerPage, handleModalOpen }) => {
  return (
    <TableRow key={user.id} hover>
      {Object.keys(user).map(key => {
        if (key === 'id') {
          return;
        }
        if (key === 'active') {
          return (
            <TableCell align="center" key={key}>
              {user[key] && getUserStatusLabel(user[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            style={{ paddingLeft: `${key === 'name' ? '24px' : '0px'}` }}
            padding="normal"
            key={key}
            align={'left'}
          >
            {user[key] && user[key]}
          </TableCell>
        );
      })}
      <TableCell align="left">
        <IconButton onClick={() => handleModalOpen(user.id)}>
          <PencilAltIcon fontSize="small" />
        </IconButton>
      </TableCell>
    </TableRow>
  );
};

export default UserRow;
