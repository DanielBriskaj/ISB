import React, { useEffect } from 'react';
import {
  Box,
  Button,
  Container,
  Grid,
  Typography,
  Divider,
} from '@material-ui/core';
import useSettings from '../../../materialUI/hooks/useSettings';
import { useForm, FormProvider } from 'react-hook-form';
import Close from 'src/icons/X';
import { yupResolver } from '@hookform/resolvers/yup';
import { userFormSchema } from 'src/modules/shared/yup/userFormSchema';
import { useDispatch, useSelector } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import userSelector from 'src/modules/users/userSelector';
import userActions from 'src/modules/users/userActions';
import UserForm from 'src/view/materialUI/components/widgets/forms/UserForm';
import { UserData } from 'src/models/data/users/UsersData';
import { ROLES } from 'src/modules/shared/authentication/authReducer';

interface UserFormProps {
  setModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
  userId: number;
  query: any;
}
const UsersFormPopup: React.FC<UserFormProps> = ({
  setModalOpen,
  userId,
  query,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const userData = useSelector(userSelector.userData);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const initialValues: UserData = {
    id: 0,
    name: '',
    surname: '',
    username: '',
    role: '',
    email: '',
    costOwner: null,
    active: null,
  };

  const form = useForm({
    resolver: yupResolver(userFormSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const selectedRole = form.watch('role');

  const handleSubmit = data => {
    let clearCostOwner = false;

    const transformedData = {
      userId,
      active: data?.active,
      role: data?.role,
      costOwnerId: data?.costOwner?.id,
    };

    if (
      userData?.role !== data?.role &&
      data?.role !== ROLES.COST_OWNER &&
      data?.role !== ROLES.COST_OWNER_AUTHORIZER
    ) {
      clearCostOwner = true;
    }
    dispatch(
      userActions.updateCoThenupdateUser(
        transformedData,
        query,
        clearCostOwner,
      ),
    );

    setModalOpen(false);
  };

  useEffect(() => {
    dispatch(userActions.getUserById(userId));
  }, [userId]);

  useEffect(() => {
    if (userData) {
      Object.keys(userData)?.forEach(key => {
        form.setValue(key as keyof UserData, userData[key]);
      });
    }
  }, [userData]);

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                User
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <UserForm selectedRole={selectedRole} />
              </Box>
              <Box
                sx={{ mt: 2, gap: 1 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role === ROLES.ACCOUNTING_INPUT && (
                  <Button variant="contained" color="primary" type="submit">
                    Save
                  </Button>
                )}
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 8px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                  type="button"
                >
                  Cancel
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default UsersFormPopup;
