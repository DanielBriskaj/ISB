import { useState, useEffect } from 'react';
import type { FC } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
  Box,
  Breadcrumbs,
  Container,
  Grid,
  Link,
  TextField,
  Typography,
} from '@material-ui/core';
import ChevronRightIcon from '../../../../icons/ChevronRight';
import useSettings from '../../../materialUI/hooks/useSettings';
import { useSelector, useDispatch } from 'react-redux';
import userSelector from '../../../../modules/users/userSelector';
import userAction from '../../../../modules/users/userActions';
import DynamicTable from '../../../../view/materialUI/components/widgets/tables/DynamicTable';
import { usersFields } from '../../../../enums/shared/headerFields/usersFields';
import WidgetPreviewer from '../../../../view/materialUI/components/WidgetPreviewer';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import UsersFormPopup from './UsersFormPopup';
import { roleOptions } from 'src/enums/roleOptions.';
import ReactSelect from 'src/view/materialUI/components/ReactSelect';

const userStatusOptions = [
  { label: 'ALL', value: '' },
  { label: 'ACTIVE', value: true },
  { label: 'INACTIVE', value: false },
];

const UserTable: FC = () => {
  const { settings } = useSettings();
  const [tableData, setTableData] = useState([]);
  const dispatch = useDispatch();
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [userId, setUserId] = useState<number>();
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [limitPerPage, setLimitPerPage] = useState<number>(10);
  const [status, setStatus] = useState<boolean | string>(true);
  const [filterRole, setFilterRole] = useState<string>('');

  const usersState = useSelector(userSelector.usersDataArray);
  const loading = useSelector(statusSelector.loading);

  const query = {
    size: limitPerPage,
    page: currentPage,
    active: status,
    role: filterRole,
  };

  useEffect(() => {
    dispatch(userAction.read(query));
  }, [limitPerPage, currentPage, status, filterRole]);

  useEffect(() => {
    if (usersState && usersState.length !== 0) {
      setTableData(
        usersState?.users?.map(user => ({
          id: user?.id,
          name: user?.name,
          surname: user?.surname,
          username: user?.username,
          role: user?.role,
          division: user?.costOwner?.division,
          active: user?.active ? user?.active : 'inactive',
        })),
      );
    }
    setTotalItems(usersState?.totalItems);
  }, [usersState]);

  const handleModalOpen = (id: number) => {
    setModalOpen(true);
    setUserId(id);
  };

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    setLimitPerPage(event.target.value);
    setCurrentPage(0);
  };

  const getFilterComponent = () => {
    return (
      <>
        <Box
          sx={{
            m: 1,
            maxWidth: '100%',
            width: 240,
            display: 'flex',
            justifySelf: 'flex-start',
          }}
        >
          <TextField
            onChange={event => {
              setStatus(event.target.value);
              setCurrentPage(0);
            }}
            fullWidth
            size="small"
            label={'Filter By Status'}
            name="filterByStatus"
            select
            InputLabelProps={{ shrink: true }}
            inputProps={{
              style: {
                minWidth: 110,
                padding: '4.5px 14px',
              },
            }}
            SelectProps={{
              native: true,
            }}
            variant="outlined"
          >
            {userStatusOptions.map(
              (userStatusOptions: {
                value: boolean | string;
                label: string;
              }) => {
                return (
                  <option
                    selected={status === userStatusOptions.value}
                    value={userStatusOptions.value?.toString()}
                  >
                    {userStatusOptions.label}
                  </option>
                );
              },
            )}
          </TextField>
        </Box>
        <Box
          sx={{
            m: 1,
            maxWidth: '100%',
            width: 260,
            display: 'flex',
            justifySelf: 'flex-start',
          }}
          className="table-select-container"
        >
          <Grid item md={12} xs={12}>
            <ReactSelect
              options={roleOptions}
              name={`filterRole`}
              placeholder="Filter By Role"
              menuHeight={300}
              isClearable={true}
              handleSelect={option => {
                setCurrentPage(0);
                setFilterRole(option?.value ?? null);
              }}
            />
          </Grid>
        </Box>
      </>
    );
  };

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'white',
          minHeight: '100%',
          py: 8,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5">
                Users
              </Typography>
              <Breadcrumbs
                aria-label="breadcrumb"
                separator={<ChevronRightIcon fontSize="small" />}
                sx={{ mt: 1 }}
              >
                <Link
                  color="textPrimary"
                  component={RouterLink}
                  to="/dashboard"
                  variant="subtitle2"
                >
                  Dashboard
                </Link>
                <Link
                  color="textPrimary"
                  component={RouterLink}
                  to="/dashboard"
                  variant="subtitle2"
                >
                  Menu Config
                </Link>
                <Typography color="textSecondary" variant="subtitle2">
                  Users
                </Typography>
              </Breadcrumbs>
            </Grid>
            <Grid item>
              <Box sx={{ m: -1 }}></Box>
            </Grid>
          </Grid>
          <Box sx={{ mt: 3 }}>
            <WidgetPreviewer
              element={
                <DynamicTable
                  tableType="userTable"
                  headerFields={usersFields}
                  data={tableData}
                  loading={loading}
                  handleModalOpen={handleModalOpen}
                  currentPage={currentPage}
                  totalItems={totalItems}
                  limitPerPage={limitPerPage}
                  onPageChange={onPageChange}
                  onChangeRowsPerPage={onChangeRowsPerPage}
                  query={query}
                  StatusFilterComponent={getFilterComponent()}
                />
              }
              name="Users Table"
            />
          </Box>
        </Container>
        <ModalWrapper
          children={
            <UsersFormPopup
              setModalOpen={setModalOpen}
              userId={userId}
              query={query}
            />
          }
          modalOpen={modalOpen}
          setModalOpen={setModalOpen}
          type="editModal"
        />
      </Box>
    </>
  );
};

export default UserTable;
