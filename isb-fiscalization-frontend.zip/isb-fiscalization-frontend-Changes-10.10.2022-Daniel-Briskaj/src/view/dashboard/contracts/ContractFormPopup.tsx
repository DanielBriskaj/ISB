import { useEffect, useState } from 'react';
import {
  Box,
  Breadcrumbs,
  Button,
  Container,
  Grid,
  Link,
  Typography,
  Divider,
} from '@material-ui/core';
import useSettings from '../../materialUI/hooks/useSettings';
import { useForm, FormProvider } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import Close from 'src/icons/X';
import { yupResolver } from '@hookform/resolvers/yup';
import { contractsSchema } from 'src/modules/shared/yup/contractsSchema';
import { ContractData } from 'src/models/data/contracts/ContractsData';
import contractActions from 'src/modules/contracts/contractActions';
import contractSelector from 'src/modules/contracts/contractSelector';
import ContractsForm from 'src/view/materialUI/components/widgets/forms/ContractsForm';
import optionSelector from 'src/modules/shared/options/optionsSelector';
import LoadingScreen from 'src/view/materialUI/components/LoadingScreen';
import moment from 'moment';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import budgetActions from 'src/modules/budget/budgetActions';
import budgetSelector from 'src/modules/budget/budgetSelector';
import forecastSelector from 'src/modules/forecast/forecastSelector';
import forecastActions from 'src/modules/forecast/forecastActions';
import { RoleContractStatusRender } from 'src/helpers/supplierRoleStatusRender';
import optionsActions from 'src/modules/shared/options/optionsActions';

interface BudgetContractData extends ContractData {
  budget: {
    id: number;
  };
  budgetItemStatus: string;
  forecast: {
    id: number;
  };
  forecastItemStatus: string;
}

const ContractFormPopup = props => {
  const {
    contractId,
    setModalOpen,
    isContract,
    setDialogOpen,
    approved,
    type,
    isFormDisabled,
    budgetID,
    forecastID,
  } = props;
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const contractData = useSelector(contractSelector.contractData);
  const budgetContract = useSelector(budgetSelector.budgetItem);
  const forecastContract = useSelector(forecastSelector.forecastItem);
  const selectedContract = useSelector(contractSelector.selectedContract);
  const [loading, setLoading] = useState(false);

  const contractLoading = useSelector(statusSelector.loading);
  const optionsLoading = useSelector(optionSelector.loading);
  const authData = useSelector(authSelector.authData);
  const { role, costOwnerCode, costOwnerId } = authData;

  useEffect(() => {
    if (optionsLoading && contractLoading) {
      setLoading(true);
    } else {
      setLoading(false);
    }
  }, [contractLoading, optionsLoading]);

  const initialValues: BudgetContractData = {
    expenditureType: '',
    supplier: {
      id: null,
    },
    branch: {
      id: null,
    },
    budgetCode: '',
    costOwner: {
      code: '',
      id: null,
    },
    contractDescription: '',
    startDate: '',
    endDate: ' ',
    currency: '',
    automaticRenewal: null,
    productDescription: '',
    exitOption: null,
    contractAmount: 0,
    fixedOrVariable: '',
    prepayment: null,
    isVat: null,
    vat: null,
    gl: {
      id: null,
    },
    iban: '',
    isCriticalContract: null,
    contractStatus: 'NEW',
    resolutionClauses: null,
    project: '',
    integration: null,
    bankContactPerson: '',
    contractCode: '',
    parentContract: null,
    approved: 'NEW',
    budget: {
      id: undefined,
    },
    budgetItemStatus: 'CREATED',
    forecast: {
      id: undefined,
    },
    forecastItemStatus: 'CREATED',
  };

  const form = useForm({
    resolver: yupResolver(contractsSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });
  const isVat = form.watch('isVat');

  useEffect(() => {
    if (isVat?.toString() === 'false') {
      form.setValue('vat', 0);
    }
  }, [isVat]);

  const onSubmit = data => {
    if (data.parentContract !== null) {
      delete data.parentContract.contractCode;
    }
    if (data.id) {
      delete data.id;
    }
    if (type !== 'forecastContract') {
      delete data.contractCode;
    }
    if (isContract) {
      if (typeof contractId === 'number') {
        dispatch(
          contractActions.update(
            {
              id: contractId,
              data,
              rawContractBody: contractData,
            },
            props?.query,
          ),
        );
        setModalOpen(false);
      } else {
        dispatch(contractActions.create(data, props?.query));
        setModalOpen(false);
      }
    } else if (type === 'budgetContract') {
      if (typeof contractId === 'number') {
        dispatch(
          budgetActions.updateBudgetItem({
            id: contractId,
            data,
            query: props.query,
            costOwnerId,
          }),
        );
        setModalOpen(false);
      } else {
        const transformedData = {
          ...data,
          budget: { ...data.budget, id: budgetID },
        };
        dispatch(
          budgetActions.createNewItem(budgetID, transformedData, costOwnerId),
        );
        setModalOpen(false);
      }
    } else if (type === 'forecastContract') {
      if (typeof contractId === 'number') {
        dispatch(
          forecastActions.updateForecastItem({
            id: contractId,
            data,
            query: props.query,
            costOwnerId,
          }),
        );
        setModalOpen(false);
      } else {
        const transformedData = {
          ...data,
          forecast: { ...data.forecast, id: forecastID },
        };
        dispatch(
          forecastActions.createNewItem(
            forecastID,
            transformedData,
            costOwnerId,
          ),
        );
        setModalOpen(false);
      }
    } else {
      if (data.parentContract.id === contractId) {
        dispatch(contractActions.create(data, props?.query));
        setModalOpen(false);
      } else {
        dispatch(
          contractActions.update(
            {
              id: contractId,
              data,
              rawContractBody: contractData,
            },
            props?.query,
          ),
        );
        setModalOpen(false);
      }
    }
    dispatch(contractActions.setSelectedContract(null));
  };

  useEffect(() => {
    if (typeof contractId === 'number') {
      if (type === 'budgetContract') {
        dispatch(budgetActions.getSingleBudgetItem(contractId));
      } else if (type === 'forecastContract') {
        dispatch(forecastActions.getSingleForecastItem(contractId));
      } else {
        dispatch(contractActions.getById(contractId));
      }
    }
  }, [dispatch, contractId, type]);

  const [contract, setContract] = useState({});

  useEffect(() => {
    if (Object.keys(contractData).length > 0) {
      setContract(contractData);
    } else if (Object.keys(budgetContract).length > 0) {
      setContract(budgetContract);
    } else if (Object.keys(forecastContract).length > 0) {
      setContract(forecastContract);
    } else {
      setContract({});
    }
  }, [contractData, budgetContract, forecastContract]);

  useEffect(() => {
    return () => {
      dispatch(budgetActions.clearBudgetItemData());
      dispatch(contractActions.clearContractData());
      dispatch(forecastActions.clearForecastItemData());
      dispatch(optionsActions.clearOptionsData());
    };
  }, []);

  useEffect(() => {
    if (
      (contract &&
        Object.keys(contract).length === 0 &&
        Object.getPrototypeOf(contract) === Object.prototype) ||
      typeof contractId !== 'number' ||
      contractId === null
    ) {
      form.reset();

      form.setValue('startDate', moment(new Date()).format('YYYY-MM-DD'));
      form.setValue('endDate', moment(new Date()).format('YYYY-MM-DD'));

      if (type === 'forecastContract' || type === 'budgetContract') {
        form.setValue(`costOwner.code`, costOwnerCode);
        form.setValue(`costOwner.id`, costOwnerId);
      }
    } else {
      Object.keys(contract).forEach(key => {
        if (typeof contract[key] === 'object') {
          if (contract[key] === null) {
            form.setValue(key as keyof BudgetContractData, null);
          } else {
            Object.keys(contract[key]).forEach(objKey => {
              form.setValue(`${key}.${objKey}` as any, contract[key][objKey]);
            });
          }
        } else {
          form.setValue(key as keyof BudgetContractData, contract[key]);
        }
      });

      if (
        isContract ||
        type === 'budgetContract' ||
        type === 'forecastContract'
      ) {
        form.setValue('parentContract', null);
      } else {
        if (contract['parentContract'] === null) {
          form.setValue('parentContract', selectedContract);
        } else {
          form.setValue('parentContract', contract['parentContract']);
        }
      }
    }
  }, [contract]);

  const assignContract = () => {
    const newStatus = RoleContractStatusRender(role, 'Assign');
    dispatch(
      contractActions.updateStatus(
        {
          id: contractData.id,
          status: { contractStatus: newStatus },
        },
        props?.query,
        role,
        'Assigned',
      ),
    );
    setModalOpen(false);
  };

  const rejectContract = () => {
    setDialogOpen(true);
  };

  const procAuthFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'button',
      onClick: assignContract,
      label: 'Approve',
      disabled: contractData.contractStatus !== 'IN_APPROVAL' ? true : false,
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: rejectContract,
      label: 'Reject',
      disabled: contractData.contractStatus !== 'IN_APPROVAL' ? true : false,
    },
  ];

  const procInputFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'submit',
      // onClick: () => {},
      label: 'Save',
      disabled:
        (type === 'budgetContract' || type === 'forecastContract') &&
        isFormDisabled,
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setModalOpen(false),
      label: 'Cancel',
    },
  ];
  const accInputAuthFormButtons = [
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setModalOpen(false),
      label: 'Cancel',
    },
  ];

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Contract
              </Typography>
            </Grid>
            <Grid item>
              <Close
                onClick={() => {
                  setModalOpen(false);
                  dispatch(contractActions.clearContractData());
                  dispatch(contractActions.setSelectedContract());
                }}
              />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <ContractsForm
                  isFormDisabled={isFormDisabled}
                  type={type}
                  contract={contract}
                  isVat={isVat}
                />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role === 'PROCUREMENT_AUTHORIZER' && (
                  <>
                    {procAuthFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                          disabled={button.disabled}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {(role === 'PROCUREMENT_INPUT' ||
                  ((type === 'budgetContract' || type === 'forecastContract') &&
                    role === 'COST_OWNER' &&
                    !isFormDisabled)) && (
                  <>
                    {procInputFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                          disabled={button?.disabled}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {(type !== 'budgetContract' &&
                  type !== 'forecastContract' &&
                  role !== 'PROCUREMENT_INPUT' &&
                  role !== 'PROCUREMENT_AUTHORIZER') ||
                ((type === 'budgetContract' || type === 'forecastContract') &&
                  (role !== 'COST_OWNER' || isFormDisabled)) ? (
                  <>
                    {accInputAuthFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                ) : (
                  <></>
                )}
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default ContractFormPopup;
