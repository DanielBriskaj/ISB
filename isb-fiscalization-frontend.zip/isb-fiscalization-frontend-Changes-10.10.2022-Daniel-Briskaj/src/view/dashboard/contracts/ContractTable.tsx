import { useEffect, useState, useCallback, useRef } from 'react';
import { Box, TextField } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import DynamicTable from '../../materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from '../../materialUI/components/WidgetPreviewer';
import { debounce } from 'lodash';
import contractSelector from 'src/modules/contracts/contractSelector';
import ContractFormPopup from './ContractFormPopup';
import contractActions from 'src/modules/contracts/contractActions';
import { contractFields } from 'src/enums/shared/headerFields/contractFields';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import UploadFilePopup from './UploadFilesPopup';
import Plus from 'src/icons/Plus';
import Download from 'src/icons/Download';
import Upload from 'src/icons/Upload';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { FilteredExportedContractsProps } from 'src/models/data/contracts/ContractsData';
import { RoleContractStatusRender } from 'src/helpers/supplierRoleStatusRender';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import numberWithCommas from 'src/helpers/numberWithCommas';
import notificationThrower from 'src/helpers/notificationThrower';

type ContractStatusInput =
  | ''
  | 'NEW'
  | 'IN_APPROVAL'
  | 'ACTIVE'
  | 'FORECAST'
  | 'BUDGET'
  | 'EXPIRED';
const ContractStatusOptions = [
  { value: '', label: 'ALL' },
  { value: 'NEW', label: 'NEW' },
  { value: 'IN_APPROVAL', label: 'IN APPROVAL' },
  { value: 'ACTIVE', label: 'ACTIVE' },
  { value: 'FORECAST', label: 'FORECAST' },
  { value: 'BUDGET', label: 'BUDGET' },
  { value: 'EXPIRED', label: 'EXPIRED' },
];

const ContractTable = () => {
  const [contractDescription, setContractDescription] = useState('');
  const [supplierCompanyName, setSupplierCompanyName] = useState('');
  const [costOwnerCode, setCostOwnerCode] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [popupOpen, setPopupOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [contractId, setContractId] = useState(null);
  const [isContract, setIsContract] = useState(true);
  const [tableData, setTableData] = useState([]);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [sortDirection, setSortDirect] = useState<'asc' | 'desc'>('desc');
  const [searchFunctionArray, setSearchFunctionArray] = useState([]);
  const [filteredExportedContracts, setFilteredExportedContracts] =
    useState<FilteredExportedContractsProps>();

  const dispatch = useDispatch();

  const contractData = useSelector(contractSelector.contractData);
  const contractsState = useSelector(contractSelector.contractsDataArray);
  const loading = useSelector(statusSelector.loading);
  const selectedContract = useSelector(contractSelector.selectedContract);
  const authData = useSelector(authSelector.authData);
  const [sortedColumns, setSortedColumns] = useState({
    Description: 'desc',
    'Cost Owner': 'desc',
  });
  const { role, division, costOwnerId } = authData;
  const initialRenderRef = useRef(false);
  const [approved, setApproved] = useState<ContractStatusInput>(
    role === ROLES.PROCUREMENT_INPUT || role === ROLES.PROCUREMENT_AUTHORIZER
      ? 'EXPIRED'
      : '',
  );

  const sortQuery = [
    `costOwner.ownerName,${sortedColumns['Cost Owner']}`,
    `contractDescription,${sortedColumns['Description']}`,
  ];

  const query: any = {};
  query.sort = sortQuery;
  query.description = contractDescription;
  query.supplierCompanyName = supplierCompanyName;
  query.costOwnerName = costOwnerCode;
  query.size = limitPerPage;
  query.page = currentPage;
  query.contractStatus = role === 'COST_OWNER_AUTHORIZER' ? 'ACTIVE' : approved;
  query.division = division;

  useEffect(() => {
    setCurrentPage(0);
  }, [approved]);

  useEffect(() => {
    if (role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong',
        toastId: 'Contracts1',
      });
    } else {
      dispatch(contractActions.read(query));
    }
  }, [
    contractDescription,
    supplierCompanyName,
    costOwnerCode,
    approved,
    sortedColumns,
    limitPerPage,
    currentPage,
  ]);

  useEffect(() => {
    if (
      contractsState &&
      Object.keys(contractsState).length === 0 &&
      Object.getPrototypeOf(contractsState) === Object.prototype
    ) {
      return;
    } else {
      if (contractsState.contracts) {
        setTableData(
          contractsState.contracts.map(contract => ({
            id: contract.id,
            supplier: contract.supplier?.companyName,
            costOwner: contract.costOwner?.ownerName,
            divisionCode: contract.costOwner?.code,
            contractCode: contract.contractCode,
            startDate: contract.startDate,
            description: contract.contractDescription,
            amount: numberWithCommas(contract.contractAmount.toFixed(2)),
            currency: contract?.currency,
            status:
              contract.contractStatus === null
                ? 'ACTIVE'
                : contract?.contractStatus || 'NEW',
          })),
        );
        setTotalItems(contractsState.totalItems);
      }
    }
  }, [contractsState]);

  const contractCodeSearchOnChange = event => {
    setContractDescription(event.target.value);
    setCurrentPage(0);
  };
  const handleContractCodeSearch = useCallback(
    debounce(contractCodeSearchOnChange, 100),
    [],
  );

  const supplierCompanyNameSearchOnChange = event => {
    setSupplierCompanyName(event.target.value);
    setCurrentPage(0);
  };
  const handleSupplierCompanyNameSearch = useCallback(
    debounce(supplierCompanyNameSearchOnChange, 100),
    [],
  );

  const costOwnerCodeSearchOnChange = event => {
    setCostOwnerCode(event.target.value);
    setCurrentPage(0);
  };
  const handleCostOwnerCodeSearch = useCallback(
    debounce(costOwnerCodeSearchOnChange, 100),
    [],
  );

  useEffect(() => {
    setSearchFunctionArray([
      {
        placeholder: 'Contract Description',
        function: handleContractCodeSearch,
        customClass: 'search-input',
        disabled: role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId,
      },
      {
        placeholder: 'Supplier Company Name',
        function: handleSupplierCompanyNameSearch,
        customClass: 'search-input',
        disabled: role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId,
      },
      {
        placeholder: 'Cost Owner Name',
        function: handleCostOwnerCodeSearch,
        customClass: 'search-input',
        disabled: role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId,
      },
    ]);
  }, []);

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  function handleDirectionSorting(sortDirection) {
    setSortDirect(sortDirection);
    setCurrentPage(0);
  }

  function handleMultipleDirectionSorting(sortingProps) {
    if (sortedColumns[sortingProps]) {
      setSortedColumns({
        ...sortedColumns,
        [sortingProps]: sortedColumns[sortingProps] === 'asc' ? 'desc' : 'asc',
      });
    } else {
      setSortedColumns({ ...sortedColumns, [sortingProps]: 'asc' });
    }
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const handleDelete = id => {
    dispatch(contractActions.delete((id = contractId?.id), query));
  };

  const rejectContract = data => {
    const newStatus = RoleContractStatusRender(role, 'Reject');
    dispatch(
      contractActions.updateStatus(
        {
          id: contractData.id,
          status: {
            contractStatus: newStatus,
            authorizerFeedback: data?.reason,
          },
        },
        query,
        role,
        'Rejected',
      ),
    );
    setModalOpen(false);
    setDialogOpen(false);
  };

  const setSelectedContract = (id?) => {
    dispatch(contractActions.setSelectedContract(id));
  };

  const exportExel = () => {
    dispatch(contractActions.exportExelFile());
  };

  useEffect(() => {
    if (
      contractDescription ||
      supplierCompanyName ||
      costOwnerCode ||
      sortQuery ||
      approved
    ) {
      setFilteredExportedContracts({
        sort: sortQuery,
        description: contractDescription,
        supplierCompanyName: supplierCompanyName,
        costOwnerName: costOwnerCode,
        contractStatus: approved,
      });
    }
  }, [
    contractDescription,
    supplierCompanyName,
    costOwnerCode,
    sortedColumns,
    approved,
  ]);

  useEffect(() => {
    return () => {
      dispatch(contractActions.clearContractsArray());
    };
  }, []);

  const exportExelwithFilters = () => {
    dispatch(
      contractActions.exportExelFilewithFilters(filteredExportedContracts),
    );
  };

  function handleModalOpen(obj?) {
    if (obj.contract === true) {
      setIsContract(true);
    } else if (obj.contract === false) {
      setIsContract(false);
    } else {
      setIsContract(true);
    }
    if (obj.id) {
      setContractId(obj.id);
    } else {
      setContractId(null);
    }
    setModalOpen(!modalOpen);
  }

  function handleDialogOpen(id?) {
    if (id) {
      setContractId(id);
    }
    setDialogOpen(!dialogOpen);
  }

  function handlePopupOpen(id?) {
    if (id) {
      setContractId(id);
    }
    setPopupOpen(!popupOpen);
  }

  const contractModalOpen = open => {
    setModalOpen(open);
    dispatch(contractActions.clearContractData());
    dispatch(contractActions.setSelectedContract());
  };

  const handleApproveAll = () => {
    const status = { currentStatus: 'IN_APPROVAL', newStatus: 'ACTIVE' };
    dispatch(contractActions.batchUpdate(status, query));
  };

  const contractButtonData = [
    {
      label: 'Export',
      startIcon: <Download />,
      color: 'success',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: filteredExportedContracts ? exportExelwithFilters : exportExel,
    },
    {
      label: 'Add Sub-Contract',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      disabled: selectedContract === null ? true : false,
      onClick: () => {
        if (selectedContract !== null) {
          handleModalOpen({ id: selectedContract.id, contract: false });
        }
      },
    },
    {
      label: 'Add Contract',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      disabled: false,
      sx: {},
      onClick: handleModalOpen,
    },
    {
      label: 'Approve All',
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleApproveAll,
    },
  ];

  const filterButtons = () => {
    switch (role) {
      case 'PROCUREMENT_INPUT':
        return contractButtonData.filter(item => item.label !== 'Approve All');
      case 'PROCUREMENT_AUTHORIZER':
        return contractButtonData.filter(
          item =>
            item.label !== 'Add Contract' &&
            item.label !== 'Add Sub-Contract' &&
            item.label !== 'Import',
        );
      case 'ACCOUNTING_INPUT':
        return contractButtonData.filter(item => item.label === 'Export');
      case 'ACCOUNTING_AUTHORIZER':
        return contractButtonData.filter(item => item.label === 'Export');
      case 'COST_OWNER_AUTHORIZER':
        return null;
      default:
        return contractButtonData;
    }
  };

  const getFilterComponent = () => {
    return (
      <Box
        sx={{
          m: 1,
          maxWidth: '100%',
          width: 240,
          display: 'flex',
          justifySelf: 'flex-start',
        }}
      >
        <TextField
          onChange={event => {
            setApproved(event.target.value as ContractStatusInput);
            setCurrentPage(0);
          }}
          fullWidth
          size="small"
          label={'Filter by status'}
          name="filterByStatus"
          select
          InputLabelProps={{ shrink: true }}
          inputProps={{
            style: {
              minWidth: 110,
              padding: '4.5px 14px',
            },
          }}
          SelectProps={{
            native: true,
          }}
          variant="outlined"
        >
          {ContractStatusOptions.map(
            (ContractStatusOption: { value: string; label: string }) => {
              return (
                <option
                  selected={approved === ContractStatusOption.value}
                  value={ContractStatusOption.value}
                >
                  {ContractStatusOption.label}
                </option>
              );
            },
          )}
        </TextField>
      </Box>
    );
  };

  const modalWrapperData = [
    {
      children: (
        <UploadFilePopup
          setModalOpen={setPopupOpen}
          contractId={contractId}
          contract={contractsState}
        />
      ),
      modalOpen: popupOpen,
      setModalOpen: setPopupOpen,
      type: 'editModal',
    },
    {
      children: (
        <ContractFormPopup
          setModalOpen={setModalOpen}
          contractId={contractId}
          isContract={isContract}
          setDialogOpen={setDialogOpen}
          query={query}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },

    {
      children: (
        <AlertDialog
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          handleDelete={
            contractId?.type === 'delete' ? handleDelete : rejectContract
          }
          message={
            contractId?.type === 'delete'
              ? `Are you sure you want to delete this Contract ?`
              : `Why do you want to reject this Contract ?`
          }
          hasFeedback={contractId?.type === 'delete' ? false : true}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
        }}
      >
        <Box>
          <WidgetPreviewer
            element={
              <DynamicTable
                tableType="contractTable"
                headerFields={
                  role === 'ACCOUNTING_INPUT' ||
                  role === 'ACCOUNTING_AUTHORIZER' ||
                  role === 'COST_OWNER_AUTHORIZER'
                    ? contractFields.filter(field => field.label !== 'Process')
                    : contractFields
                }
                handleModalOpen={handleModalOpen}
                handleDialogOpen={handleDialogOpen}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                handleDirectionSorting={handleDirectionSorting}
                handleMultipleDirectionSorting={handleMultipleDirectionSorting}
                handlePopupOpen={handlePopupOpen}
                data={tableData}
                handleDelete={handleDelete}
                loading={loading}
                totalItems={totalItems}
                currentPage={currentPage}
                searchArrayOfFunctions={searchFunctionArray}
                limitPerPage={limitPerPage}
                setSelected={setSelectedContract}
                selected={selectedContract}
                buttonData={role && filterButtons()}
                sortedProps={sortedColumns}
                sortDirection={sortQuery}
                StatusFilterComponent={
                  role !== ROLES.COST_OWNER_AUTHORIZER && getFilterComponent()
                }
                query={query}
              />
            }
            name="Contract Table"
          />
        </Box>
        {modalWrapperData &&
          modalWrapperData.map(modalData => {
            return <ModalWrapper {...modalData} />;
          })}
      </Box>
    </>
  );
};

export default ContractTable;
