import { useState, useEffect, useRef } from 'react';
import {
  TableCell,
  TableRow,
  IconButton,
  Button,
  Collapse,
  Box,
} from '@material-ui/core';
import PencilAltIcon from '../../../icons/PencilAlt';
import ArrowRightIcon from '../../../icons/ArrowRight';
import Label from 'src/view/materialUI/components/Label';
import { useDispatch, useSelector } from 'react-redux';
import contractActions from 'src/modules/contracts/contractActions';
import contractSelector from 'src/modules/contracts/contractSelector';
import Trash from 'src/icons/Trash';
import Upload from 'src/icons/Upload';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { status } from 'src/enums/status';
import LoadingScreen from 'src/view/materialUI/components/LoadingScreen';
import { contractFields } from 'src/enums/shared/headerFields/contractFields';
// import {
//   enableProcAuth,
//   enableProcInput,
// } from 'src/view/materialUI/utils/enableApproval';
import { enableProcApproval } from 'src/view/materialUI/utils/enableApproval';
import { RoleContractStatusRender } from 'src/helpers/supplierRoleStatusRender';

const getStatusLabel = status => {
  const map = {
    ACTIVE: {
      color: 'success',
      text: 'ACTIVE',
    },
    EXPIRED: {
      color: 'error',
      text: 'EXPIRED',
    },
    BUDGET: {
      color: 'warning',
      text: 'BUDGET',
    },
    FORECAST: {
      color: 'primary',
      text: 'FORECAST',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: status,
    },
  };

  const { text, color }: any = map[status] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const ContractRow = ({
  contract,
  handleModalOpen,
  handleDialogOpen,
  handlePopupOpen,
  handleDelete,
  selected,
  setSelected,
  page,
  rowsPerPage,
  approved,
  sort,
  query,
}) => {
  const [open, setOpen] = useState(false);
  const [rowColor, setRowColor] = useState(false);
  const dispatch = useDispatch();
  const subContractState = useSelector(contractSelector.subContractsData);
  const subloading = useSelector(contractSelector.subloading);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const ref = useRef(false);

  const expandRow = () => {
    setOpen(!open);
  };

  useEffect(() => {
    if (open) {
      dispatch(contractActions.readSubContracts(contract.id));
    }
  }, [open]);

  useEffect(() => {
    if (selected !== null) {
      if (selected.id !== contract.id) {
        setRowColor(false);
      }
    }
  }, [selected]);

  const assignContract = selectedContract => {
    const newStatus = RoleContractStatusRender(role, 'Assign');

    dispatch(
      contractActions.updateStatus(
        {
          id: selectedContract.id,
          status: { contractStatus: newStatus },
        },
        query,
        role,
        'Assigned',
      ),
    );
  };

  return (
    <>
      <TableRow
        hover
        key={contract.id}
        sx={rowColor ? { backgroundColor: 'lavender' } : {}}
        onClick={() => {
          if (selected === null) {
            setSelected(contract.id);
            setRowColor(true);
          } else {
            if (selected.id === contract.id) {
              setSelected();
              setRowColor(false);
            } else {
              setSelected(contract.id);
              setRowColor(true);
            }
          }
        }}
      >
        <TableCell align="center">
          <IconButton
            sx={{ transform: open && 'rotate(90deg)', transition: 'all 200ms' }}
            onClick={() => {
              expandRow();
            }}
          >
            <ArrowRightIcon fontSize="small" />
          </IconButton>
        </TableCell>
        {Object.keys(contract).map(key => {
          if (key === 'id') {
            return;
          }
          if (key === 'status' || key === 'approved') {
            return (
              <TableCell align="center" key={key}>
                {contract[key] && getStatusLabel(contract[key])}
              </TableCell>
            );
          }
          return (
            <TableCell
              key={key}
              sx={
                key === 'supplier' ||
                key === 'costOwner' ||
                key === 'description'
                  ? {
                      paddingLeft: key === 'supplier' ? 0 : 3,
                      maxWidth: '200px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }
                  : { paddingLeft: 0 }
              }
              align={
                key === 'divisionCode' ||
                key === 'contractCode' ||
                key === 'startDate' ||
                key === 'status' ||
                key === 'currency'
                  ? 'center'
                  : key === 'amount'
                  ? 'right'
                  : 'left'
              }
            >
              {contract[key] && contract[key]}
            </TableCell>
          );
        })}
        <TableCell align="center">
          <IconButton
            onClick={() => handleModalOpen({ id: contract.id, contract: true })}
          >
            <PencilAltIcon fontSize="small" />
          </IconButton>
          {role === 'PROCUREMENT_INPUT' || role === 'PROCUREMENT_AUTHORIZER' ? (
            <IconButton
              onClick={() =>
                handleDialogOpen({ id: contract.id, type: 'delete' })
              }
            >
              <Trash fontSize="small" />
            </IconButton>
          ) : (
            <></>
          )}
          <IconButton onClick={() => handlePopupOpen(contract.id)}>
            <Upload fontSize="small" />
          </IconButton>
        </TableCell>
        <TableCell align="center">
          {role === 'ACCOUNTING_INPUT' ||
          role === 'ACCOUNTING_AUTHORIZER' ||
          role === 'COST_OWNER_AUTHORIZER' ? (
            <></>
          ) : (
            <Button
              onClick={() => assignContract(contract)}
              disabled={
                role === 'PROCUREMENT_AUTHORIZER'
                  ? enableProcApproval.enableProcAuth(role, contract.status)
                  : enableProcApproval.enableProcInput(role, contract.status)
              }
            >
              {role === 'PROCUREMENT_AUTHORIZER'
                ? 'Approve'
                : 'Send for Approval'}
            </Button>
          )}
        </TableCell>
      </TableRow>
      {open &&
      subContractState[contract.id] &&
      subContractState[contract.id].length !== 0
        ? subContractState[contract.id].map((subContract, i) => {
            const temp = {
              id: contract?.id,

              supplier: subContract?.supplier?.companyName,
              costOwner: subContract?.costOwner?.ownerName,
              divisionCode: subContract?.costOwner?.code,
              contractCode: subContract?.contractCode,
              startDate: subContract?.startDate,
              description: subContract?.contractDescription,
              amount: subContract?.contractAmount,
              status:
                subContract?.contractStatus === null
                  ? 'ACTIVE'
                  : subContract?.contractStatus || 'NEW',
            };

            if (subloading) {
              return <LoadingScreen />;
            } else {
              return (
                <>
                  <TableRow hover key={subContract.id} selected>
                    <TableCell align="center" key={i}></TableCell>
                    {Object.keys(temp).map(key => {
                      if (key === 'id') {
                        return;
                      }

                      if (key === 'status' || key === 'approved') {
                        return (
                          <TableCell align="center" key={key}>
                            {temp[key] && getStatusLabel(temp[key])}
                          </TableCell>
                        );
                      }
                      return (
                        <TableCell
                          key={key}
                          sx={
                            key === 'supplier' ||
                            key === 'costOwner' ||
                            key === 'description'
                              ? {
                                  paddingLeft: key === 'supplier' ? 0 : 3,
                                  maxWidth: '200px',
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  whiteSpace: 'nowrap',
                                }
                              : { paddingLeft: 0 }
                          }
                          align={
                            key === 'divisionCode' ||
                            key === 'contractCode' ||
                            key === 'startDate' ||
                            key === 'amount' ||
                            key === 'status'
                              ? 'center'
                              : 'left'
                          }
                        >
                          {temp[key] && temp[key]}
                        </TableCell>
                      );
                    })}
                    <TableCell align="center">
                      <IconButton
                        onClick={() => {
                          dispatch(contractActions.clearContractData());
                          handleModalOpen({
                            id: subContract.id,
                            contract: false,
                          });
                        }}
                      >
                        <PencilAltIcon fontSize="small" />
                      </IconButton>
                      {role === 'PROCUREMENT_INPUT' ||
                      role === 'PROCUREMENT_AUTHORIZER' ? (
                        <IconButton
                          onClick={() =>
                            handleDialogOpen({
                              id: subContract.id,
                              type: 'delete',
                            })
                          }
                        >
                          <Trash fontSize="small" />
                        </IconButton>
                      ) : (
                        role === 'ACCOUNTING_INPUT' && <></>
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {role === 'ACCOUNTING_INPUT' ||
                      role === 'ACCOUNTING_AUTHORIZER' ||
                      role === 'COST_OWNER_AUTHORIZER' ? (
                        <></>
                      ) : (
                        <Button
                          onClick={() => assignContract(subContract)}
                          disabled={
                            role === 'PROCUREMENT_AUTHORIZER'
                              ? enableProcApproval.enableProcAuth(
                                  role,
                                  subContract.contractStatus,
                                )
                              : enableProcApproval.enableProcInput(
                                  role,
                                  subContract.contractStatus,
                                )
                          }
                        >
                          {role === 'PROCUREMENT_AUTHORIZER'
                            ? 'Approve'
                            : 'Send for Approval'}
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                </>
              );
            }
          })
        : open && (
            <>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: 'center',
                    fontSize: '1.01rem',
                    fontWeight: '500',
                    color: '#777',
                    padding: '1.15rem 0.9rem',
                  }}
                  colSpan={12}
                >
                  No subcontracts
                </TableCell>
              </TableRow>
            </>
          )}
    </>
  );
};

export default ContractRow;
