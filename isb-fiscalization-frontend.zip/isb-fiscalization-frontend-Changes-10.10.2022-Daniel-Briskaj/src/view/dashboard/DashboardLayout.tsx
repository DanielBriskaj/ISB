import { useState } from 'react';
import type { FC, ReactNode } from 'react';
import { Outlet } from 'react-router';
import { experimentalStyled } from '@material-ui/core/styles';
import DashboardNavbar from './DashboardNavbar';
import DashboardSidebar from './DashboardSidebar';

interface DashboardLayoutProps {
  children?: ReactNode;
}

const DashboardLayoutRoot = experimentalStyled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.default,
  display: 'flex',
  height: '100%',
  overflow: 'auto',
  width: '100%',
}));

const DashboardLayoutWrapper = experimentalStyled('div')(
  ({ theme, styleProps }) => ({
    display: 'flex',
    flex: '1 1 auto',
    overflow: 'auto',
    paddingTop: '84px',
    paddingLeft: styleProps.paddingLeft as string,
  }),
);

const DashboardLayoutContainer = experimentalStyled('div')({
  display: 'flex',
  flex: '1 1 auto',
  overflow: 'auto',
});

const DashboardLayoutContent = experimentalStyled('div')({
  flex: '1 1 auto',
  height: '100%',
  overflow: 'auto',
  position: 'relative',
  WebkitOverflowScrolling: 'touch',
});

const DashboardLayout: FC<DashboardLayoutProps> = () => {
  const [isSidebarMobileOpen, setIsSidebarMobileOpen] =
    useState<boolean>(false);
  return (
    <DashboardLayoutRoot>
      <DashboardNavbar
        openMobile={isSidebarMobileOpen}
        onSidebarMobileOpen={setIsSidebarMobileOpen}
      />
      <DashboardSidebar
        onMobileClose={(): void => setIsSidebarMobileOpen(true)}
        openMobile={isSidebarMobileOpen}
      />

      <DashboardLayoutWrapper
        styleProps={{ paddingLeft: !isSidebarMobileOpen ? 280 : 0 }}
      >
        <DashboardLayoutContainer>
          <DashboardLayoutContent>
            <Outlet />
          </DashboardLayoutContent>
        </DashboardLayoutContainer>
      </DashboardLayoutWrapper>
    </DashboardLayoutRoot>
  );
};

export default DashboardLayout;
