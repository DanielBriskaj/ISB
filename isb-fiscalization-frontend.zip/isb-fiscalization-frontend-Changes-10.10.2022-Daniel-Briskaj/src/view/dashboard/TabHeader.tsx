import { useState, useEffect } from 'react';
import {
  TableHead,
  TableRow,
  TableCell,
  Tooltip,
  TableSortLabel,
  SortDirection,
} from '@material-ui/core';
import { TabHeader as TabHeaders } from 'src/models/data/tableInterfaces/TabHeader';

const TabHeader = ({
  headerFields,
  handleDirectionSorting,
  handleMultipleDirectionSorting,
  sortedProps,
}: TabHeaders) => {
  const [sortDirection, setSortDirect] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    if (handleDirectionSorting) {
      handleDirectionSorting(sortDirection);
    }
  }, [sortDirection]);

  return (
    <TableHead>
      <TableRow>
        {headerFields.map((headerField, i) => {
          if (headerField.sort) {
            return (
              <TableCell
                key={i}
                align={headerField.align}
                sortDirection={
                  sortedProps && sortedProps[headerField.label]
                    ? sortedProps[headerField.label]
                    : (sortDirection as SortDirection)
                }
                sx={
                  headerField?.sx
                    ? headerField?.sx
                    : headerField === headerFields[0]
                    ? { paddingLeft: 3 }
                    : { paddingLeft: 0 }
                }
              >
                <Tooltip
                  enterDelay={300}
                  title={`Sort by ${headerField.label}`}
                  onClick={() => {
                    if (sortDirection === 'desc') {
                      setSortDirect('asc');
                    } else {
                      setSortDirect('desc');
                    }

                    if (handleMultipleDirectionSorting) {
                      handleMultipleDirectionSorting(headerField.label);
                    }
                  }}
                >
                  <TableSortLabel
                    active
                    direction={
                      sortedProps && sortedProps[headerField.label]
                        ? sortedProps[headerField.label]
                        : (sortDirection as SortDirection)
                    }
                  >
                    {headerField.label}
                  </TableSortLabel>
                </Tooltip>
              </TableCell>
            );
          }
          return (
            <TableCell
              key={i}
              align={headerField.align}
              sx={
                headerField?.sx
                  ? headerField?.sx
                  : headerField === headerFields[0]
                  ? { paddingLeft: 3 }
                  : { paddingLeft: 0 }
              }
            >
              {headerField.label}
            </TableCell>
          );
        })}
      </TableRow>
    </TableHead>
  );
};

export default TabHeader;
