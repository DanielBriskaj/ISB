import { FC, useEffect } from 'react';
import { Link as RouterLink, useLocation, useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import {
  Avatar,
  Box,
  Button,
  Divider,
  Drawer,
  Link,
  Typography,
} from '@material-ui/core';
import type { Theme } from '@material-ui/core';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import ArchiveIcon from 'src/icons/Archive';
import UsersIcon from '../../icons/Users';
import FolderOpenIcon from '../../icons/FolderOpen';
import BriefcaseIcon from '../../icons/Briefcase';
import CashIcon from '../../icons/Cash';
import ChartPie from '../../icons/ChartPie';

import CreditCardIcon from '../../icons/CreditCard';
import NavSection from './NavSection';
import Scrollbar from '../materialUI/components/Scrollbar';
import supplierActions from 'src/modules/suppliers/supplierActions';
import costOwnerActions from 'src/modules/costowners/costOwnerActions';
import userActions from '../../modules/users/userActions';
import contractActions from 'src/modules/contracts/contractActions';
import { useDispatch, useSelector } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { tokenExpiry } from 'src/helpers/tokenExpiry';

interface DashboardSidebarProps {
  onMobileClose: () => void;
  openMobile: boolean;
}

const allSections = {
  ACCOUNTING_INPUT: [
    {
      title: 'General',
      items: [
        {
          title: 'Suppliers',
          path: '/dashboard/suppliers',
          icon: <UsersIcon fontSize="small" />,
        },
        {
          title: 'Contracts',
          path: '/dashboard/contracts',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Invoices',
          path: '/dashboard/invoices',
          icon: <CreditCardIcon fontSize="small" />,
        },
        {
          title: 'Reports',
          path: '/dashboard/reports',
          icon: <ChartPie fontSize="small" />,
        },
      ],
    },
    {
      title: 'Config',
      items: [
        {
          title: 'Menu',
          path: '/dashboard/menuconfig',
          icon: <FolderOpenIcon fontSize="small" />,
          children: [
            {
              title: 'Branches',
              path: '/dashboard/menuconfig/branches',
            },
            {
              title: 'Cost Owners',
              path: '/dashboard/menuconfig/costowners',
            },
            {
              title: 'GL',
              path: '/dashboard/menuconfig/gl',
            },
            {
              title: 'Users',
              path: '/dashboard/menuconfig/users',
            },
          ],
        },
      ],
    },
    {
      title: 'History',
      items: [
        {
          title: 'Audit',
          path: '/dashboard/history/audit',
          icon: <ArchiveIcon fontSize="small" />,
        },
      ],
    },
  ],
  ACCOUNTING_AUTHORIZER: [
    {
      title: 'General',
      items: [
        {
          title: 'Suppliers',
          path: '/dashboard/suppliers',
          icon: <UsersIcon fontSize="small" />,
        },
        {
          title: 'Contracts',
          path: '/dashboard/contracts',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Invoices',
          path: '/dashboard/invoices',
          icon: <CreditCardIcon fontSize="small" />,
        },
      ],
    },
    {
      title: 'Config',
      items: [
        {
          title: 'Menu',
          path: '/dashboard/menuconfig',
          icon: <FolderOpenIcon fontSize="small" />,
          children: [
            {
              title: 'Branches',
              path: '/dashboard/menuconfig/branches',
            },
            {
              title: 'Cost Owners',
              path: '/dashboard/menuconfig/costowners',
            },
            {
              title: 'GL',
              path: '/dashboard/menuconfig/gl',
            },
            {
              title: 'Users',
              path: '/dashboard/menuconfig/users',
            },
          ],
        },
      ],
    },
  ],
  COST_OWNER: [
    {
      title: 'Cost Owner',
      items: [
        {
          title: 'Contracts',
          path: '/dashboard/cost-owner/contracts',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Invoices',
          path: '/dashboard/cost-owner/invoices',
          icon: <CreditCardIcon fontSize="small" />,
        },
        {
          title: 'Purchase Order',
          path: '/dashboard/cost-owner/po',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Purchase Request',
          path: '/dashboard/pr',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Budget',
          path: '/dashboard/budget',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Forecast',
          path: '/dashboard/forecast',
          icon: <BriefcaseIcon fontSize="small" />,
        },
      ],
    },
  ],
  COST_OWNER_AUTHORIZER: [
    {
      title: 'General',
      items: [
        {
          title: 'Contracts',
          path: '/dashboard/contracts',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Invoices',
          path: '/dashboard/c-o-authorizer/invoices',
          icon: <CreditCardIcon fontSize="small" />,
        },
        {
          title: 'Purchace Order',
          path: '/dashboard/po',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Purchase Request',
          path: '/dashboard/pr',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Budget',
          path: '/dashboard/budget',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Forecast',
          path: '/dashboard/forecast',
          icon: <BriefcaseIcon fontSize="small" />,
        },
      ],
    },
  ],
  PROCUREMENT_INPUT: [
    {
      title: 'General',
      items: [
        {
          title: 'Purchase Request',
          path: '/dashboard/pr',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Purchase Order',
          path: '/dashboard/po',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Suppliers',
          path: '/dashboard/suppliers',
          icon: <UsersIcon fontSize="small" />,
        },
        {
          title: 'Contracts',
          path: '/dashboard/contracts',
          icon: <BriefcaseIcon fontSize="small" />,
        },
      ],
    },
  ],
  PROCUREMENT_AUTHORIZER: [
    {
      title: 'General',
      items: [
        {
          title: 'Purchase Request',
          path: '/dashboard/pr',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Purchase Order',
          path: '/dashboard/po',
          icon: <CashIcon fontSize="small" />,
        },
        {
          title: 'Suppliers',
          path: '/dashboard/suppliers',
          icon: <UsersIcon fontSize="small" />,
        },
        {
          title: 'Contracts',
          path: '/dashboard/contracts',
          icon: <BriefcaseIcon fontSize="small" />,
        },
      ],
    },
  ],
  PLANNING_CONTROL_INPUT: [
    {
      title: 'General',
      items: [
        {
          title: 'Budget',
          path: '/dashboard/budget',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Forecast',
          path: '/dashboard/forecast',
          icon: <BriefcaseIcon fontSize="small" />,
        },
      ],
    },
  ],
  PLANNING_CONTROL_AUTHORIZER: [
    {
      title: 'General',
      items: [
        {
          title: 'Budget',
          path: '/dashboard/budget',
          icon: <BriefcaseIcon fontSize="small" />,
        },
        {
          title: 'Forecast',
          path: '/dashboard/forecast',
          icon: <BriefcaseIcon fontSize="small" />,
        },
      ],
    },
  ],
  TBO_INPUT: [
    {
      title: 'General',
      items: [
        {
          title: 'Invoices',
          path: '/dashboard/tbo-invoices',
          icon: <CreditCardIcon fontSize="small" />,
        },
      ],
    },
  ],
  TBO_AUTHORIZER: [
    {
      title: 'General',
      items: [
        {
          title: 'Invoices',
          path: '/dashboard/tbo-invoices',
          icon: <CreditCardIcon fontSize="small" />,
        },
      ],
    },
  ],
};

const DashboardSidebar: FC<DashboardSidebarProps> = props => {
  const authData = useSelector(authSelector.authData);

  const sections = allSections[authData.role];
  const { openMobile } = props;
  const location = useLocation();
  const navigate = useNavigate();
  const expire = tokenExpiry();

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login', { replace: true });
  };

  useEffect(() => {
    if (expire * 1000 < new Date().getTime()) {
      handleLogout();
    }
  }, [window.location.pathname]);

  const content = (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
      }}
    >
      <Scrollbar
        style={{
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
        }}
        options={{ suppressScrollX: true }}
      >
        <div>
          <Box sx={{ p: 2 }}>
            {sections &&
              sections.map(section => (
                <NavSection
                  key={section.title}
                  pathname={location.pathname}
                  sx={{
                    '& + &': {
                      mt: 3,
                    },
                  }}
                  {...section}
                />
              ))}
          </Box>
          <Divider />
        </div>
        <Box sx={{ p: 2 }}>
          <Typography color="textPrimary" variant="subtitle2">
            Need Help?
          </Typography>
          <Button
            color="primary"
            component={RouterLink}
            fullWidth
            sx={{ mt: 2 }}
            to="/docs"
            variant="contained"
          >
            Documentation
          </Button>
        </Box>
      </Scrollbar>
    </Box>
  );

  return (
    <Drawer
      anchor="left"
      open={openMobile}
      PaperProps={{
        sx: {
          backgroundColor: 'background.paper',
          height: 'calc(100% - 84px) !important',
          top: '84px !Important',
          width: openMobile ? 0 : 280,
        },
      }}
      variant="permanent"
    >
      {content}
    </Drawer>
  );
};

DashboardSidebar.propTypes = {
  onMobileClose: PropTypes.func,
  openMobile: PropTypes.bool,
};

export default DashboardSidebar;
