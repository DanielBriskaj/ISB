import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import PencilAltIcon from '../../../icons/PencilAlt';
import ArrowRightIcon from '../../../icons/ArrowRight';
import Label from 'src/view/materialUI/components/Label';
import { useSelector, useDispatch } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { status } from 'src/enums/status';
import supplierActions from 'src/modules/suppliers/supplierActions';
import Trash from 'src/icons/Trash';
import RoleSupplierStatusRender from 'src/helpers/supplierRoleStatusRender';

const getStatusLabel = invoiceStatus => {
  const map = {
    N: {
      color: 'error',
      text: 'N',
    },
    Y: {
      color: 'success',
      text: 'Y',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'success',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const SupplierRow = ({
  supplier,
  handleModalOpen,
  page,
  rowsPerPage,
  approved,
  handleDialogOpen,
  query,
}) => {
  const authData = useSelector(authSelector.authData);
  const role = authData.role;
  const dispatch = useDispatch();

  const assignSupplier = () => {
    const newStatus = RoleSupplierStatusRender(role, 'Assign');

    dispatch(
      supplierActions.updateStatus(
        {
          id: supplier.id,
          status: { supplierStatus: newStatus },
        },
        query,
        role,
        'Assigned',
      ),
    );
  };
  return (
    <TableRow hover key={supplier.id}>
      {Object.keys(supplier).map(key => {
        if (key === 'id') {
          return;
        }

        if (key === 'approved') {
          return (
            <TableCell key={key} align={'center'}>
              {supplier[key] && getStatusLabel(supplier[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            key={key}
            sx={key === 'companyName' ? { paddingLeft: 3 } : { paddingLeft: 0 }}
            align={
              key === 'supplierAccountId' ||
              key === 'userRole' ||
              key === 'userCode' ||
              key === 'city' ||
              key === 'userFullName'
                ? 'center'
                : 'left'
            }
          >
            {supplier[key] && supplier[key]}
          </TableCell>
        );
      })}
      <TableCell align="center">
        <IconButton onClick={() => handleModalOpen(supplier.id)}>
          <PencilAltIcon fontSize="small" />
        </IconButton>
        {role === 'PROCUREMENT_AUTHORIZER' || role === 'PROCUREMENT_INPUT' ? (
          <IconButton
            onClick={() =>
              handleDialogOpen({ id: supplier.id, type: 'delete' })
            }
          >
            <Trash fontSize="small" />
          </IconButton>
        ) : (
          ''
        )}
      </TableCell>
      {role === 'PROCUREMENT_AUTHORIZER' || role === 'PROCUREMENT_INPUT' ? (
        <TableCell align="center">
          <Button
            onClick={() => assignSupplier()}
            disabled={role !== status[supplier.approved]}
          >
            {role === 'PROCUREMENT_AUTHORIZER'
              ? 'Approve'
              : 'Send for Approval'}
          </Button>
        </TableCell>
      ) : (
        ''
      )}
    </TableRow>
  );
};

export default SupplierRow;
