import { useState, useEffect } from 'react';
import type { ChangeEvent } from 'react';
import {
  Box,
  Container,
  Divider,
  Grid,
  Button,
  Tab,
  Tabs,
  Typography,
} from '@material-ui/core';
import useSettings from '../../materialUI/hooks/useSettings';
import Form1 from '../../materialUI/components/widgets/forms/UserDetailsForm';
import Form2 from '../../materialUI/components/widgets/forms/OrganisationDetailsForm';
import Close from '../../../icons/X';
import { useDispatch, useSelector } from 'react-redux';
import supplierActions from 'src/modules/suppliers/supplierActions';
import supplierSelector from 'src/modules/suppliers/supplierSelector';
import { useForm, FormProvider } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { SupplierDetails } from 'src/models/data/suppliers/SuppliersData';
import { suppliersSchema } from 'src/modules/shared/yup/suppliersSchema';
import authSelector from 'src/modules/shared/authentication/authSelector';
import RoleSupplierStatusRender from 'src/helpers/supplierRoleStatusRender';

const tabs = [
  { label: 'Organisation Details', value: 'organization' },
  { label: 'User Details', value: 'user' },
];

const TabTemplate = props => {
  const { setModalOpen, supplierId, setDialogOpen, query } = props;
  const { settings } = useSettings();
  const [currentTab, setCurrentTab] = useState<string>('organization');

  const initialValues: SupplierDetails = {
    userFirstname: '',
    userLastname: '',
    userRole: '',
    userTelephone: '',
    userMobile: '',
    userEmail: '',
    userPreferredLanguage: '',
    userTimeZone: '',
    username: '',
    userCode: '',
    registrationDate: new Date().toISOString(),
    companyName: '',
    organisationLegalStructure: '',
    companyRegistrationNumber: '',
    euVatNumber: '',
    dunAndBradstreet: '',
    vatNumber: '',
    address: '',
    city: '',
    postalCode: '',
    country: '',
    state: '',
    mainPhoneNumber: '',
    organizationFaxNumber: '',
    webSite: '',
    bvd9: '',
    sapCode: '',
    alboCode: '',
    supplierAccountId: 0,
    isLocal: null,
    isBankClient: false,
    approved: 'NEW',
  };
  const supplierData = useSelector(supplierSelector.supplierData);
  const dispatch = useDispatch();
  const handleTabsChange = (event: ChangeEvent<{}>, value: string): void => {
    setCurrentTab(value);
  };
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const form = useForm({
    resolver: yupResolver(suppliersSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = data => {
    if (typeof supplierId === 'number') {
      dispatch(
        supplierActions.updateSupplier(
          { data, rawSupplierData: supplierData },
          supplierId,
          query,
        ),
      );
      setModalOpen(false);
    } else {
      dispatch(supplierActions.createSupplier(data, query));
      setModalOpen(false);
    }
  };

  useEffect(() => {
    if (typeof supplierId === 'number') {
      dispatch(supplierActions.getById(supplierId));
    }
  }, [dispatch, supplierId]);

  useEffect(() => {
    if (
      (supplierData &&
        Object.keys(supplierData).length === 0 &&
        Object.getPrototypeOf(supplierData) === Object.prototype) ||
      typeof supplierId !== 'number'
    ) {
      form.reset();
    } else {
      Object.keys(supplierData).forEach(key => {
        form.setValue(key as keyof SupplierDetails, supplierData[key]);
      });
    }
  }, [supplierData]);

  const assignSupplier = () => {
    const newStatus = RoleSupplierStatusRender(role, 'Assign');
    dispatch(
      supplierActions.updateStatus(
        {
          id: supplierData.id,
          status: { supplierStatus: newStatus },
        },
        query,
        role,
        'Assigned',
      ),
    );
    setModalOpen(false);
  };

  const rejectSupplier = () => {
    setDialogOpen(true);
  };

  const accInputFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'submit',
      onClick: () => {},
      label: 'Save',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: () => setModalOpen(false),
      label: 'Cancel',
    },
  ];

  const accAuthFormButtons = [
    {
      color: 'primary',
      sx: {
        m: '0 6px',
        p: '6px 10px',
        fontSize: '14px',
      },
      variant: 'contained',
      type: 'button',
      onClick: assignSupplier,
      label: 'Approve',
      disabled: supplierData.approved !== 'IN_APPROVAL',
    },
    {
      color: 'secondary',
      sx: {
        background: '#666',
        '&:hover': { background: '#333' },
        fontSize: '14px',
        p: '6px 10px',
      },
      variant: 'contained',
      type: 'button',
      onClick: rejectSupplier,
      label: 'Reject',
      disabled: supplierData.approved !== 'IN_APPROVAL',
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Supplier
              </Typography>
            </Grid>
            <Grid item>
              <Close
                onClick={() => setModalOpen(false)}
                style={{ cursor: 'pointer' }}
              />
            </Grid>
          </Grid>
          <Box sx={{ mt: 3 }}>
            <Tabs
              indicatorColor="primary"
              onChange={handleTabsChange}
              scrollButtons="auto"
              textColor="primary"
              value={currentTab}
              variant="scrollable"
            >
              {tabs.map(tab => (
                <Tab key={tab.value} label={tab.label} value={tab.value} />
              ))}
            </Tabs>
          </Box>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                {currentTab === 'user' && (
                  <Form1 setCurrentTab={setCurrentTab} />
                )}
                {currentTab === 'organization' && (
                  <Form2 setCurrentTab={setCurrentTab} />
                )}
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role === 'PROCUREMENT_AUTHORIZER' && (
                  <>
                    {accAuthFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                          disabled={button.disabled}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
                {role === 'PROCUREMENT_INPUT' && (
                  <>
                    {accInputFormButtons.map((button, i) => {
                      return (
                        <Button
                          key={i}
                          color={
                            button.color as 'inherit' | 'primary' | 'secondary'
                          }
                          sx={button.sx}
                          variant={
                            button.variant as 'text' | 'outlined' | 'contained'
                          }
                          type={button.type as 'submit' | 'button' | 'reset'}
                          onClick={button.onClick}
                        >
                          {button.label}
                        </Button>
                      );
                    })}
                  </>
                )}
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default TabTemplate;
