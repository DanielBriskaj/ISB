import { useEffect, useState, useCallback, useRef } from 'react';
import type { FC } from 'react';
import { Box } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { Helmet } from 'react-helmet-async';

import supplierSelector from 'src/modules/suppliers/supplierSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import DynamicTable from '../../materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from '../../materialUI/components/WidgetPreviewer';
import TabTemplate from 'src/view/dashboard/suppliers/TabTemplate';
import supplierActions from 'src/modules/suppliers/supplierActions';
import { suppliersFields } from 'src/enums/shared/headerFields/suppliersFields';
import { debounce } from 'lodash';

import Download from 'src/icons/Download';
import Upload from 'src/icons/Upload';
import Plus from 'src/icons/Plus';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import authSelector from 'src/modules/shared/authentication/authSelector';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import RoleSupplierStatusRender from 'src/helpers/supplierRoleStatusRender';

const SupplierTable: FC = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [supplierId, setSupplierId] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [companyName, setCompanyName] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const dispatch = useDispatch();
  const [sortDirection, setSortDirect] = useState<'asc' | 'desc'>('desc');
  const [approved, setApproved] = useState<
    '' | 'NEW' | 'IN_APPROVAL' | 'ACTIVE' | 'APPROVED'
  >('');

  const supplierData = useSelector(supplierSelector.supplierData);
  const suppliersState = useSelector(supplierSelector.suppliersDataArray);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const query: any = {};
  query.sort = `companyName,${sortDirection}`;
  query.companyName = companyName;
  query.size = limitPerPage;
  query.page = currentPage;
  query.approved = approved;

  useEffect(() => {
    setCurrentPage(0);
  }, [approved]);

  useEffect(() => {
    dispatch(supplierActions.read(query));
  }, [companyName, sortDirection, approved, limitPerPage, currentPage]);

  useEffect(() => {
    if (
      suppliersState &&
      Object.keys(suppliersState).length === 0 &&
      Object.getPrototypeOf(suppliersState) === Object.prototype
    ) {
    } else {
      if (suppliersState.suppliers) {
        setTableData(
          suppliersState.suppliers.map(supplier => ({
            companyName: supplier.companyName,
            id: supplier.id,
            city: supplier.city,
            supplierAccountId: supplier.supplierAccountId,
            userFullName: supplier.userFirstname + ' ' + supplier.userLastname,
            userRole: supplier.userRole,
            userCode: supplier.userCode,
            approved: supplier.approved,
          })),
        );
        setTotalItems(suppliersState.totalItems);
      }
    }
  }, [suppliersState]);

  const searchOnChange = event => {
    setCurrentPage(0);
    setCompanyName(event.target.value);
  };
  const handleSearch = useCallback(debounce(searchOnChange, 700), []);

  const searchFunctionArray = [
    {
      placeholder: 'Search by Company Name',
      function: handleSearch,
      customClass: 'search-input',
    },
  ];

  function handleDirectionSorting(sortDirection) {
    setSortDirect(sortDirection);
    setCurrentPage(0);
  }

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setCurrentPage(defaultPage);
    setLimitPerPage(newLimitPerPage);
  };

  function handleModalOpen(id?) {
    if (id) {
      setSupplierId(id);
    }
    setModalOpen(true);
  }

  function handleDialogOpen(id?) {
    if (id) {
      setSupplierId(id);
    }
    setDialogOpen(true);
  }

  const handleDelete = () => {
    dispatch(supplierActions.delete(supplierId?.id, query));
  };

  function rejectSupplier(data) {
    const newStatus = RoleSupplierStatusRender(role, 'Reject');

    dispatch(
      supplierActions.updateStatus(
        {
          id: supplierData.id,
          status: {
            supplierStatus: newStatus,
            authorizerFeedback: data?.reason,
          },
        },
        query,
        role,
        'Rejected',
      ),
    );
    setModalOpen(false);
    setDialogOpen(false);
  }

  function exportExelFile() {
    dispatch(supplierActions.exportExelFile());
  }
  function importSuppliers() {
    dispatch(supplierActions.importSuppliers());
  }

  const supplierButtonData = [
    {
      label: 'Import',
      startIcon: <Upload />,
      color: 'secondary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: importSuppliers,
    },
    {
      label: 'Add Supplier',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleModalOpen,
    },
    {
      label: 'Export',
      startIcon: <Download />,
      size: 'large',
      variant: 'contained',
      sx: {
        backgroundColor: '#4caf50',
        ':hover': {
          backgroundColor: '#4caf50',
          opacity: 0.8,
        },
      },
      onClick: exportExelFile,
    },
  ];

  const modalWrapperData = [
    {
      children: (
        <TabTemplate
          setModalOpen={setModalOpen}
          supplierId={supplierId}
          setDialogOpen={setDialogOpen}
          query={query}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          handleDelete={
            supplierId?.type === 'delete' ? handleDelete : rejectSupplier
          }
          message={
            supplierId?.type === 'delete'
              ? `Are you sure you want to delete this Supplier ?`
              : `Why do you want to reject this Supplier ?`
          }
          hasFeedback={supplierId?.type === 'delete' ? false : true}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
        }}
      >
        <Box>
          <WidgetPreviewer
            element={
              <DynamicTable
                tableType="supplierTable"
                headerFields={
                  role === 'ACCOUNTING_INPUT' ||
                  role === 'ACCOUNTING_AUTHORIZER'
                    ? suppliersFields.filter(field => field.label !== 'Process')
                    : suppliersFields
                }
                handleModalOpen={handleModalOpen}
                handleDialogOpen={handleDialogOpen}
                handleDirectionSorting={handleDirectionSorting}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                data={tableData}
                loading={loading}
                totalItems={totalItems}
                currentPage={currentPage}
                searchArrayOfFunctions={searchFunctionArray}
                buttonData={
                  role !== 'PROCUREMENT_INPUT'
                    ? supplierButtonData.filter(item => item.label === 'Export')
                    : supplierButtonData
                }
                limitPerPage={limitPerPage}
                setApproved={setApproved}
                approved={approved}
                query={query}
              />
            }
            name="Suppliers Table"
          />
        </Box>
        {modalWrapperData &&
          modalWrapperData.map(modalData => {
            return <ModalWrapper {...modalData} />;
          })}
      </Box>
    </>
  );
};

export default SupplierTable;
