import SupplierRow from 'src/view/dashboard/suppliers/SupplierRow';
import BranchRow from 'src/view/dashboard/menuConfig/branches/BranchRow';
import CostOwnerRow from 'src/view/dashboard/menuConfig/costOwners/CostOwnerRow';
import CostOwnerContractRow from 'src/view/dashboard/costOwnerContracts/CostOwnerContractRow';
import ContractRow from 'src/view/dashboard/contracts/ContractRow';
import InvoiceRow from 'src/view/dashboard/invoices/InvoiceRow';
import COInvoiceRow from 'src/view/dashboard/c-o-authorizerInvoices/COAuthorizerInvoiceRow';
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
import CostOwnerInvoiceRow from 'src/view/dashboard/costOwnerInvoices/CostOwnerInvoiceRow';
import PoRow from 'src/view/dashboard/po/PoRow';
import PrRow from 'src/view/dashboard/pr/PrRow';
import PoItemsRow from 'src/view/dashboard/po/poItems/PoItemsRow';
import UserRow from 'src/view/dashboard/menuConfig/users/UserRow';
import GlRow from 'src/view/dashboard/menuConfig/gl/GlRow';
import PrItemsRow from './pr/prItems/PrItemsRow';
import AuditRow from './history/audit/AuditRow';
import AdvancedInvoiceRow from './invoices/AcceptedInvoiceRow';
import ManualInvoiceRow from './costOwnerInvoices/ManualInvoiceRow';
import AvailableFundsRow from './pr/availableFunds/availableFundsRow';

const TableRowRender = ({
  object,
  handleProcessOpen,
  handleModalOpen,
  handleDialogOpen,
  handlePopupOpen,
  handleDelete,
  selected,
  setSelected,
  buttonData,
  index,
  tableFooterData,
  tableType,
  page,
  rowsPerPage,
  approved,
  sortDirection,
  isEditModal,
  isEditable,
  query,
}: any) => {
  for (const key in object) {
    switch (tableType) {
      case 'supplierTable':
        return (
          <SupplierRow
            supplier={object}
            handleModalOpen={handleModalOpen}
            page={page}
            rowsPerPage={rowsPerPage}
            approved={approved}
            handleDialogOpen={handleDialogOpen}
            query={query}
          />
        );
      case 'branchTable':
        return (
          <BranchRow
            branch={object}
            handleModalOpen={handleModalOpen}
            handleDialogOpen={handleDialogOpen}
            handleDelete={handleDelete}
            page={page}
            approved={approved}
            rowsPerPage={rowsPerPage}
          />
        );
      case 'costOwnerTable':
        return (
          <CostOwnerRow
            handleDialogOpen={handleDialogOpen}
            costOwner={object}
            handleModalOpen={handleModalOpen}
            handleDelete={handleDelete}
            page={page}
            rowsPerPage={rowsPerPage}
            approved={approved}
          />
        );
      case 'poTable':
        return (
          <PoRow
            po={object}
            handleModalOpen={handleModalOpen}
            handleDialogOpen={handleDialogOpen}
            handleDelete={handleDelete}
            page={page}
            rowsPerPage={rowsPerPage}
            sortDirection={sortDirection}
            query={query}
          />
        );
      case 'prTable':
        return (
          <PrRow
            pr={object}
            handleModalOpen={handleModalOpen}
            handleDelete={handleDelete}
            handleDialogOpen={handleDialogOpen}
            handlePopupOpen={handlePopupOpen}
            query={query}
          />
        );
      case 'costOwnerContractTable':
        return (
          <CostOwnerContractRow
            contract={object}
            page={page}
            rowsPerPage={rowsPerPage}
            handleModalOpen={handleModalOpen}
            handlePopupOpen={handlePopupOpen}
          />
        );
      case 'costOwnerInvoiceTable':
        return (
          <CostOwnerInvoiceRow
            invoice={object}
            buttonData={buttonData}
            page={page}
            rowsPerPage={rowsPerPage}
            handleModalOpen={handleModalOpen}
          />
        );
      case 'manualInvoicesTable':
        return (
          <ManualInvoiceRow
            invoice={object}
            buttonData={buttonData}
            page={page}
            rowsPerPage={rowsPerPage}
            handleDialogOpen={handleDialogOpen}
            handleModalOpen={handleModalOpen}
            handlePopupOpen={handlePopupOpen}
            handleProcessOpen={handleProcessOpen}
            handleDelete={handleDelete}
          />
        );
      case 'invoiceTable':
        return (
          <InvoiceRow
            invoice={object}
            buttonData={buttonData}
            page={page}
            rowsPerPage={rowsPerPage}
          />
        );
      case 'acceptedInvoiceTable':
        return (
          <AdvancedInvoiceRow
            invoice={object}
            buttonData={buttonData}
            page={page}
            rowsPerPage={rowsPerPage}
          />
        );
      case 'COInvoiceTable':
        return (
          <COInvoiceRow
            invoice={object}
            buttonData={buttonData}
            page={page}
            rowsPerPage={rowsPerPage}
            handleDialogOpen={handleDialogOpen}
          />
        );
      case 'poItemsTable':
        return (
          <PoItemsRow
            poItem={object}
            index={index}
            valuesArray={tableFooterData.valuesArray}
            setValuesArray={tableFooterData.setValuesArray}
            handleDelete={handleDelete}
            page={page}
            rowsPerPage={rowsPerPage}
            isEditModal={isEditModal}
            isEditable={isEditable}
          />
        );
      case 'prItemsTable':
        return (
          <PrItemsRow
            prItem={object}
            index={index}
            valuesArray={tableFooterData.valuesArray}
            setValuesArray={tableFooterData.setValuesArray}
            handleDelete={handleDelete}
            isEditModal={isEditModal}
            isEditable={isEditable}
          />
        );
      case 'availableFundsTable':
        return (
          <AvailableFundsRow
            availableFunds={object}
            index={index}
            valuesArray={tableFooterData.valuesArray}
            setValuesArray={tableFooterData.setValuesArray}
            handleDelete={handleDelete}
            isEditModal={isEditModal}
            isEditable={isEditable}
          />
        );
      case 'contractTable':
        return (
          <ContractRow
            contract={object}
            handleModalOpen={handleModalOpen}
            handleDialogOpen={handleDialogOpen}
            handlePopupOpen={handlePopupOpen}
            handleDelete={handleDelete}
            setSelected={setSelected}
            selected={selected}
            page={page}
            rowsPerPage={rowsPerPage}
            approved={approved}
            sort={sortDirection}
            query={query}
          />
        );
      case 'glTable':
        return (
          <GlRow
            gl={object}
            handleDelete={handleDelete}
            handleModalOpen={handleModalOpen}
            handleDialogOpen={handleDialogOpen}
            page={page}
            rowsPerPage={rowsPerPage}
            approved={approved}
          />
        );
      case 'userTable':
        return (
          <UserRow
            user={object}
            page={page}
            rowsPerPage={rowsPerPage}
            handleModalOpen={handleModalOpen}
          />
        );
      case 'auditTable':
        return (
          <AuditRow audit={object} page={page} rowsPerPage={rowsPerPage} />
        );
    }
  }
};

export default TableRowRender;
