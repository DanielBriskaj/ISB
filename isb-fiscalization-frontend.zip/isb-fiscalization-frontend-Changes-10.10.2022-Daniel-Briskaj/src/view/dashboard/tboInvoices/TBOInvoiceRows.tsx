import {
  TableBody,
  TableRow,
  TableCell,
  IconButton,
  Button,
} from '@material-ui/core';
import moment from 'moment';
import React from 'react';
import tboInvoiceColumns from 'src/enums/shared/headerFields/tboInvoiceFields';
import numberWithCommas from 'src/helpers/numberWithCommas';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import { getStatusLabel } from '../invoices/InvoiceRow';
import Download from 'src/icons/Download';
import { useDispatch } from 'react-redux';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import { INVOICE_STATUS } from 'src/modules/invoices/invoiceReducer';

interface TBOInvoiceRowProps {
  loading: boolean;
  tableData: Array<any>;
  role: string;
  handleModalOpen: any;
}
const TBOInvoiceRows: React.FC<TBOInvoiceRowProps> = ({
  loading,
  tableData,
  role,
  handleModalOpen,
}) => {
  const dispatch = useDispatch();
  const style: any = {
    maxWidth: '150px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
  };

  const handleDownloadMemo = (id, invoiceNumber) => {
    dispatch(
      invoiceActions.exportMemo({
        id,
        invoiceNumber,
      }),
    );
  };

  return (
    <TableBody>
      {loading ? (
        <TableRow>
          <TableCell
            sx={{
              textAlign: 'center',
              fontSize: '1.01rem',
              fontWeight: '500',
              color: '#777',
              padding: '1.15rem 0.9rem',
            }}
            colSpan={tboInvoiceColumns?.length}
          >
            Data is loading ...
          </TableCell>
        </TableRow>
      ) : tableData?.length === 0 ? (
        <TableRow>
          <TableCell
            sx={{
              textAlign: 'center',
              fontSize: '1.01rem',
              fontWeight: '500',
              color: '#777',
              padding: '1.15rem 0.9rem',
            }}
            colSpan={tboInvoiceColumns?.length}
          >
            There are no data for this module!
          </TableCell>
        </TableRow>
      ) : (
        tableData?.map((row, index) => {
          return (
            <>
              <TableRow hover sx={{ height: '50px' }} key={row?.id}>
                <TableCell
                  align="center"
                  sx={{
                    paddingLeft: 1.5,
                    maxWidth: '150px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {row?.nipt}
                </TableCell>
                <TableCell
                  align="center"
                  sx={{
                    paddingLeft: 1.5,
                    maxWidth: '150px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {row?.invoiceNumber}
                </TableCell>
                <TableCell align="center" width={180}>
                  {row?.dueDate}
                </TableCell>
                <TableCell align="center" width={180}>
                  {row?.checkedTime
                    ? moment(row?.checkedTime).format('YYYY-MM-DD')
                    : 'N/A'}
                </TableCell>
                <TableCell align="right" width={180}>
                  {numberWithCommas(row?.amount.toFixed(2))}
                </TableCell>
                <TableCell align="center" sx={style}>
                  {getStatusLabel(row?.invoiceStatus)}
                </TableCell>
                <TableCell align="center" width={100}>
                  <IconButton
                    onClick={() =>
                      handleDownloadMemo(row?.id, row?.invoiceNumber)
                    }
                    disabled={
                      row?.invoiceStatus !== INVOICE_STATUS.APPROVED_PAYMENT &&
                      row?.invoiceStatus !== INVOICE_STATUS.PAID
                    }
                  >
                    <Download />
                  </IconButton>
                </TableCell>
                <TableCell align="center" width={100}>
                  <Button
                    onClick={() =>
                      handleModalOpen({
                        ...row,
                        status: row?.invoiceStatus,
                        suplier: row?.supplier?.companyName,
                      })
                    }
                    disabled={
                      role === ROLES.TBO_INPUT &&
                      row?.invoiceStatus !== INVOICE_STATUS.APPROVED_PAYMENT
                    }
                  >
                    {role === ROLES.TBO_INPUT ? 'Pay' : 'View'}
                  </Button>
                </TableCell>
              </TableRow>
            </>
          );
        })
      )}
    </TableBody>
  );
};
export default TBOInvoiceRows;
