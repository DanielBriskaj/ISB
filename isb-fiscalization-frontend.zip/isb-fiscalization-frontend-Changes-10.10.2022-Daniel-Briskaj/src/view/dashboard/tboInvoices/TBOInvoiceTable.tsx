import { Box, Card, Table, TablePagination } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import Scrollbar from 'src/view/materialUI/components/Scrollbar';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import tboInvoiceColumns from 'src/enums/shared/headerFields/tboInvoiceFields';
import TBOInvoiceRows from './TBOInvoiceRows';
import TabHeader from '../TabHeader';
import AcceptedInvoiceFormPopup from '../invoices/AcceptedInvoiceFormPopup';
import TBOInvoiceFilter, { TBOInvoiceStatus } from './TBOInvoiceFIlters';

const TBOInvoiceTable: React.FC = () => {
  const dispatch = useDispatch();

  const [tableData, setTableData] = useState([]);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState<number>(10);
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [sortDirection, setSortDirect] = useState<'asc' | 'desc'>('desc');
  const [selectedInvoice, setSelectedInvoice] = useState({});
  const [approved, setApproved] = useState<TBOInvoiceStatus>([
    'APPROVED_PAYMENT',
    'PAID',
  ]);

  const loading = useSelector(statusSelector.loading);
  const invoicesState = useSelector(invoiceSelector.acceptedInvoicesData);
  const authData = useSelector(authSelector.authData);
  const { role } = authData;

  const query: any = {
    page: currentPage,
    size: rowsPerPage,
    sort: ['dueDate', sortDirection],
    invoiceStatus: approved,
  };

  useEffect(() => {
    dispatch(invoiceActions.readAcceptInBnt(query));
  }, [currentPage, rowsPerPage, sortDirection, approved]);

  useEffect(() => {
    if (invoicesState?.invoices) {
      setTableData(invoicesState?.invoices);
      setTotalItems(invoicesState?.totalItems);
    } else {
      setTableData([]);
    }
  }, [invoicesState]);

  const onPageChange = (event, page) => {
    setCurrentPage(page);
  };
  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setRowsPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  function handleDirectionSorting(sortDirection) {
    setSortDirect(sortDirection);
    setCurrentPage(0);
  }

  const handleModalOpen = invoice => {
    setModalOpen(true);
    setSelectedInvoice(invoice);
  };

  const modalWrapperData = [
    {
      children: (
        <AcceptedInvoiceFormPopup
          setModalOpen={setModalOpen}
          data={selectedInvoice}
          tab="invoices"
          page={currentPage}
          rowsPerPage={rowsPerPage}
          query={query}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
  ];

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
      }}
    >
      <WidgetPreviewer
        element={
          <Box
            sx={{
              backgroundColor: 'background.default',
              p: 3,
            }}
          >
            <Card sx={{ overflow: 'visible' }}>
              <Box
                sx={{
                  alignItems: 'center',
                  display: 'flex',
                  flexWrap: 'wrap',
                  justifyContent: 'space-between',
                  m: -1,
                  p: 2,
                  mb: 1.5,
                }}
              >
                <TBOInvoiceFilter
                  approved={approved}
                  setApproved={setApproved}
                  setCurrentPage={setCurrentPage}
                />
              </Box>
              <Scrollbar>
                <Box sx={{ minWidth: 800 }}>
                  <Table padding="none">
                    <TabHeader
                      headerFields={
                        role === ROLES.TBO_AUTHORIZER
                          ? tboInvoiceColumns.filter(
                              field => field.label !== 'Pay Invoice',
                            )
                          : tboInvoiceColumns.filter(
                              field => field.label !== 'View Memo',
                            )
                      }
                      handleDirectionSorting={handleDirectionSorting}
                    />
                    <TBOInvoiceRows
                      loading={loading}
                      tableData={tableData}
                      role={role}
                      handleModalOpen={handleModalOpen}
                    />
                  </Table>
                </Box>
              </Scrollbar>
              {totalItems > 0 && (
                <TablePagination
                  component="div"
                  count={totalItems ? totalItems : 1}
                  page={currentPage}
                  rowsPerPage={rowsPerPage}
                  rowsPerPageOptions={[5, 10, 25]}
                  onPageChange={(event, page) => onPageChange(event, page)}
                  onRowsPerPageChange={event => onChangeRowsPerPage(event)}
                />
              )}
            </Card>
          </Box>
        }
        name="Invoices"
      />
      {modalWrapperData &&
        modalWrapperData.map((modalData, index) => {
          return <ModalWrapper key={index} {...modalData} />;
        })}
    </Box>
  );
};
export default TBOInvoiceTable;
