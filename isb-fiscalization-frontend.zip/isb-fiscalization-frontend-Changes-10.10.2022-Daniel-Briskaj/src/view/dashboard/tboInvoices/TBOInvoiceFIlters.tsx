import { Box, TextField } from '@material-ui/core';
import React from 'react';

export type TBOInvoiceStatus =
  | ['APPROVED_PAYMENT', 'PAID']
  | 'APPROVED_PAYMENT'
  | 'PAID';

const invoiceStatusOptions = [
  { value: ['APPROVED_PAYMENT', 'PAID'], label: 'ALL' },
  { value: 'APPROVED_PAYMENT', label: 'APPROVED PAYMENT' },
  { value: 'PAID', label: 'PAID' },
];

interface TBOInvoiceFilterProps {
  setCurrentPage: React.Dispatch<React.SetStateAction<number>>;
  approved: TBOInvoiceStatus;
  setApproved: React.Dispatch<React.SetStateAction<TBOInvoiceStatus>>;
}
const TBOInvoiceFilter: React.FC<TBOInvoiceFilterProps> = ({
  setCurrentPage,
  approved,
  setApproved,
}) => {
  return (
    <Box sx={{ m: 1, display: 'flex', alignItems: 'center' }}>
      <Box
        sx={{
          m: 1,
          maxWidth: '100%',
          width: 240,
        }}
      >
        <TextField
          onChange={event => {
            setApproved(event.target.value as TBOInvoiceStatus);
            setCurrentPage(0);
          }}
          fullWidth
          size="small"
          label={'Filter by status'}
          name="filterByStatus"
          select
          InputLabelProps={{ shrink: true }}
          inputProps={{
            style: {
              minWidth: 110,
              padding: '4.5px 14px',
            },
          }}
          SelectProps={{
            native: true,
          }}
          variant="outlined"
        >
          {invoiceStatusOptions.map(
            (invoiceStatus: { value: string; label: string }) => {
              return (
                <option
                  selected={approved === invoiceStatus.value}
                  value={invoiceStatus.value}
                >
                  {invoiceStatus.label}
                </option>
              );
            },
          )}
        </TextField>
      </Box>
    </Box>
  );
};

export default TBOInvoiceFilter;
