import { TableCell, TableRow, IconButton, TextField } from '@material-ui/core';
import Trash from '../../../../icons/Trash';
import { useFormContext, useFieldArray } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { ErrorMessage } from '@hookform/error-message';
import ReactSelectInput from 'src/view/materialUI/components/widgets/formFields/reactSelect';
import { currency } from 'src/enums/currency';
import { useSelector } from 'react-redux';
import prSelector from 'src/modules/PR/prSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import numberWithCommas from 'src/helpers/numberWithCommas';

const AvailableFundsRow = props => {
  const {
    availableFunds,
    index,
    setValuesArray,
    valuesArray,
    handleDelete,
    isEditable,
  } = props;

  const prData = useSelector(prSelector.prData);
  const prStatus = prData.prStatus;
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const { register, formState: errors, setValue, getValues } = useFormContext();
  const { remove } = useFieldArray({
    name: 'availableFunds', // unique name for your Field Array
  });

  const [amountExpensedYtd, setAmountExpensedYtd] = useState(0);
  const [budgetedAmount, setBudgetedAmount] = useState(0);
  const [stateValue, setStateValue] = useState(0);

  function round(num) {
    var m = Number((Math.abs(num) * 100).toPrecision(15));
    return (Math.round(m) / 100) * Math.sign(num);
  }

  useEffect(() => {
    if (getValues(`availableFunds.${index}.amountExpensedYtd`)) {
      setAmountExpensedYtd(
        getValues(`availableFunds.${index}.amountExpensedYtd`),
      );
    }
    if (getValues(`availableFunds.${index}.budgetedAmount`)) {
      setBudgetedAmount(getValues(`availableFunds.${index}.budgetedAmount`));
    }
  }, []);

  useEffect(() => {
    setStateValue(budgetedAmount - amountExpensedYtd);
  }, [amountExpensedYtd, budgetedAmount]);

  useEffect(() => {
    setValuesArray(values => [
      ...values.slice(0, index),
      stateValue,
      ...values.slice(index + 1),
    ]);
  }, [stateValue]);

  return (
    <TableRow hover key={availableFunds.id}>
      {Object.keys(availableFunds).map(key => {
        if (key === 'id') {
          return;
        }
        if (key === 'addRow') {
          return;
        }
        if (key === 'isFocused') {
          return;
        }
        if (key === 'remainingAmount') {
          return;
        }
        if (key === 'currency') {
          return (
            <TableCell
              key={availableFunds['id'] + '_' + key}
              sx={{ paddingRight: 1.5, paddingY: 1, width: '220px' }}
            >
              <div className="pr-item-select">
                <ReactSelectInput
                  selectedValue={undefined}
                  menuHeight={undefined}
                  md={12}
                  xs={12}
                  options={currency}
                  name={`availableFunds.${index}.${key}`}
                  label="Currency"
                  errors={errors}
                  register={register}
                  setValue={setValue}
                  handleOnInputChange={e => {}}
                  handleOnMenuScrollToBottom={e => {}}
                  handleResetSearch={e => {}}
                  isClearable={false}
                  defaultValue={
                    availableFunds?.currency && {
                      label: currency?.find(
                        temp => temp?.value === availableFunds?.currency,
                      )?.label,
                      value: {
                        id: availableFunds?.currency,
                      },
                    }
                  }
                  disabled={
                    role !== 'COST_OWNER' ||
                    (role === 'COST_OWNER' && isEditable === false)
                  }
                  isMulti={false}
                />
              </div>
            </TableCell>
          );
        }
        return (
          <TableCell
            key={availableFunds['id'] + '_' + key}
            sx={{ paddingRight: 1.5, paddingY: 1 }}
            align={'center'}
            width={
              key === 'amountExpensedYtd' || key === 'budgetedAmount'
                ? '250px'
                : key === 'projectName'
                ? '350px'
                : ''
            }
          >
            <TextField
              key={availableFunds['id']}
              ref={register}
              {...register(`availableFunds.${index}.${key}`)}
              onChange={event => {
                if (key === 'amountExpensedYtd') {
                  setAmountExpensedYtd(+event.target.value);
                }
                if (key === 'budgetedAmount') {
                  setBudgetedAmount(+event.target.value);
                }
                setValue(`availableFunds.${index}.${key}`, event.target.value);
              }}
              autoFocus={key === 'projectName' && availableFunds.isFocused}
              fullWidth
              defaultValue={key === 'projectName' ? ' ' : '0.00'}
              size="small"
              name={`availableFunds.${index}.${key}`}
              variant="standard"
              type={key === 'projectName' ? 'text' : 'number'}
              InputProps={{
                disableUnderline: true,
                inputProps:
                  key === 'projectName'
                    ? {
                        style: { textAlign: 'center' },
                      }
                    : {
                        style: { textAlign: 'center' },
                        min: 0,
                        step: 0.01,
                      },
              }}
              disabled={
                role !== 'COST_OWNER' ||
                (role === 'COST_OWNER' && isEditable === false)
              }
            />
            {errors.errors && (
              <ErrorMessage
                errors={errors.errors}
                name={`availableFunds.${index}.${key}`}
                render={({ message }) => (
                  <p
                    style={{
                      color: 'red',
                      margin: '0px',
                      padding: '5px 10px 0px 0px',
                    }}
                  >
                    {message}
                  </p>
                )}
              />
            )}
          </TableCell>
        );
      })}
      <TableCell sx={{ paddingX: 5, paddingY: 1 }} align="center">
        {numberWithCommas(round(stateValue).toFixed(2))}
      </TableCell>
      <TableCell align="center">
        <IconButton
          onClick={() => {
            const index = valuesArray.indexOf(stateValue);
            setValuesArray(values => [...values.splice(index + 1)]);
            remove(index);
            handleDelete(index);
          }}
          disabled={
            role !== 'COST_OWNER' ||
            (role === 'COST_OWNER' && isEditable === false)
          }
        >
          <Trash fontSize="small" />
        </IconButton>
      </TableCell>
    </TableRow>
  );
};

export default AvailableFundsRow;
