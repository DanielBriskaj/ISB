import { useEffect, useState } from 'react';
import { TableCell, TableRow } from '@material-ui/core';
import { useSelector } from 'react-redux';
import prSelector from 'src/modules/PR/prSelector';
import DynamicTable from '../../../materialUI/components/widgets/tables/DynamicTable';
import { prItemsFields } from 'src/enums/shared/headerFields/prItemsFields';
import Plus from 'src/icons/Plus';
import authSelector from 'src/modules/shared/authentication/authSelector';
import numberWithCommas from 'src/helpers/numberWithCommas';

const PrItemsTable = () => {
  const prData = useSelector(prSelector.prData);
  const [tableData, setTableData] = useState([]);
  const [valuesArray, setValuesArray] = useState([]);
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const addRowItem = {
    description: '',
    goodCategory: '',
    quantity: '',
    unitCost: '',
    deliveryPlace: '',
    deliveryDate: '',
  };

  let isEditModal: boolean;
  let isEditable: boolean;

  if (Object.keys(prData).length !== 0) {
    isEditModal = true;
  } else isEditModal = false;

  if (Object.keys(prData).length !== 0 && prData.prStatus !== 'NEW') {
    isEditable = false;
  } else isEditable = true;

  function addRow() {
    setTableData(state => [...state, { ...addRowItem, isFocused: true }]);
  }

  function round(num) {
    var m = Number((Math.abs(num) * 100).toPrecision(15));
    return (Math.round(m) / 100) * Math.sign(num);
  }

  function handleDelete(index) {
    var array = [...tableData]; // make a separate copy of the array
    array.splice(index, 1);
    setTableData(array);
  }

  useEffect(() => {
    if (Array.isArray(prData['prItems']) && prData['prItems'].length > 0) {
      setTableData(prData['prItems']);
    }
  }, [prData]);

  const tableFooterData = {
    children: (
      <TableRow>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}></TableCell>
        <TableCell align={'center'}>
          Total Values :{' '}
          {numberWithCommas(
            round(valuesArray.reduce((a, v) => (a = a + v), 0)).toFixed(2),
          )}
        </TableCell>
        <TableCell align={'center'}></TableCell>
      </TableRow>
    ),
    setValuesArray,
    valuesArray,
  };

  const prButtonData =
    isEditModal && isEditable === false
      ? [{}]
      : [
          {
            label: 'Add Item',
            startIcon: <Plus />,
            color: 'primary',
            size: 'large',
            variant: 'contained',
            sx: { mr: 1 },
            onClick: addRow,
          },
        ];

  return (
    <>
      <div className="pr-items-table">
        <DynamicTable
          tableType="prItemsTable"
          headerFields={prItemsFields}
          data={tableData}
          buttonData={role === 'COST_OWNER' ? prButtonData : []}
          tableFooterData={tableFooterData}
          handleDelete={handleDelete}
          isEditModal={isEditModal}
          isEditable={isEditable}
        />
      </div>
    </>
  );
};

export default PrItemsTable;
