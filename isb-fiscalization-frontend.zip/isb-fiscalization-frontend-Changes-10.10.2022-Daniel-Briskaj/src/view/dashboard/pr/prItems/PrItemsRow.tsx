import { TableCell, TableRow, IconButton, TextField } from '@material-ui/core';
import Trash from '../../../../icons/Trash';
import { useFormContext, useFieldArray } from 'react-hook-form';
import { useState, useEffect, useRef } from 'react';
import { ErrorMessage } from '@hookform/error-message';
import ReactSelectInput from 'src/view/materialUI/components/widgets/formFields/reactSelect';
import { commodityCategory } from 'src/enums/commodityCategory';
import moment from 'moment';
import { useSelector } from 'react-redux';
import prSelector from 'src/modules/PR/prSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import numberWithCommas from 'src/helpers/numberWithCommas';

const PrItemsRow = props => {
  const {
    prItem,
    index,
    setValuesArray,
    valuesArray,
    handleDelete,
    isEditable,
  } = props;
  const prData = useSelector(prSelector.prData);
  const prStatus = prData.prStatus;
  const authData = useSelector(authSelector.authData);
  const role = authData.role;

  const {
    register,
    formState: errors,
    setValue,
    getValues,
    watch,
  } = useFormContext();
  const { remove } = useFieldArray({
    name: 'prItems', // unique name for your Field Array
    // keyName: "id", default to "id", you can change the key name
  });

  const [unitCost, setUnitCost] = useState(0);
  const [quantity, setQuantity] = useState(0);
  const [stateValue, setStateValue] = useState(0);

  const categoryCode = watch('code');
  const [subCategoryOptions, setSubCategoryOptions] = useState([]);
  const initialRenderRef = useRef(false);

  useEffect(() => {
    if (initialRenderRef.current) {
      setValue(`prItems.${index}.goodCategory`, null);
      setSelected([]);
    } else {
      initialRenderRef.current = true;
    }
    setSubCategoryOptions(
      commodityCategory.find(temp => temp.value === categoryCode)?.subcategory,
    );
  }, [categoryCode]);

  function round(num) {
    var m = Number((Math.abs(num) * 100).toPrecision(15));
    return (Math.round(m) / 100) * Math.sign(num);
  }

  useEffect(() => {
    if (getValues(`prItems.${index}.unitCost`)) {
      setUnitCost(getValues(`prItems.${index}.unitCost`));
    }
    if (getValues(`prItems.${index}.quantity`)) {
      setQuantity(getValues(`prItems.${index}.quantity`));
    }
  }, []);

  useEffect(() => {
    setStateValue(unitCost * quantity);
  }, [unitCost, quantity]);

  useEffect(() => {
    setValuesArray(values => [
      ...values.slice(0, index),
      stateValue,
      ...values.slice(index + 1),
    ]);
  }, [stateValue, prData]);

  const dateValue = moment(new Date()).format('YYYY-MM-DD');
  var [selected, setSelected] = useState(undefined);
  return (
    <TableRow hover key={prItem.id}>
      {Object.keys(prItem).map(key => {
        if (key === 'id') {
          return;
        }
        if (key === 'addRow') {
          return;
        }
        if (key === 'isFocused') {
          return;
        }
        if (key === 'totalValue') {
          return;
        }
        if (key === 'goodCategory') {
          return (
            <TableCell
              key={prItem['id'] + '_' + key}
              sx={{ paddingRight: 1.5, paddingY: 1, width: '250px' }}
            >
              <div className="pr-item-select">
                <ReactSelectInput
                  selectedValue={selected}
                  menuHeight={300}
                  md={12}
                  xs={12}
                  options={subCategoryOptions}
                  name={`prItems.${index}.${key}`}
                  label="Good Category"
                  errors={errors}
                  register={register}
                  setValue={setValue}
                  handleOnInputChange={e => {}}
                  handleOnMenuScrollToBottom={e => {}}
                  handleResetSearch={e => {}}
                  isClearable={false}
                  defaultValue={
                    prItem?.goodCategory && {
                      label: commodityCategory
                        ?.find(cat =>
                          cat?.subcategory?.find(
                            temp => temp?.value === prItem?.goodCategory,
                          ),
                        )
                        ?.subcategory?.find(
                          temp => temp?.value === prItem?.goodCategory,
                        )?.label,
                      value: {
                        id: prItem?.goodCategory,
                      },
                    }
                  }
                  disabled={
                    !categoryCode ||
                    role !== 'COST_OWNER' ||
                    (role === 'COST_OWNER' && isEditable === false)
                  }
                  isMulti={false}
                />
              </div>
            </TableCell>
          );
        }
        return (
          <TableCell
            key={prItem['id'] + '_' + key}
            sx={{ paddingRight: 1.5, paddingY: 1 }}
            align={key === 'quantity' || key === 'unitCost' ? 'center' : 'left'}
            width={
              key === 'quantity' || key === 'unitCost'
                ? '120px'
                : key === 'deliveryPlace' || key === 'deliveryDate'
                ? '160px'
                : ''
            }
          >
            <TextField
              key={prItem['id']}
              ref={register}
              {...register(`prItems.${index}.${key}`)}
              onChange={event => {
                if (key === 'quantity') {
                  setQuantity(+event.target.value);
                }
                if (key === 'unitCost') {
                  setUnitCost(+event.target.value);
                }
                setValue(`prItems.${index}.${key}`, event.target.value);
              }}
              autoFocus={key === 'description' && prItem.isFocused}
              fullWidth
              defaultValue={
                key === 'description' || key === 'deliveryPlace'
                  ? ' '
                  : key === 'deliveryDate'
                  ? dateValue
                  : key === 'quantity'
                  ? '1'
                  : '0.00'
              }
              size="small"
              name={`prItems.${index}.${key}`}
              variant="standard"
              type={
                key === 'description' || key === 'deliveryPlace'
                  ? 'text'
                  : key === 'deliveryDate'
                  ? 'date'
                  : 'number'
              }
              InputProps={{
                disableUnderline: true,
                inputProps:
                  key === 'description'
                    ? {
                        style: { textAlign: 'center' },
                      }
                    : {
                        style: { textAlign: 'center' },
                        min: 0,
                        step: key === 'quantity' ? 1 : 0.01,
                      },
              }}
              disabled={
                role !== 'COST_OWNER' ||
                (role === 'COST_OWNER' && isEditable === false)
              }
            />
            {errors.errors && (
              <ErrorMessage
                errors={errors.errors}
                name={`prItems.${index}.${key}`}
                render={({ message }) => (
                  <p
                    style={{
                      color: 'red',
                      margin: '0px',
                      padding: '5px 10px 0px 0px',
                    }}
                  >
                    {message}
                  </p>
                )}
              />
            )}
          </TableCell>
        );
      })}
      <TableCell sx={{ paddingX: 5, paddingY: 1 }} align="center">
        {numberWithCommas(round(stateValue).toFixed(2))}
      </TableCell>
      <TableCell align="center">
        <IconButton
          onClick={() => {
            const index = valuesArray.indexOf(stateValue);
            setValuesArray(values => [...values.splice(index + 1)]);
            remove(index);
            handleDelete(index);
          }}
          disabled={
            role !== 'COST_OWNER' ||
            (role === 'COST_OWNER' && isEditable === false)
          }
        >
          <Trash fontSize="small" />
        </IconButton>
      </TableCell>
    </TableRow>
  );
};

export default PrItemsRow;
