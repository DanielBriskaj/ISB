import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import PencilAltIcon from '../../../icons/PencilAlt';
import Download from '../../../icons/Download';
import Trash from 'src/icons/Trash';
import Upload from 'src/icons/Upload';
import authSelector from 'src/modules/shared/authentication/authSelector';
import prActions from 'src/modules/PR/prActions';
import RolePOstatusRender from 'src/helpers/POhelplers/RolePOstatusRender';
import { poStatus } from 'src/enums/status';
import notificationThrower from 'src/helpers/notificationThrower';
import IsAuthorizer from 'src/helpers/isAuthorizer';
import getPOStatusLabel from 'src/helpers/POhelplers/getPOStatusLabel';

const PrRow = props => {
  const {
    pr,
    handleModalOpen,
    handleDelete,
    handleDialogOpen,
    query,
    handlePopupOpen,
  } = props;
  const authData = useSelector(authSelector.authData);
  const { role } = authData;
  const dispatch = useDispatch();

  const exportPrData = async () => {
    dispatch(prActions.exportExelFile(pr?.id));
  };

  const assignPR = () => {
    const payload: any = {};
    payload.data = { prStatus: RolePOstatusRender(role, 'Assign') };
    payload.id = pr.id;

    if (pr?.prItems?.length < 1) {
      notificationThrower({
        type: 'warning',
        message: 'Please Add Purchase Request Items To Continue',
      });
    } else {
      dispatch(prActions.changeStatusPR(query, payload, role, 'Assigned'));
    }
  };

  return (
    <TableRow hover key={pr.id}>
      {pr &&
        Object.keys(pr).map(key => {
          if (key === 'id') {
            return;
          }
          if (key === 'prItems') {
            return;
          }
          if (key === 'prStatus') {
            return (
              <TableCell align="center" key={key}>
                {pr[key] && getPOStatusLabel(pr[key])}
              </TableCell>
            );
          }
          if (key === 'subject' || key === 'place') {
            return (
              <TableCell
                key={key}
                sx={{
                  minWidth: '150px',
                  paddingLeft: 0,
                  maxWidth: '200px',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                }}
                align="center"
              >
                {pr[key] && pr[key]}
              </TableCell>
            );
          }
          return (
            <TableCell
              key={key}
              sx={key === 'code' ? { paddingLeft: 3 } : { paddingLeft: 0 }}
              align={
                key === 'currency' ||
                key === 'date' ||
                key === 'previousCurrency' ||
                key === 'unitType'
                  ? 'center'
                  : 'left'
              }
            >
              {pr[key] && pr[key]}
            </TableCell>
          );
        })}
      <TableCell align="center">
        <IconButton
          disabled={
            role !== poStatus[pr.prStatus] || poStatus['NEW'] ? false : true
          }
          onClick={() => handleModalOpen(pr.id)}
        >
          <PencilAltIcon fontSize="small" />
        </IconButton>
        {role === 'COST_OWNER' ? (
          <>
            <IconButton
              onClick={() => handleDialogOpen({ id: pr.id, type: 'delete' })}
            >
              <Trash fontSize="small" />
            </IconButton>
          </>
        ) : (
          ''
        )}
        <IconButton
          onClick={() => {
            handlePopupOpen(pr.id);
          }}
        >
          <Upload fontSize="small" />
        </IconButton>
        <IconButton
          disabled={
            pr.prStatus === 'APPROVED' || pr.prStatus === 'COMPLETED'
              ? false
              : true
          }
          onClick={() => exportPrData()}
        >
          <Download />
        </IconButton>
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => assignPR()}
          disabled={role !== poStatus[pr.prStatus]}
        >
          {role === 'COST_OWNER_AUTHORIZER' || role === 'PROCUREMENT_AUTHORIZER'
            ? 'Approve'
            : 'Send For Approval'}
        </Button>
        {role !== 'COST_OWNER' && (
          <Button
            onClick={() => {
              handleDialogOpen(pr.id);
            }}
            disabled={role !== poStatus[pr.prStatus]}
          >
            Reject
          </Button>
        )}
      </TableCell>
    </TableRow>
  );
};

export default PrRow;
