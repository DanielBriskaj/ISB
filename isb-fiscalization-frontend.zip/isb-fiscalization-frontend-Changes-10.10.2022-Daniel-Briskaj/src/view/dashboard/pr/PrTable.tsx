import React, { useEffect, useState } from 'react';
import { Box, TextField } from '@material-ui/core';
import DynamicTable from '../../materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from '../../materialUI/components/WidgetPreviewer';
import { useSelector, useDispatch } from 'react-redux';
import prActions from 'src/modules/PR/prActions';
import prSelector from 'src/modules/PR/prSelector';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import Plus from 'src/icons/Plus';
import PrFormPopup from './PrFormPopup';
import { prFields } from 'src/enums/shared/headerFields/prFields';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import StatusArrayRender from 'src/helpers/POhelplers/statusArrayRender';
import RolePOstatusRender, {
  ApproveAllStatusRender,
} from 'src/helpers/POhelplers/RolePOstatusRender';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import IsAuthorizer from 'src/helpers/isAuthorizer';
import UploadFilesPrPopup from './UploadFilesPrPopup';
import notificationThrower from 'src/helpers/notificationThrower';

type PRStatusInput = '' | 'NEW' | 'COA' | 'PRI' | 'PRA' | 'APPROVED';
const PRStatusOptions = [
  { value: '', label: 'ALL' },
  { value: 'NEW', label: 'NEW' },
  { value: 'COA', label: 'COA' },
  { value: 'PRI', label: 'PRI' },
  { value: 'PRA', label: 'PRA' },
  { value: 'APPROVED', label: 'APPROVED' },
];
const PrTable = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [popupOpen, setPopupOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [prId, setPrId] = useState(null);
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [sortDirection, setSortDirection] = useState('desc');
  const [statusFilter, setStatusFilter] = useState<PRStatusInput>('');

  const dispatch = useDispatch();
  const prsData = useSelector(prSelector.purchaseRequestData);
  const loading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const { role, division, costOwnerId } = authData;

  const prStatus = StatusArrayRender(role);

  const removeUnderscore = word => {
    const words = word.slice(1).split('_');
    return words.join('.');
  };

  const query: any = {};
  query.size = limitPerPage;
  query.page = currentPage;
  query.prStatus = statusFilter;
  query.sort = `id,${sortDirection}`;
  query.division = division;

  useEffect(() => {
    if (
      (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
      !costOwnerId
    ) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong',
      });
    } else {
      dispatch(prActions.fetchPR(query));
    }
  }, [sortDirection, limitPerPage, currentPage, statusFilter]);

  useEffect(() => {
    if (prsData?.pr) {
      setTableData(
        prsData?.pr?.map(pr => ({
          id: pr?.id,
          code: removeUnderscore(pr?.code),
          subject: pr?.subject,
          currency: pr?.currency,
          prStatus: pr?.prStatus,
          date: pr?.date,
          place: pr?.place,
          previousCurrency: pr?.previousCurrency,
          unitType: pr?.unitType,
          prItems: pr?.prItems,
        })),
      );
    }
    setTotalItems(prsData?.totalItems);
  }, [prsData]);

  function handleModalOpen(id?) {
    if (typeof id === 'number') {
      setPrId(id);
    } else {
      dispatch(prActions.clearPRData());
      setPrId(null);
    }
    setModalOpen(!modalOpen);
  }

  function handleDialogOpen(id?) {
    if (id) {
      setPrId(id);
    }
    setDialogOpen(true);
  }

  function handlePopupOpen(id?) {
    if (id) {
      setPrId(id);
    }
    setPopupOpen(true);
  }

  const handleDelete = () => {
    dispatch(prActions.deletePR(prId?.id, query));
  };

  const handleReject = data => {
    const payload: any = {};
    payload.data = {
      prStatus: RolePOstatusRender(role, 'Reject'),
      authorizerFeedback: data?.reason,
    };
    payload.id = prId;

    dispatch(prActions.changeStatusPR(query, payload, role, 'Rejected'));
    setDialogOpen(false);
  };

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  const handleApproveAll = () => {
    const status = ApproveAllStatusRender(role);
    dispatch(prActions.batchUpdate(status, query));
  };
  const prButtonData = [
    {
      label: 'Add PR',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleModalOpen,
      disabled: !costOwnerId,
    },
    {
      label:
        role === ROLES.PROCUREMENT_INPUT
          ? 'Send All For Approval'
          : 'Approve All',
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { mr: 1 },
      onClick: handleApproveAll,
      disabled: role === ROLES.COST_OWNER_AUTHORIZER && !costOwnerId,
    },
  ];

  const filterButtons = () => {
    if (role === ROLES.COST_OWNER) {
      return prButtonData.filter(item => item.label === 'Add PR');
    } else {
      return prButtonData.filter(item => item.label !== 'Add PR');
    }
  };

  const sortOptions = [
    { label: 'ASC', value: 'asc' },
    { label: 'DESC', value: 'desc' },
  ];
  const handleSorting = sortDirection => {
    setSortDirection(sortDirection);
    setCurrentPage(0);
  };

  const prSortingData = [
    {
      label: 'Sort Direction',
      sortOptions: sortOptions,
      handleSorting: handleSorting,
      defaultValue: sortDirection,
      disabled:
        (role === ROLES.COST_OWNER || role === ROLES.COST_OWNER_AUTHORIZER) &&
        !costOwnerId,
    },
  ];

  const getFilterComponent = () => {
    return (
      <Box
        sx={{
          m: 1,
          maxWidth: '100%',
          width: 240,
          display: 'flex',
          justifySelf: 'flex-start',
        }}
      >
        <TextField
          onChange={event => {
            setStatusFilter(event.target.value as PRStatusInput);
            setCurrentPage(0);
          }}
          fullWidth
          size="small"
          label={'Filter by status'}
          name="filterByStatus"
          select
          InputLabelProps={{ shrink: true }}
          inputProps={{
            style: {
              minWidth: 110,
              padding: '4.5px 14px',
            },
          }}
          SelectProps={{
            native: true,
          }}
          variant="outlined"
          disabled={
            (role === ROLES.COST_OWNER ||
              role === ROLES.COST_OWNER_AUTHORIZER) &&
            !costOwnerId
          }
        >
          {PRStatusOptions.map(
            (PRStatusOption: { value: string; label: string }) => {
              return (
                <option
                  selected={statusFilter === PRStatusOption.value}
                  value={PRStatusOption.value}
                >
                  {PRStatusOption.label}
                </option>
              );
            },
          )}
        </TextField>
      </Box>
    );
  };

  const modalWrapperData = [
    {
      children: (
        <UploadFilesPrPopup
          setModalOpen={setPopupOpen}
          prId={prId}
          pr={prsData}
        />
      ),
      modalOpen: popupOpen,
      setModalOpen: setPopupOpen,
      type: 'editModal',
    },
    {
      children: (
        <PrFormPopup
          setModalOpen={setModalOpen}
          prId={prId}
          page={currentPage}
          rowsPerPage={limitPerPage}
          sortDirection={sortDirection}
          query={query}
        />
      ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },

    {
      children: (
        <AlertDialog
          setDialogOpen={setDialogOpen}
          handleDelete={prId?.type === 'delete' ? handleDelete : handleReject}
          message={
            prId?.type === 'delete'
              ? `Are you sure you want to delete this PR ?`
              : `Why do you want to reject this PR ?`
          }
          hasFeedback={prId?.type === 'delete' ? false : true}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
  ];

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.paper',
          minHeight: '100%',
        }}
      >
        <Box>
          <WidgetPreviewer
            element={
              <DynamicTable
                tableType="prTable"
                headerFields={prFields}
                data={tableData}
                loading={loading}
                buttonData={role && filterButtons()}
                handleModalOpen={handleModalOpen}
                handleDelete={handleDelete}
                currentPage={currentPage}
                totalItems={totalItems}
                limitPerPage={limitPerPage}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                handleDialogOpen={handleDialogOpen}
                handlePopupOpen={handlePopupOpen}
                sortData={prSortingData}
                sortDirection={sortDirection}
                query={query}
                StatusFilterComponent={getFilterComponent()}
              />
            }
            name="Purchase Request Table"
          />
        </Box>
        {modalWrapperData &&
          modalWrapperData.map(modalData => {
            return <ModalWrapper {...modalData} />;
          })}
      </Box>
    </>
  );
};

export default PrTable;
