import { useEffect, useState, Fragment } from 'react';
import {
  Box,
  Button,
  Container,
  Grid,
  Link,
  Table,
  TableRow,
  TableCell,
  Typography,
  Divider,
} from '@material-ui/core';
import useSettings from '../../materialUI/hooks/useSettings';
import { useDispatch, useSelector } from 'react-redux';
import Close from 'src/icons/X';
import Upload from 'src/icons/Upload';
import Trash from 'src/icons/Trash';
import Download from 'src/icons/Download';
import prActions from 'src/modules/PR/prActions';
import prSelector from 'src/modules/PR/prSelector';
import LoadingScreen from 'src/view/materialUI/components/LoadingScreen';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import { ROLES } from 'src/modules/shared/authentication/authReducer';
import authSelector from 'src/modules/shared/authentication/authSelector';

const UploadFilesPrPopup = props => {
  const { prId, setModalOpen, pr } = props;
  const { settings } = useSettings();
  const dispatch = useDispatch();

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    dispatch(prActions.getUploadedFiles(prId));
  }, [prId]);

  const filesState = useSelector(prSelector.files);
  const filesLoading = useSelector(statusSelector.loading);
  const authData = useSelector(authSelector.authData);
  const { role } = authData;

  let currentPr = pr?.pr?.find(item => item.id === prId);

  useEffect(() => {
    if (filesLoading) {
      setLoading(true);
    } else {
      setLoading(false);
    }
  }, [filesLoading]);

  useEffect(() => {
    return () => {
      dispatch(prActions.clearFiles());
    };
  }, []);

  const handleFileUpload = e => {
    const data = e.target.files[0];
    const inputFileName = e.target.files[0].name;

    let formData = new FormData();

    formData.append('file', data);
    dispatch(prActions.uploadFile(prId, formData, inputFileName, filesState));
  };

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center' }}>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
          margin: '2 auto',
        }}
        height="100%"
        width="65%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                {`PR ${currentPr?.code} files`}
              </Typography>
            </Grid>
            <Grid item>
              <Close
                sx={{ cursor: 'pointer' }}
                onClick={() => {
                  setModalOpen(false);
                }}
              />
            </Grid>
          </Grid>
          <Divider />
          <Grid xs={12} spacing={3}>
            <Box sx={{ mt: 3, mb: 3 }} height="100%" width="100%">
              {filesState && filesState.length !== 0 ? (
                filesState.map(file => (
                  <Table sx={{ width: '100%' }}>
                    <TableRow
                      hover
                      sx={{
                        minWidth: 700,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        borderBottom: '1px solid rgba(224, 224, 224, 1)',
                      }}
                    >
                      <TableCell
                        sx={{
                          border: 'none',
                          textAlign: 'center',
                          lineHeight: 1.7,
                        }}
                        align="left"
                      >
                        {file.name}
                      </TableCell>
                      <TableCell
                        sx={{
                          display: 'flex',
                          flexWrap: 'wrap',
                          minWidth: 80,
                          justifyContent: 'space-between',
                          border: 'none',
                        }}
                      >
                        <Download
                          fontSize="small"
                          sx={{
                            '&:hover': {
                              cursor: 'pointer',
                            },
                          }}
                          onClick={() =>
                            dispatch(
                              prActions.downloadUploadedFile(prId, file.name),
                            )
                          }
                        />
                        {role === ROLES.COST_OWNER && (
                          <Trash
                            fontSize="small"
                            sx={{
                              '&:hover': {
                                cursor: 'pointer',
                              },
                            }}
                            onClick={() =>
                              dispatch(
                                prActions.deleteUploadedFile(prId, file.name),
                              )
                            }
                          />
                        )}

                        {/* </Button> */}
                        {/* </div> */}
                      </TableCell>
                    </TableRow>
                  </Table>
                ))
              ) : (
                <Table>
                  <TableRow hover sx={{ minWidth: 700 }}>
                    <TableCell
                      sx={{
                        textAlign: 'center',
                        fontSize: '1.01rem',
                        fontWeight: '500',
                        color: '#777',
                        padding: '1.15rem 0.9rem',
                      }}
                      align="center"
                    >
                      {`No files are available for ${currentPr?.code} PR`}
                    </TableCell>
                  </TableRow>
                </Table>
              )}
            </Box>
          </Grid>
          <Grid
            xs={12}
            spacing={3}
            sx={{
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
              m: '5 0',
            }}
          >
            {role === ROLES.COST_OWNER && (
              <Fragment>
                <input
                  color="primary"
                  accept="application/pdf, .doc,.docx,.xml,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.documen , .csv , application/vnd.ms-excel , application/vnd.openxmlformats-officedocument.spreadsheetml.sheet "
                  type="file"
                  id="icon-button-file"
                  style={{ display: 'none' }}
                  onChange={handleFileUpload}
                />
                <label htmlFor="icon-button-file">
                  <Button
                    variant="contained"
                    component="span"
                    size="large"
                    color="primary"
                  >
                    <Upload fontSize="small" />
                    Upload file
                  </Button>
                </label>
              </Fragment>
            )}
            <Button
              sx={{ ml: 1.1, padding: '8px 22px', fontSize: '0.9375rem' }}
              color="secondary"
              variant="contained"
              onClick={() => setModalOpen(false)}
            >
              Cancel
            </Button>
          </Grid>
        </Container>
      </Box>
    </div>
  );
};

export default UploadFilesPrPopup;
