import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Divider,
  Button,
  Typography,
} from '@material-ui/core';
import { useDispatch, useSelector } from 'react-redux';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import prSelector from 'src/modules/PR/prSelector';
import { PurchaseRequestData } from 'src/models/data/pr/PrData';
import prActions from 'src/modules/PR/prActions';
import { yupResolver } from '@hookform/resolvers/yup';
import { FormProvider, useForm } from 'react-hook-form';
import { prSchema } from 'src/modules/shared/yup/prSchema';
import moment from 'moment';
import Close from 'src/icons/X';
import PrForm from 'src/view/materialUI/components/widgets/forms/PrForm';
import authSelector from 'src/modules/shared/authentication/authSelector';
import RolePOstatusRender from 'src/helpers/POhelplers/RolePOstatusRender';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import StatusArrayRender from 'src/helpers/POhelplers/statusArrayRender';
import {
  toggleDisable,
  toggleDisplay,
} from 'src/view/materialUI/utils/toggleDisable';
import IsAuthorizer from 'src/helpers/isAuthorizer';
import { poStatus } from 'src/enums/status';

const PrFormPopup = props => {
  const { setModalOpen, prId, page, rowsPerPage, sortDirection, query } = props;
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const prData = useSelector(prSelector.prData);
  const authData = useSelector(authSelector.authData);
  const { role, division } = authData;

  const [dialogOpen, setDialogOpen] = useState(false);
  let isEditModalPr: boolean;

  const initialValues: PurchaseRequestData = {
    approved: 'NEW',
    code: '',
    currency: '',
    date: '',
    deliveryDate: '',
    place: '',
    previousCurrency: '',
    previousValue: null,
    procScopeAsses: null,
    subject: '',
    prSuppliers: [],
    unitType: '',
    prItems: [],
    availableFunds: [],
  };

  const form = useForm({
    resolver: yupResolver(prSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const previousCurrency = form.watch(`previousCurrency`);

  const prStatus = StatusArrayRender(role);

  const ChangePRStatus = (action, data?) => {
    const payload: any = {};
    payload.data = {
      prStatus: RolePOstatusRender(role, action),
      authorizerFeedback: data?.reason,
    };
    payload.id = prId;

    action === 'Assign'
      ? dispatch(prActions.changeStatusPR(query, payload, role, 'Assigned'))
      : dispatch(prActions.changeStatusPR(query, payload, role, 'Rejected'));

    setModalOpen(false);
  };

  const onSubmit = data => {
    if (typeof prId === 'number') {
      dispatch(prActions.updatePR(prId, data, query));
    } else {
      dispatch(prActions.createPR(data, query));
    }
    setModalOpen(false);
  };

  useEffect(() => {
    if (typeof prId === 'number') {
      dispatch(prActions.getById(prId));
    }
  }, [dispatch, prId]);

  useEffect(() => {
    form.reset();
    if (prId !== null && prData) {
      Object.keys(prData).forEach(key => {
        if (prData[key] !== null) {
          if (Array.isArray(prData[key])) {
            if (key === 'prItems') {
              prData[key].forEach((prListItem, index) => {
                Object.keys(prListItem).forEach(k => {
                  form.setValue(`prItems.${index}.${k}`, prListItem[k]);
                });
              });
            }
            if (key === 'availableFunds') {
              prData[key].forEach((prListItem, index) => {
                Object.keys(prListItem).forEach(k => {
                  form.setValue(`availableFunds.${index}.${k}`, prListItem[k]);
                });
              });
            }
            if (key === 'prSuppliers') {
              prData[key].forEach((supplier, index) => {
                Object.keys(supplier).forEach(k => {
                  form.setValue(
                    `prSuppliers.${index}.${k}` as any,
                    supplier[k],
                  );
                });
              });
            }
          } else {
            form.setValue(key as keyof PurchaseRequestData, prData[key]);
          }
        }
      });
    }

    if (Object.keys(prData).length === 0) {
      form.setValue('date', moment(new Date()).format('YYYY-MM-DD'));
      form.setValue('deliveryDate', moment(new Date()).format('YYYY-MM-DD'));
    }
  }, [prData]);

  const editableStatuses: string[] = ['PRI', 'PRA', 'COA'];

  function findEditableStatuses(status: string) {
    return editableStatuses.find(item => item === status);
  }

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 4,
        }}
        height="100%"
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid container justifyContent="space-between" spacing={3}>
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Purchase Request
              </Typography>
            </Grid>
            <Grid item>
              <Close
                onClick={() => {
                  setModalOpen(false);
                }}
              />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box sx={{ mt: 3 }} height="100%">
                <PrForm
                  id={prId}
                  isEditModal={
                    prId !== null
                      ? (isEditModalPr = true)
                      : (isEditModalPr = false)
                  }
                  previousCurrency={previousCurrency}
                />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                {role !== 'COST_OWNER' && role === poStatus[prData.prStatus] ? (
                  <>
                    <Button
                      color="primary"
                      sx={{
                        m: '0 6px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      type="button"
                      onClick={() => ChangePRStatus('Assign')}
                    >
                      Approve
                    </Button>
                    <Button
                      sx={{
                        background: '#666',
                        '&:hover': {
                          background: '#333',
                        },
                        m: '0 8px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      onClick={() => setDialogOpen(true)}
                    >
                      Reject
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      color="primary"
                      sx={{
                        m: '0 6px',
                        p: '6px 10px',
                        fontSize: '14px',
                        display:
                          prId === null
                            ? 'inherit'
                            : toggleDisplay(role, prData.prStatus),
                      }}
                      variant="contained"
                      type="submit"
                    >
                      Save
                    </Button>
                    <Button
                      sx={{
                        background: '#666',
                        '&:hover': {
                          background: '#333',
                        },
                        m: '0 8px',
                        p: '6px 10px',
                        fontSize: '14px',
                      }}
                      variant="contained"
                      onClick={() => setModalOpen(false)}
                    >
                      Cancel
                    </Button>
                  </>
                )}
              </Box>
            </form>
          </FormProvider>
        </Container>
        <ModalWrapper
          children={
            <AlertDialog
              setDialogOpen={setDialogOpen}
              handleDelete={data => ChangePRStatus('Reject', data)}
              message={`Why do you want to reject this PR ?`}
              hasFeedback={true}
            />
          }
          modalOpen={dialogOpen}
          setModalOpen={setDialogOpen}
          type="deleteModal"
        />
      </Box>
    </>
  );
};

export default PrFormPopup;
