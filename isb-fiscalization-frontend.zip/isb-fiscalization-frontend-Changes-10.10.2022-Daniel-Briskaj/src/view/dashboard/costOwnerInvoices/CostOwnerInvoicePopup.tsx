import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import Close from 'src/icons/X';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import CostOwnerInvoicesForm from 'src/view/materialUI/components/widgets/forms/CostOwnerInvoicesForm';
import costOwnerInvoicesActions from 'src/modules/costOwnersInvoices/costOwnerInvoicesActions';
import costOwnerInvoiceSelector from 'src/modules/costOwnersInvoices/costOwnerInvoicesSelector';
import { CostOwnerFormInvoiceData } from 'src/models/data/invoices/InvoiceData';
import { invoicesSchema } from 'src/modules/shared/yup/invoicesSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm, FormProvider } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { costOwnerInvoicesSchema } from 'src/modules/shared/yup/costOwnerInvoicesSchema';

const CostOwnerInvoiceFormPopup = ({
  setModalOpen,
  data,
  page,
  rowsPerPage,
  isManual,
  setDialogOpen,
  query,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const authData = useSelector(authSelector.authData);
  const invoiceData = useSelector(costOwnerInvoiceSelector.invoicesDataArray);
  const { costOwnerId, division } = authData;

  let currentInvoice = invoiceData?.invoices?.find(
    invoice => invoice.id === data.id,
  );

  data && data.invoiceStatus === 'DELIVERED'
    ? (isManual = true)
    : (isManual = false);

  let manualInvoiceProcessData = { ...data };

  Object.defineProperty(manualInvoiceProcessData, 'eic', {
    value: currentInvoice && currentInvoice.eic ? currentInvoice.eic : 'ABCD',
    writable: true,
    enumerable: true,
  });
  Object.defineProperty(manualInvoiceProcessData, 'nipt', {
    value: currentInvoice && currentInvoice.nipt ? currentInvoice.nipt : 'ABCD',
    writable: true,
    enumerable: true,
  });

  const initialValues: CostOwnerFormInvoiceData = {
    amount: 0,
    dueDate: '',
    eic: '',
    importedInvoiceNumber: '',
    invoiceNumber: '',
    nipt: '',
    receivedDate: '',
    status: '',
    type: '',
    invoiceStatus: 'SEND_SUBMIT',
    approved: 'NEW',
    contract: { id: null },
    supplier: { id: null },
    po: { id: null },
    costOwner: {
      id: costOwnerId,
    },
  };

  const form = useForm({
    resolver: yupResolver(costOwnerInvoicesSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const onSubmit = submitData => {
    const id = parseInt(submitData.id);
    const transformedSubmitData = {
      contractId:
        submitData?.contract && submitData?.contract?.id
          ? submitData?.contract?.id
          : null,
      poId: submitData.po && submitData.po.id ? submitData.po.id : null,
      invoiceStatus: 'SEND_SUBMIT',
    };
    dispatch(
      costOwnerInvoicesActions.assignInvoice(
        {
          id: id,
          data: transformedSubmitData,
        },
        isManual,
        query,
      ),
    );
    setModalOpen(false);
  };

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          py: 4,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid
            container
            justifyContent="space-between"
            alignItems="center"
            spacing={3}
            sx={{ mb: 2 }}
          >
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Process
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box
                sx={{
                  mt: 3,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <CostOwnerInvoicesForm
                  data={
                    !data.eic && !data.nipt ? manualInvoiceProcessData : data
                  }
                />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  variant="contained"
                  type="submit"
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                >
                  Process Invoice
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => {
                    isManual ? setModalOpen(false) : setDialogOpen(data.id);
                  }}
                >
                  {isManual ? 'Cancel' : 'Reject'}
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default CostOwnerInvoiceFormPopup;
