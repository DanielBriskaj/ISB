import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Divider,
  Button,
} from '@material-ui/core';
import Close from 'src/icons/X';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import ManualInvoiceForm from 'src/view/materialUI/components/widgets/forms/ManualInvoiceForm';
import costOwnerInvoicesActions from 'src/modules/costOwnersInvoices/costOwnerInvoicesActions';
import costOwnerInvoiceSelector from 'src/modules/costOwnersInvoices/costOwnerInvoicesSelector';
import optionSelector from 'src/modules/shared/options/optionsSelector';
import optionsActions from 'src/modules/shared/options/optionsActions';
import { ManualInvoiceData } from 'src/models/data/invoices/manualInvoiceData';
import { invoicesSchema } from 'src/modules/shared/yup/invoicesSchema';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm, FormProvider } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import authSelector from 'src/modules/shared/authentication/authSelector';
import { manualInvoiceSchema } from 'src/modules/shared/yup/manualInvoiceSchema';
import { toggleDisplayMI } from 'src/view/materialUI/utils/toggleDisable';

const ManualInvoicePopup = ({
  setModalOpen,
  data,
  page,
  rowsPerPage,
  isInvoice,
  invoiceId,
  query,
  setApproved,
}) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();
  const authData = useSelector(authSelector.authData);
  const invoiceData = useSelector(costOwnerInvoiceSelector.invoiceData);
  const { costOwnerId, division, role } = authData;
  let isEditModal: boolean;

  const initialValues: ManualInvoiceData = {
    costOwner: {
      id: costOwnerId ? costOwnerId : 0,
    },
    supplier: { id: null },
    invoiceNumber: '',
    receivedDate: '',
    dueDate: '',
    nipt: '',
    currency: '',
    invoiceStatus: 'DELIVERED',
    amount: 0,
    vat: 0,
    description: '',
    isManual: true,
    po: {
      id: null,
    },
    contract: {
      id: null,
    },
  };

  const form = useForm({
    resolver: yupResolver(manualInvoiceSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  useEffect(() => {
    if (typeof invoiceId === 'number') {
      dispatch(costOwnerInvoicesActions.getById(invoiceId));
    }
  }, [dispatch, invoiceId]);

  const onSubmit = data => {
    const mySupplierId = parseInt(data?.supplier?.id);
    if (data) {
      data.contract = null;
      data.po = null;

      const rawData = {
        ...data,
        supplier: {
          id: mySupplierId,
          companyName: data?.supplier?.companyName,
          supplierAccountId: data?.supplier?.supplierAccountId,
          userFirstname: data?.supplier?.userFirstname,
          userLastname: data?.supplier?.userLastname,
        },
      };
      if (rawData.id) {
        delete rawData.id;
      }
      if (typeof invoiceId === 'number') {
        dispatch(
          costOwnerInvoicesActions.updateManualInvoice(
            rawData,
            invoiceId,
            query,
          ),
        );
        setModalOpen(false);
      } else {
        dispatch(costOwnerInvoicesActions.postManualInvoice(rawData, query));
        setApproved('DELIVERED');
        setModalOpen(false);
      }
    }

    setModalOpen(false);
  };

  useEffect(() => {
    if (
      (invoiceData &&
        Object.keys(invoiceData).length === 0 &&
        Object.getPrototypeOf(invoiceData) === Object.prototype) ||
      typeof invoiceId !== 'number' ||
      invoiceId === null
    ) {
      form.reset();
    } else {
      invoiceData &&
        Object.keys(invoiceData).forEach(key => {
          if (typeof invoiceData[key] === 'object') {
            if (invoiceData[key] === null) {
              form.setValue(key as keyof ManualInvoiceData, null);
            } else {
              Object.keys(invoiceData[key]).forEach(objKey => {
                form.setValue(
                  `${key}.${objKey}` as any,
                  invoiceData[key][objKey],
                );
                if (key === 'po') {
                  form.setValue(key, invoiceData?.po?.poNumber);
                }
                if (key === 'contract') {
                  form.setValue(
                    key,
                    `${invoiceData?.contract?.contractCode} - ${invoiceData?.contract?.contractDescription}`,
                  );
                }
              });
            }
          } else {
            form.setValue(key as keyof ManualInvoiceData, invoiceData[key]);
          }
        });
    }
  }, [invoiceData, invoiceId]);

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          py: 4,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid
            container
            justifyContent="space-between"
            alignItems="center"
            spacing={3}
            sx={{ mb: 2 }}
          >
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Manual Invoice
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Divider />
              <Box
                sx={{
                  mt: 3,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <ManualInvoiceForm
                  data={invoiceData}
                  isEditModal={
                    invoiceId !== null
                      ? (isEditModal = true)
                      : (isEditModal = false)
                  }
                />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  variant="contained"
                  type="submit"
                  color="primary"
                  sx={{
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                    display:
                      (invoiceData?.invoiceStatus === 'DELIVERED' &&
                        isEditModal) ||
                      !isEditModal
                        ? 'inherit'
                        : 'none',
                  }}
                >
                  Save
                </Button>
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default ManualInvoicePopup;
