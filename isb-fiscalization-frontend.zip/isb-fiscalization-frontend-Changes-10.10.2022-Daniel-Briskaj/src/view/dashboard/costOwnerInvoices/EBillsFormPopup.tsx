import { useEffect } from 'react';
import {
  Button,
  Container,
  Grid,
  Divider,
  Typography,
  Box,
} from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import Close from 'src/icons/X';
import useSettings from 'src/view/materialUI/hooks/useSettings';
import { useForm, FormProvider } from 'react-hook-form';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import invoiceSelector from 'src/modules/invoices/invoiceSelector';
import EBillsForm from 'src/view/materialUI/components/widgets/forms/EBillsForm';

const EBillsFomPopup = ({ setModalOpen, id }) => {
  const { settings } = useSettings();
  const dispatch = useDispatch();

  const invoiceData = useSelector(invoiceSelector?.invoiceData);

  useEffect(() => {
    dispatch(invoiceActions.getById(id));
  }, [id]);

  useEffect(() => {
    return () => {
      dispatch(invoiceActions.clearSingleInvoice());
    };
  }, []);

  const form = useForm();

  return (
    <>
      <Box
        sx={{
          backgroundColor: 'background.default',
          py: 4,
        }}
      >
        <Container maxWidth={settings.compact ? 'xl' : false}>
          <Grid
            container
            justifyContent="space-between"
            alignItems="center"
            spacing={3}
            sx={{ mb: 2 }}
          >
            <Grid item>
              <Typography color="textPrimary" variant="h5" paddingLeft={1}>
                Invoice Details
              </Typography>
            </Grid>
            <Grid item>
              <Close onClick={() => setModalOpen && setModalOpen(false)} />
            </Grid>
          </Grid>
          <FormProvider {...form}>
            <form>
              <Divider />
              <Box
                sx={{
                  mt: 3,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}
              >
                <EBillsForm data={invoiceData} />
              </Box>
              <Box
                sx={{ mt: 2 }}
                display="flex"
                justifyContent="end"
                alignContent="end"
              >
                <Button
                  sx={{
                    background: '#666',
                    '&:hover': {
                      background: '#333',
                    },
                    m: '0 6px',
                    p: '6px 10px',
                    fontSize: '14px',
                  }}
                  variant="contained"
                  onClick={() => setModalOpen(false)}
                >
                  Cancel
                </Button>
              </Box>
            </form>
          </FormProvider>
        </Container>
      </Box>
    </>
  );
};

export default EBillsFomPopup;
