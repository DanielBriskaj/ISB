import { useEffect, useState, useCallback } from 'react';
import { Box, Tab, Tabs, TextField } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import type { ChangeEvent } from 'react';
import DynamicTable from 'src/view/materialUI/components/widgets/tables/DynamicTable';
import WidgetPreviewer from 'src/view/materialUI/components/WidgetPreviewer';
import costOwnerInvoiceSelector from 'src/modules/costOwnersInvoices/costOwnerInvoicesSelector';
import costOwnerInvoicesActions from 'src/modules/costOwnersInvoices/costOwnerInvoicesActions';
import { costOwnerInvoicesFields } from 'src/enums/shared/headerFields/costOwnersInvoices';
import { costOwnerManualInvoicesFields } from 'src/enums/shared/headerFields/costOwnerManualInvoices';
import AlertDialog from 'src/view/materialUI/components/widgets/modals/AlertDialog';
import CostOwnerInvoiceFormPopup from './CostOwnerInvoicePopup';
import Plus from 'src/icons/Plus';
import UploadFilesMIPopup from './UploadFilesMIPopup';
import { debounce } from 'lodash';
import statusSelector from 'src/modules/shared/statuses/statusesSelector';
import authSelector from 'src/modules/shared/authentication/authSelector';
import ModalWrapper from 'src/view/shared/modal/ModalWrapper';
import ManualInvoicePopup from './ManualInvoicePopup';
import { InvoiceStatus } from 'src/models/data/invoices/InvoiceData';
import EBillsFomPopup from './EBillsFormPopup';
import numberWithCommas from 'src/helpers/numberWithCommas';
import notificationThrower from 'src/helpers/notificationThrower';

type InvoiceStatusInput =
  | ''
  | 'DELIVERED'
  | 'SEND_SUBMIT'
  | 'APPROVED_PAYMENT'
  | 'ACCEPTED'
  | 'ASSIGNED'
  | 'REQUEST_PAYMENT';

const invoiceStatusOptions = [
  { value: '', label: 'ALL' },
  { value: 'DELIVERED', label: 'DELIVERED' },
  { value: 'SEND_SUBMIT', label: 'SEND SUBMIT' },
  { value: 'APPROVED_PAYMENT', label: 'APPROVED PAYMENT' },
  { value: 'ACCEPTED', label: 'ACCEPTED' },
  { value: 'ASSIGNED', label: 'ASSIGNED' },
  { value: 'REQUEST_PAYMENT', label: 'REQUEST PAYMENT' },
];

const costOwnerTabs = [
  { label: 'E-Invoices', value: 'co_invoices' },
  { label: 'Manual Invoices', value: 'co_manual_invoices' },
];

const CostOwnerInvoiceTable = () => {
  const [tableData, setTableData] = useState([]);
  const [manualInvoices, setManualInvoices] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [ebillsOpen, setEbillsOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [popupOpen, setPopupOpen] = useState(false);
  const [processOpen, setProcessOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState({});
  const [limitPerPage, setLimitPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [isInvoice, setIsInvoice] = useState(null);
  const [invoiceId, setInvoiceId] = useState(null);
  const [searchFunctionArray, setSearchFunctionArray] = useState([]);
  const [approved, setApproved] = useState<InvoiceStatusInput>('');
  const [supplierName, setSupplierName] = useState('');

  const dispatch = useDispatch();

  const loading = useSelector(statusSelector.loading);
  const invoicesState = useSelector(costOwnerInvoiceSelector.invoicesDataArray);
  const selectedInvoiceMI = useSelector(
    costOwnerInvoiceSelector.selectedInvoice,
  );
  const currentTab = useSelector(costOwnerInvoiceSelector.currentTab);
  const authData = useSelector(authSelector.authData);
  const { division, costOwnerCode } = authData;
  let isManual: boolean = false;

  const [query, setQuery] = useState({
    coaDivision: division,
    codeOwnerCode: costOwnerCode,
    page: currentPage,
    size: limitPerPage,
    invoiceStatus: '',
    isManual: false,
  });

  const handleTabsChange = (event: ChangeEvent<{}>, value: string): void => {
    dispatch(costOwnerInvoicesActions.setCurrentTab(value));
    setCurrentPage(0);
  };

  const setSelectedInvoiceMI = (id?) => {
    dispatch(costOwnerInvoicesActions.setSelectedInvoice(id));
  };

  const getFilterComponent = (tableType, value) => {
    return (
      <Box
        sx={{
          m: 1,
          maxWidth: '100%',
          width: 240,
          display: 'flex',
          justifySelf: 'flex-start',
        }}
      >
        <TextField
          onChange={event => {
            setApproved(event.target.value as InvoiceStatusInput);
            setCurrentPage(0);
          }}
          fullWidth
          size="small"
          label={'Filter by status'}
          name="sort"
          select
          InputLabelProps={{ shrink: true }}
          inputProps={{
            style: {
              minWidth: 110,
              padding: '4.5px 14px',
            },
          }}
          SelectProps={{
            native: true,
          }}
          variant="outlined"
          disabled={!costOwnerCode}
        >
          {invoiceStatusOptions.map(
            (invoiceStatusOption: { value: string; label: string }) => {
              if (
                tableType === 'costOwnerInvoiceTable' &&
                invoiceStatusOption.value === 'DELIVERED'
              ) {
                return null;
              }
              return (
                <option
                  selected={approved === invoiceStatusOption.value}
                  value={invoiceStatusOption.value}
                >
                  {invoiceStatusOption.label}
                </option>
              );
            },
          )}
        </TextField>
      </Box>
    );
  };

  useEffect(() => {
    setApproved(null);
  }, [currentTab]);

  useEffect(() => {
    if (costOwnerCode) {
      if (currentTab === 'co_invoices') {
        setQuery(oldQuery => {
          return {
            ...oldQuery,
            isManual: false,
            invoiceStatus: approved !== 'ASSIGNED' ? approved : 'ASSIGNED',
            page: currentPage,
            size: limitPerPage,
          };
        });

        dispatch(
          costOwnerInvoicesActions.readCostOwnerInvoices({
            codeOwnerCode: costOwnerCode,
            invoiceStatus: approved,
            coaDivision: division,
            isManual: isManual,
            page: currentPage,
            size: limitPerPage,
          }),
        );
      } else if (currentTab === 'co_manual_invoices') {
        setQuery(oldQuery => {
          return {
            ...oldQuery,
            isManual: true,
            page: currentPage,
            invoiceStatus: approved !== '' ? approved : '',
            size: limitPerPage,
          };
        });
        dispatch(
          costOwnerInvoicesActions.readCostOwnerInvoices({
            codeOwnerCode: costOwnerCode,
            supplierName,
            coaDivision: division,
            invoiceStatus: approved,
            isManual: !isManual,
            page: currentPage,
            size: limitPerPage,
          }),
        );
      }
    } else {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong',
        toastId: 'display once',
      });
    }
  }, [
    costOwnerCode,
    division,
    isManual,
    currentTab,
    currentPage,
    limitPerPage,
    approved,
    supplierName,
  ]);

  useEffect(() => {
    if (
      invoicesState &&
      Object.keys(invoicesState).length === 0 &&
      Object.getPrototypeOf(invoicesState) === Object.prototype
    ) {
    } else {
      setTableData(
        invoicesState.invoices.map(invoice => ({
          id: invoice?.id,
          eic: invoice?.eic,
          invoiceNumber: invoice?.invoiceNumber,
          receivedDate: invoice?.receivedDate,
          dueDate: invoice?.dueDate,
          status: invoice?.invoiceStatus,
          amount: numberWithCommas(invoice?.amount.toFixed(2)),
          nipt: invoice?.nipt,
          approved: invoice?.approved,
        })),
      );
      setManualInvoices(
        invoicesState.invoices.map(invoice => ({
          id: invoice?.id,
          supplierName: invoice?.supplier?.companyName,
          invoiceNumber: invoice?.invoiceNumber,
          receivedDate: invoice?.receivedDate,
          dueDate: invoice?.dueDate,
          invoiceStatus: invoice?.invoiceStatus,
          amount: numberWithCommas(invoice?.amount.toFixed(2)),
          description: invoice?.description,
          supplierId: invoice?.supplier?.id,
        })),
      );
      setTotalItems(invoicesState.totalItems);
    }
  }, [invoicesState]);

  const supplierNameSearchOnChange = event => {
    setSupplierName(event.target.value);
    setCurrentPage(0);
  };
  const handleSupplierNameSearch = useCallback(
    debounce(supplierNameSearchOnChange, 100),
    [],
  );

  useEffect(() => {
    setSearchFunctionArray([
      {
        placeholder: 'Supplier Name',
        function: handleSupplierNameSearch,
        customClass: 'search-input',
        disabled: !costOwnerCode,
      },
    ]);
  }, []);

  function handleModalOpen(obj) {
    if (obj?.open) {
      setEbillsOpen(true);
      setInvoiceId(obj?.id);
    } else {
      setModalOpen(obj);
    }
  }

  function handleProcessOpen(id?, data?) {
    if (id) {
      setInvoiceId(id);
    }
    setProcessOpen(!processOpen);
    setSelectedInvoice(data);
  }

  function handleModalOpenMI(obj?) {
    if (obj.invoice === true) {
      setIsInvoice(true);
    } else if (obj.invoice === false) {
      setIsInvoice(false);
    } else {
      setIsInvoice(true);
    }
    if (obj.id) {
      setInvoiceId(obj.id);
    } else {
      setInvoiceId(null);
    }
    setModalOpen(!modalOpen);
  }

  function handleDialogOpen(id?) {
    if (id) {
      setInvoiceId(id);
    }
    setDialogOpen(!dialogOpen);
  }

  function handlePopupOpen(id?) {
    if (id) {
      setInvoiceId(id);
    }
    setPopupOpen(!popupOpen);
  }

  const handleDelete = () => {
    dispatch(costOwnerInvoicesActions.deleteInvoice(invoiceId, query));
  };

  const invoiceButtonData = [
    {
      buttonFunction: selected => {
        setModalOpen(!modalOpen);
        setSelectedInvoice(selected);
      },
    },
  ];

  const manualInvoiceButtonData = [
    {
      label: 'Add Manual Invoice',
      startIcon: <Plus />,
      color: 'primary',
      size: 'large',
      variant: 'contained',
      sx: { margin: '1.2rem 0', p: 1.2 },
      onClick: handleModalOpenMI,
      disabled: !costOwnerCode,
    },
  ];

  const modalWrapperData = [
    {
      children: (
        <UploadFilesMIPopup
          setModalOpen={setPopupOpen}
          invoiceId={invoiceId}
          invoice={invoicesState}
        />
      ),
      modalOpen: popupOpen,
      setModalOpen: setPopupOpen,
      type: 'editModal',
    },
    {
      children: (
        <CostOwnerInvoiceFormPopup
          setModalOpen={setProcessOpen}
          setDialogOpen={handleDialogOpen}
          data={selectedInvoice}
          page={currentPage}
          rowsPerPage={limitPerPage}
          isManual={isManual}
          query={query}
        />
      ),
      modalOpen: processOpen,
      setModalOpen: setProcessOpen,
      type: 'editModal',
    },
    {
      children:
        currentTab === 'co_invoices' ? (
          <CostOwnerInvoiceFormPopup
            setModalOpen={handleModalOpen}
            setDialogOpen={handleDialogOpen}
            data={selectedInvoice}
            page={currentPage}
            rowsPerPage={limitPerPage}
            isManual={isManual}
            query={query}
          />
        ) : (
          <ManualInvoicePopup
            setModalOpen={handleModalOpenMI}
            data={selectedInvoice}
            isInvoice={isInvoice}
            invoiceId={invoiceId}
            page={currentPage}
            rowsPerPage={limitPerPage}
            query={query}
            setApproved={setApproved}
          />
        ),
      modalOpen: modalOpen,
      setModalOpen: setModalOpen,
      type: 'editModal',
    },
    {
      children: (
        <AlertDialog
          setModalOpen={setModalOpen}
          setDialogOpen={setDialogOpen}
          handleDelete={handleDelete}
          message={`Are you sure you want to continue?`}
          hasFeedback={false}
        />
      ),
      modalOpen: dialogOpen,
      setModalOpen: setDialogOpen,
      type: 'deleteModal',
    },
    {
      children: <EBillsFomPopup setModalOpen={setEbillsOpen} id={invoiceId} />,
      modalOpen: ebillsOpen,
      setModalOpen: setEbillsOpen,
      type: 'editModal',
    },
  ];

  function onPageChange(event, page) {
    setCurrentPage(page);
  }

  const onChangeRowsPerPage = event => {
    const newLimitPerPage = event.target.value;
    const defaultPage = 0;
    setLimitPerPage(newLimitPerPage);
    setCurrentPage(defaultPage);
  };

  return (
    <Box
      sx={{
        backgroundColor: 'background.paper',
        minHeight: '100%',
      }}
    >
      <Box sx={{ mt: 3 }}>
        <Tabs
          indicatorColor="primary"
          onChange={handleTabsChange}
          scrollButtons="auto"
          textColor="primary"
          value={currentTab}
          variant="scrollable"
        >
          {costOwnerTabs.map(tab => (
            <Tab
              sx={{ p: 2.4 }}
              key={tab.value}
              label={tab.label}
              value={tab.value}
            />
          ))}
        </Tabs>
      </Box>
      <Box>
        <WidgetPreviewer
          element={
            currentTab === 'co_invoices' ? (
              <DynamicTable
                tableType="costOwnerInvoiceTable"
                headerFields={costOwnerInvoicesFields}
                data={tableData}
                loading={loading}
                buttonData={invoiceButtonData}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                totalItems={totalItems}
                currentPage={currentPage}
                limitPerPage={limitPerPage}
                setApproved={setApproved}
                approved={approved}
                handleModalOpen={handleModalOpen}
                StatusFilterComponent={getFilterComponent(
                  'costOwnerInvoiceTable',
                  approved,
                )}
              />
            ) : (
              <DynamicTable
                tableType="manualInvoicesTable"
                headerFields={costOwnerManualInvoicesFields}
                data={manualInvoices}
                loading={loading}
                buttonData={manualInvoiceButtonData}
                onPageChange={onPageChange}
                onChangeRowsPerPage={onChangeRowsPerPage}
                totalItems={totalItems}
                currentPage={currentPage}
                limitPerPage={limitPerPage}
                selected={selectedInvoiceMI}
                setSelected={setSelectedInvoiceMI}
                handleDialogOpen={handleDialogOpen}
                handleModalOpen={handleModalOpenMI}
                handlePopupOpen={handlePopupOpen}
                handleProcessOpen={handleProcessOpen}
                searchArrayOfFunctions={searchFunctionArray}
                handleDelete={handleDelete}
                setApproved={setApproved}
                approved={approved}
                StatusFilterComponent={getFilterComponent(
                  'manualInvoicesTable',
                  approved,
                )}
              />
            )
          }
          name="Cost Owner Invoice Table"
        />
      </Box>
      {modalWrapperData &&
        modalWrapperData.map(modalData => {
          return <ModalWrapper {...modalData} />;
        })}
    </Box>
  );
};

export default CostOwnerInvoiceTable;
