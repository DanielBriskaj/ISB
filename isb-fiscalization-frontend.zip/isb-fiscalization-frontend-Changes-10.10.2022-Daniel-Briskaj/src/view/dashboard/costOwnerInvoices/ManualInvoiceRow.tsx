import React from 'react';
import { TableCell, TableRow, IconButton, Button } from '@material-ui/core';
import Label from 'src/view/materialUI/components/Label';
import PencilAltIcon from '../../../icons/PencilAlt';
import ArrowRightIcon from 'src/icons/ArrowRight';
import Download from 'src/icons/Download';
import Trash from 'src/icons/Trash';
import Upload from 'src/icons/Upload';
import { useDispatch, useSelector } from 'react-redux';
import invoiceActions from 'src/modules/invoices/invoiceActions';
import costOwnerInvoiceSelector from 'src/modules/costOwnersInvoices/costOwnerInvoicesSelector';
import costOwnerInvoicesActions from 'src/modules/costOwnersInvoices/costOwnerInvoicesActions';

const getStatusLabel = invoiceStatus => {
  const map = {
    ASSIGNED: {
      color: 'warning',
      text: 'ASSIGNED',
    },
    ACCEPTED: {
      color: 'success',
      text: 'ACCEPTED',
    },
    SEND_SUBMIT: {
      color: 'primary',
      text: 'SEND_SUBMIT',
    },
    REQUEST_PAYMENT: {
      color: 'secondary',
      text: 'REQUEST_PAYMENT',
    },
    DELIVERED: {
      color: 'primary',
      text: 'DELIVERED',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const ManualInvoiceRow = ({
  invoice,
  buttonData,
  page,
  rowsPerPage,
  handleDelete,
  handleProcessOpen,
  handleDialogOpen,
  handlePopupOpen,
  handleModalOpen,
}) => {
  const dispatch = useDispatch();

  return (
    <TableRow key={invoice.id} hover>
      {Object.keys(invoice).map(key => {
        if (
          key === 'id' ||
          key === 'supplierId' ||
          key === 'po' ||
          key === 'contract'
        ) {
          return;
        }
        if (key === 'invoiceStatus') {
          return (
            <TableCell sx={{ padding: '16px' }} align="center" key={key}>
              {invoice[key] && getStatusLabel(invoice[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            sx={{ padding: '16px' }}
            key={key}
            align={
              key === 'supplierName' ||
              key === 'invoiceNumber' ||
              key === 'receivedDate' ||
              key === 'dueDate' ||
              key === 'status' ||
              key === 'description'
                ? 'center'
                : key === 'amount'
                ? 'right'
                : 'left'
            }
          >
            {invoice[key] && invoice[key]}
          </TableCell>
        );
      })}

      <TableCell align="center" sx={{ padding: '16px' }}>
        <IconButton
          onClick={() => {
            handleModalOpen({ id: invoice.id, invoice: true });
          }}
        >
          <PencilAltIcon fontSize="small" />
        </IconButton>
        <IconButton
          onClick={() => {
            handleDialogOpen(invoice.id, true);
          }}
        >
          <Trash fontSize="small" />
        </IconButton>

        <IconButton
          onClick={() => {
            handlePopupOpen(invoice.id);
          }}
        >
          <Upload fontSize="small" />
        </IconButton>
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => {
            handleProcessOpen(invoice.id, invoice);
          }}
          disabled={invoice.invoiceStatus === 'DELIVERED' ? false : true}
        >
          Process
        </Button>
      </TableCell>
    </TableRow>
  );
};

export default ManualInvoiceRow;
