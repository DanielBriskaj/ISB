import React from 'react';
import {
  TableCell,
  TableRow,
  IconButton,
  Button,
  Switch,
} from '@material-ui/core';
import Label from 'src/view/materialUI/components/Label';
import PencilAltIcon from '../../../icons/PencilAlt';
import ArrowRightIcon from '../../../icons/ArrowRight';
import Download from 'src/icons/Download';
import { useDispatch } from 'react-redux';
import costOwnerInvoicesActions from 'src/modules/costOwnersInvoices/costOwnerInvoicesActions';

const getStatusLabel = invoiceStatus => {
  const map = {
    ASSIGNED: {
      color: 'warning',
      text: 'ASSIGNED',
    },
    ACCEPTED: {
      color: 'success',
      text: 'ACCEPTED',
    },
    SEND_SUBMIT: {
      color: 'primary',
      text: 'SEND_SUBMIT',
    },
    REQUEST_PAYMENT: {
      color: 'secondary',
      text: 'REQUEST_PAYMENT',
    },
    NEW: {
      color: 'primary',
      text: 'NEW',
    },
    APPROVED: {
      color: 'success',
      text: 'APPROVED',
    },
    IN_APPROVAL: {
      color: 'secondary',
      text: 'IN_APPROVAL',
    },
    DEFAULT: {
      color: 'primary',
      text: invoiceStatus,
    },
  };

  const { text, color }: any = map[invoiceStatus] || map.DEFAULT;

  return (
    <Label sx={{ p: '8px' }} color={color}>
      {text}
    </Label>
  );
};

const CostOwnerInvoiceRow = ({
  invoice,
  buttonData,
  page,
  rowsPerPage,
  handleModalOpen,
}) => {
  const dispatch = useDispatch();
  return (
    <TableRow key={invoice.eic} hover>
      {Object.keys(invoice).map(key => {
        if (key === 'status' || key === 'approved') {
          return (
            <TableCell align="center" key={key} padding="normal">
              {invoice[key] && getStatusLabel(invoice[key])}
            </TableCell>
          );
        }
        return (
          <TableCell
            padding="normal"
            key={key}
            sx={key === 'eic' ? { paddingLeft: 3 } : { paddingLeft: 0 }}
            align={
              key === 'id' ||
              key === 'invoiceNumber' ||
              key === 'importedInvoiceNumber' ||
              key === 'receivedDate' ||
              key === 'dueDate' ||
              key === 'status' ||
              key === 'NIPT'
                ? // key === 'downloadPdf' ||
                  // key === 'process'
                  'center'
                : key === 'amount'
                ? 'right'
                : 'left'
            }
          >
            {invoice[key]}
          </TableCell>
        );
      })}

      <TableCell align="center">
        <IconButton
          onClick={() => {
            handleModalOpen({ open: true, id: invoice?.id });
          }}
        >
          <PencilAltIcon fontSize="small" />
        </IconButton>
        <IconButton
          onClick={() =>
            dispatch(costOwnerInvoicesActions.downloadPdf({ eic: invoice.eic }))
          }
        >
          <Download />
        </IconButton>
      </TableCell>
      <TableCell align="center">
        <Button
          onClick={() => {
            buttonData[0].buttonFunction(invoice);
          }}
          disabled={invoice.status === 'ASSIGNED' ? false : true}
        >
          Process
        </Button>
      </TableCell>
    </TableRow>
  );
};

export default CostOwnerInvoiceRow;
