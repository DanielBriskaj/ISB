import { Store, createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import { IGlobalState } from '../models/GlobalState';
import { composeWithDevTools } from 'redux-devtools-extension/developmentOnly';
import createRootReducers from './reducers';

let store: Store<IGlobalState>;

export function configureStore(preloadedState?) {
  store = createStore(
    createRootReducers(),
    preloadedState,
    composeWithDevTools(applyMiddleware(thunk)),
  );

  return store;
}
