import { userApis } from './userApi';
import {
  USER_READ_SUCCESS,
  USER_GET_BY_ID,
  USER_CLEAR_DATA,
} from './userActiontypes';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
const userActions = {
  read: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await userApis.fetchUsers(query);

      if (response.success) {
        dispatch({
          type: USER_READ_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        dispatch({
          type: STATUS_ERROR,
          payload: response.payload,
        });
      }
    } catch {
      dispatch({
        type: STATUS_ERROR,
      });
    }
  },

  getUserById: (id: number) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await userApis.getUserById(id);
      if (response.success) {
        dispatch({
          type: USER_GET_BY_ID,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Failed To Get User' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  assignCo: data => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await userApis.assignCo(data);
      if (response.success) {
        dispatch(userActions.read());
        dispatch({ type: STATUS_LOADING_FALSE });
        notificationThrower({
          type: 'success',
          message: 'Cost Owner Assigned Successfully' as string,
        });
      } else {
        if (response?.payload?.response?.status === 409) {
          notificationThrower({
            type: 'error',
            message: 'Cost Owner Is Already Assigned To A User' as string,
          });
        } else {
          notificationThrower({
            type: 'error',
            message: 'Failed To Assign Cost Owner' as string,
          });
        }

        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateUser: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await userApis.updateUser(data);
      if (response.success) {
        dispatch(userActions.read(query));
        dispatch({ type: STATUS_LOADING_FALSE });
        notificationThrower({
          type: 'success',
          message: 'User Updated Successfully' as string,
        });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Failed To Update User' as string,
        });

        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateCoThenupdateUser: (data, query, clearCostOwner) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const coData = {
        userId: data?.userId,
        costOwnerId: clearCostOwner ? null : data?.costOwnerId,
      };

      const response = await userApis.assignCo(coData);
      if (response.success) {
        dispatch(userActions.updateUser(data, query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Failed To Update User' as string,
        });

        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  clearUserData: () => dispatch => {
    dispatch({ type: USER_CLEAR_DATA });
  },
};

export default userActions;
