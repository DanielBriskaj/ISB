import Request from '../../../src/helpers/request';
import getConfig from '../../../src/helpers/config';

const config = getConfig();

const { test } = config;

export const userApis = {
  fetchUsers: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/users`,
      query: query || {},
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
    }),
  getUserById: (id: number) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/users/${id}`,
    }),
  assignCo: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/users/assignCo`,
      data: data,
    }),
  updateUser: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/users/update`,
      data: data,
    }),
};
