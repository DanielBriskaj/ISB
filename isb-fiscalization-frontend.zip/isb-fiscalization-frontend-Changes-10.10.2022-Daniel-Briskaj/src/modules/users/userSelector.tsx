import { createSelector } from 'reselect';

const selectRaw = state => state.users;

const usersDataArray = createSelector([selectRaw], users => users.usersData);

const userData = createSelector([selectRaw], users => users.userData);

const loading = createSelector([selectRaw], users => users.loading);

const userSelector = {
  usersDataArray,
  userData,
  loading,
};

export default userSelector;
