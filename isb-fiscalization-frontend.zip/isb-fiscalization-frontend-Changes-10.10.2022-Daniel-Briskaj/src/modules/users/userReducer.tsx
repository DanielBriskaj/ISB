import { UsersData } from '../../models/data/users/UsersData';
import {
  USER_READ_SUCCESS,
  USER_GET_BY_ID,
  USER_CLEAR_DATA,
} from './userActiontypes';

const initailValues: UsersData = {
  usersData: [],
  userData: {},
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case USER_READ_SUCCESS:
      return {
        ...state,
        usersData: payload,
      };
    case USER_GET_BY_ID:
      return {
        ...state,
        userData: payload,
      };
    case USER_CLEAR_DATA:
      return {
        ...state,
        userData: {},
      };
  }
  return state;
}
