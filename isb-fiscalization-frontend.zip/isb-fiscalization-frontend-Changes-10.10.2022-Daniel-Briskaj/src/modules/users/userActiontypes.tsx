const prefix = 'USER';

export const USER_READ_SUCCESS = `${prefix}_READ_SUCCESS`;
export const USER_LOADING = `${prefix}_LOADING`;
export const USER_ERROR = `${prefix}_ERROR`;
export const USER_GET_BY_ID = `${prefix}_GET_BY_ID`;
export const USER_CLEAR_DATA = `${prefix}_CLEAR_DATA`;
