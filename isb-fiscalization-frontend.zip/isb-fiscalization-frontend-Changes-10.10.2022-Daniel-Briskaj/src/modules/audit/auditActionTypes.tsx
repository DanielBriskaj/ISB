const prefix = 'AUDIT';

export const AUDIT_SUCCESS = `${prefix}_SUCCESS`;
export const SET_CURRENT_PAGE = `SET_CURRENT_PAGE`;
