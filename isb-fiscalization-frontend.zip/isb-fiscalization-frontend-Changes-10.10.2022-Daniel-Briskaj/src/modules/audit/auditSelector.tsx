import { createSelector } from 'reselect';

const selectRaw = state => state.audit;

const auditDataArray = createSelector([selectRaw], audit => audit.auditsData);

const auditSelector = { auditDataArray };

export default auditSelector;
