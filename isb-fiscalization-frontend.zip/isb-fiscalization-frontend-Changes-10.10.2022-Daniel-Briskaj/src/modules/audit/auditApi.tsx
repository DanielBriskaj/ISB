import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

const auditApi = {
  fetchAudits: (query?) =>
    Request.doRequest({
      url: `${test.baseUrl}/audit`,
      method: 'get',
      query: query || {},
    }),
  exportAudit: () =>
    Request.doRequest({
      url: `${test.baseUrl}/audit/export`,
      method: 'get',
      responseType: 'blob',
    }),
};

export default auditApi;
