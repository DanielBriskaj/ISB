import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS_UPDATE_SUCCESS_MESSAGE,
  STATUS,
} from '../shared/statuses/statusesActionTypes';
import auditApi from './auditApi';
import { AUDIT_SUCCESS, SET_CURRENT_PAGE } from './auditActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';

const auditActions = {
  fetchAudits: (query?) => async dispatch => {
    try {
      if (!query) dispatch({ type: STATUS_LOADING_TRUE });
      const response = await auditApi.fetchAudits(query);
      if (response.success) {
        dispatch({
          type: AUDIT_SUCCESS,
          payload: response.payload?.data,
        });
        dispatch({
          type: STATUS_LOADING_FALSE,
        });
      } else
        notificationThrower({
          type: 'error',
          message: 'Something went wrong' as string,
        });
      dispatch({ type: STATUS_LOADING_FALSE });
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something went wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  setCurrentPage: page => dispatch => {
    dispatch({
      type: SET_CURRENT_PAGE,
      payload: page,
    });
  },
  exportAudit: () => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await auditApi.exportAudit();

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'audit.xlsx');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
};

export default auditActions;
