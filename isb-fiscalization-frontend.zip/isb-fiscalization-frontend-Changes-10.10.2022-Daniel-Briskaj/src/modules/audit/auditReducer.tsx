import { AUDIT_SUCCESS, SET_CURRENT_PAGE } from './auditActionTypes';
import { AuditsData } from 'src/models/data/audits/AuditData';

const initialValues: AuditsData = {
  auditsData: {},
};

export default function (state = initialValues, { type, payload }) {
  switch (type) {
    case AUDIT_SUCCESS:
      return {
        ...state,
        auditsData: payload,
      };
    case SET_CURRENT_PAGE:
      return {
        ...state,
        auditsData: {
          ...state,
          currentPage: payload,
        },
      };
  }
  return state;
}
