import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const suppliersSchema = yup.object().shape({
  userFirstName: yupFormSchemas.string(i18n('First Name'), {
    required: false,
  }),
  userLastName: yupFormSchemas.string(i18n('Last Name'), {
    required: false,
  }),
  userRole: yupFormSchemas
    .string(i18n('User Role'), {
      required: false,
    })
    .transform(function (value) {
      return !value ? '' : value;
    }),
  userTelephone: yupFormSchemas.string(i18n('User Telephone'), {
    required: false,
  }),
  userMobile: yupFormSchemas
    .string(i18n('User Mobile'), {
      required: false,
    })
    .transform(function (value) {
      return !value ? '' : value;
    }),
  userEmail: yupFormSchemas.string(i18n('User Email'), {
    required: false,
  }),
  userPreferredLanguage: yupFormSchemas.string(
    i18n('User Preferred Language'),
    {
      required: false,
    },
  ),
  userTimeZone: yupFormSchemas.string(i18n('User Time Zone'), {
    required: false,
  }),
  username: yupFormSchemas.string(i18n('Username'), {
    required: false,
  }),
  userCode: yupFormSchemas.string(i18n('User Code'), {
    required: false,
  }),
  registrationDate: yupFormSchemas.string(i18n('Registration Date'), {
    required: false,
  }),
  organisationLegalStructure: yupFormSchemas
    .string(i18n('Organisation Legal Structure'), {
      required: false,
    })
    .transform(function (value) {
      return !value ? '' : value;
    }),
  euVatNumber: yupFormSchemas.string(i18n('EU VAT Number'), {
    required: false,
  }),
  dunAndBradstreet: yupFormSchemas.string(i18n('Dun and Breadstreet'), {
    required: false,
  }),
  vatNumber: yupFormSchemas
    .string(i18n('Vat Number'), {
      required: false,
    })
    .transform(function (value) {
      return !value ? '' : value;
    }),
  address: yupFormSchemas
    .string(i18n('Address'), {
      required: false,
    })
    .transform(function (value) {
      return !value ? '' : value;
    }),
  city: yupFormSchemas.string(i18n('City'), {
    required: false,
  }),
  postalCode: yupFormSchemas.string(i18n('Postal Code'), {
    required: false,
  }),
  country: yupFormSchemas.string(i18n('Country'), {
    required: false,
  }),
  state: yupFormSchemas.string(i18n('State'), {
    required: false,
  }),
  mainPhoneNumber: yupFormSchemas.string(i18n('Main Phone Number'), {
    required: false,
  }),
  organizationFaxNumber: yupFormSchemas
    .string(i18n('Organisation Fax Number'), {
      required: false,
    })
    .transform(function (value) {
      return !value ? '' : value;
    }),
  webSite: yupFormSchemas.string(i18n('Web Site'), {
    required: false,
  }),
  bvd9: yupFormSchemas.string(i18n('BVD9'), {
    required: false,
  }),
  sapCode: yupFormSchemas.string(i18n('Sap Code'), {
    required: false,
  }),
  companyName: yupFormSchemas.string(i18n(`Company Name`), {
    required: true,
  }),
  companyRegistrationNumber: yupFormSchemas.string(
    i18n(`Company Registration Number`),
    {
      required: true,
    },
  ),
  alboCode: yupFormSchemas.string(i18n(`Albo Code`), {
    required: true,
  }),
  supplierAccountId: yupFormSchemas.integer(i18n(`Supplier Account ID`), {
    required: true,
  }),
  isLocal: yupFormSchemas.boolean(i18n(`Supplier Type`), {
    required: true,
  }),
  isBankClient: yupFormSchemas.boolean(i18n(`Bank Client`), {
    required: true,
  }),
  approved: yupFormSchemas.string(i18n(`Approved`), {
    required: false,
  }),
});
