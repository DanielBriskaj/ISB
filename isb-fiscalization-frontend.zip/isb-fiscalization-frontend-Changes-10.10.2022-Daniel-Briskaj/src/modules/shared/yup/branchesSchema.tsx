import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const branchesSchema = yup.object().shape({
  cityCode: yupFormSchemas.string(i18n(`City`), {
    required: true,
  }),
  branchCode: yupFormSchemas.integer(i18n(`Branch Code`), {
    required: true,
  }),
  description: yupFormSchemas.string(i18n(`Description`), {
    required: true,
  }),
  approved: yupFormSchemas.string(i18n(`Approved`), {
    required: true,
  }),
});
