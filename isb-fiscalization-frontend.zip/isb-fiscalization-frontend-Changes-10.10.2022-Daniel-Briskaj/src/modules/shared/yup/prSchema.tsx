import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const prSchema = yup.object({
  date: yupFormSchemas
    .date(i18n(`Date`), { required: true })
    .required('This field is required.'),
  unitType: yupFormSchemas.string(i18n(`Unit Type`), {
    required: false,
  }),
  place: yupFormSchemas.string(i18n(`Place`), {
    required: true,
  }),
  previousCurrency: yupFormSchemas.string(i18n(`Previous Year Currency`), {
    required: true,
  }),
  procScopeAsses: yupFormSchemas.boolean(i18n(`Scope Assessment`), {
    required: true,
  }),
  subject: yupFormSchemas
    .string(i18n(`Subject`), {
      required: true,
    })
    .max(100, '100 Characters Maximum'),
  previousValue: yupFormSchemas.integer(i18n(`Previous Year Value`), {
    required: true,
  }),
  approved: yupFormSchemas.string(i18n(`Approved Status`), {
    required: true,
  }),
  currency: yupFormSchemas.string(i18n(`Currency`), {
    required: true,
  }),
  code: yupFormSchemas.string(i18n(`Commodity Category Code`), {
    required: true,
  }),
  typeScopeCommitment: yupFormSchemas
    .string(i18n(`Type And Scope Of Commitment`), {
      required: true,
    })
    .max(1000, '1000 Characters Maximum'),
  prItems: yup.array().of(
    yup.object({
      description: yupFormSchemas
        .string(i18n(`Description`), {
          required: true,
        })
        .required('This field is required.'),
      goodCategory: yupFormSchemas.string(i18n(`Good Category`), {
        required: false,
      }),
      quantity: yupFormSchemas
        .decimal(i18n(`Quantity`), { required: true })
        .required('This field is required.'),
      unitCost: yupFormSchemas
        .decimal(i18n(`Unit Cost`), { required: true })
        .required('This field is required.'),
      deliveryPlace: yupFormSchemas.string(i18n(`Delivery Place`), {
        required: true,
      }),
      deliveryDate: yupFormSchemas.date(i18n(`Delivery Date`), {
        required: true,
      }),
    }),
  ),
  prSuppliers: yup.array().of(
    yup.object({
      id: yupFormSchemas
        .integer(i18n(`Id`), { required: true })
        .required('This field is required.'),
    }),
  ),
  availableFunds: yup.array().of(
    yup.object({
      projectName: yupFormSchemas
        .string(i18n(`Project Name`), {
          required: true,
        })
        .required('This field is required.'),
      currency: yupFormSchemas.string(i18n(`Currency`), {
        required: false,
      }),
      budgetedAmount: yupFormSchemas
        .decimal(i18n(`Budgeted Amount`), { required: true })
        .required('This field is required.'),
      amountExpensedYtd: yupFormSchemas
        .decimal(i18n(`YTD`), { required: true })
        .required('This field is required.'),
    }),
  ),
});
