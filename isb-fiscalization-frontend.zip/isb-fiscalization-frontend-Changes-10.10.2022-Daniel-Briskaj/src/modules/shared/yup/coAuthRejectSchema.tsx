import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const coAuthRejectSchema = yup.object().shape({
  reason: yupFormSchemas
    .string(i18n(`Reason`), {
      required: true,
    })
    .max(2000, 'Maximum 2000 characters'),
});
