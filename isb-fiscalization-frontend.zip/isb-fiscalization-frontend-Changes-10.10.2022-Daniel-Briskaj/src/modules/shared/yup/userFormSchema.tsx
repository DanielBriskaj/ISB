import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const userFormSchema = yup.object().shape({
  costOwner: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`costOwner id`), {
        required: true,
      }),
    })
    .nullable(),
});
