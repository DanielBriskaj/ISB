import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const glSchema = yup.object().shape({
  glCode: yupFormSchemas.string(i18n(`GL Code`), {
    required: true,
  }),
  description: yupFormSchemas.string(i18n(`Description`), {
    required: true,
  }),
  glAccrual: yupFormSchemas.string(i18n(`GL Accrual`), {
    required: false,
  }),
  approved: yupFormSchemas.string(i18n(`Is Approved`), {
    required: true,
  }),
});
