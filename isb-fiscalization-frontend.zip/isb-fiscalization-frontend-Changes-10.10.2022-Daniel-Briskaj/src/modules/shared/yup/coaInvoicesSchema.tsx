import * as yup from 'yup';
import yupFormSchemas from './yupFormSchemas';
import { i18n } from 'src/i18n';

export const coaInvoicesSchema = yup.object().shape({
  invoiceNumber: yupFormSchemas.string(i18n(`Invoice Number`), {
    required: false,
  }),
  eic: yupFormSchemas.string(i18n(`EIC`), {
    required: false,
  }),
  receivedDate: yupFormSchemas.string(i18n(`Recived Date`), {
    required: false,
  }),
  dueDate: yupFormSchemas.string(i18n(`Due Date`), {
    required: false,
  }),
  nipt: yupFormSchemas.string(i18n(`NIPT`), {
    required: false,
  }),
  amount: yupFormSchemas.decimal(i18n(`Amount`), {
    required: false,
  }),
  invoiceStatus: yupFormSchemas.string(i18n(`Status`), {
    required: false,
  }),
  description: yupFormSchemas.string(i18n(`Description`), {
    required: false,
  }),
  currency: yupFormSchemas.string(i18n(`Currency`), {
    required: false,
  }),
  vat: yupFormSchemas.decimal(i18n(`VAT`), {
    required: false,
  }),
});
