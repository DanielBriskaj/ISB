import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const budgetSchema = yup.object().shape({
  name: yupFormSchemas.string(i18n(`Budget Name`), {
    required: true,
  }),
  year: yupFormSchemas
    .string(i18n(`Budget Year`), {
      required: true,
    })
    .test('len', 'Please enter a correct year', val => val?.length === 4),
  dueDate: yupFormSchemas.date(i18n(`Due Date`), {
    required: true,
  }),
});
