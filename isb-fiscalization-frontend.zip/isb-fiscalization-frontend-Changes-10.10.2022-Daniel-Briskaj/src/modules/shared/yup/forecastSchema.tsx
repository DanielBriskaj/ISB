import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const forecastSchema = yup.object().shape({
  name: yupFormSchemas.string(i18n(`Forecast Name`), {
    required: true,
  }),
  month: yupFormSchemas
    .integer(i18n('Forecast Month'), {
      required: true,
    })
    .min(1, "Month Can't Be Lower Than 1")
    .max(12, "Month Can't Be Higher Than 12"),
  year: yupFormSchemas
    .string(i18n(`Forecast Year`), {
      required: true,
    })
    .test('len', 'Please enter a correct year', val => val?.length === 4),
  dueDate: yupFormSchemas.date(i18n(`Due Date`), {
    required: true,
  }),
});
