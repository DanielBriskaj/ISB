import * as yup from 'yup';
import yupFormSchemas from './yupFormSchemas';
import { i18n } from 'src/i18n';

export const manualInvoiceSchema = yup.object().shape({
  supplier: yup
    .object()
    .shape({
      id: yupFormSchemas.string('Id', {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('supplier', 'Please select a Supplier', contractData =>
      !contractData.id ? false : true,
    ),
  invoiceNumber: yupFormSchemas.string(i18n(`Invoice Number`), {
    required: true,
  }),

  receivedDate: yupFormSchemas.string(i18n(` Received Date`), {
    required: true,
  }),
  dueDate: yupFormSchemas.string(i18n(`Due Date`), {
    required: true,
  }),
  nipt: yupFormSchemas.string(i18n(`NIPT`), {
    required: true,
  }),

  currency: yupFormSchemas.string(i18n(`Currency`), {
    required: true,
  }),
  invoiceStatus: yupFormSchemas.string(i18n(`Invoice Status`), {
    required: false,
  }),
  amount: yupFormSchemas.decimal(i18n(`Amount`), {
    required: false,
  }),

  vat: yupFormSchemas
    .decimal(i18n(`VAT`), {
      required: true,
    })
    .max(1, "Can't be higher than 1"),
  description: yupFormSchemas.string(i18n(`Description`), {
    required: false,
  }),
});
