import * as yup from 'yup';
import yupFormSchemas from './yupFormSchemas';
import { i18n } from 'src/i18n';

export const costOwnerInvoicesSchema = yup.object().shape({
  id: yupFormSchemas.string('Id', { required: false }),
  eic: yupFormSchemas.string(i18n(`EIC`), {
    required: false,
  }),
  invoiceNumber: yupFormSchemas.string(i18n(`Invoice Number`), {
    required: false,
  }),
  importedInvoiceNumber: yupFormSchemas.string(
    i18n(`Imported Invoice Number`),
    {
      required: false,
    },
  ),
  receivedDate: yupFormSchemas.string(i18n(`Recived Date`), {
    required: false,
  }),
  dueDate: yupFormSchemas.string(i18n(`Due Date`), {
    required: false,
  }),
  amount: yupFormSchemas.decimal(i18n(`Amount`), {
    required: false,
  }),
  invoiceStatus: yupFormSchemas.string(i18n(`Invoice Status`), {
    required: false,
  }),
  nipt: yupFormSchemas.string(i18n(`NIPT`), {
    required: false,
  }),
  contract: yup
    .object()
    .shape({
      id: yupFormSchemas.integer('Contracts Id', {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('contracts', 'Please select a Contract', contractData =>
      !contractData.id ? false : true,
    ),
  po: yup.object().shape({
    id: yupFormSchemas.integer('Purchase Order Id', {
      required: false,
    }),
  }),
  costOwner: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`Cost Owner id`), {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('costOwner', 'Please select a Cost Owner', costOwnerData =>
      !costOwnerData.id ? false : true,
    ),
});
