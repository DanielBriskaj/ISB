import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const costOwnerSchema = yup.object().shape({
  ownerName: yupFormSchemas.string(i18n(`Owner Name`), {
    required: true,
  }),
  code: yupFormSchemas.string(i18n(`Code`), {
    required: true,
  }),
  division: yupFormSchemas.string(i18n(`Description`), {
    required: true,
  }),
  isAuthorizer: yupFormSchemas.boolean(i18n(`Is Authorized`), {
    required: true,
  }),
  approved: yupFormSchemas.string(i18n(`Approved`), {
    required: true,
  }),
});
