import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const invoiceMemoSchema = (isManual: boolean) => {
  const schema = yup.object().shape({
    nivf: yupFormSchemas.string(i18n(`NIVF`), {
      required: !isManual,
    }),
    valueDate: yupFormSchemas.string(i18n(`Value Date`), {
      required: true,
    }),
    subject: yupFormSchemas.string(i18n(`Subject`), {
      required: true,
    }),
    bankName: yupFormSchemas.string(i18n(`Bank Name`), {
      required: false,
    }),
    iban: yupFormSchemas.string(i18n(`IBAN`), {
      required: false,
    }),
    currency: yupFormSchemas.string(i18n(`Currency`), {
      required: true,
    }),
    invoiceGls: yup
      .array()
      .of(
        yup.object().shape({
          id: yupFormSchemas.integer(i18n(`Invoice GL Id`), {
            required: true,
          }),
          value: yupFormSchemas.string(i18n(`Value`), {
            required: true,
          }),
          debitCredit: yupFormSchemas.string(i18n(`Value`), {
            required: true,
          }),
          description: yupFormSchemas.string(i18n(`Value`), {
            required: true,
          }),
          branch: yup.object().shape({
            id: yupFormSchemas.integer(i18n(`Branch Id`), {
              required: true,
            }),
          }),
          gl: yup.object().shape({
            id: yupFormSchemas.integer(i18n(`GL Id`), {
              required: true,
            }),
          }),
        }),
      )
      .test({
        message: `Invoice GL's Are Required`,
        test: arr => arr.length !== 0,
      }),
  });
  return schema;
};
