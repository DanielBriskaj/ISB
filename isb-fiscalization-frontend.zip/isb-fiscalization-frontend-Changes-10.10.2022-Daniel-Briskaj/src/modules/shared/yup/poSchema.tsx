import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const poSchema = yup.object({
  date: yupFormSchemas.date(i18n(`Date`), { required: true }),
  supplier: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`Supplier id`), {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('supplier', 'Please select a Supplier', supplier =>
      !supplier.id ? false : true,
    ),
  contract: yup.lazy(value => {
    switch (typeof value) {
      case 'object':
        return yup
          .object()
          .shape({
            id: yupFormSchemas.integer(i18n(`contract id`), {
              required: false,
            }),
          })
          .nullable();
      case 'undefined':
        return yup.string().default(null).nullable();
      default:
        throw new yup.ValidationError('Must be an object or `undefined`');
    }
  }),
  deliverAtName: yupFormSchemas.string(i18n(`Deliver at Name`), {
    required: true,
  }),
  deliverAtAddress: yupFormSchemas.string(i18n(`Deliver at Address`), {
    required: true,
  }),
  deliverAtTelFax: yupFormSchemas.string(i18n(`Deliver at Tel Fax`), {
    required: true,
  }),
  deliverAtCel: yupFormSchemas.string(i18n(`Deliver Ar Cel`), {
    required: true,
  }),
  deliverAtEmail: yupFormSchemas.string(i18n(`Deliver At Email`), {
    required: true,
  }),
  transportedVia: yupFormSchemas.string(i18n(`Transported`), {
    required: false,
  }),
  termsOfTransportation: yupFormSchemas.string(i18n(`Terms of Transport`), {
    required: false,
  }),
  poStatus: yupFormSchemas.string(i18n(`Purchase Order Status`), {
    required: true,
  }),
  currency: yupFormSchemas.string(i18n(`Currency`), {
    required: true,
  }),
  description: yupFormSchemas.string(i18n(`Description`), {
    required: false,
  }),
  costOwner: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`costOwner id`), {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('costOwner', 'Please select a costOwner', costOwner =>
      !costOwner.id ? false : true,
    ),
  poItems: yup.array().of(
    yup.object({
      description: yupFormSchemas.string(i18n(`Description`), {
        required: true,
      }),
      quantity: yupFormSchemas.decimal(i18n(`Quantity`), { required: true }),
      price: yupFormSchemas.decimal(i18n(`Price`), { required: true }),
    }),
  ),
});
