import * as yup from 'yup';
import yupFormSchemas from 'src/modules/shared/yup/yupFormSchemas';
import { i18n } from 'src/i18n';

export const contractsSchema = yup.object().shape({
  expenditureType: yupFormSchemas.string(i18n(`CAPEX`), {
    required: true,
  }),
  supplier: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`Supplier id`), {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('supplier', 'Please select a Supplier', supplier =>
      !supplier.id ? false : true,
    ),
  branch: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`Branch id`), {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('branch', 'Please select a Branch', branch =>
      !branch.id ? false : true,
    ),
  budgetCode: yupFormSchemas.string(i18n(`Budget Code`), {
    required: true,
  }),
  costOwner: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`Cost Owner id`), {
        required: true,
      }),
      code: yupFormSchemas.string(i18n(`Code`), {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('costOwner', 'Please select a Cost Owner', costOwner =>
      !costOwner.id ? false : true,
    ),
  contractDescription: yupFormSchemas.string(i18n(`Contract Description`), {
    required: true,
  }),
  startDate: yupFormSchemas
    .date(i18n(`Start Date`), {
      required: true,
    })
    .required('Start date is a required field.'),
  endDate: yupFormSchemas.date(i18n(`End Date`), {
    required: true,
  }),
  currency: yupFormSchemas.string(i18n(`Currency`), {
    required: true,
  }),
  automaticRenewal: yupFormSchemas.boolean(i18n(`Automatic Renewal`), {
    required: true,
  }),
  productDescription: yupFormSchemas.string(i18n(`Product Description`), {
    required: true,
  }),
  exitOption: yupFormSchemas.boolean(i18n(`Exit Option`), {
    required: true,
  }),
  contractAmount: yupFormSchemas.decimal(i18n(`Contract Amount`), {
    required: true,
  }),
  fixedOrVariable: yupFormSchemas.string(i18n(`Fixed Or Variable`), {
    required: true,
  }),
  prepayment: yupFormSchemas.boolean(i18n(`Contract Description`), {
    required: true,
  }),
  isVat: yupFormSchemas.boolean(i18n(`ISVAT`), {
    required: true,
  }),
  vat: yupFormSchemas
    .decimal(i18n(`VAT`), {
      required: true,
    })
    .max(1, "Can't be higher than 1"),
  gl: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`GL id`), {
        required: true,
      }),
    })
    .required('This field is required.')
    .test('gl', 'Please select a GL', gl => (!gl.id ? false : true)),

  iban: yupFormSchemas.string(i18n(`IBAN`), {
    required: true,
  }),
  isCriticalContract: yupFormSchemas.boolean(i18n(`Critical Contract`), {
    required: true,
  }),
  contractStatus: yupFormSchemas.enumerator(i18n(`Contract Status`), {
    required: false,
    options: ['ACTIVE', 'EXPIRED', 'BUDGET', 'FORECAST', 'NEW', 'IN_APPROVAL'],
  }),
  resolutionClauses: yupFormSchemas.boolean(i18n(`Resolution Clauses`), {
    required: true,
  }),
  project: yupFormSchemas.string(i18n(`Project`), {
    required: false,
  }),
  integration: yupFormSchemas.boolean(i18n(`Integration`), {
    required: true,
  }),
  bankContactPerson: yupFormSchemas.string(i18n(`Bank Contact Person`), {
    required: true,
  }),
  contractCode: yupFormSchemas.string(i18n(`Contract Code`), {
    required: false,
  }),
  parentContract: yup
    .object()
    .shape({
      id: yupFormSchemas.integer(i18n(`Parent Contact id`), {
        required: true,
      }),
    })
    .nullable(),
  approved: yupFormSchemas.string(i18n(`Approved`), {
    required: false,
  }),
  authorizerFeedback: yupFormSchemas
    .string(i18n(`Notes`), {
      required: false,
    })
    .max(2000, 'Maximum 2000 characters'),
});
