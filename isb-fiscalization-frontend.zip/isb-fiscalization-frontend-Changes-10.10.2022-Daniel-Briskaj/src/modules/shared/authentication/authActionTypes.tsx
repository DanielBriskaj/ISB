const prefix = 'Auth';

export const AUTH_LOADING = `${prefix}_LOADING`;
export const AUTH_SUCCESS = `${prefix}_SUCCESS`;
export const AUTH_CONFIRM = `${prefix}_CONFIRM`;
export const AUTH_ROLE = `${prefix}_ROLE`;
export const AUTH_ERROR = `${prefix}_ERROR`;
