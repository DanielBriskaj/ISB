import { createSelector } from 'reselect';

const selectRaw = state => state.auth;

const authData = createSelector([selectRaw], auth => auth.authData);

const loading = createSelector([selectRaw], auth => auth.loading);
const error = createSelector([selectRaw], auth => auth.error);

const authSelector = {
  authData,
  loading,
  error,
};

export default authSelector;
