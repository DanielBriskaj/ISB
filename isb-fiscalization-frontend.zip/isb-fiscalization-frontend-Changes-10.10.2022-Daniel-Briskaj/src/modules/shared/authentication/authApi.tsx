import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const authApis = {
  login: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/auth/login`,
      data,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
    }),
  getRole: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/auth/role`,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
    }),
  getLoggedInUser: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/users/getLoggedInUser`,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
    }),
};
