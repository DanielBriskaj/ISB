import { AuthenticationData } from 'src/models/data/auth/AuthenticationData';
import {
  AUTH_ERROR,
  AUTH_LOADING,
  AUTH_SUCCESS,
  AUTH_CONFIRM,
  AUTH_ROLE,
} from './authActionTypes';

export enum ROLES {
  COST_OWNER = 'COST_OWNER',
  COST_OWNER_AUTHORIZER = 'COST_OWNER_AUTHORIZER',
  ACCOUNTING_INPUT = 'ACCOUNTING_INPUT',
  ACCOUNTING_AUTHORIZER = 'ACCOUNTING_AUTHORIZER',
  PROCUREMENT_INPUT = 'PROCUREMENT_INPUT',
  PROCUREMENT_AUTHORIZER = 'PROCUREMENT_AUTHORIZER',
  PLANNING_CONTROL_INPUT = 'PLANNING_CONTROL_INPUT',
  PLANNING_CONTROL_AUTHORIZER = 'PLANNING_CONTROL_AUTHORIZER',
  TBO_INPUT = 'TBO_INPUT',
  TBO_AUTHORIZER = 'TBO_AUTHORIZER',
}

const initailValues: AuthenticationData = {
  loading: false,
  error: false,
  authData: {
    jwt: '',
    isLoggedIn: false,
    role: '',
    costOwnerId: 0,
    costOwnerCode: '',
    ownerName: '',
    name: '',
    surname: '',
    username: '',
    division: ' ',
  },
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case AUTH_LOADING:
      return {
        ...state,
        loading: true,
        error: false,
      };
    case AUTH_CONFIRM:
      return {
        ...state,
        loading: false,
        authData: {
          ...state.authData,
          jwt: payload.jwt,
          isLoggedIn: payload.isLoggedIn,
          role: payload.role,
          costOwnerId: payload.costOwnerId,
          costOwnerCode: payload.code,
          ownerName: payload?.ownerName,
          name: payload.name,
          surname: payload.surname,
          username: payload.username,
          division: payload.division,
        },
      };
    case AUTH_ERROR:
      return {
        ...state,
        loading: false,
        error: payload,
      };
  }
  return state;
}
