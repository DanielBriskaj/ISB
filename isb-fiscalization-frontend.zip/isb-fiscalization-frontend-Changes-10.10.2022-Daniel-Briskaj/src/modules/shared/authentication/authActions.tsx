import { authApis } from './authApi';
import { AUTH_SUCCESS, AUTH_CONFIRM, AUTH_ROLE } from './authActionTypes';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
} from '../statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';

const authActions = {
  confirmLogin: () => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const loginResponse = await authApis.getLoggedInUser();
      if (loginResponse.success) {
        const jwt = localStorage.getItem('idToken');
        const authData = {
          jwt,
          isLoggedIn: true,
          role: loginResponse.payload.data.role,
          costOwnerId: loginResponse.payload.data.costOwner?.id,
          code: loginResponse.payload.data.costOwner?.code,
          name: loginResponse.payload.data.name,
          surname: loginResponse.payload.data.surname,
          username: loginResponse.payload.data.username,
          division: loginResponse.payload.data.costOwner?.division,
          ownerName: loginResponse.payload?.data?.costOwner?.ownerName,
        };
        dispatch({
          type: AUTH_CONFIRM,
          payload: authData,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        dispatch({
          type: STATUS_ERROR,
          payload: loginResponse.payload,
        });
      }
    } catch (error) {
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },
  login: data => async dispatch => {
    try {
      localStorage.removeItem('idToken');
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await authApis.login(data);
      if (response.success) {
        try {
          localStorage.setItem('idToken', response.payload.data.jwt);
          const loginResponse = await authApis.getLoggedInUser();
          if (loginResponse.success) {
            const jwt = localStorage.getItem('idToken');
            const authData = {
              jwt,
              isLoggedIn: true,
              role: loginResponse.payload.data.role,
              costOwnerId: loginResponse.payload.data.costOwner?.id,
              name: loginResponse.payload.data.name,
              surname: loginResponse.payload.data.surname,
              username: loginResponse.payload.data.username,
              division: loginResponse.payload.data.costOwner?.division,
            };
            dispatch({
              type: AUTH_CONFIRM,
              payload: authData,
            });
            dispatch({ type: STATUS_LOADING_FALSE });
          } else {
            if (!response.success && response.payload.response.status === 500) {
              dispatch({
                type: STATUS_LOADING_FALSE,
              });
            }
          }
        } catch (error) {
          dispatch({
            type: STATUS_ERROR,
            payload: error,
          });
        }
      } else {
        dispatch({
          type: STATUS_ERROR,
          payload: response.payload,
        });
      }
    } catch (error) {
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },
};

export default authActions;
