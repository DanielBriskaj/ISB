import { createSelector } from 'reselect';

const selectRaw = state => state.options;

const branchesOptions = createSelector(
  [selectRaw],
  options => options.branchesOptions,
);

const suppliersOptions = createSelector(
  [selectRaw],
  options => options.suppliersOptions,
);

const costOwnersOptions = createSelector(
  [selectRaw],
  options => options.costOwnersOptions,
);

const contractsOptions = createSelector(
  [selectRaw],
  options => options.contractsOptions,
);

const poOptions = createSelector([selectRaw], options => options.poOptions);

const loading = createSelector([selectRaw], options => options.loading);

const optionSelector = {
  branchesOptions,
  suppliersOptions,
  costOwnersOptions,
  contractsOptions,
  poOptions,
  loading,
};

export default optionSelector;
