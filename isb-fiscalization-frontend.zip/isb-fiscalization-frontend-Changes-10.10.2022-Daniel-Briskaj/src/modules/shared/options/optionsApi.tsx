import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const optionsApis = {
  fetchSuppliers: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/suppliers`,
      query: query || {},
    }),
  fetchBranches: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/branches`,
      query: query || {},
    }),
  fetchCostOwmers: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/cost-owners`,
      query: query || {},
    }),
  fetchContracts: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts`,
      query: query || {},
    }),
  fetchPO: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/po`,
      query: query || {},
    }),
};
