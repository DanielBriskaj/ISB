import { optionsApis } from './optionsApi';
import {
  OPTIONS_ERROR,
  OPTIONS_GET_BRANCHES,
  OPTIONS_GET_COSTOWNERS,
  OPTIONS_GET_SUPPLIERS,
  OPTIONS_LOADING,
  SET_CURRENT_PAGE,
  OPTIONS_GET_PO,
  OPTIONS_GET_CONTRACTS,
  OPTIONS_CLEAR_DATA,
} from './optionsActionTypes';

const optionsActions = {
  readSuppliers: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: OPTIONS_LOADING });
      }
      const response = await optionsApis.fetchSuppliers(query);

      if (response.success) {
        dispatch({
          type: OPTIONS_GET_SUPPLIERS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
      } else {
        dispatch({
          type: OPTIONS_ERROR,
          payload: response.payload,
        });
      }
    } catch {
      dispatch({
        type: OPTIONS_ERROR,
      });
    }
  },
  fetchPo: (query?) => async dispatch => {
    try {
      dispatch({ type: OPTIONS_LOADING });
      const response = await optionsApis.fetchPO(query);
      if (response.success) {
        dispatch({
          type: OPTIONS_GET_PO,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
      } else {
        dispatch({
          type: OPTIONS_ERROR,
          payload: response.payload,
        });
      }
    } catch (error) {
      dispatch({
        type: OPTIONS_ERROR,
        payload: error,
      });
    }
  },

  readBranches: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: OPTIONS_LOADING });
      }
      const response = await optionsApis.fetchBranches(query);

      if (response.success) {
        dispatch({
          type: OPTIONS_GET_BRANCHES,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
      } else {
        dispatch({
          type: OPTIONS_ERROR,
          payload: response.payload,
        });
      }
    } catch {
      dispatch({
        type: OPTIONS_ERROR,
      });
    }
  },

  readCostOwners: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: OPTIONS_LOADING });
      }
      const response = await optionsApis.fetchCostOwmers(query);

      if (response.success) {
        dispatch({
          type: OPTIONS_GET_COSTOWNERS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
      } else {
        dispatch({
          type: OPTIONS_ERROR,
          payload: response.payload,
        });
      }
    } catch {
      dispatch({
        type: OPTIONS_ERROR,
      });
    }
  },

  readContracts: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: OPTIONS_LOADING });
      }
      const response = await optionsApis.fetchContracts(query);

      if (response.success) {
        dispatch({
          type: OPTIONS_GET_CONTRACTS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
      } else {
        dispatch({
          type: OPTIONS_ERROR,
          payload: response.payload,
        });
      }
    } catch {
      dispatch({
        type: OPTIONS_ERROR,
      });
    }
  },

  setCurrentPage: page => dispatch => {
    dispatch({
      type: SET_CURRENT_PAGE,
      payload: page,
    });
  },

  clearOptionsData: () => dispatch => {
    dispatch({ type: OPTIONS_CLEAR_DATA });
  },
};

export default optionsActions;
