const prefix = 'OPTIONS';

export const OPTIONS_LOADING = `${prefix}_LOADING`;
export const OPTIONS_ERROR = `${prefix}_ERROR`;
export const OPTIONS_GET_SUPPLIERS = `${prefix}_GET_SUPPLIERS`;
export const OPTIONS_GET_BRANCHES = `${prefix}_GET_BRANCHES`;
export const OPTIONS_GET_PO = `${prefix}_GET_PO`;
export const OPTIONS_GET_COSTOWNERS = `${prefix}_GET_COSTOWNERS`;
export const OPTIONS_GET_CONTRACTS = `${prefix}_GET_CONTRACTS`;
export const SET_CURRENT_PAGE = `SET_CURRENT_PAGE`;
export const OPTIONS_CLEAR_DATA = `${prefix}_CLEAR_DATA`;
