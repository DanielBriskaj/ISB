import { OptionsData } from 'src/models/data/options/OptionsData';
import {
  OPTIONS_ERROR,
  SET_CURRENT_PAGE,
  OPTIONS_GET_BRANCHES,
  OPTIONS_GET_COSTOWNERS,
  OPTIONS_GET_SUPPLIERS,
  OPTIONS_GET_CONTRACTS,
  OPTIONS_LOADING,
  OPTIONS_GET_PO,
  OPTIONS_CLEAR_DATA,
} from './optionsActionTypes';

const initailValues: OptionsData = {
  loading: false,
  error: false,
  branchesOptions: {},
  suppliersOptions: {},
  costOwnersOptions: {},
  contractsOptions: {},
  poOptions: {},
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case OPTIONS_LOADING:
      return {
        ...state,
        loading: true,
        error: false,
      };
    case OPTIONS_GET_BRANCHES:
      return {
        ...state,
        loading: false,
        branchesOptions: payload,
      };
    case OPTIONS_GET_PO:
      return {
        ...state,
        loading: false,
        poOptions: payload,
      };
    case OPTIONS_GET_COSTOWNERS:
      return {
        ...state,
        loading: false,
        costOwnersOptions: payload,
      };
    case OPTIONS_GET_SUPPLIERS:
      return {
        ...state,
        loading: false,
        suppliersOptions: payload,
      };
    case OPTIONS_GET_CONTRACTS:
      return {
        ...state,
        loading: false,
        contractsOptions: payload,
      };

    case OPTIONS_ERROR:
      return {
        ...state,
        loading: false,
        subLoading: false,
        error: payload,
      };
    case SET_CURRENT_PAGE:
      return {
        ...state,
      };
    case OPTIONS_CLEAR_DATA:
      return {
        ...state,
        branchesOptions: {},
        suppliersOptions: {},
        costOwnersOptions: {},
        contractsOptions: {},
        poOptions: {},
      };
  }
  return state;
}
