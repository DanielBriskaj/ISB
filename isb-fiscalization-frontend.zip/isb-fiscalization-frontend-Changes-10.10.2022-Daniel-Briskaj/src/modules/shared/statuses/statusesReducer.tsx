import { StatusData } from 'src/models/data/status/StatusData';
import {
  STATUS_ERROR,
  STATUS_LOADING_FALSE,
  STATUS_LOADING_TRUE,
  STATUS_CLEAR_ERROR_MESSAGE,
  STATUS_CLEAR_SUCCESS_MESSAGE,
  STATUS_UPDATE_ERROR_MESSAGE,
  STATUS_UPDATE_SUCCESS_MESSAGE,
  STATUS_CLEAR_WARNING_MESSAGE,
  STATUS_UPDATE_WARNING_MESSAGE,
} from './statusesActionTypes';

const InitialValues: StatusData = {
  loading: false,
  error: false,
  errorMessage: null,
  successMessage: null,
  warningMessage: null,
};

export default function (state = InitialValues, { type, payload }) {
  switch (type) {
    case STATUS_LOADING_TRUE:
      return {
        ...state,
        loading: true,
        error: false,
      };
    case STATUS_LOADING_FALSE:
      return {
        ...state,
        loading: false,
        error: false,
      };
    case STATUS_ERROR:
      if (payload?.response?.status === 409) {
        return {
          ...state,
          loading: false,
          warningMessage: payload.response.data,
          error: payload,
        };
      }
      return {
        ...state,
        loading: false,
        errorMessage: 'Internal Server Error',
        error: payload,
      };
    case STATUS_CLEAR_ERROR_MESSAGE:
      return {
        ...state,
        errorMessage: null,
      };
    case STATUS_CLEAR_SUCCESS_MESSAGE:
      return {
        ...state,
        successMessage: null,
      };
    case STATUS_CLEAR_WARNING_MESSAGE:
      return {
        ...state,
        warningMessage: null,
      };
    case STATUS_UPDATE_SUCCESS_MESSAGE:
      return {
        ...state,
        successMessage: payload,
      };
    case STATUS_UPDATE_WARNING_MESSAGE:
      return {
        ...state,
        warningMessage: payload,
      };
    case STATUS_UPDATE_ERROR_MESSAGE:
      return {
        ...state,
        errorMessage: payload,
      };
    default:
      return state;
  }
}
