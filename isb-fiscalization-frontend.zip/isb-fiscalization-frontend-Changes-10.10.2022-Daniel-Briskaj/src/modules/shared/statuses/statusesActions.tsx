import {
  STATUS_CLEAR_SUCCESS_MESSAGE,
  STATUS_CLEAR_ERROR_MESSAGE,
  STATUS_UPDATE_ERROR_MESSAGE,
  STATUS_UPDATE_SUCCESS_MESSAGE,
  STATUS_CLEAR_WARNING_MESSAGE,
  STATUS_UPDATE_WARNING_MESSAGE,
} from './statusesActionTypes';

const statusActions = {
  clearErrorMessage: () => dispatch => {
    dispatch({ type: STATUS_CLEAR_ERROR_MESSAGE });
  },

  clearSuccessMessage: () => dispatch => {
    dispatch({ type: STATUS_CLEAR_SUCCESS_MESSAGE });
  },

  updateErrorMessage: payload => dispatch => {
    dispatch({ type: STATUS_UPDATE_ERROR_MESSAGE, payload });
  },

  updateSuccessMessage: payload => dispatch => {
    dispatch({ type: STATUS_UPDATE_SUCCESS_MESSAGE, payload });
  },

  clearWarningMessage: () => dispatch => {
    dispatch({ type: STATUS_CLEAR_WARNING_MESSAGE });
  },

  updateWarningMessage: payload => dispatch => {
    dispatch({ type: STATUS_UPDATE_WARNING_MESSAGE, payload });
  },
};

export default statusActions;
