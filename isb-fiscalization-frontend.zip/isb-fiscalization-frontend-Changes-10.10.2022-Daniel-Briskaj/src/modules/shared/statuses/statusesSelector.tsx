import { createSelector } from 'reselect';

const selectRaw = state => state.status;

const loading = createSelector([selectRaw], status => status.loading);
const error = createSelector([selectRaw], status => status.error);
const errorMessage = createSelector([selectRaw], status => status.errorMessage);
const warningMessage = createSelector(
  [selectRaw],
  status => status.warningMessage,
);
const successMessage = createSelector(
  [selectRaw],
  status => status.successMessage,
);

const statusSelector = {
  loading,
  error,
  errorMessage,
  successMessage,
  warningMessage,
};

export default statusSelector;
