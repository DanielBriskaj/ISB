const prefix = 'STATUS';

export const STATUS_LOADING_TRUE = `${prefix}_LOADING_TRUE`;
export const STATUS_LOADING_FALSE = `${prefix}_LOADING_FALSE`;
export const STATUS_ERROR = `${prefix}_ERROR`;
export const STATUS_CLEAR_ERROR_MESSAGE = `${prefix}_CLEAR_ERROR_MESSAGE`;
export const STATUS_UPDATE_ERROR_MESSAGE = `${prefix}_UPDATE_ERROR_MESSAGE`;
export const STATUS_CLEAR_SUCCESS_MESSAGE = `${prefix}_CLEAR_SUCCESS_MESSAGE`;
export const STATUS_UPDATE_SUCCESS_MESSAGE = `${prefix}UPDATE_SUCCESS_MESSAGE`;
export const STATUS_CLEAR_WARNING_MESSAGE = `${prefix}_CLEAR_WARNING_MESSAGE`;
export const STATUS_UPDATE_WARNING_MESSAGE = `${prefix}UPDATE_WARNING_MESSAGE`;
export const STATUS = `${prefix}`;
