import { InvoicesData } from 'src/models/data/invoices/InvoiceData';
import {
  INVOICE_READ_SUCCESS,
  INVOICE_GET_BY_ID_SUCCESS,
  INVOICE_ASSIGN_COSTOWNERS,
  INVOICE_GET_COSTOWNERS,
  INVOICE_ACCEPTED_READ_SUCCESS,
  INVOICE_SET_CURRENT_TAB,
  INVOICE_LOADING,
  INVOICE_CLEAR_CO_OPTIONS,
  INVOICE_EBILLS_READ_SUCCESS,
  INVOICE_CLEAR_SINGLE_INVOICE,
  INVOICE_CLEAR_DATA,
} from './invoiceActionTypes';

const initailValues: InvoicesData = {
  invoicesData: [],
  ebillsData: [],
  acceptedInvoicesData: null,
  invoiceData: {},
  costOwnersOptions: {},
  currentTab: 'invoices',
  loading: false,
};

export enum INVOICE_STATUS {
  ASSIGNED = 'ASSIGNED',
  SEND_SUBMIT = 'SEND_SUBMIT',
  ACCEPTED = 'ACCEPTED',
  REQUEST_PAYMENT = 'REQUEST_PAYMENT',
  APPROVED_PAYMENT = 'APPROVED_PAYMENT',
  PAID = 'PAID',
}

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case INVOICE_READ_SUCCESS:
      return {
        ...state,
        invoicesData: payload,
      };
    case INVOICE_ACCEPTED_READ_SUCCESS:
      return {
        ...state,
        acceptedInvoicesData: payload,
      };
    case INVOICE_GET_COSTOWNERS:
      return {
        ...state,
        costOwnersOptions: payload,
      };
    case INVOICE_ASSIGN_COSTOWNERS:
      return {
        ...state,
        invoiceData: payload,
      };
    case INVOICE_SET_CURRENT_TAB:
      return {
        ...state,
        currentTab: payload,
      };
    case INVOICE_LOADING:
      return {
        ...state,
        loading: payload,
      };
    case INVOICE_GET_BY_ID_SUCCESS:
      return {
        ...state,
        invoiceData: payload,
      };
    case INVOICE_CLEAR_CO_OPTIONS:
      return {
        ...state,
        costOwnersOptions: {},
      };
    case INVOICE_EBILLS_READ_SUCCESS:
      return {
        ...state,
        ebillsData: payload,
      };
    case INVOICE_CLEAR_SINGLE_INVOICE:
      return {
        ...state,
        invoiceData: {},
      };
    case INVOICE_CLEAR_DATA:
      return {
        ...state,
        invoicesData: [],
        ebillsData: [],
        acceptedInvoicesData: null,
        invoiceData: {},
      };
  }
  return state;
}
