import { createSelector } from 'reselect';

const selectRaw = state => state.invoices;

const invoicesDataArray = createSelector(
  [selectRaw],
  invoices => invoices.invoicesData,
);
const eBillsDataArray = createSelector(
  [selectRaw],
  invoices => invoices.ebillsData,
);
const acceptedInvoicesData = createSelector(
  [selectRaw],
  invoices => invoices.acceptedInvoicesData,
);
const invoiceData = createSelector(
  [selectRaw],
  invoices => invoices.invoiceData,
);

const costOwnersOptions = createSelector(
  [selectRaw],
  invoices => invoices.costOwnersOptions,
);

const loading = createSelector([selectRaw], invoices => invoices.loading);
const status = createSelector([selectRaw], invoices => invoices.status);
const currentTab = createSelector([selectRaw], invoices => invoices.currentTab);

const invoiceSelector = {
  invoicesDataArray,
  eBillsDataArray,
  acceptedInvoicesData,
  loading,
  invoiceData,
  costOwnersOptions,
  status,
  currentTab,
};

export default invoiceSelector;
