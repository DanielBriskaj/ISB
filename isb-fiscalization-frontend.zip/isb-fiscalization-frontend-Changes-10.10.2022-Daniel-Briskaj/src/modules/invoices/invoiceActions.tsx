import {
  INVOICE_READ_SUCCESS,
  INVOICE_GET_COSTOWNERS,
  INVOICE_ASSIGN_COSTOWNERS,
  INVOICE_DOWNLOAD_PDF,
  INVOICE_ACCEPTED_READ_SUCCESS,
  INVOICE_UPDATE_STATUS,
  INVOICE_SET_CURRENT_TAB,
  INVOICE_GET_BY_ID_SUCCESS,
  INVOICE_LOADING,
  INVOICE_CLEAR_CO_OPTIONS,
  INVOICE_EBILLS_READ_SUCCESS,
  INVOICE_CLEAR_SINGLE_INVOICE,
  INVOICE_CLEAR_DATA,
} from './invoiceActionTypes';
import { invoiceApis } from './invoiceApi';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import moment from 'moment';
import costOwnerInvoicesActions from '../COAuthorizerInvoices/COAuthorizerInvoicesActions';
import { ROLES } from '../shared/authentication/authReducer';

const invoiceActions = {
  setCurrentTab: value => dispatch => {
    dispatch({
      type: INVOICE_SET_CURRENT_TAB,
      payload: value,
    });
  },
  read: (query?, options?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      let invoicesResponse = null;
      let ebillsResponse = null;

      if (options && options.fiscalization) {
        if (query.invoiceStatus) delete query.invoiceStatus;
        ebillsResponse = await invoiceApis.fetchFiscalizationInvoices(query);
      } else {
        invoicesResponse = await invoiceApis.fetchInvoices(query);
      }

      if (invoicesResponse && invoicesResponse.success) {
        const data =
          invoicesResponse &&
          invoicesResponse.payload.data &&
          invoicesResponse.payload.data;

        dispatch({
          type: INVOICE_READ_SUCCESS,
          payload: invoicesResponse.payload.status === 200 ? data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else if (ebillsResponse && ebillsResponse?.success) {
        const data =
          ebillsResponse &&
          ebillsResponse.payload.data &&
          ebillsResponse.payload.data;

        dispatch({
          type: INVOICE_EBILLS_READ_SUCCESS,
          payload: ebillsResponse.payload.status === 200 ? data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  readAcceptInBnt: query => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      let response = await invoiceApis.fetchInvoices(query);
      if (response && response.success) {
        dispatch({
          type: INVOICE_ACCEPTED_READ_SUCCESS,
          payload:
            response.payload.status === 200 ? response?.payload?.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  readCostOwners: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await invoiceApis.fetchCostOwmers(query);

      if (response.success) {
        dispatch({
          type: INVOICE_GET_COSTOWNERS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  assignCostOwners: (data, query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      dispatch({ type: INVOICE_ASSIGN_COSTOWNERS });
      data.receivedDate = new Date(data.receivedDate);

      const response = await invoiceApis.assignCostOwner(data);

      if (response.success) {
        dispatch({
          type: INVOICE_READ_SUCCESS,
          payload:
            response.payload.status === 200
              ? response.payload.data.costOwners
              : [],
        });
        notificationThrower({
          type: 'success',
          message: 'Invoice Successfully Assigned' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          invoiceActions.read(query, {
            fiscalization: true,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  exportPdfFile: query => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await invoiceApis.downloadPDF(query);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', `${query.eic}.pdf`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  exportMemo: data => async dispatch => {
    const response = await invoiceApis.exportMemo(data?.id);
    try {
      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', `${data.invoiceNumber}.xlsx`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  invoiceUpdateStatus: (data, query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const fiscalizationResponse =
        await invoiceApis.assignInvoiceToEFiscalizations({
          eic: data.eic,
          status: 'REFUSED',
        });
      if (fiscalizationResponse.success) {
        notificationThrower({
          type: 'success',
          message: 'Invoice Successfully Rejected' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(invoiceActions.read(query, { fiscalization: true }));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  invoiceUpdateMemoData:
    (id, data, reset?, query?, reqPayment?) => async dispatch => {
      try {
        dispatch({ type: STATUS_LOADING_TRUE });
        const response = await invoiceApis.updateInvoiceWithMemoData(id, data);
        if (response.success) {
          notificationThrower({
            type: 'success',
            message: reqPayment
              ? 'Invoice Successfully Sent For Payment'
              : 'Invoice Successfully Updated',
          });
          dispatch({ type: STATUS_LOADING_FALSE });
          dispatch(invoiceActions.readAcceptInBnt(query));

          if (reset) {
            dispatch({
              type: INVOICE_GET_BY_ID_SUCCESS,
              payload: {},
            });
          }
        } else {
          dispatch({ type: STATUS_LOADING_FALSE });
          notificationThrower({
            type: 'error',
            message: 'Invoice Update Failed.' as string,
          });
        }
      } catch (error) {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    },

  getById: id => async dispatch => {
    try {
      dispatch({ type: INVOICE_LOADING, payload: true });
      const response = await invoiceApis.fetchInvoiceById(id);
      if (response.success) {
        dispatch({
          type: INVOICE_GET_BY_ID_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: INVOICE_LOADING });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: INVOICE_LOADING });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: INVOICE_LOADING });
    }
  },

  changeStatus: (id, data, queryData, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await invoiceApis.changeStatus(id, data);

      if (response && response.success) {
        dispatch(invoiceActions.readAcceptInBnt(queryData));
        if (actionType === 'Assigned') {
          notificationThrower({
            type: 'success',
            message: 'Invoice Payment Successfully Accepted' as string,
          });
        } else {
          notificationThrower({
            type: 'success',
            message:
              role === ROLES.ACCOUNTING_INPUT
                ? 'Invoice Successfully Rejected'
                : 'Invoice Payment Successfully Rejected',
          });
        }
      } else {
        notificationThrower({
          type: 'error',
          message: `An error occured in the process of payment` as string,
        });
      }
      dispatch({ type: STATUS_LOADING_FALSE });
    } catch (err) {
      dispatch({ type: STATUS_LOADING_FALSE });

      notificationThrower({
        type: 'error',
        message: `Something Went Wrong` as string,
      });
    }
  },

  exportBySupplier: (query, supplier) => async dispatch => {
    const response = await invoiceApis.exportBySupplier(query);
    try {
      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', `${supplier} Invoices.xlsx`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  exportByContract: (query, contract) => async dispatch => {
    const response = await invoiceApis.exportByContract(query);
    try {
      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', `${contract} Invoices.xlsx`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  batchUpdate: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await invoiceApis.bactchUpdate(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Successfully Approved All Invoices',
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        if (data?.newStatus === 'ACCEPTED') {
          dispatch(
            costOwnerInvoicesActions.readCostOwnerAuthorizerInvoices(query),
          );
        } else {
          dispatch(invoiceActions.readAcceptInBnt(query));
        }
      } else {
        if (response.payload.response.status === 404) {
          notificationThrower({
            type: 'warning',
            message: 'No Invoices Are Applicable To Be Approved',
          });
        } else {
          notificationThrower({
            type: 'error',
            message: 'Something Went Wrong' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },

  clearCostOwnerOptions: () => dispatch => {
    dispatch({
      type: INVOICE_CLEAR_CO_OPTIONS,
    });
  },
  clearSingleInvoice: () => dispatch => {
    {
      dispatch({
        type: INVOICE_CLEAR_SINGLE_INVOICE,
      });
    }
  },
  clearInvoiceData: () => dispatch => {
    dispatch({
      type: INVOICE_CLEAR_DATA,
    });
  },
};

export default invoiceActions;
