import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const invoiceApis = {
  fetchInvoices: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices`,
      query: query || {},
    }),
  updateInvoiceWithMemoData: (id?, data?) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/invoices/${id}`,
      data,
    }),
  fetchInvoiceById: (id?, query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices/${id}`,
      query: query || {},
    }),
  fetchFiscalizationInvoices: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/fiscalization/einvoices`,
      query: query || {},
    }),
  downloadPDF: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/fiscalization/einvoices/pdf`,
      query: query || {},
      responseType: 'blob',
    }),
  exportMemo: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices/exportMemo/${id}`,
      responseType: 'blob',
    }),
  assignInvoiceToEFiscalizations: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/fiscalization/einvoices/status`,
      data,
    }),
  fetchGl: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/gl`,
      query: query || {},
    }),
  fetchCostOwmers: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/cost-owners`,
      query: query || {},
    }),
  assignCostOwner: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/invoices`,
      data,
    }),
  exportBySupplier: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices/export_by_suppliers`,
      query: query || {},
      responseType: 'blob',
    }),
  exportByContract: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices/export_by_contracts`,
      query: query || {},
      responseType: 'blob',
    }),
  bactchUpdate: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/invoices/batch_update`,
      data,
    }),
  changeStatus: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/invoices/changeStatus/${id}`,
      data,
    }),
};
