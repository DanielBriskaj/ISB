import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const costOwnerInvoicesApi = {
  fetchInvoices: query =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices`,
      query: query || {},
    }),
  fetchInvoice: (id, query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices/${id}`,
      query: query || {},
    }),
  postInvoice: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/invoices`,
      data,
    }),
  fetchCostOwners: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/cost-owners`,
      query: query || {},
    }),
  fetchContracts: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts`,
      query: query || {},
    }),
  fetchPO: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/po`,
      query: query || {},
    }),
  deleteInvoice: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/invoices/${id}`,
    }),
  assignInvoice: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/invoices/process/${id}`,
      data,
    }),
  updateInvoice: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/invoices/${id}`,
      data,
    }),
  changePoStatus: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/po/${id}`,
      data,
    }),
  downloadPDF: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/fiscalization/einvoices/pdf`,
      query: query || {},
      responseType: 'blob',
    }),
  uploadFile: (id, data) =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/invoices/${id}/upload`,
      data,
      headers: {
        'content-type': 'multipart/form-data',
        accept: 'application/pdf',
      },
    }),
  getUploadedFiles: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices/${id}/files`,
    }),
  getUploadedFile: (id, filename) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices/${id}/files/${filename}`,
      responseType: 'blob',
    }),
  deleteFile: (id, filename) =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/invoices/${id}/files/${filename}`,
    }),
};
