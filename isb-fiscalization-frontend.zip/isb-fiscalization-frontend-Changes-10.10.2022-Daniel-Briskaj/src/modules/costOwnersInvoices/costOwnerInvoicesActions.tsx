import {
  COST_OWNER_INVOICES_CONTRACTS_SUCCESS,
  COST_OWNER_INVOICES_PO,
  COST_OWNER_INVOICES_SELECTED,
  COST_OWNER_INVOICES_SUCCESS,
  COST_OWNER_INVOICES_GET_COST_OWNERS,
  COST_OWNER_INVOICES_DELETE,
  COST_OWNER_INVOICES_UPDATE,
  COST_OWNER_INVOICES_SET_CURRENT_TAB,
  COST_OWNER_INVOICES_POST,
  UPLOAD_FILE_SUCCESS,
  GET_FILES_SUCCESS,
  COST_OWNER_INVOICES_GET_BY_ID_SUCCESS,
  DELETE_FILE_SUCCESS,
  CLEAR_FILES,
} from './costOwnerInvoicesActionTypes';
import { costOwnerInvoicesApi } from './costOwnerInvoicesApi';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import { poApis } from '../PO/poApi';

const costOwnerInvoicesActions = {
  setCurrentTab: value => dispatch => {
    dispatch({
      type: COST_OWNER_INVOICES_SET_CURRENT_TAB,
      payload: value,
    });
  },
  clearFiles: () => dispatch => {
    dispatch({ type: CLEAR_FILES });
  },
  readCostOwnerInvoices: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.fetchInvoices(query);
      if (response.success) {
        dispatch({
          type: COST_OWNER_INVOICES_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  getById: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.fetchInvoice(id);

      if (response.success) {
        dispatch({
          type: COST_OWNER_INVOICES_GET_BY_ID_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  postManualInvoice: (data, query?) => async dispatch => {
    try {
      const response = await costOwnerInvoicesApi.postInvoice(data);
      if (response.success) {
        dispatch({
          type: COST_OWNER_INVOICES_POST,
          payload:
            response.payload.status === 200
              ? response.payload.data.invoces
              : [],
        });
        notificationThrower({
          type: 'success',
          message: 'Manual Invoice successfully created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          costOwnerInvoicesActions.readCostOwnerInvoices({
            ...query,
            invoiceStatus: 'DELIVERED',
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateManualInvoice: (data, id, query?) => async dispatch => {
    try {
      const response = await costOwnerInvoicesApi.updateInvoice(data, id);

      if (response.success) {
        dispatch({
          type: COST_OWNER_INVOICES_UPDATE,
          payload:
            response.payload.status === 200
              ? response.payload.data.invoces
              : [],
        });
        notificationThrower({
          type: 'success',
          message: 'Manual Invoice successfully updated' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(costOwnerInvoicesActions.readCostOwnerInvoices(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  setSelectedInvoice: (id?) => dispatch => {
    dispatch({
      type: COST_OWNER_INVOICES_SELECTED,
      payload: id ? { id: id } : null,
    });
  },
  readCostOwners: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await costOwnerInvoicesApi.fetchCostOwners(query);

      if (response.success) {
        dispatch({
          type: COST_OWNER_INVOICES_GET_COST_OWNERS,
          payload:
            response.payload.status === 200
              ? response.payload.data.costOwners
              : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  readContracts: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await costOwnerInvoicesApi.fetchContracts(query);

      if (response.success) {
        dispatch({
          type: COST_OWNER_INVOICES_CONTRACTS_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  downloadPdf: query => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.downloadPDF(query);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', `${query.eic}.pdf`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  assignInvoice: (payload, isManual?, query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.assignInvoice(
        payload.data,
        payload.id,
      );
      if (response.success) {
        try {
          if (response.payload.data?.po) {
            const poUpdateResponse = await poApis.changeStatusPO(
              response.payload.data?.po?.id,
              {
                poStatus: 'COMPLETED',
              },
            );

            if (poUpdateResponse.success) {
              dispatch({
                type: COST_OWNER_INVOICES_UPDATE,
                payload:
                  response.payload.status === 200 ? response.payload.data : [],
              });
              notificationThrower({
                type: 'success',
                message: 'Invoice Status Successfully Updated' as string,
              });
              dispatch({ type: STATUS_LOADING_FALSE });
              dispatch(costOwnerInvoicesActions.readCostOwnerInvoices(query));
            }
          } else {
            dispatch({
              type: COST_OWNER_INVOICES_UPDATE,
              payload:
                response.payload.status === 200 ? response.payload.data : [],
            });
            notificationThrower({
              type: 'success',
              message: 'Invoice Status Successfully Updated' as string,
            });
            dispatch({ type: STATUS_LOADING_FALSE });
            dispatch(costOwnerInvoicesActions.readCostOwnerInvoices(query));
          }
        } catch (error) {
          notificationThrower({
            type: 'error',
            message: 'Something Went Wrong' as string,
          });
          dispatch({ type: STATUS_LOADING_FALSE });
        }
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  deleteInvoice: (id, query: any) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.deleteInvoice(id);
      if (response.success) {
        dispatch({
          type: COST_OWNER_INVOICES_DELETE,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        notificationThrower({
          type: 'success',
          message: 'Invoice Successfully Deleted' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(costOwnerInvoicesActions.readCostOwnerInvoices(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getUploadedFiles: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.getUploadedFiles(id);

      if (response.success) {
        dispatch({
          type: GET_FILES_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  uploadFile: (id, data, inputFileName?, filesArray?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.uploadFile(id, data);

      if (response.success) {
        dispatch({
          type: UPLOAD_FILE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch(costOwnerInvoicesActions.getUploadedFiles(id));
        filesArray.some(item => item.name === inputFileName)
          ? notificationThrower({
              type: 'warning',
              message: 'This file is already uploaded!' as string,
            })
          : notificationThrower({
              type: 'success',
              message: 'File uploaded successfully' as string,
            });

        dispatch({ type: STATUS_LOADING_FALSE });
      } else if (!response.success) {
        response.payload.response.data &&
        response.payload.response.status === 400
          ? notificationThrower({
              type: 'error',
              message: 'Only PDF files are supported!' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  deleteUploadedFile: (id, filename) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.deleteFile(id, filename);

      if (response.success) {
        dispatch({
          type: DELETE_FILE_SUCCESS,
          payload: filename,
        });
        notificationThrower({
          type: 'success',
          message: 'File deleted successfully' as string,
        });

        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  downloadUploadedFile: (id, filename) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.getUploadedFile(id, filename);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'file.pdf');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
};

export default costOwnerInvoicesActions;
