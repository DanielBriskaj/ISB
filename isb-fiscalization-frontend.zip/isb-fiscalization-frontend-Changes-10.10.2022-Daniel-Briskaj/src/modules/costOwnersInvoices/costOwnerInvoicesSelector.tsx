import { createSelector } from 'reselect';

const selectRaw = state => state.costOwnerInvoices;

const invoicesDataArray = createSelector(
  [selectRaw],
  invoices => invoices.invoicesData,
);
const invoiceData = createSelector(
  [selectRaw],
  invoices => invoices.invoiceData,
);

const costOwnersOptions = createSelector(
  [selectRaw],
  invoices => invoices.costOwnersOptions,
);

const contractsOptions = createSelector(
  [selectRaw],
  invoices => invoices.contractsOptions,
);

const selectedInvoice = createSelector(
  [selectRaw],
  invoices => invoices.selectedInvoice,
);

const loading = createSelector([selectRaw], invoices => invoices.loading);
const currentTab = createSelector([selectRaw], invoices => invoices.currentTab);
const files = createSelector([selectRaw], invoices => invoices.files);

const costOwnerInvoiceSelector = {
  invoicesDataArray,
  invoiceData,
  loading,
  costOwnersOptions,
  contractsOptions,
  selectedInvoice,
  currentTab,
  files,
};

export default costOwnerInvoiceSelector;
