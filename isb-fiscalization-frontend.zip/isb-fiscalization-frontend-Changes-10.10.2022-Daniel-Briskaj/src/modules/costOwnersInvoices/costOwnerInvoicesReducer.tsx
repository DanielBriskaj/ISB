import {
  COST_OWNER_INVOICES_CONTRACTS_SUCCESS,
  COST_OWNER_INVOICES_SELECTED,
  COST_OWNER_INVOICES_SUCCESS,
  COST_OWNER_INVOICES_GET_COST_OWNERS,
  COST_OWNER_INVOICES_DOWNLOAD_PDF,
  COST_OWNER_INVOICES_DELETE,
  COST_OWNER_INVOICES_UPDATE,
  COST_OWNER_INVOICES_SET_CURRENT_TAB,
  COST_OWNER_INVOICES_GET_BY_ID_SUCCESS,
  COST_OWNER_INVOICES_POST,
  CLEAR_FILES,
  GET_FILES_SUCCESS,
  DELETE_FILE_SUCCESS,
} from './costOwnerInvoicesActionTypes';
import { CostOwnerInvoicesData } from 'src/models/data/costOwnerInvoices/CostOwnerInvoiceData';

const initialValues: CostOwnerInvoicesData = {
  invoicesData: {
    invoices: [],
  },
  invoiceData: {},
  costOwnersOptions: [],
  contractsOptions: [],
  selectedInvoice: null,
  currentTab: 'co_invoices',
  files: [],
};

export default function (state = initialValues, { type, payload }) {
  switch (type) {
    case COST_OWNER_INVOICES_SET_CURRENT_TAB:
      return {
        ...state,
        currentTab: payload,
      };
    case CLEAR_FILES:
      return {
        ...state,
        files: [],
      };
    case GET_FILES_SUCCESS: {
      return {
        ...state,
        files: payload,
      };
    }
    case COST_OWNER_INVOICES_GET_BY_ID_SUCCESS: {
      return {
        ...state,
        invoiceData: payload,
      };
    }
    case DELETE_FILE_SUCCESS: {
      return {
        ...state,
        files: state.files.filter(file => file.name !== payload),
      };
    }

    case COST_OWNER_INVOICES_CONTRACTS_SUCCESS:
      return {
        ...state,
        contractsOptions: payload.contracts,
      };
    case COST_OWNER_INVOICES_SUCCESS: {
      return {
        ...state,
        invoicesData: payload,
      };
    }
    case COST_OWNER_INVOICES_SELECTED:
      return {
        ...state,
        selectedInvoice: payload,
      };
    case COST_OWNER_INVOICES_DOWNLOAD_PDF:
      return {
        ...state,
      };
    case COST_OWNER_INVOICES_DELETE:
      return {
        ...state,
        invoiceData: payload,
      };
    case COST_OWNER_INVOICES_POST:
      return {
        ...state,
        invoiceData: payload,
      };
    case COST_OWNER_INVOICES_UPDATE:
      return {
        ...state,
        invoiceData: payload,
      };
    case COST_OWNER_INVOICES_GET_COST_OWNERS:
      return {
        ...state,
        costOwnersOptions: payload,
      };

    default:
      return state;
  }
}
