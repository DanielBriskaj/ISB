import {
  COST_OWNER_AUTHORIZER_INVOICES_CONTRACTS_SUCCESS,
  COST_OWNER_AUTHORIZER_INVOICES_SUCCESS,
  COST_OWNER_AUTHORIZER_INVOICES_GET_COST_OWNERS,
  COST_OWNER_AUTHORIZER_INVOICES_DELETE,
  COST_OWNER_AUTHORIZER_INVOICES_UPDATE,
} from './COAuthorizerInvoicesActionTypes';
import { CostOwnerAuthorizerInvoicesData } from 'src/models/data/costOwnerAuthorizerInvoices/invoiceData';

const initialValues: CostOwnerAuthorizerInvoicesData = {
  invoicesData: {
    invoices: [],
  },
  invoiceData: {},
  costOwnersAuthorizerOptions: [],
  contractsAuthorizerOptions: [],
};

export default function (state = initialValues, { type, payload }) {
  switch (type) {
    case COST_OWNER_AUTHORIZER_INVOICES_CONTRACTS_SUCCESS:
      return {
        ...state,
        contractsAuthorizerOptions: payload.contracts,
      };
    case COST_OWNER_AUTHORIZER_INVOICES_SUCCESS: {
      return {
        ...state,
        invoicesData: payload,
      };
    }
    case COST_OWNER_AUTHORIZER_INVOICES_DELETE:
      return {
        ...state,
        invoiceData: payload,
      };
    case COST_OWNER_AUTHORIZER_INVOICES_UPDATE:
      return {
        ...state,
        invoiceData: payload,
      };
    case COST_OWNER_AUTHORIZER_INVOICES_GET_COST_OWNERS:
      return {
        ...state,
        costOwnersAuthorizerOptions: payload,
      };

    default:
      return state;
  }
}
