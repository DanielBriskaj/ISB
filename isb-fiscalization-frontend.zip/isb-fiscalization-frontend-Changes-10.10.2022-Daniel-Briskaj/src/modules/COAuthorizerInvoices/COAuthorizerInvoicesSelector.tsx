import { createSelector } from 'reselect';

const selectRaw = state => state.costOwnerAuthorizerInvoices;
const invoicesDataArray = createSelector(
  [selectRaw],
  invoices => invoices.invoicesData,
);
const invoiceData = createSelector(
  [selectRaw],
  invoices => invoices.invoiceData,
);

const costOwnersAuthorizerOptions = createSelector(
  [selectRaw],
  invoices => invoices.costOwnersOptions,
);

const contractsAuthorizerOptions = createSelector(
  [selectRaw],
  invoices => invoices.contractsOptions,
);

const loading = createSelector([selectRaw], invoices => invoices.loading);

const costOwnerAuthorizerInvoiceSelector = {
  invoicesDataArray,
  invoiceData,
  loading,
  costOwnersAuthorizerOptions,
  contractsAuthorizerOptions,
};

export default costOwnerAuthorizerInvoiceSelector;
