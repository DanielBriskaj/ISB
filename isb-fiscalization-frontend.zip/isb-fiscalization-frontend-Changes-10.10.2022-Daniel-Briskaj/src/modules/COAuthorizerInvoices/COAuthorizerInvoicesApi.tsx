import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const costOwnerInvoicesApi = {
  fetchInvoices: query =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/invoices`,
      query: query || {},
    }),
  fetchCostOwners: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/cost-owners`,
      query: query || {},
    }),
  fetchContracts: (id, query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/cost-owner/${id}`,
      query: query || {},
    }),
  deleteInvoice: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/invoices/${id}`,
    }),
  changeStatus: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/invoices/changeStatus/${id}`,
      data,
    }),
  assignInvoiceToEFiscalizations: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/fiscalization/einvoices/status`,
      data,
    }),
  changePoStatus: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/po/${id}`,
      data,
    }),
  downloadPDF: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/fiscalization/einvoices/pdf`,
      query: query || {},
      responseType: 'blob',
    }),
};
