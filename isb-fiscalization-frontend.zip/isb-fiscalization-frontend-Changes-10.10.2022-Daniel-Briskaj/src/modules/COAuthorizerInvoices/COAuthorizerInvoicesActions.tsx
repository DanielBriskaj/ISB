import {
  COST_OWNER_AUTHORIZER_INVOICES_SUCCESS,
  COST_OWNER_AUTHORIZER_INVOICES_UPDATE,
} from './COAuthorizerInvoicesActionTypes';
import { costOwnerInvoicesApi } from './COAuthorizerInvoicesApi';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import { poApis } from '../PO/poApi';

const costOwnerInvoicesActions = {
  readCostOwnerAuthorizerInvoices: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.fetchInvoices(query);
      if (response.success) {
        dispatch({
          type: COST_OWNER_AUTHORIZER_INVOICES_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  invoiceUpdate: (data, id, action?, poId?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.changeStatus(data, id);

      if (response.success) {
        dispatch(
          costOwnerInvoicesActions.readCostOwnerAuthorizerInvoices({
            invoiceStatus: 'SEND_SUBMIT',
          }),
        );
        if (action === 'Reject' && poId) {
          const data = {
            poStatus: 'APPROVED',
          };
          const updatePO = await poApis.changeStatusPO(poId, data);
          if (!updatePO.success) {
            notificationThrower({
              type: 'error',
              message: 'Failed To Update PO Connected To Invoice',
            });
          }
        }
        notificationThrower({
          type: 'success',
          message:
            action === 'Assign'
              ? 'Invoice Approved successfully'
              : 'Invoice Rejected successfully',
        });
      } else if (response.success && data.invoiceStatus === 'ACCEPTED') {
        try {
          const fiscalizationResponse =
            await costOwnerInvoicesApi.assignInvoiceToEFiscalizations({
              eic: data.eic,
              status: 'ACCEPTED',
            });

          if (fiscalizationResponse.success) {
            dispatch({
              type: COST_OWNER_AUTHORIZER_INVOICES_UPDATE,
              payload: [],
            });
          } else {
            notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
            dispatch({ type: STATUS_LOADING_FALSE });
          }
        } catch (error) {
          notificationThrower({
            type: 'error',
            message: 'Something Went Wrong' as string,
          });
          dispatch({ type: STATUS_LOADING_FALSE });
        }
      } else if (
        response.success &&
        (data.invoiceStatus === 'ASSIGNED' ||
          data.invoiceStatus === 'DELIVERED')
      ) {
        dispatch({ type: STATUS_LOADING_FALSE });
        notificationThrower({
          type: 'info',
          message: 'Invoice Rejected' as string,
        });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  downloadPdf: query => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerInvoicesApi.downloadPDF(query);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', `${query.eic}.pdf`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        dispatch({ type: STATUS_LOADING_FALSE });
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
    }
  },
};

export default costOwnerInvoicesActions;
