import { combineReducers } from 'redux';
import suppliers from './suppliers/supplierReducer';
import branches from './branches/branchReducer';
import costOwners from './costowners/costOwnerReducer';
import contracts from './contracts/contractReducer';
import invoices from './invoices/invoiceReducer';
import costOwnerInvoices from './costOwnersInvoices/costOwnerInvoicesReducer';
import costOwnerAuthorizerInvoices from './COAuthorizerInvoices/COAuthorizerInvoicesReducer';
import po from './PO/poReducer';
import pr from './PR/prReducer';
import auth from './shared/authentication/authReducer';
import options from './shared/options/optionsReducer';
import users from './users/userReducer';
import status from './shared/statuses/statusesReducer';
import gl from './GL/glReducer';
import audit from './audit/auditReducer';
import budget from './budget/budgetReducer';
import forecast from './forecast/forecastReducer';

export default () =>
  combineReducers({
    suppliers,
    branches,
    costOwners,
    contracts,
    invoices,
    costOwnerInvoices,
    costOwnerAuthorizerInvoices,
    po,
    users,
    auth,
    options,
    status,
    gl,
    pr,
    audit,
    budget,
    forecast,
  });
