import { BranchesData } from 'src/models/data/branches/BranchesData';
import {
  BRANCH_CREATE_SUCCESS,
  BRANCH_DELETE,
  BRANCH_GET_BY_ID_SUCCESS,
  BRANCH_READ_SUCCESS,
  BRANCH_UPDATE_SUCCESS,
  BRANCH_CLEAR,
} from './branchActiontypes';

const initailValues: BranchesData = {
  branchesData: [],
  branchData: {},
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case BRANCH_READ_SUCCESS:
      return {
        ...state,
        branchesData: payload,
      };
    case BRANCH_UPDATE_SUCCESS:
      return {
        ...state,
        branchData: payload,
      };
    case BRANCH_CREATE_SUCCESS:
      return {
        ...state,
        branchData: payload,
      };
    case BRANCH_GET_BY_ID_SUCCESS:
      return {
        ...state,
        branchData: payload,
      };
    case BRANCH_DELETE:
      return {
        ...state,
        branchData: payload,
      };
    case BRANCH_CLEAR:
      return {
        ...state,
        branchesData: [],
        branchData: {},
      };
  }
  return state;
}
