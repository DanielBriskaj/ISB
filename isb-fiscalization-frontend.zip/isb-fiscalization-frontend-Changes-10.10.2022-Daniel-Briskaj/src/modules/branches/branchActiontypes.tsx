const prefix = 'BRANCH';

export const BRANCH_CREATE_SUCCESS = `${prefix}_CREATE_SUCCESS`;
export const BRANCH_UPDATE_SUCCESS = `${prefix}_UPDATE_SUCCESS`;
export const BRANCH_DELETE = `${prefix}_DELETE`;
export const BRANCH_LOADING = `${prefix}_LOADING`;
export const BRANCH_READ_SUCCESS = `${prefix}_READ_SUCCESS`;
export const BRANCH_GET_BY_ID_SUCCESS = `${prefix}_GET_BY_ID_SUCCESS`;
export const BRANCH_ERROR = `${prefix}_ERROR`;
export const BRANCH_CLEAR = `${prefix}_CLEAR`;
