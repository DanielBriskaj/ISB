import { createSelector } from 'reselect';

const selectRaw = state => state.branches;

const branchesDataArray = createSelector(
  [selectRaw],
  branches => branches.branchesData,
);

const branchData = createSelector([selectRaw], branches => branches.branchData);

const loading = createSelector([selectRaw], branches => branches.loading);
const status = createSelector([selectRaw], branches => branches.status);

const branchSelector = {
  branchesDataArray,
  branchData,
  loading,
  status,
};

export default branchSelector;
