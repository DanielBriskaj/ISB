import { branchApis } from './branchApi';
import {
  BRANCH_DELETE,
  BRANCH_GET_BY_ID_SUCCESS,
  BRANCH_READ_SUCCESS,
  BRANCH_UPDATE_SUCCESS,
  BRANCH_CLEAR,
} from './branchActiontypes';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import deepEqual from 'deep-equal';

const branchActions = {
  create: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await branchApis.addBranch(payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Branch Successfully Created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          branchActions.read({
            page: payload.page || 0,
            size: payload.rowsPerPage || 10,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Branch Creation Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Branch Creation Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  update: payload => async dispatch => {
    try {
      let initialBranch = payload?.rawBranchData;
      let updatedBranch = payload?.data;

      if (initialBranch?.approved === 'APPROVED') {
        const equal = deepEqual(initialBranch, updatedBranch);
        if (!equal) {
          updatedBranch = {
            ...updatedBranch,
            approved: 'NEW',
          };
        }
      }

      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await branchApis.updateBranch(updatedBranch, payload.id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Branch Successfully Updated' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          branchActions.read({
            page: payload.page || 0,
            size: payload.rowsPerPage || 10,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Branch Deletion Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Branch Deletion Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  updateStatus: (payload, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await branchApis.updateBranchStatus(
        payload.id,
        payload.data,
      );

      if (response.success) {
        dispatch({
          type: BRANCH_UPDATE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : [],
        });
        if (actionType === 'Assigned') {
          role === 'ACCOUNTING_INPUT'
            ? notificationThrower({
                type: 'success',
                message: 'Branch successfully sent for approval' as string,
              })
            : notificationThrower({
                type: 'success',
                message: 'Branch successfully approved' as string,
              });
        } else {
          notificationThrower({
            type: 'success',
            message: 'Branch successfully rejected' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          branchActions.read({
            page: payload.page || 0,
            size: payload.rowsPerPage || 10,
            approved: payload.approved,
          }),
        );
      } else {
        actionType === 'Assigned'
          ? notificationThrower({
              type: 'error',
              message: 'Branch Approval Failed' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'Branch Rejection Failed' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something went wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  delete: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await branchApis.delete(payload.id);
      if (response.success) {
        dispatch({
          type: BRANCH_DELETE,
          payload:
            response.payload?.status === 200 ? response.payload.data : [],
        });
        notificationThrower({
          type: 'success',
          message: 'Branch Successfully Deleted' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          branchActions.read({
            page: payload.page || 0,
            size: payload.rowsPerPage || 10,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: response.payload.response?.status === 409 ? 'warning' : 'error',
          message:
            response.payload.response?.status === 409
              ? (response.payload.response.data as string)
              : ('Branch Deletion Failed' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Branch Deletion Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  read: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await branchApis.read(query);

      if (response.success) {
        dispatch({
          type: BRANCH_READ_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  getById: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await branchApis.fetchBranch(id);

      if (response.success) {
        dispatch({
          type: BRANCH_GET_BY_ID_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  clearBranchData: () => dispatch => {
    dispatch({ type: BRANCH_CLEAR });
  },
};

export default branchActions;
