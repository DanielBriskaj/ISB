import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const branchApis = {
  read: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/branches`,
      query: query || {},
    }),
  fetchBranch: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/branches/${id}`,
    }),
  addBranch: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/branches`,
      data,
    }),
  updateBranch: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/branches/${id}`,
      data,
    }),
  updateBranchStatus: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/branches/approvalStatus/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data,
    }),
  delete: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/branches/${id}`,
    }),
};
