import { createSelector } from 'reselect';

const selectRaw = state => state.suppliers;

const suppliersDataArray = createSelector(
  [selectRaw],
  suppliers => suppliers.suppliersData,
);

const supplierData = createSelector(
  [selectRaw],
  suppliers => suppliers.supplierData,
);

const loading = createSelector([selectRaw], suppliers => suppliers.loading);
const status = createSelector([selectRaw], suppliers => suppliers.status);

const supplierSelector = {
  suppliersDataArray,
  supplierData,
  loading,
  status,
};

export default supplierSelector;
