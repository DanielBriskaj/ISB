import { supplierApis } from './supplierApi';
import {
  SUPPLIER_CREATE_SUCCESS,
  SUPPLIER_DELETE,
  SUPPLIER_READ_SUCCESS,
  SUPPLIER_UPDATE_SUCCESS,
  SUPPLIER_GET_BY_ID_SUCCESS,
  SET_CURRENT_PAGE,
  SUPPLIER_CLEAR_DATA,
  EXPORT_EXEL,
} from './supplierActiontypes';
import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import deepEqual from 'deep-equal';

const supplierActions = {
  createSupplier: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await supplierApis.addSupplier(data);
      if (response.success) {
        dispatch({
          type: SUPPLIER_CREATE_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        notificationThrower({
          type: 'success',
          duration: 3000,
          message: 'Supplier Successfully Created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(supplierActions.read(query));
      } else {
        notificationThrower({
          type: response.payload.status === 409 ? 'warning' : 'error',
          duration: 3000,
          message:
            response.payload.status === 409
              ? response.payload.data
              : ('Supplier Creation Failed' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        duration: 3000,
        message: 'Supplier Creation Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateSupplier: (payload, id, query) => async dispatch => {
    try {
      let initialSupplier = payload?.rawSupplierData;
      let updatedSupplier = payload?.data;

      if (initialSupplier?.approved === 'APPROVED') {
        const equal = deepEqual(initialSupplier, updatedSupplier);
        if (!equal) {
          updatedSupplier = {
            ...updatedSupplier,
            approved: 'NEW',
          };
        }
      }

      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await supplierApis.updateSupplier(updatedSupplier, id);
      if (response.success) {
        dispatch({
          type: SUPPLIER_UPDATE_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        notificationThrower({
          type: 'success',
          duration: 3000,
          message: 'Supplier Successfully Updated' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(supplierActions.read(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  updateStatus: (payload, query, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await supplierApis.updateSupplierStatus(
        payload.id,
        payload.status,
      );
      if (response.success) {
        dispatch({
          type: SUPPLIER_UPDATE_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });

        if (actionType === 'Assigned') {
          role === 'PROCUREMENT_INPUT'
            ? notificationThrower({
                type: 'success',
                duration: 3000,
                message: 'Supplier Successfully Sent for Approval' as string,
              })
            : notificationThrower({
                type: 'success',
                duration: 3000,
                message: 'Supplier Successfully Approved' as string,
              });
        } else {
          notificationThrower({
            type: 'success',
            duration: 3000,
            message: 'Supplier Successfully Rejected' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(supplierActions.read(query));
      } else {
        actionType === 'Assigned'
          ? notificationThrower({
              type: 'error',
              message: 'Supplier Approval Failed' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'Supplier Rejection Failed' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  delete: (id, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await supplierApis.deleteSupplier(id);
      if (response.success) {
        dispatch({
          type: SUPPLIER_DELETE,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch(
          supplierActions.read({
            sort: query.sort,
            companyName: query.companyName,
            size: query.size,
            page: query.page,
            approved: query.approved,
          }),
        );
        notificationThrower({
          type: 'success',
          duration: 3000,
          message: 'Supplier Successfully Deleted' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        !response.success && response.payload.response.request.status === 409
          ? notificationThrower({
              type: 'warning',
              message: `${response.payload.response.data}`,
            })
          : notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  read: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }

      const response = await supplierApis.fetchSuppliers(query);

      if (response.success) {
        dispatch({
          type: SUPPLIER_READ_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getById: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await supplierApis.fetchSupplier(id);

      if (response.success) {
        dispatch({
          type: SUPPLIER_GET_BY_ID_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  setCurrentPage: page => dispatch => {
    dispatch({
      type: SET_CURRENT_PAGE,
      payload: page,
    });
  },

  exportExelFile: () => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await supplierApis.exportExelFile();

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'suppliers.xlsx');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  importSuppliers: () => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await supplierApis.importSuppliers();

      if (response.success) {
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  clearSupplierData: () => dispatch => {
    dispatch({
      type: SUPPLIER_CLEAR_DATA,
    });
  },
};

export default supplierActions;
