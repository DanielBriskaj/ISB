const prefix = 'SUPPLIER';

export const SUPPLIER_CREATE_SUCCESS = `${prefix}_CREATE_SUCCESS`;
export const SUPPLIER_UPDATE_SUCCESS = `${prefix}_UPDATE_SUCCESS`;
export const SUPPLIER_DELETE = `${prefix}_DELETE`;
export const SUPPLIER_LOADING = `${prefix}_LOADING`;
export const SUPPLIER_READ_SUCCESS = `${prefix}_READ_SUCCESS`;
export const SUPPLIER_GET_BY_ID_SUCCESS = `${prefix}_GET_BY_ID_SUCCESS`;
export const SUPPLIER_ERROR = `${prefix}_ERROR`;
export const SET_CURRENT_PAGE = `SET_CURRENT_PAGE`;
export const EXPORT_EXEL = `EXPORT_EXEL`;
export const SUPPLIER_CLEAR_DATA = `${prefix}_CLEAR_DATA`;
