import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const supplierApis = {
  fetchSuppliers: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/suppliers`,
      query: query || {},
    }),
  fetchSupplier: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/suppliers/${id}`,
    }),
  addSupplier: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/suppliers`,
      data,
    }),
  updateSupplier: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/suppliers/${id}`,
      data,
    }),
  deleteSupplier: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/suppliers/${id}`,
    }),
  updateSupplierStatus: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/suppliers/approvalStatus/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data,
    }),
  exportExelFile: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/suppliers/export`,
      responseType: 'blob',
    }),
  importSuppliers: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/import_suppliers_from_excel`,
    }),
};
