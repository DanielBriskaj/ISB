import { SuppliersData } from 'src/models/data/suppliers/SuppliersData';
import {
  SUPPLIER_CREATE_SUCCESS,
  SUPPLIER_READ_SUCCESS,
  SUPPLIER_GET_BY_ID_SUCCESS,
  SUPPLIER_UPDATE_SUCCESS,
  SET_CURRENT_PAGE,
  SUPPLIER_CLEAR_DATA,
} from './supplierActiontypes';

const initailValues: SuppliersData = {
  suppliersData: {},
  supplierData: {},
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case SUPPLIER_READ_SUCCESS:
      return {
        ...state,
        suppliersData: payload,
      };
    case SUPPLIER_UPDATE_SUCCESS:
      return {
        ...state,
        supplierData: payload,
      };
    case SUPPLIER_CREATE_SUCCESS:
      return {
        ...state,
        supplierData: payload,
      };
    case SUPPLIER_GET_BY_ID_SUCCESS:
      return {
        ...state,
        supplierData: payload,
      };
    case SET_CURRENT_PAGE:
      return {
        ...state,
        suppliersData: {
          ...state,
          currentPage: payload,
        },
      };
    case SUPPLIER_CLEAR_DATA:
      return {
        ...state,
        suppliersData: {},
        supplierData: {},
      };
  }
  return state;
}
