import {
  COST_OWNER_GET_BY_ID_SUCCESS,
  COST_OWNER_READ_SUCCESS,
  COST_OWNER_UPDATE_SUCCESS,
  SET_CURRENT_PAGE,
  COST_OWNER_GET_ASSIGNED,
  COST_OWNER_CLEAR_DATA,
} from './costOwnerActionTypes';
import { costOwnerApis } from './costOwnerApi';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import deepEqual from 'deep-equal';
import { isUndefined } from 'lodash';

const costOwnerActions = {
  create: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerApis.addCostOwner(payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Cost Owner Successfully Created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          costOwnerActions.read({
            page: payload.page,
            size: payload.rowsPerPage,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Cost Owner Creation Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  update: payload => async dispatch => {
    try {
      let initialCostOwner = payload?.rawCostOwnerData;
      let updatedCostOwner = payload?.data;

      if (initialCostOwner?.approved === 'APPROVED') {
        const equal = deepEqual(initialCostOwner, updatedCostOwner);
        if (!equal) {
          updatedCostOwner = {
            ...updatedCostOwner,
            approved: 'NEW',
          };
        }
      }

      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerApis.updateCostOwner(
        updatedCostOwner,
        payload.id,
      );
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Cost Owner Successfully Updated' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          costOwnerActions.read({
            page: payload.page,
            size: payload.rowsPerPage,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Cost Owner Update Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  updateStatus: (payload, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerApis.updateCostOwnerStatus(
        payload.id,
        payload.data,
      );
      if (response.success) {
        dispatch({
          type: COST_OWNER_UPDATE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : [],
        });
        if (actionType === 'Assigned') {
          role === 'ACCOUNTING_INPUT'
            ? notificationThrower({
                type: 'success',
                message: 'Cost Owner successfully sent for approval' as string,
              })
            : notificationThrower({
                type: 'success',
                message: 'Cost Owner successfully approved' as string,
              });
        } else {
          notificationThrower({
            type: 'success',
            message: 'Cost Owner successfully rejected' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          costOwnerActions.read({
            page: payload.page || 0,
            size: payload.rowsPerPage || 10,
            approved: payload.approved,
          }),
        );
      } else {
        actionType === 'Assigned'
          ? notificationThrower({
              type: 'error',
              message: 'Cost Owner Approval Failed' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'Cost Owner Rejection Failed' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  delete: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerApis.deleteCostOwner(payload.id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Cost Owner Successfully Deleted' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          costOwnerActions.read({
            page: payload.page,
            size: payload.rowsPerPage,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: response.payload.response?.status === 409 ? 'warning' : 'error',
          message:
            response.payload.response?.status === 409
              ? (response.payload.response?.data as string)
              : ('Cost Owner Deletion Failed' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  read: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await costOwnerApis.fetchCostOwners(query);

      if (response.success) {
        dispatch({
          type: COST_OWNER_READ_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  getById: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerApis.fetchCostOwner(id);

      if (response.success) {
        dispatch({
          type: COST_OWNER_GET_BY_ID_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Branch Creation Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getAssignedCO: (value: boolean) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await costOwnerApis.getAssignedCO(value);
      if (response.success) {
        dispatch({
          type: COST_OWNER_GET_ASSIGNED,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  clearCOData: () => dispatch => {
    dispatch({ type: COST_OWNER_CLEAR_DATA });
  },

  setCurrentPage: page => dispatch => {
    dispatch({
      type: SET_CURRENT_PAGE,
      payload: page,
    });
  },
};

export default costOwnerActions;
