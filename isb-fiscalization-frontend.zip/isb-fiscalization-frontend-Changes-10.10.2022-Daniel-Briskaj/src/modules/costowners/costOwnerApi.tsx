import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const costOwnerApis = {
  fetchCostOwners: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/cost-owners`,
      query: query || {},
    }),
  fetchCostOwner: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/cost-owners/${id}`,
    }),
  addCostOwner: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/cost-owners`,
      data,
    }),
  updateCostOwner: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/cost-owners/${id}`,
      data,
    }),
  updateCostOwnerStatus: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/cost-owners/approvalStatus/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data,
    }),
  deleteCostOwner: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/cost-owners/${id}`,
    }),
  getAssignedCO: (value: boolean) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/cost-owners/assigned/${value}`,
    }),
};
