import { CostOwnersData } from 'src/models/data/costOwners/CostOwnerData';
import {
  COST_OWNER_CREATE_SUCCESS,
  COST_OWNER_GET_BY_ID_SUCCESS,
  COST_OWNER_READ_SUCCESS,
  COST_OWNER_UPDATE_SUCCESS,
  SET_CURRENT_PAGE,
  COST_OWNER_GET_ASSIGNED,
  COST_OWNER_CLEAR_DATA,
} from './costOwnerActionTypes';

const initailValues: CostOwnersData = {
  costOwnerData: {},
  costOwnersData: {},
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case COST_OWNER_READ_SUCCESS:
      return {
        ...state,
        costOwnersData: payload,
      };
    case COST_OWNER_UPDATE_SUCCESS:
      return {
        ...state,
        costOwnerData: payload,
      };
    case COST_OWNER_CREATE_SUCCESS:
      return {
        ...state,
        costOwnerData: payload,
      };
    case COST_OWNER_GET_BY_ID_SUCCESS:
      return {
        ...state,
        costOwnerData: payload,
      };
    case SET_CURRENT_PAGE:
      return {
        ...state,
        costOwnersData: {
          ...state,
          currentPage: payload,
        },
      };
    case COST_OWNER_GET_ASSIGNED:
      return {
        ...state,
        costOwnersData: payload,
      };
    case COST_OWNER_CLEAR_DATA:
      return {
        ...state,
        costOwnersData: {},
      };
  }
  return state;
}
