const prefix = 'COST_OWNER';

export const COST_OWNER_CREATE_SUCCESS = `${prefix}_CREATE_SUCCESS`;
export const COST_OWNER_UPDATE_SUCCESS = `${prefix}_UPDATE_SUCCESS`;
export const COST_OWNER_DELETE = `${prefix}_DELETE`;
export const COST_OWNER_LOADING = `${prefix}_LOADING`;
export const COST_OWNER_READ_SUCCESS = `${prefix}_READ_SUCCESS`;
export const COST_OWNER_GET_BY_ID_SUCCESS = `${prefix}_GET_BY_ID_SUCCESS`;
export const COST_OWNER_ERROR = `${prefix}_ERROR`;
export const SET_CURRENT_PAGE = `SET_CURRENT_PAGE`;
export const COST_OWNER_GET_ASSIGNED = `${prefix}_GET_ASSIGNED`;
export const COST_OWNER_CLEAR_DATA = `${prefix}_CLEAR_DATA`;
