import { createSelector } from 'reselect';

const selectRaw = state => state.costOwners;

const costOwnersDataArray = createSelector(
  [selectRaw],
  costOwners => costOwners.costOwnersData,
);

const costOwnerData = createSelector(
  [selectRaw],
  costOwners => costOwners.costOwnerData,
);

const loading = createSelector([selectRaw], costOwners => costOwners.loading);
const status = createSelector([selectRaw], costOwners => costOwners.status);

const costOwnerSelector = {
  costOwnersDataArray,
  costOwnerData,
  loading,
  status,
};

export default costOwnerSelector;
