import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const budgetApis = {
  getAllBudgets: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/budget`,
      query: query || {},
    }),
  createBudget: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/budget`,
      data: data,
    }),
  updateBudget: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/budget/${id}`,
      data: data,
    }),
  deleteBudget: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/budget/${id}`,
    }),
  getBudgetById: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/budget/${id}`,
    }),
  getBudgetItems: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/budget_item`,
      query: query || {},
    }),
  getSingleBudgetItem: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/budget_item/${id}`,
    }),
  updateBudgetItem: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/budget_item/${id}`,
      data: data,
    }),
  updateItemStatus: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/budget_item/update_for_approval`,
      data: data,
    }),
  sendBudgetItems: query =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/budget_item`,
      query: query || {},
    }),
  createNewItem: (id, data) =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/budget_item/new_item/${id}`,
      data: data,
    }),
  getItemsByCO: (id, query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/budget_item/cost_owner/${id}`,
      query: query || {},
    }),
  getBudgetContracts: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/budget_contracts`,
      query: query || {},
    }),
  cloneBudgetContract: id =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/budget_item/clone/${id}`,
    }),
  getBudgetSubItems: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/budget_item/children/${id}`,
    }),
  getBudgetId: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/budget/active`,
    }),
  rejectBudgetItem: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/budget_item/reject`,
      data: data,
    }),
  importSingleContract: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/budget_item/new`,
      data: data,
    }),
  contractsToImport: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/contracts_to_import`,
      query: query || {},
    }),
};
