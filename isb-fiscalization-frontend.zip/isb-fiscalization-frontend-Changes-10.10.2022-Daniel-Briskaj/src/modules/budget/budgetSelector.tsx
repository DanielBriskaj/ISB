import { createSelector } from 'reselect';

const selectRaw = state => state.budget;

const budgetItemsArray = createSelector(
  [selectRaw],
  budgets => budgets.budgetItems,
);
const loading = createSelector([selectRaw], budgets => budgets.loading);
const status = createSelector([selectRaw], budgets => budgets.status);
const allBudgets = createSelector([selectRaw], budget => budget.allBudgets);
const budgetData = createSelector([selectRaw], budget => budget.budgetData);
const budgetItem = createSelector([selectRaw], budget => budget.singleItem);
const failedItems = createSelector([selectRaw], budget => budget.failedItems);
const progress = createSelector([selectRaw], budget => budget.progress);
const contractsToImport = createSelector(
  [selectRaw],
  budget => budget.contractsToImport,
);
const budgetCreated = createSelector(
  [selectRaw],
  budget => budget.budgetCreated,
);
const budgetContracts = createSelector(
  [selectRaw],
  budget => budget.budgetContracts,
);

const subBudgetItems = createSelector(
  [selectRaw],
  budget => budget.subBudgetItems,
);
const budgetId = createSelector([selectRaw], budget => budget.budgetId);
const budgetSelector = {
  allBudgets,
  budgetItemsArray,
  budgetData,
  budgetId,
  budgetCreated,
  budgetContracts,
  subBudgetItems,
  budgetItem,
  failedItems,
  loading,
  status,
  progress,
  contractsToImport,
};

export default budgetSelector;
