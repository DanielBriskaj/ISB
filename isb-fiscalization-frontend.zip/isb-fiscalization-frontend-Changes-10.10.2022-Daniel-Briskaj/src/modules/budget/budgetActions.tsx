import { budgetApis } from './budgetApi';
import {
  BUDGET_GET_BY_ID_SUCCESS,
  BUDGET_GET_ALL_ITEMS,
  BUDGET_GET_SINGLE_ITEM,
  BUDGET_GET_BY_COST_OWNER,
  BUDGET_GET_CONTRACTS,
  BUDGET_CREATE_SUCCESS,
  BUDGET_SENT_ITEMS,
  BUDGET_CLONE_CONTRACT,
  BUDGET_READ_SUCCESS,
  BUDGET_UPDATE_SUCCESS,
  BUDGET_PROGRESS,
  BUDGET_READ_SUB_ITEMS_SUCCESS,
  BUDGET_GET_ID,
  BUDGET_CLEAR_ITEM_DATA,
  BUDGET_CLEAR_DATA,
  BUDGET_GET_ALL,
  BUDGET_CLEAR_OPTIONS,
  BUDGET_GET_CONTRACTS_TO_IMPORT,
} from './budgetActionTypes';
import _ from 'lodash';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import { ROLES } from '../shared/authentication/authReducer';
import { BudgetStatus } from 'src/enums/status';

const budgetActions = {
  getAllBudgets: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getAllBudgets(query);
      if (response.success) {
        dispatch({
          type: BUDGET_GET_ALL,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  createBudget: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.createBudget(payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Budget Successfully Created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch({
          type: BUDGET_CREATE_SUCCESS,
          payload: response.payload.status === 201 ? response.payload.data : {},
        });
        const isBudget = true;
        dispatch(budgetActions.getBudgetContracts({ isBudget }));
      } else {
        notificationThrower({
          type: 'error',
          message:
            response.payload.response?.status === 400
              ? (response.payload.response?.data as string)
              : ('Budget Creation Failed' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Budget Creation Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateBudget: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.updateBudget(payload.id, payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Budget Successfully Updated' as string,
        });
        dispatch(
          budgetActions.getBudgetItems({
            budgetStatus: BudgetStatus.NEW,
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Budget Update Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Budget Update Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  deleteBudget: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.deleteBudget(id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Budget Successfully Deleted' as string,
        });
        dispatch(
          budgetActions.getBudgetItems({
            budgetStatus: BudgetStatus.NEW,
          }),
        );
        dispatch(budgetActions.clearBudgetData());
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Budget Delete Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getBudgetById: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getBudgetById(id);
      if (response.success) {
        dispatch({
          type: BUDGET_GET_BY_ID_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getBudgetItems: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getBudgetItems(query);
      if (response.success) {
        dispatch({
          type: BUDGET_GET_ALL_ITEMS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getBudgetSubItems: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getBudgetSubItems(id);

      if (response.success) {
        dispatch({ type: STATUS_LOADING_FALSE });

        dispatch({
          type: BUDGET_READ_SUB_ITEMS_SUCCESS,
          payload: {
            id,
            items: response.payload.status === 200 ? response.payload.data : [],
          },
        });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  getSingleBudgetItem: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getSingleBudgetItem(id);
      if (response.success) {
        dispatch({
          type: BUDGET_GET_SINGLE_ITEM,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateBudgetItem: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.updateBudgetItem(
        payload.id,
        payload.data,
      );
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Budget Item Successfully Updated' as string,
        });
        dispatch(
          budgetActions.getItemsByCO({
            id: payload?.costOwnerId,
            query: payload?.query,
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Budget Item Update Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Budget Item Update Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateItemStatus: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const budgetId = await budgetApis.getBudgetId();
      if (budgetId.success) {
        if (
          payload.role === ROLES.PLANNING_CONTROL_INPUT ||
          payload.role === ROLES.PLANNING_CONTROL_AUTHORIZER ||
          payload.role === ROLES.COST_OWNER_AUTHORIZER
        ) {
          const allItems = await budgetApis.getBudgetItems({
            division: payload?.query?.division,
            budgetStatus: BudgetStatus.NEW,
            size: 1,
          });
          if (allItems.success) {
            const items = await budgetApis.getBudgetItems({
              size: allItems?.payload?.data?.totalItems,
              budgetStatus: BudgetStatus.NEW,
              division: payload?.query?.division,
            });
            if (items.success) {
              const validItems = items?.payload?.data?.contracts
                ?.filter(
                  contract =>
                    contract?.budgetItemStatus === payload?.validBudgetStatus,
                )
                .map(contract => contract?.id);

              if (validItems.length > 0) {
                const response = await budgetApis.updateItemStatus({
                  budgetItemStatus: payload.budgetItemStatus,
                  itemIDs: validItems,
                });
                if (response.success) {
                  payload.role === ROLES.PLANNING_CONTROL_INPUT ||
                  payload.role === ROLES.COST_OWNER_AUTHORIZER ||
                  payload.role === ROLES.COST_OWNER
                    ? notificationThrower({
                        type: 'success',
                        message:
                          `${validItems.length} Budget Items successfully sent for approval` as string,
                      })
                    : notificationThrower({
                        type: 'success',
                        message:
                          `${validItems.length} Budget Items successfully approved` as string,
                      });
                  dispatch(budgetActions.getBudgetItems(payload?.query));
                  dispatch({ type: STATUS_LOADING_FALSE });
                } else {
                  notificationThrower({
                    type: 'error',
                    message: 'Budget Items Approval Failed' as string,
                  });
                  dispatch({ type: STATUS_LOADING_FALSE });
                }
              } else {
                notificationThrower({
                  type: 'warning',
                  message:
                    'No Items Are Applicable To Be Sent For Approval' as string,
                });
                dispatch({ type: STATUS_LOADING_FALSE });
              }
            } else {
              notificationThrower({
                type: 'error',
                message: 'Something Went Wrong' as string,
              });
              dispatch({ type: STATUS_LOADING_FALSE });
            }
          } else {
            notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
            dispatch({ type: STATUS_LOADING_FALSE });
          }
        } else if (payload.role === ROLES.COST_OWNER) {
          const allItems = await budgetApis.getItemsByCO(payload?.costOwnerId, {
            size: 1,
            budgetStatus: BudgetStatus.NEW,
          });
          if (allItems.success) {
            const items = await budgetApis.getItemsByCO(payload?.costOwnerId, {
              size: allItems?.payload?.data?.totalItems,
              budgetStatus: BudgetStatus.NEW,
            });
            if (items.success) {
              const validItems = items?.payload?.data?.contracts
                ?.filter(
                  contract =>
                    contract?.budgetItemStatus === payload?.validBudgetStatus,
                )
                .map(contract => contract?.id);

              if (validItems.length > 0) {
                const response = await budgetApis.updateItemStatus({
                  budgetItemStatus: payload.budgetItemStatus,
                  itemIDs: validItems,
                });
                if (response.success) {
                  payload.role === ROLES.PLANNING_CONTROL_INPUT ||
                  payload.role === ROLES.COST_OWNER_AUTHORIZER ||
                  payload.role === ROLES.COST_OWNER
                    ? notificationThrower({
                        type: 'success',
                        message:
                          `${validItems.length} Budget Items successfully sent for approval` as string,
                      })
                    : notificationThrower({
                        type: 'success',
                        message:
                          `${validItems.length} Budget Items successfully approved` as string,
                      });
                  dispatch({ type: STATUS_LOADING_FALSE });
                  dispatch(
                    budgetActions.getItemsByCO({
                      id: payload?.costOwnerId,
                      query: { budgetStatus: BudgetStatus.NEW },
                    }),
                  );
                } else {
                  notificationThrower({
                    type: 'error',
                    message: 'Budget Items Approval Failed' as string,
                  });
                  dispatch({ type: STATUS_LOADING_FALSE });
                }
              } else {
                notificationThrower({
                  type: 'warning',
                  message:
                    'No Items Are Applicable To Be Sent For Approval' as string,
                });
                dispatch({ type: STATUS_LOADING_FALSE });
              }
            } else {
              notificationThrower({
                type: 'error',
                message: 'Something Went Wrong' as string,
              });
              dispatch({ type: STATUS_LOADING_FALSE });
            }
          } else {
            notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
            dispatch({ type: STATUS_LOADING_FALSE });
          }
        }
      } else {
        notificationThrower({
          type: 'error',
          message:
            budgetId.payload.response?.status === 404
              ? ('No Active Budget Initialized' as string)
              : ('Something Went Wrong' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  sendBudgetItems: (items: any, subItems: any, id: any) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const chunks = _.chunk(items, 50);
      const subItemChunks = _.chunk(subItems, 50);

      const progressUnit = 100 / (chunks.length + subItemChunks.length);

      for await (const chunk of chunks) {
        const postChunkPayload = await budgetApis.sendBudgetItems({
          budgetId: id,
          contractIDs: chunk,
        });

        dispatch({
          type: BUDGET_SENT_ITEMS,
          payload:
            postChunkPayload.payload.status === 200
              ? postChunkPayload.payload.data
              : {},
        });
        dispatch({
          type: BUDGET_PROGRESS,
          payload: progressUnit,
        });
      }
      for await (const subChunk of subItemChunks) {
        const postSubChunkPayload = await budgetApis.sendBudgetItems({
          budgetId: id,
          contractIDs: subChunk,
        });
        dispatch({
          type: BUDGET_SENT_ITEMS,
          payload:
            postSubChunkPayload.payload.status === 200
              ? postSubChunkPayload.payload.data
              : {},
        });
        dispatch({
          type: BUDGET_PROGRESS,
          payload: progressUnit,
        });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  createNewItem: (id, data, costOwnerId) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.createNewItem(id, data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Budget Item Successfully Created' as string,
        });
        dispatch(
          budgetActions.getItemsByCO({
            id: costOwnerId,
            query: { budgetStatus: BudgetStatus.NEW },
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getItemsByCO: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getItemsByCO(payload.id, payload.query);
      if (response.success) {
        dispatch({
          type: BUDGET_GET_BY_COST_OWNER,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getBudgetContracts: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getBudgetContracts(query);
      if (response.success) {
        dispatch({
          type: BUDGET_GET_CONTRACTS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  cloneBudgetContract: (id, costOwnerId) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.cloneBudgetContract(id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Contract Cloned Successfully' as string,
        });
        dispatch({
          type: BUDGET_CLONE_CONTRACT,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch(
          budgetActions.getItemsByCO({
            id: costOwnerId,
            query: { budgetStatus: BudgetStatus.NEW },
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getBudgetId: (payload?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.getBudgetId();
      if (response.success) {
        dispatch({
          type: BUDGET_GET_ID,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        if (payload?.type !== 'newBudget') {
          notificationThrower({
            type: 'error',
            message:
              response.payload.response?.status === 404
                ? ('No Active Budget Initialized' as string)
                : ('Something Went Wrong' as string),
          });
        }
        dispatch({
          type: BUDGET_GET_ID,
          payload: null,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  rejectBudgetItem: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.rejectBudgetItem(payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Budget Item Successfully Rejected' as string,
        });
        dispatch(budgetActions.getBudgetItems(payload?.query));
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Budget Item Reject Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  importSingleContract: data => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.importSingleContract(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Contract Successfully Imported' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          budgetActions.getBudgetItems({
            budgetStatus: BudgetStatus.NEW,
            page: 0,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Contract Import Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  contractsToImport: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await budgetApis.contractsToImport(query);
      if (response.success) {
        dispatch({
          type: BUDGET_GET_CONTRACTS_TO_IMPORT,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  clearBudgetItemData: () => dispatch => {
    dispatch({
      type: BUDGET_CLEAR_ITEM_DATA,
    });
  },
  clearBudgetData: () => dispatch => {
    dispatch({
      type: BUDGET_CLEAR_DATA,
    });
  },
  clearBudgetOptions: () => dispatch => {
    dispatch({
      type: BUDGET_CLEAR_OPTIONS,
    });
  },
};

export default budgetActions;
