import {
  BUDGET_CREATE_SUCCESS,
  BUDGET_GET_BY_ID_SUCCESS,
  BUDGET_READ_SUCCESS,
  BUDGET_UPDATE_SUCCESS,
  BUDGET_GET_ALL_ITEMS,
  BUDGET_GET_SINGLE_ITEM,
  BUDGET_GET_BY_COST_OWNER,
  BUDGET_GET_CONTRACTS,
  BUDGET_SENT_ITEMS,
  BUDGET_LOADING_TRUE,
  BUDGET_LOADING_FALSE,
  BUDGET_PROGRESS,
  BUDGET_READ_SUB_ITEMS_SUCCESS,
  BUDGET_GET_ID,
  BUDGET_CLEAR_ITEM_DATA,
  BUDGET_CLEAR_DATA,
  BUDGET_GET_ALL,
  BUDGET_CLEAR_OPTIONS,
  BUDGET_GET_CONTRACTS_TO_IMPORT,
} from './budgetActionTypes';

const initailValues = {
  allBudgets: {},
  budgetData: {},
  budgetCreated: false,
  budgetId: null,
  budgetItems: [],
  singleItem: {},
  budgetContracts: [],
  failedItems: [],
  loading: false,
  progress: 0,
  subBudgetItems: {},
  contractsToImport: [],
};

// eslint-disable-next-line import/no-anonymous-default-export
export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case BUDGET_LOADING_TRUE:
      return {
        ...state,
        loading: true,
      };
    case BUDGET_LOADING_FALSE:
      return {
        ...state,
        loading: false,
      };
    case BUDGET_GET_ALL:
      return {
        ...state,
        allBudgets: payload,
      };
    case BUDGET_UPDATE_SUCCESS:
      return {
        ...state,
        budgetData: payload,
      };
    case BUDGET_CREATE_SUCCESS:
      return {
        ...state,
        budgetData: payload,
        budgetCreated: true,
        budgetId: payload?.id,
      };
    case BUDGET_GET_BY_ID_SUCCESS:
      return {
        ...state,
        budgetData: payload,
      };
    case BUDGET_GET_ALL_ITEMS:
      return {
        ...state,
        budgetItems: payload,
      };
    case BUDGET_READ_SUB_ITEMS_SUCCESS:
      return {
        ...state,
        subBudgetItems: {
          ...state.subBudgetItems,
          [payload.id]: payload.items,
        },
      };
    case BUDGET_GET_SINGLE_ITEM:
      return {
        ...state,
        singleItem: payload,
      };
    case BUDGET_GET_BY_COST_OWNER:
      return {
        ...state,
        budgetItems: payload,
      };
    case BUDGET_GET_CONTRACTS:
      return {
        ...state,
        budgetContracts: payload,
      };
    case BUDGET_SENT_ITEMS:
      return {
        ...state,
        failedItems: payload,
      };
    case BUDGET_PROGRESS:
      return {
        ...state,
        progress: state.progress + payload,
      };
    case BUDGET_GET_ID:
      return {
        ...state,
        budgetId: payload,
      };
    case BUDGET_GET_CONTRACTS_TO_IMPORT:
      return {
        ...state,
        contractsToImport: payload,
      };
    case BUDGET_CLEAR_ITEM_DATA:
      return {
        ...state,
        singleItem: {},
      };
    case BUDGET_CLEAR_DATA:
      return {
        ...state,
        budgetData: {},
        budgetId: null,
        budgetCreated: false,
        progress: 0,
        failedItems: [],
        budgetContracts: [],
      };
    case BUDGET_CLEAR_OPTIONS:
      return {
        ...state,
        allBudgets: {},
        contractsToImport: [],
      };
  }
  return state;
}
