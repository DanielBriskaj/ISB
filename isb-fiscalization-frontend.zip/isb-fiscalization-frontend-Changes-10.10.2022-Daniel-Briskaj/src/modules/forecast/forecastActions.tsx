import { forecastApis } from './forecastApi';
import {
  FORECAST_GET_BY_ID_SUCCESS,
  FORECAST_GET_ALL_ITEMS,
  FORECAST_GET_SINGLE_ITEM,
  FORECAST_GET_BY_COST_OWNER,
  FORECAST_GET_CONTRACTS,
  FORECAST_CREATE_SUCCESS,
  FORECAST_SENT_ITEMS,
  FORECAST_CLONE_CONTRACT,
  FORECAST_READ_SUCCESS,
  FORECAST_UPDATE_SUCCESS,
  FORECAST_PROGRESS,
  FORECAST_READ_SUB_ITEMS_SUCCESS,
  FORECAST_CLEAR_ITEM_DATA,
  FORECAST_GET_ID,
  FORECAST_CLEAR_DATA,
  FORECAST_CLEAR_OPTIONS,
  FORECAST_GET_ALL,
  FORECAST_GET_CONTRACTS_TO_IMPORT,
} from './forecastActionTypes';
import _ from 'lodash';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import { ROLES } from '../shared/authentication/authReducer';
import { ForecastStatus } from 'src/enums/status';

const forecastActions = {
  getAllForecasts: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getAllForecasts(query);
      if (response.success) {
        dispatch({
          type: FORECAST_GET_ALL,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  createForecast: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.createForecast(payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Forecast Successfully Created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch({
          type: FORECAST_CREATE_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        const isBudget = false;
        dispatch(forecastActions.getForecastContracts({ isBudget }));
      } else {
        notificationThrower({
          type: 'error',
          message:
            response.payload.response?.status === 400
              ? (response.payload.response?.data as string)
              : ('Forecast Creation Failed' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Forecast Creation Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateForecast: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.updateForecast(
        payload.id,
        payload.data,
      );
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Forecast Successfully Updated' as string,
        });
        dispatch(
          forecastActions.getForecastItems({
            forecastStatus: ForecastStatus.NEW,
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Forecast Update Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Forecast Update Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  deleteForecast: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.deleteForecast(id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Forecast Successfully Deleted' as string,
        });
        dispatch(
          forecastActions.getForecastItems({
            forecastStatus: ForecastStatus.NEW,
          }),
        );
        dispatch(forecastActions.clearForecastData());
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Forecast Delete Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getForecastById: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getForecastById(id);
      if (response.success) {
        dispatch({
          type: FORECAST_GET_BY_ID_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getForecastItems: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getForecastItems(query);
      if (response.success) {
        dispatch({
          type: FORECAST_GET_ALL_ITEMS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getForecastSubItems: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getForecastSubItems(id);

      if (response.success) {
        dispatch({ type: STATUS_LOADING_FALSE });

        dispatch({
          type: FORECAST_READ_SUB_ITEMS_SUCCESS,
          payload: {
            id,
            items: response.payload.status === 200 ? response.payload.data : [],
          },
        });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  getSingleForecastItem: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getSingleForecastItem(id);
      if (response.success) {
        dispatch({
          type: FORECAST_GET_SINGLE_ITEM,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateForecastItem: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.updateForecastItem(
        payload.id,
        payload.data,
      );
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Forecast Item Successfully Updated' as string,
        });
        dispatch(
          forecastActions.getItemsByCO({
            id: payload?.costOwnerId,
            query: payload?.query,
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Forecast Item Update Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Forecast Item Update Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updateItemStatus: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const forecastId = await forecastApis.getForecastId();
      if (forecastId.success) {
        if (
          payload.role === ROLES.PLANNING_CONTROL_INPUT ||
          payload.role === ROLES.PLANNING_CONTROL_AUTHORIZER ||
          payload.role === ROLES.COST_OWNER_AUTHORIZER
        ) {
          const allItems = await forecastApis.getForecastItems({
            division: payload?.query?.division,
            forecastStatus: ForecastStatus.NEW,
            size: 1,
          });
          if (allItems.success) {
            const items = await forecastApis.getForecastItems({
              size: allItems?.payload?.data?.totalItems,
              division: payload?.query?.division,
              forecastStatus: ForecastStatus.NEW,
            });
            if (items.success) {
              const validItems = items?.payload?.data?.forecastItems
                ?.filter(
                  contract =>
                    contract?.forecastItemStatus ===
                    payload?.validForecastStatus,
                )
                .map(contract => contract?.id);

              if (validItems?.length > 0) {
                const response = await forecastApis.updateItemStatus({
                  forecastItemStatus: payload.forecastItemStatus,
                  itemIDs: validItems,
                });
                if (response.success) {
                  payload.role === ROLES.PLANNING_CONTROL_INPUT ||
                  payload.role === ROLES.COST_OWNER_AUTHORIZER ||
                  payload.role === ROLES.COST_OWNER
                    ? notificationThrower({
                        type: 'success',
                        message:
                          `${validItems?.length} Forecast Items successfully sent for approval` as string,
                      })
                    : notificationThrower({
                        type: 'success',
                        message:
                          `${validItems?.length} Forecast Items successfully approved` as string,
                      });
                  dispatch(forecastActions.getForecastItems(payload?.query));
                  dispatch({ type: STATUS_LOADING_FALSE });
                } else {
                  notificationThrower({
                    type: 'error',
                    message: 'Forecast Items Approval Failed' as string,
                  });
                  dispatch({ type: STATUS_LOADING_FALSE });
                }
              } else {
                notificationThrower({
                  type: 'warning',
                  message:
                    'No Items Are Applicable To Be Sent For Approval' as string,
                });
                dispatch({ type: STATUS_LOADING_FALSE });
              }
            } else {
              notificationThrower({
                type: 'error',
                message: 'Something Went Wrong' as string,
              });
              dispatch({ type: STATUS_LOADING_FALSE });
            }
          } else {
            notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
            dispatch({ type: STATUS_LOADING_FALSE });
          }
        } else if (payload.role === ROLES.COST_OWNER) {
          const allItems = await forecastApis.getItemsByCO(
            payload?.costOwnerId,
            {
              size: 1,
              forecastStatus: ForecastStatus.NEW,
            },
          );
          if (allItems.success) {
            const items = await forecastApis.getItemsByCO(
              payload?.costOwnerId,
              {
                size: allItems?.payload?.data?.totalItems,
                forecastStatus: ForecastStatus.NEW,
              },
            );
            if (items.success) {
              const validItems = items?.payload?.data?.forecastItems
                ?.filter(
                  contract =>
                    contract?.forecastItemStatus ===
                    payload?.validForecastStatus,
                )
                .map(contract => contract?.id);

              if (validItems?.length > 0) {
                const response = await forecastApis.updateItemStatus({
                  forecastItemStatus: payload.forecastItemStatus,
                  itemIDs: validItems,
                });
                if (response.success) {
                  payload.role === ROLES.PLANNING_CONTROL_INPUT ||
                  payload.role === ROLES.COST_OWNER_AUTHORIZER ||
                  payload.role === ROLES.COST_OWNER
                    ? notificationThrower({
                        type: 'success',
                        message:
                          `${validItems?.length} Forecast Items successfully sent for approval` as string,
                      })
                    : notificationThrower({
                        type: 'success',
                        message:
                          `${validItems?.length} Forecast Items successfully approved` as string,
                      });
                  dispatch({ type: STATUS_LOADING_FALSE });
                  dispatch(
                    forecastActions.getItemsByCO({
                      id: payload?.costOwnerId,
                      query: { forecastStatus: ForecastStatus.NEW },
                    }),
                  );
                } else {
                  notificationThrower({
                    type: 'error',
                    message: 'Forecast Items Approval Failed' as string,
                  });
                  dispatch({ type: STATUS_LOADING_FALSE });
                }
              } else {
                notificationThrower({
                  type: 'warning',
                  message:
                    'No Items Are Applicable To Be Sent For Approval' as string,
                });
                dispatch({ type: STATUS_LOADING_FALSE });
              }
            } else {
              notificationThrower({
                type: 'error',
                message: 'Something Went Wrong' as string,
              });
              dispatch({ type: STATUS_LOADING_FALSE });
            }
          } else {
            notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
            dispatch({ type: STATUS_LOADING_FALSE });
          }
        }
      } else {
        notificationThrower({
          type: 'error',
          message:
            forecastId.payload.response?.status === 404
              ? ('No Active Forecast Initialized' as string)
              : ('Something Went Wrong' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  sendForecastItems: (items: any, subItems: any, id: any) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const chunks = _.chunk(items, 50);
      const subItemChunks = _.chunk(subItems, 50);

      const progressUnit = 100 / (chunks.length + subItemChunks.length);

      for await (const chunk of chunks) {
        const postChunkPayload = await forecastApis.sendForecastItems({
          forecastId: id,
          contractIDs: chunk,
        });

        dispatch({
          type: FORECAST_SENT_ITEMS,
          payload:
            postChunkPayload.payload.status === 200
              ? postChunkPayload.payload.data
              : {},
        });
        dispatch({
          type: FORECAST_PROGRESS,
          payload: progressUnit,
        });
      }
      for await (const subChunk of subItemChunks) {
        const postSubChunkPayload = await forecastApis.sendForecastItems({
          forecastId: id,
          contractIDs: subChunk,
        });
        dispatch({
          type: FORECAST_SENT_ITEMS,
          payload:
            postSubChunkPayload.payload.status === 200
              ? postSubChunkPayload.payload.data
              : {},
        });
        dispatch({
          type: FORECAST_PROGRESS,
          payload: progressUnit,
        });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  createNewItem: (id, data, costOwnerId) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.createNewItem(id, data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Forecast Item Successfully Created' as string,
        });
        dispatch(
          forecastActions.getItemsByCO({
            id: costOwnerId,
            query: { forecastStatus: ForecastStatus.NEW },
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getItemsByCO: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getItemsByCO(
        payload.id,
        payload.query,
      );
      if (response.success) {
        dispatch({
          type: FORECAST_GET_BY_COST_OWNER,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getForecastContracts: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getForecastContracts(query);
      if (response.success) {
        dispatch({
          type: FORECAST_GET_CONTRACTS,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  cloneForecastContract: (id, costOwnerId) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.cloneForecastContract(id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Contract Cloned Successfully' as string,
        });
        dispatch({
          type: FORECAST_CLONE_CONTRACT,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch(
          forecastActions.getItemsByCO({
            id: costOwnerId,
            query: { forecastStatus: ForecastStatus.NEW },
          }),
        );
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getForecastId: (payload?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.getForecastId();
      if (response.success) {
        dispatch({
          type: FORECAST_GET_ID,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        if (payload?.type !== 'newForecast') {
          notificationThrower({
            type: 'error',
            message:
              response.payload.response?.status === 404
                ? ('No Active Forecast Initialized' as string)
                : ('Something Went Wrong' as string),
          });
        }
        dispatch({
          type: FORECAST_GET_ID,
          payload: null,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  rejectForecastItem: payload => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.rejectForecastItem(payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Forecast Item Successfully Rejected' as string,
        });
        dispatch(forecastActions.getForecastItems(payload?.query));
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Forecast Item Reject Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  importSingleContract: data => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.importSingleContract(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Contract Successfully Imported' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(
          forecastActions.getForecastItems({
            budgetStatus: ForecastStatus.NEW,
            page: 0,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Contract Import Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  contractsToImport: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await forecastApis.contractsToImport(query);
      if (response.success) {
        dispatch({
          type: FORECAST_GET_CONTRACTS_TO_IMPORT,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  clearForecastItemData: () => dispatch => {
    dispatch({
      type: FORECAST_CLEAR_ITEM_DATA,
    });
  },
  clearForecastData: () => dispatch => {
    dispatch({
      type: FORECAST_CLEAR_DATA,
    });
  },
  clearForecastOptions: () => dispatch => {
    dispatch({
      type: FORECAST_CLEAR_OPTIONS,
    });
  },
};

export default forecastActions;
