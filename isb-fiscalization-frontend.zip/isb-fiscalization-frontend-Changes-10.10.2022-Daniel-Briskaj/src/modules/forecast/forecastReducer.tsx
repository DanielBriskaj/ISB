import {
  FORECAST_CREATE_SUCCESS,
  FORECAST_GET_BY_ID_SUCCESS,
  FORECAST_READ_SUCCESS,
  FORECAST_UPDATE_SUCCESS,
  FORECAST_GET_ALL_ITEMS,
  FORECAST_GET_SINGLE_ITEM,
  FORECAST_GET_BY_COST_OWNER,
  FORECAST_GET_CONTRACTS,
  FORECAST_SENT_ITEMS,
  FORECAST_LOADING_TRUE,
  FORECAST_LOADING_FALSE,
  FORECAST_PROGRESS,
  FORECAST_READ_SUB_ITEMS_SUCCESS,
  FORECAST_GET_ID,
  FORECAST_CLEAR_ITEM_DATA,
  FORECAST_CLEAR_DATA,
  FORECAST_GET_ALL,
  FORECAST_CLEAR_OPTIONS,
  FORECAST_GET_CONTRACTS_TO_IMPORT,
} from './forecastActionTypes';

const initailValues = {
  allForecasts: {},
  forecastData: {},
  forecastCreated: false,
  forecastId: null,
  forecastItems: [],
  singleItem: {},
  forecastContracts: [],
  failedItems: [],
  loading: false,
  progress: 0,
  subForecastItems: {},
  contractsToImport: [],
};

// eslint-disable-next-line import/no-anonymous-default-export
export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case FORECAST_LOADING_TRUE:
      return {
        ...state,
        loading: true,
      };
    case FORECAST_LOADING_FALSE:
      return {
        ...state,
        loading: false,
      };
    case FORECAST_GET_ALL:
      return {
        ...state,
        allForecasts: payload,
      };
    case FORECAST_READ_SUCCESS:
      return {
        ...state,
        forecastData: payload,
      };
    case FORECAST_UPDATE_SUCCESS:
      return {
        ...state,
        forecastData: payload,
      };
    case FORECAST_CREATE_SUCCESS:
      return {
        ...state,
        forecastData: payload,
        forecastCreated: true,
        forecastId: payload?.id,
      };
    case FORECAST_GET_BY_ID_SUCCESS:
      return {
        ...state,
        forecastData: payload,
      };
    case FORECAST_GET_ALL_ITEMS:
      return {
        ...state,
        forecastItems: payload,
      };
    case FORECAST_READ_SUB_ITEMS_SUCCESS:
      return {
        ...state,
        subForecastItems: {
          ...state.subForecastItems,
          [payload.id]: payload.items,
        },
      };
    case FORECAST_GET_SINGLE_ITEM:
      return {
        ...state,
        singleItem: payload,
      };
    case FORECAST_GET_BY_COST_OWNER:
      return {
        ...state,
        forecastItems: payload,
      };
    case FORECAST_GET_CONTRACTS:
      return {
        ...state,
        forecastContracts: payload,
      };
    case FORECAST_SENT_ITEMS:
      return {
        ...state,
        failedItems: payload,
      };
    case FORECAST_PROGRESS:
      return {
        ...state,
        progress: state.progress + payload,
      };
    case FORECAST_GET_ID:
      return {
        ...state,
        forecastId: payload,
      };
    case FORECAST_GET_CONTRACTS_TO_IMPORT:
      return {
        ...state,
        contractsToImport: payload,
      };
    case FORECAST_CLEAR_ITEM_DATA:
      return {
        ...state,
        singleItem: {},
      };
    case FORECAST_CLEAR_DATA:
      return {
        ...state,
        forecastData: {},
        forecastId: null,
        forecastCreated: false,
        forecastContracts: [],
        failedItems: [],
        progress: 0,
      };
    case FORECAST_CLEAR_OPTIONS:
      return {
        ...state,
        allForecasts: {},
        contractsToImport: [],
      };
  }
  return state;
}
