import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const forecastApis = {
  getAllForecasts: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/forecast`,
      query: query || {},
    }),
  createForecast: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/forecast`,
      data: data,
    }),
  updateForecast: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/forecast/${id}`,
      data: data,
    }),
  deleteForecast: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/forecast/${id}`,
    }),
  getForecastById: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/forecast/${id}`,
    }),
  getForecastItems: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/forecast_item`,
      query: query || {},
    }),
  getSingleForecastItem: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/forecast_item/${id}`,
    }),
  updateForecastItem: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/forecast_item/${id}`,
      data: data,
    }),
  updateItemStatus: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/forecast_item/update_for_approval`,
      data: data,
    }),
  sendForecastItems: query =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/forecast_item`,
      query: query || {},
    }),
  createNewItem: (id, data) =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/forecast_item/new_item/${id}`,
      data: data,
    }),
  getItemsByCO: (id, query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/forecast_item/cost_owner/${id}`,
      query: query || {},
    }),
  getForecastContracts: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/budget_contracts`,
      query: query || {},
    }),
  cloneForecastContract: id =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/forecast_item/clone/${id}`,
    }),
  getForecastSubItems: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/forecast_item/children/${id}`,
    }),
  getForecastId: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/forecast/active`,
    }),
  rejectForecastItem: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/forecast_item/reject`,
      data: data,
    }),
  importSingleContract: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/forecast_item/new`,
      data: data,
    }),
  contractsToImport: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/contracts_to_import`,
      query: query || {},
    }),
};
