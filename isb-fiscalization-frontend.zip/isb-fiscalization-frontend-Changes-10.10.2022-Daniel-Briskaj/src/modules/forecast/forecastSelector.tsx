import { createSelector } from 'reselect';

const selectRaw = state => state.forecast;

const forecastItemsArray = createSelector(
  [selectRaw],
  forecasts => forecasts.forecastItems,
);
const loading = createSelector([selectRaw], forecasts => forecasts.loading);
const status = createSelector([selectRaw], forecasts => forecasts.status);
const allForecasts = createSelector(
  [selectRaw],
  forecast => forecast.allForecasts,
);
const forecastData = createSelector(
  [selectRaw],
  forecast => forecast.forecastData,
);
const forecastItem = createSelector(
  [selectRaw],
  forecast => forecast.singleItem,
);
const failedItems = createSelector(
  [selectRaw],
  forecast => forecast.failedItems,
);
const progress = createSelector([selectRaw], forecast => forecast.progress);
const forecastCreated = createSelector(
  [selectRaw],
  forecast => forecast.forecastCreated,
);
const forecastContracts = createSelector(
  [selectRaw],
  forecast => forecast.forecastContracts,
);

const subForecastItems = createSelector(
  [selectRaw],
  forecast => forecast.subForecastItems,
);
const contractsToImport = createSelector(
  [selectRaw],
  forecast => forecast.contractsToImport,
);
const forecastId = createSelector([selectRaw], forecast => forecast.forecastId);
const forecastSelector = {
  allForecasts,
  forecastItemsArray,
  forecastData,
  forecastId,
  forecastCreated,
  forecastContracts,
  subForecastItems,
  forecastItem,
  failedItems,
  loading,
  status,
  progress,
  contractsToImport,
};

export default forecastSelector;
