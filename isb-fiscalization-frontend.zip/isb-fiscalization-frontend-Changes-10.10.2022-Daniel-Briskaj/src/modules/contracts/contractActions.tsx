import { contractApis } from './contractApi';
import {
  CONTRACT_CREATE_SUCCESS,
  CONTRACT_DELETE,
  CONTRACT_READ_SUCCESS,
  CONTRACT_UPDATE_SUCCESS,
  CONTRACT_GET_BY_ID_SUCCESS,
  SET_CURRENT_PAGE,
  CONTRACT_READ_SUBCONTRACTS_SUCCESS,
  CONTRACT_SET_SELECTED_CONTRACT,
  CONTRACT_CLEAR_CONTRACT_DATA,
  CONTRACT_CLEAR_CONTRACT_ARRAY,
  CONTRACT_SUBLOADING,
  UPLOAD_FILE_SUCCESS,
  GET_FILES_SUCCESS,
  DELETE_FILE_SUCCESS,
  EXPORT_EXEL,
  CLEAR_FILES,
} from './contractActionTypes';

import {
  STATUS,
  STATUS_ERROR,
  STATUS_LOADING_FALSE,
  STATUS_LOADING_TRUE,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from 'src/modules/shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import deepEqual from 'deep-equal';

enum CONTRACT_STATUS {
  ACTIVE = 'ACTIVE',
  EXPIRED = 'EXPIRED',
  BUDGET = 'BUDGET',
  FORECAST = 'FORECAST',
  NEW = 'NEW',
}

const contractActions = {
  clearContractData: () => dispatch => {
    dispatch({ type: CONTRACT_CLEAR_CONTRACT_DATA });
  },
  clearContractsArray: () => dispatch => {
    dispatch({ type: CONTRACT_CLEAR_CONTRACT_ARRAY });
  },
  clearFiles: () => dispatch => {
    dispatch({ type: CLEAR_FILES });
  },
  setSelectedContract: (id?) => dispatch => {
    dispatch({
      type: CONTRACT_SET_SELECTED_CONTRACT,
      payload: id ? { id: id } : null,
    });
  },
  create: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.addContract(data);
      if (response.success) {
        dispatch({
          type: CONTRACT_CREATE_SUCCESS,
        });
        notificationThrower({
          type: 'success',
          message: 'Contract Successfully Created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(contractActions.read(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Contract Creation Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Contract Creation Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  update: (payload, query) => async dispatch => {
    try {
      let initialContractData = payload.rawContractBody;
      let updatedContractData = payload.data;

      if (initialContractData?.contractStatus === CONTRACT_STATUS.ACTIVE) {
        const tempInitialContractData = payload.rawContractBody;
        const tempUpdatedContractData = { ...payload.data, id: payload.id };

        delete tempInitialContractData.contractCode;
        delete tempInitialContractData.contractStatus;
        delete tempUpdatedContractData.budget;
        delete tempUpdatedContractData.forecast;
        delete tempUpdatedContractData.budgetItemStatus;
        delete tempUpdatedContractData.forecastItemStatus;
        delete tempUpdatedContractData.contractStatus;

        const equal = deepEqual(
          tempInitialContractData,
          tempUpdatedContractData,
        );

        if (!equal) {
          updatedContractData = {
            ...updatedContractData,
            contractStatus: CONTRACT_STATUS.NEW,
          };
        }
      }

      const response = await contractApis.updateContract(
        updatedContractData,
        payload.id,
      );
      if (response.success) {
        dispatch({
          type: CONTRACT_UPDATE_SUCCESS,
        });
        notificationThrower({
          type: 'success',
          message: 'Contract Successfully Updated' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(contractActions.read(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Contract Update Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Contract Update Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  updateStatus: (payload, query, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.updateContractStatus(
        payload.id,
        payload.status,
      );
      if (response.success) {
        dispatch({
          type: CONTRACT_UPDATE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : [],
        });
        if (actionType === 'Assigned') {
          role === 'PROCUREMENT_INPUT'
            ? notificationThrower({
                type: 'success',
                message: 'Contract Successfully Sent for Approval' as string,
              })
            : notificationThrower({
                type: 'success',
                message: 'Contract Successfully Approved' as string,
              });
        } else {
          notificationThrower({
            type: 'success',
            message: 'Contract Successfully Rejected' as string,
          });
        }

        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(contractActions.read(query));
      } else {
        actionType === 'Assigned'
          ? notificationThrower({
              type: 'error',
              message: 'Contract Approval Failed' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'Contract Rejection Failed' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something went wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  delete: (id, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.deleteContract(id);
      if (response.success) {
        const contracts = await contractApis.fetchContracts();
        dispatch({
          type: CONTRACT_DELETE,
          payload: contracts.payload?.data?.contracts,
        });
        notificationThrower({
          type: 'success',
          message: 'Contract Successfully Deleted' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(contractActions.read(query));
      } else {
        notificationThrower({
          type:
            response.payload.response?.status === 409 ||
            response.payload.response?.status === 400
              ? 'warning'
              : 'error',
          message:
            response.payload.response?.status === 409 ||
            response.payload.response?.status === 400
              ? (response.payload.response?.data as string)
              : ('Contract Deletion Failed' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Contract Deletion Failed' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  read: (query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await contractApis.fetchContracts(query);

      if (response.success) {
        dispatch({
          type: CONTRACT_READ_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  readByCostOwner: (id, query?) => async dispatch => {
    try {
      if (!query) {
        dispatch({ type: STATUS_LOADING_TRUE });
      }
      const response = await contractApis.fetchContractsByCostOwner(id, query);

      if (response.success) {
        dispatch({
          type: CONTRACT_READ_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  readSubContracts: id => async dispatch => {
    try {
      dispatch({ type: CONTRACT_SUBLOADING });
      const response = await contractApis.fetchSubContracts(id);

      if (response.success) {
        dispatch({
          type: CONTRACT_READ_SUBCONTRACTS_SUCCESS,
          payload: {
            id,
            subContracts:
              response.payload?.status === 200 ? response.payload.data : [],
          },
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getById: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.fetchContract(id);

      if (response.success) {
        dispatch({
          type: CONTRACT_GET_BY_ID_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  getUploadedFiles: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.getUploadedFiles(id);

      if (response.success) {
        dispatch({
          type: GET_FILES_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  uploadFile: (id, data, inputFileName?, filesArray?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.uploadFile(id, data);

      if (response.success) {
        dispatch({
          type: UPLOAD_FILE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        filesArray.some(item => item.name === inputFileName)
          ? notificationThrower({
              type: 'warning',
              message: 'This file is already uploaded!' as string,
            })
          : notificationThrower({
              type: 'success',
              message: 'File uploaded successfully' as string,
            });
        dispatch(contractActions.getUploadedFiles(id));

        dispatch({ type: STATUS_LOADING_FALSE });
      } else if (!response.success) {
        response.payload.response.data &&
        response.payload.response.status === 400
          ? notificationThrower({
              type: 'error',
              message: 'Only PDF files are supported!' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  deleteUploadedFile: (id, filename) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.deleteFile(id, filename);

      if (response.success) {
        dispatch({
          type: DELETE_FILE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        notificationThrower({
          type: 'success',
          message: 'File deleted successfully' as string,
        });
        dispatch(contractActions.getUploadedFiles(id));

        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  downloadUploadedFile: (id, filename) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.getUploadedFile(id, filename);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'file.pdf');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  setCurrentPage: page => dispatch => {
    dispatch({
      type: SET_CURRENT_PAGE,
      payload: page,
    });
  },
  exportExelFile: () => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.exportExelFile();

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'contracts.xlsx');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  exportExelFilewithFilters: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.exportExelFileWithFilters(query);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'contracts.xlsx');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  importContract: () => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.importContracts();

      if (response.success) {
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  exportActiveContractsPaidAmount: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await contractApis.exportActiveContractsPaidAmount(
        query,
      );

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'TotalExpensesForActiveContracts.xlsx');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  batchUpdate: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await contractApis.bactchUpdate(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Successfully Approved All Contracts',
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(contractActions.read(query));
      } else {
        if (response.payload.response.status === 404) {
          notificationThrower({
            type: 'warning',
            message: 'No Contracts Are Applicable To Be Approved',
          });
        } else {
          notificationThrower({
            type: 'error',
            message: 'Something Went Wrong' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },
};

export default contractActions;
