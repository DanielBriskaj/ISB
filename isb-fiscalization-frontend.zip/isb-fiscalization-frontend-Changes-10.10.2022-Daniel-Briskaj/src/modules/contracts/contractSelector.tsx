import { createSelector } from 'reselect';

const selectRaw = state => state.contracts;

const contractsDataArray = createSelector(
  [selectRaw],
  contracts => contracts.contractsData,
);

const contractData = createSelector(
  [selectRaw],
  contracts => contracts.contractData,
);

const subContractsData = createSelector(
  [selectRaw],
  contracts => contracts.subContractsData,
);

const selectedContract = createSelector(
  [selectRaw],
  contracts => contracts.selectedContract,
);
const files = createSelector([selectRaw], contracts => contracts.files);

const loading = createSelector([selectRaw], contracts => contracts.loading);
const status = createSelector([selectRaw], contracts => contracts.status);
const subloading = createSelector(
  [selectRaw],
  contracts => contracts.subloading,
);

const contractSelector = {
  contractsDataArray,
  subContractsData,
  contractData,
  selectedContract,
  loading,
  subloading,
  status,
  files,
};

export default contractSelector;
