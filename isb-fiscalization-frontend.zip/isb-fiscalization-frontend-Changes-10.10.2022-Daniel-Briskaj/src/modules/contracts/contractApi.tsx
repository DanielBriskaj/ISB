import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const contractApis = {
  fetchContracts: (query?) => {
    return Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts`,
      query: query || {},
    });
  },
  fetchContractsByCostOwner: (id, query?) => {
    return Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/cost-owner/${id}`,
      query: query || {},
    });
  },
  exportExelFile: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/export`,
      responseType: 'blob',
    }),
  exportExelFileWithFilters: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/export_with_filters_applied`,
      responseType: 'blob',
      query: query || {},
    }),
  importContracts: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/import_contracts_from_excel`,
      responseType: 'blob',
    }),
  fetchSubContracts: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/children/${id}`,
    }),
  fetchContract: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/${id}`,
    }),
  addContract: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/contracts`,
      data,
    }),
  updateContract: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/contracts/${id}`,
      data,
    }),
  updateContractStatus: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/contracts/approvalStatus/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data,
    }),
  deleteContract: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/contracts/${id}`,
    }),
  uploadFile: (id, data) =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/contracts/${id}/upload`,
      data,
      headers: {
        'content-type': 'multipart/form-data',
        accept: 'application/pdf',
      },
    }),
  getUploadedFiles: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/${id}/files`,
    }),
  getUploadedFile: (id, filename) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/${id}/files/${filename}`,
      responseType: 'blob',
    }),
  deleteFile: (id, filename) =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/contracts/${id}/files/${filename}`,
    }),
  exportActiveContractsPaidAmount: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/contracts/export_active_contracts_paid_amount`,
      responseType: 'blob',
      query: query || {},
    }),
  bactchUpdate: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/contracts/batch_update`,
      data,
    }),
};
