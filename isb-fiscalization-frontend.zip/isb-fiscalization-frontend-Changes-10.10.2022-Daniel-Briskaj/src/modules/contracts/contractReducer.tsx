import { ContractsData } from 'src/models/data/contracts/ContractsData';
import {
  CONTRACT_CREATE_SUCCESS,
  CONTRACT_DELETE,
  CONTRACT_READ_SUCCESS,
  CONTRACT_UPDATE_SUCCESS,
  CONTRACT_GET_BY_ID_SUCCESS,
  SET_CURRENT_PAGE,
  CONTRACT_READ_SUBCONTRACTS_SUCCESS,
  CONTRACT_CLEAR_CONTRACT_DATA,
  CONTRACT_CLEAR_CONTRACT_ARRAY,
  CONTRACT_SET_SELECTED_CONTRACT,
  CONTRACT_SUBLOADING,
  CLEAR_FILES,
  GET_FILES_SUCCESS,
} from './contractActionTypes';

const initailValues: ContractsData = {
  contractsData: {},
  subContractsData: {},
  contractData: {},
  subLoading: false,
  selectedContract: null,
  files: [],
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case CONTRACT_CLEAR_CONTRACT_ARRAY:
      return {
        ...state,
        contractsData: {},
      };
    case CONTRACT_CLEAR_CONTRACT_DATA:
      return {
        ...state,
        contractData: {},
      };
    case CLEAR_FILES:
      return {
        ...state,
        files: [],
      };
    case CONTRACT_SET_SELECTED_CONTRACT:
      return {
        ...state,
        selectedContract: payload,
      };
    case CONTRACT_SUBLOADING:
      return {
        ...state,
        subLoading: true,
        error: false,
      };
    case CONTRACT_READ_SUCCESS:
      return {
        ...state,
        contractsData: payload,
      };
    case CONTRACT_UPDATE_SUCCESS:
      return {
        ...state,
        status: 200,
      };
    case CONTRACT_DELETE:
      return {
        ...state,
        contractData: payload,
      };
    case GET_FILES_SUCCESS:
      return {
        ...state,
        files: payload,
      };
    case CONTRACT_CREATE_SUCCESS:
      return {
        ...state,
        status: 200,
      };
    case CONTRACT_GET_BY_ID_SUCCESS:
      return {
        ...state,
        contractData: payload,
      };
    case CONTRACT_READ_SUBCONTRACTS_SUCCESS:
      const { id, subContracts } = payload;
      let subContractsData = state.subContractsData;

      subContractsData = {
        ...state.subContractsData,
        [id]: subContracts,
      };

      return {
        ...state,
        subLoading: false,
        subContractsData,
      };
    case SET_CURRENT_PAGE:
      return {
        ...state,
        contractsData: {
          ...state,
          currentPage: payload,
        },
      };
  }
  return state;
}
