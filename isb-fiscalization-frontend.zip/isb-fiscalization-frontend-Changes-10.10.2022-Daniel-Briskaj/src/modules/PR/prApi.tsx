import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const prApis = {
  fetchPR: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/pr`,
      query: query || {},
    }),
  fetchPRById: (id, query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/pr/${id}`,
      query: query || {},
    }),
  createPR: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/pr`,
      data,
    }),
  updatePR: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/pr/${id}`,
      data,
    }),
  changeStatusPR: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/pr/changeStatus/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data,
    }),
  deletePR: (id, query?) =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/pr/${id}`,
      query: query || {},
    }),
  exportExelFile: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/pr/exportPr/${id}`,
      responseType: 'blob',
    }),
  uploadFile: (id, data) =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/pr/${id}/upload`,
      data,
      headers: {
        'content-type': 'multipart/form-data',
        accept: 'application/pdf',
      },
    }),
  getUploadedFiles: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/pr/${id}/files`,
    }),
  getUploadedFile: (id, filename) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/pr/${id}/files/${filename}`,
      responseType: 'blob',
    }),
  deleteFile: (id, filename) =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/pr/${id}/files/${filename}`,
    }),
  bactchUpdate: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/pr/batch_update`,
      data,
    }),
};
