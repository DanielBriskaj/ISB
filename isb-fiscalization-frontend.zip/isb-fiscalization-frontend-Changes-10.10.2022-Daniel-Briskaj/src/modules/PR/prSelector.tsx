import { createSelector } from 'reselect';

const selectRaw = state => state.pr;

const purchaseRequestData = createSelector(
  [selectRaw],
  pr => pr.purchaseRequestData,
);

const prData = createSelector([selectRaw], pr => pr.prData);
const files = createSelector([selectRaw], pr => pr.files);

const prSelector = {
  purchaseRequestData,
  prData,
  files,
};
export default prSelector;
