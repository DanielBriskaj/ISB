const prefix = 'PR';

export const PR_SUCCESS = `${prefix}_SUCCESS`;
export const PR_CREATE = `${prefix}_CREATE`;
export const PR_DELETE = `${prefix}_DELETE`;
export const PR_UPDATE = `${prefix}_UPDATE`;
export const PR_GET_BY_ID = `${prefix}_GET_BY_ID`;
export const PR_CLEAR_DATA = `${prefix}_CLEAR_DATA`;
export const GET_DESCRIPTION = 'GET_DESCRIPTION';
export const UPLOAD_FILE_SUCCESS = `UPLOAD_FILE_SUCCESS`;
export const GET_FILES_SUCCESS = `GET_FILES_SUCCESS`;
export const DELETE_FILE_SUCCESS = `DELETE_FILE_SUCCESS`;
export const CLEAR_FILES = `CLEAR_FILES`;
