import { PrData } from 'src/models/data/pr/PrData';
import {
  PR_SUCCESS,
  PR_CLEAR_DATA,
  PR_CREATE,
  PR_DELETE,
  PR_GET_BY_ID,
  PR_UPDATE,
  GET_DESCRIPTION,
  GET_FILES_SUCCESS,
  CLEAR_FILES,
} from './prActionTypes';

const initailValues: PrData = {
  purchaseRequestData: [],
  prData: {},
  rejectedPr: '',
  files: [],
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case PR_SUCCESS:
      return {
        ...state,
        purchaseRequestData: payload,
      };
    case CLEAR_FILES:
      return {
        ...state,
        files: [],
      };
    case GET_FILES_SUCCESS:
      return {
        ...state,
        files: payload,
      };
    case PR_GET_BY_ID:
      return {
        ...state,
        prData: payload,
      };
    case GET_DESCRIPTION:
      return {
        ...state,
        rejectedPr: payload,
      };
    case PR_CREATE:
      return {
        ...state,
        prData: payload,
      };
    case PR_DELETE:
      return {
        ...state,
        prData: payload,
      };
    case PR_UPDATE:
      return {
        ...state,
        prData: payload,
      };
    case PR_CLEAR_DATA:
      return {
        ...state,
        prData: {},
      };
    default:
      return state;
  }
}
