import { prApis } from './prApi';
import {
  PR_SUCCESS,
  PR_CLEAR_DATA,
  PR_CREATE,
  PR_DELETE,
  GET_DESCRIPTION,
  PR_GET_BY_ID,
  PR_UPDATE,
  UPLOAD_FILE_SUCCESS,
  GET_FILES_SUCCESS,
  DELETE_FILE_SUCCESS,
  CLEAR_FILES,
} from './prActionTypes';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import IsAuthorizer from 'src/helpers/isAuthorizer';

enum FileEnum {
  PDF = 'file.pdf',
  DOCX = 'file.docx',
  XLSX = 'file.xlsx',
}

const downloadFileByExtension = (filename, link) => {
  const extension = filename.includes('.pdf')
    ? filename.slice(-4)
    : filename.slice(-5);
  switch (extension) {
    case '.pdf':
      return link.setAttribute('download', FileEnum.PDF);
    case '.docx':
      return link.setAttribute('download', FileEnum.DOCX);
    case '.xlsx':
      return link.setAttribute('download', FileEnum.XLSX);
    default:
      return '';
  }
};

const prActions = {
  clearFiles: () => dispatch => {
    dispatch({ type: CLEAR_FILES });
  },
  getUploadedFiles: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.getUploadedFiles(id);

      if (response.success) {
        dispatch({
          type: GET_FILES_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  uploadFile: (id, data, inputFileName?, filesArray?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.uploadFile(id, data);

      if (response.success) {
        dispatch({
          type: UPLOAD_FILE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        filesArray.some(item => item.name === inputFileName)
          ? notificationThrower({
              type: 'warning',
              message: 'This file is already uploaded!' as string,
            })
          : notificationThrower({
              type: 'success',
              message: 'File uploaded successfully' as string,
            });
        dispatch(prActions.getUploadedFiles(id));

        dispatch({ type: STATUS_LOADING_FALSE });
      } else if (!response.success) {
        response.payload.response.data &&
        response.payload.response.status === 400
          ? notificationThrower({
              type: 'error',
              message:
                'Only Pdf, Word and Excel files are supported!' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'Something Went Wrong' as string,
            });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  deleteUploadedFile: (id, filename) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.deleteFile(id, filename);

      if (response.success) {
        dispatch({
          type: DELETE_FILE_SUCCESS,
          payload:
            response.payload?.status === 200 ? response.payload.data : {},
        });
        notificationThrower({
          type: 'success',
          message: 'File deleted successfully' as string,
        });
        dispatch(prActions.getUploadedFiles(id));

        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  downloadUploadedFile: (id, filename) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.getUploadedFile(id, filename);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        downloadFileByExtension(filename, link);
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },
  fetchPR: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.fetchPR(query);
      if (response.success) {
        dispatch({
          type: PR_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({
          type: STATUS_ERROR,
        });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },

  getById: (id, query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.fetchPRById(id, query);
      if (response.success) {
        dispatch({
          type: PR_GET_BY_ID,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_ERROR });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },

  createPR: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await prApis.createPR(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'PR Successfully Created' as string,
        });
        dispatch({
          type: PR_CREATE,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({
          type: STATUS_UPDATE_SUCCESS_MESSAGE,
          payload: 'Purchase Request Successfully Added',
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(prActions.fetchPR(query));
      } else {
        dispatch({ type: STATUS_ERROR });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },

  updatePR: (id, data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.updatePR(id, data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'PR Successfully Updated' as string,
        });
        dispatch({
          type: PR_UPDATE,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({
          type: STATUS_UPDATE_SUCCESS_MESSAGE,
          payload: 'Purchase Request Successfully Updated',
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(prActions.fetchPR(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_ERROR });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },

  changeStatusPR: (query, payload, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.changeStatusPR(payload.id, payload.data);
      if (response.success) {
        if (actionType === 'Assigned') {
          IsAuthorizer(role) === false
            ? notificationThrower({
                type: 'success',
                message: 'PR Successfully Sent For Approval' as string,
              })
            : notificationThrower({
                type: 'success',
                message: 'PR Successfully Approved' as string,
              });
        } else {
          notificationThrower({
            type: 'success',
            message: 'PR Successfully Rejected' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(prActions.fetchPR(query));
        dispatch({
          type: STATUS_UPDATE_SUCCESS_MESSAGE,
          payload: `Purchase Request with id:${payload.id} Successfully Approved`,
        });
      } else {
        if (actionType === 'Assigned') {
          notificationThrower({
            type: 'error',
            message: 'PR Approval Failed' as string,
          });
        } else {
          notificationThrower({
            type: 'error',
            message: 'PR Rejection Failed' as string,
          });
        }
        dispatch({ type: STATUS_ERROR });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },

  getRejectedDescription: userInput => dispatch => {
    dispatch({
      type: GET_DESCRIPTION,
      payload: userInput,
    });
  },

  deletePR: (id, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.deletePR(id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'PR Successfully Deleted' as string,
        });
        dispatch({
          type: STATUS_UPDATE_SUCCESS_MESSAGE,
          payload: 'Purchase Request Successfully Deleted',
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(prActions.fetchPR(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'PR Deletion Failed' as string,
        });
        dispatch({ type: STATUS_ERROR });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },

  clearPRData: () => dispatch => {
    dispatch({
      type: PR_CLEAR_DATA,
    });
  },
  exportExelFile: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await prApis.exportExelFile(id);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;

        link.setAttribute('download', 'PR.pdf');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'PR Download Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  batchUpdate: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await prApis.bactchUpdate(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message:
            data?.newStatus === 'PRA'
              ? 'Successfully Sent All Purchase Requests For Approval'
              : 'Successfully Approved All Purchase Requests',
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(prActions.fetchPR(query));
      } else {
        if (response.payload.response.status === 404) {
          notificationThrower({
            type: 'warning',
            message:
              data?.newStatus === 'PRA'
                ? 'No Purchase Requests Are Applicable To Be Sent For Approval'
                : 'No Purchase Requests Are Applicable To Be Approved',
          });
        } else {
          notificationThrower({
            type: 'error',
            message: 'Something Went Wrong' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },
};

export default prActions;
