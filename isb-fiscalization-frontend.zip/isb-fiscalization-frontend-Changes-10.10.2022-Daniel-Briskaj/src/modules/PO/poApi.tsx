import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const poApis = {
  fetchPO: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/po`,
      query: query || {},
    }),
  fetchPOById: (id, query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/po/${id}`,
      query: query || {},
    }),
  createPO: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/po`,
      data,
    }),
  updatePO: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/po/${id}`,
      data,
    }),

  changeStatusPO: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/po/changeStatus/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data,
    }),
  deletePO: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/po/${id}`,
    }),
  exportExelFile: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/po/exportPo/${id}`,
      responseType: 'blob',
    }),
  bactchUpdate: data =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/po/batch_update`,
      data,
    }),
};
