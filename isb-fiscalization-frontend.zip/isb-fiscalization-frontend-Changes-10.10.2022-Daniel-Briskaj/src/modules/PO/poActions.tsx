import { poApis } from './poApi';
import {
  PO_SUCCESS,
  PO_CREATE,
  PO_DELETE,
  PO_UPDATE,
  PO_GET_BY_ID,
  PO_CLEAR_DATA,
  SET_CURRENT_PAGE,
  PO_EXPORT,
  GET_DESCRIPTION,
} from './poActionTypes';

import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../shared/statuses/statusesActionTypes';
import notificationThrower from 'src/helpers/notificationThrower';
import IsAuthorizer from 'src/helpers/isAuthorizer';

const poActions = {
  fetchPO: (query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await poApis.fetchPO(query);
      if (response.success) {
        dispatch({
          type: PO_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  setCurrentPage: page => dispatch => {
    dispatch({
      type: SET_CURRENT_PAGE,
      payload: page,
    });
  },

  getRejectedDescription: userInput => dispatch => {
    dispatch({
      type: GET_DESCRIPTION,
      payload: userInput,
    });
  },

  getById: (id, query?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await poApis.fetchPOById(id, query);
      if (response.success) {
        dispatch({
          type: PO_GET_BY_ID,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  createPO: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await poApis.createPO(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Po Successfully Created' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(poActions.fetchPO(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  updatePO: (id, payload, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await poApis.updatePO(id, payload);

      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Po Successfully Updated' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(poActions.fetchPO(query));
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  changeStatusPO: (query, payload, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await poApis.changeStatusPO(payload.id, payload.data);

      if (response.success) {
        if (actionType === 'Assigned') {
          IsAuthorizer(role) === false
            ? notificationThrower({
                type: 'success',
                message: 'PO Successfully Sent For Approval' as string,
              })
            : notificationThrower({
                type: 'success',
                message: 'Po Successfully Approved' as string,
              });
        } else {
          notificationThrower({
            type: 'success',
            message: 'PO Successfully Rejected' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(poActions.fetchPO(query));
      } else {
        if (actionType === 'Assigned') {
          notificationThrower({
            type: 'error',
            message: 'PO Approval Failed' as string,
          });
        } else {
          notificationThrower({
            type: 'error',
            message: 'PO Rejection Failed' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  deletePO: (id, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await poApis.deletePO(id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'PO Successfully Deleted' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(poActions.fetchPO(query));
      } else {
        notificationThrower({
          type: response.payload.response.status === 409 ? 'warning' : 'error',
          message:
            response.payload.response.status === 409
              ? (response.payload.response.data as string)
              : ('PO Deletion Failed' as string),
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  clearPoData: () => dispatch => {
    dispatch({
      type: PO_CLEAR_DATA,
    });
  },

  exportExelFile: id => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });
      const response = await poApis.exportExelFile(id);

      if (response.success) {
        const path = window.URL.createObjectURL(response.payload.data);
        const link = document.createElement('a');
        link.href = path;
        link.setAttribute('download', 'po.pdf');
        document.body.appendChild(link);
        link.click();
        link.remove();
        dispatch({ type: STATUS_LOADING_FALSE });
      } else {
        notificationThrower({
          type: 'error',
          message: 'PO Download Failed' as string,
        });
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: STATUS_LOADING_FALSE });
    }
  },

  batchUpdate: (data, query) => async dispatch => {
    try {
      dispatch({ type: STATUS_LOADING_TRUE });

      const response = await poApis.bactchUpdate(data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message:
            data?.newStatus === 'PRA'
              ? 'Successfully Sent All Purchase Orders For Approval'
              : 'Successfully Approved All Purchase Orders',
        });
        dispatch({ type: STATUS_LOADING_FALSE });
        dispatch(poActions.fetchPO(query));
      } else {
        if (response.payload.response.status === 404) {
          notificationThrower({
            type: 'warning',
            message:
              data?.newStatus === 'PRA'
                ? 'No Purchase Orders Are Applicable To Be Sent For Approval'
                : 'No Purchase Orders Are Applicable To Be Approved',
          });
        } else {
          notificationThrower({
            type: 'error',
            message: 'Something Went Wrong' as string,
          });
        }
        dispatch({ type: STATUS_LOADING_FALSE });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({
        type: STATUS_ERROR,
        payload: error,
      });
    }
  },
};

export default poActions;
