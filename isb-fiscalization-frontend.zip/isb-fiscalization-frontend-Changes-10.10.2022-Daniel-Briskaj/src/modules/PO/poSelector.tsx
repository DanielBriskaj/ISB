import { createSelector } from 'reselect';

const selectRaw = state => state.po;

const purchaseOrderData = createSelector(
  [selectRaw],
  po => po.purchaseOrderData,
);

const poData = createSelector([selectRaw], po => po.poData);

const poSelector = {
  purchaseOrderData,
  poData,
};
export default poSelector;
