import { PoData } from 'src/models/data/po/PoData';
import {
  PO_SUCCESS,
  PO_CREATE,
  PO_DELETE,
  PO_UPDATE,
  PO_GET_BY_ID,
  PO_CLEAR_DATA,
  SET_CURRENT_PAGE,
  PO_EXPORT,
  GET_DESCRIPTION,
} from './poActionTypes';

const initailValues: PoData = {
  purchaseOrderData: [],
  poData: {},
  rejectedPo: '',
};

export default function (state = initailValues, { type, payload }) {
  switch (type) {
    case PO_SUCCESS:
      return {
        ...state,
        purchaseOrderData: payload,
      };
    case SET_CURRENT_PAGE:
      return {
        ...state,
        purchaseOrderData: {
          ...state,
          currentPage: payload,
        },
      };
    case GET_DESCRIPTION:
      return {
        ...state,
        rejectedPo: payload,
      };
    case PO_GET_BY_ID:
      return {
        ...state,
        poData: payload,
      };
    case PO_CREATE:
      return {
        ...state,
        poData: payload,
      };
    case PO_DELETE:
      return {
        ...state,
        poData: payload,
      };
    case PO_UPDATE:
      return {
        ...state,
        poData: payload,
      };
    case PO_CLEAR_DATA:
      return {
        ...state,
        poData: {},
      };
    default:
      return state;
  }
}
