const prefix = 'PO';

export const PO_LOADING = `${prefix}_LOADING`;
export const PO_SUCCESS = `${prefix}_SUCCESS`;
export const PO_ERROR = `${prefix}_ERROR`;
export const PO_CREATE = `${prefix}_CREATE`;
export const PO_DELETE = `${prefix}_DELETE`;
export const PO_UPDATE = `${prefix}_UPDATE`;
export const PO_GET_BY_ID = `${prefix}_GET_BY_ID`;
export const PO_CLEAR_DATA = `${prefix}_CLEAR_DATA`;
export const SET_CURRENT_PAGE = `${prefix}_SET_CURRENT_PAGE`;
export const PO_EXPORT = `${prefix}_EXPORT`;
export const GET_DESCRIPTION = `GET_DESCRIPTION`;
