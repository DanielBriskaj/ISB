const prefix = 'GL';

export const GL_LOADING = `${prefix}_LOADING`;
export const GL_ERROR = `${prefix}_ERROR`;
export const GL_SUCCESS = `${prefix}_SUCCESS`;
export const GL_CREATE_SUCCESS = `${prefix}_SUCCESS`;
export const GL_UPDATE_SUCCESS = `${prefix}_UPDATE_SUCCESS`;
export const GL_DELETE_SUCCESS = `${prefix}_DELETE_SUCCESS`;
export const SET_CURRENT_PAGE = 'SET_CURRENT_PAGE';
export const GL_GET_BY_ID = `${prefix}_GET_BY_ID`;
export const GL_GET_ALL = `${prefix}_GET_ALL`;
export const GL_CLEAR = `${prefix}_CLEAR`;
