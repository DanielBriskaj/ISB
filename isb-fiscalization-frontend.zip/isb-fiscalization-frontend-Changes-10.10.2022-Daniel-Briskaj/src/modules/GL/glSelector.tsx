import { createSelector } from 'reselect';

const selectRaw = state => state.gl;

const glsDataArray = createSelector([selectRaw], gl => gl.glsData);

const glData = createSelector([selectRaw], gl => gl.glData);
const allGl = createSelector([selectRaw], gl => gl.allGl);

const status = createSelector([selectRaw], gl => gl.status);
const loading = createSelector([selectRaw], gl => gl.loading);

const glSelector = {
  allGl,
  glsDataArray,
  glData,
  status,
  loading,
};

export default glSelector;
