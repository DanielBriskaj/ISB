import {
  GL_LOADING,
  GL_ERROR,
  GL_SUCCESS,
  GL_GET_ALL,
  GL_CREATE_SUCCESS,
  GL_UPDATE_SUCCESS,
  GL_DELETE_SUCCESS,
  SET_CURRENT_PAGE,
  GL_GET_BY_ID,
  GL_CLEAR,
} from './glActionTypes';
import {
  STATUS_LOADING_TRUE,
  STATUS_LOADING_FALSE,
  STATUS_ERROR,
  STATUS,
  STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../shared/statuses/statusesActionTypes';
import { glApis } from './glApi';
import notificationThrower from 'src/helpers/notificationThrower';
import deepEqual from 'deep-equal';
import isAuthorizer from 'src/helpers/isAuthorizer';

export const glActions = {
  readGl: (query?) => async dispatch => {
    try {
      dispatch({ type: GL_LOADING, payload: true });
      const response = await glApis.fetchGl(query);
      if (response.success) {
        dispatch({
          type: GL_SUCCESS,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: GL_LOADING, payload: false });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: GL_LOADING, payload: false });
    }
  },
  getAllGl: (query?) => async dispatch => {
    try {
      dispatch({ type: GL_LOADING, payload: true });
      const response = await glApis.fetchGl(query);
      if (response.success) {
        dispatch({
          type: GL_GET_ALL,
          payload: response.payload.status === 200 ? response.payload.data : [],
        });
        dispatch({ type: GL_LOADING, payload: false });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: GL_LOADING, payload: false });
    }
  },
  createGl: payload => async dispatch => {
    try {
      dispatch({ type: GL_LOADING, payload: true });
      const response = await glApis.createGl(payload.data);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Gl Successfully Created' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
        dispatch(
          glActions.readGl({
            page: payload.page,
            size: payload.rowsPerPage,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: GL_LOADING, payload: false });
    }
  },
  updateGl: (payload, id) => async dispatch => {
    try {
      let initialGL = payload?.rawGLData;
      let updatedGL = payload?.data;

      if (initialGL?.approved === 'APPROVED') {
        const equal = deepEqual(initialGL, updatedGL);
        if (!equal) {
          updatedGL = {
            ...updatedGL,
            approved: 'NEW',
          };
        }
      }

      dispatch({ type: GL_LOADING, payload: true });
      const response = await glApis.updateGl(updatedGL, id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Gl Successfully Updated' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
        dispatch(
          glActions.readGl({
            page: payload.page,
            size: payload.rowsPerPage,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: GL_LOADING, payload: false });
    }
  },

  updateStatus: (payload, role?, actionType?) => async dispatch => {
    try {
      dispatch({ type: GL_LOADING, payload: true });
      const response = await glApis.updateGlStatus(payload.id, payload.data);
      if (response.success) {
        if (actionType === 'Assigned') {
          role === 'ACCOUNTING_INPUT'
            ? notificationThrower({
                type: 'success',
                message: 'GL successfully sent for approval' as string,
              })
            : notificationThrower({
                type: 'success',
                message: 'GL successfully approved' as string,
              });
        } else {
          notificationThrower({
            type: 'success',
            message: 'GL successfully rejected' as string,
          });
        }
        dispatch({ type: GL_LOADING, payload: false });
        dispatch(
          glActions.readGl({
            page: payload.page || 0,
            size: payload.rowsPerPage || 10,
            approved: payload.approved,
          }),
        );
      } else {
        actionType === 'Assigned'
          ? notificationThrower({
              type: 'error',
              message: 'GL Approval Failed' as string,
            })
          : notificationThrower({
              type: 'error',
              message: 'GL Rejection Failed' as string,
            });

        dispatch({ type: GL_LOADING, payload: false });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: GL_LOADING, payload: false });
    }
  },
  deleteGl: payload => async dispatch => {
    try {
      dispatch({ type: GL_LOADING, payload: true });
      const response = await glApis.deleteGl(payload.id);
      if (response.success) {
        notificationThrower({
          type: 'success',
          message: 'Gl Successfully Deleted' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
        dispatch(
          glActions.readGl({
            page: payload.page,
            size: payload.rowsPerPage,
            approved: payload.approved,
          }),
        );
      } else {
        notificationThrower({
          type: response.payload.response.status === 409 ? 'warning' : 'error',
          message:
            response.payload.response.status === 409
              ? (response.payload.response.data as string)
              : ('Gl Deletion Failed' as string),
        });
        dispatch({ type: GL_LOADING, payload: false });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: GL_LOADING, payload: false });
    }
  },
  getById: id => async dispatch => {
    try {
      dispatch({ type: GL_LOADING, payload: true });
      const response = await glApis.getById(id);

      if (response.success) {
        dispatch({
          type: GL_GET_BY_ID,
          payload: response.payload.status === 200 ? response.payload.data : {},
        });
        dispatch({ type: GL_LOADING, payload: false });
      } else {
        notificationThrower({
          type: 'error',
          message: 'Something Went Wrong' as string,
        });
        dispatch({ type: GL_LOADING, payload: false });
      }
    } catch (error) {
      notificationThrower({
        type: 'error',
        message: 'Something Went Wrong' as string,
      });
      dispatch({ type: GL_LOADING, payload: false });
    }
  },
  setCurrentPage: page => dispatch => {
    dispatch({
      type: SET_CURRENT_PAGE,
      payload: page,
    });
  },
  clearGLData: () => dispatch => {
    dispatch({ type: GL_CLEAR });
  },
};
