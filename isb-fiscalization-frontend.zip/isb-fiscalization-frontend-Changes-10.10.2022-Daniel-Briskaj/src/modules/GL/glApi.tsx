import Request from 'src/helpers/request';
import getConfig from 'src/helpers/config';

const config = getConfig();

const { test } = config;

export const glApis = {
  fetchGl: (query?) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/gl`,
      query: query || {},
    }),
  getById: id =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/gl/${id}`,
    }),
  createGl: data =>
    Request.doRequest({
      method: 'post',
      url: `${test.baseUrl}/gl`,
      data,
    }),
  updateGl: (data, id) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/gl/${id}`,
      data,
    }),
  updateGlStatus: (id, data) =>
    Request.doRequest({
      method: 'put',
      url: `${test.baseUrl}/gl/approvalStatus/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data,
    }),
  deleteGl: id =>
    Request.doRequest({
      method: 'delete',
      url: `${test.baseUrl}/gl/${id}`,
    }),
};
