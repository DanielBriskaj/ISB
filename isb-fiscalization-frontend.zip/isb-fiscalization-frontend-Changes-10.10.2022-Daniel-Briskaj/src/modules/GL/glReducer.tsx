import { GlData } from 'src/models/data/gl/GlData';
import {
  GL_SUCCESS,
  GL_CREATE_SUCCESS,
  GL_UPDATE_SUCCESS,
  GL_DELETE_SUCCESS,
  SET_CURRENT_PAGE,
  GL_GET_BY_ID,
  GL_GET_ALL,
  GL_CLEAR,
  GL_LOADING,
} from './glActionTypes';

const initialValues: GlData = {
  allGl: [],
  glsData: [],
  glData: {},
  glCode: '',
  loading: false,
};

export default function (state = initialValues, { type, payload }) {
  switch (type) {
    case GL_LOADING:
      return {
        ...state,
        loading: payload,
      };
    case GL_GET_ALL:
      return {
        ...state,
        allGl: payload,
      };
    case GL_CLEAR:
      return {
        ...state,
        allGl: [],
        glsData: [],
        glData: {},
        glCode: '',
      };
    case GL_SUCCESS:
      return {
        ...state,
        glsData: payload,
      };
    case GL_CREATE_SUCCESS:
      return {
        ...state,
        glsData: payload || state.glsData,
      };
    case GL_UPDATE_SUCCESS:
      return {
        ...state,
        glData: payload,
      };
    case GL_DELETE_SUCCESS:
      return {
        ...state,
        glData: payload,
      };
    case GL_GET_BY_ID:
      return {
        ...state,
        glData: payload,
      };
    case SET_CURRENT_PAGE:
      return {
        ...state,
        glsData: {
          ...state,
          currentPage: payload,
        },
      };
  }
  return state;
}
