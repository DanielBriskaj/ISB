export interface GLDATA {
  id?: number;
  glCode: string;
  description: string;
  glAccrual: string;
  approved: string;
}

export interface GlData {
  allGl: Array<GLDATA> | any;
  glsData: Array<GLDATA> | any;
  glData: GLDATA | Object;
  glCode: string;
  loading: boolean;
}
