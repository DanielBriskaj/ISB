export interface AuthData {
  jwt: string;
  isLoggedIn: boolean;
  role: string;
  costOwnerId: number;
  costOwnerCode: string;
  name: string;
  surname: string;
  username: string;
  division: string;
}

export interface AuthenticationData {
  loading: boolean;
  authData: AuthData | Object;
  error: boolean | any;
}
