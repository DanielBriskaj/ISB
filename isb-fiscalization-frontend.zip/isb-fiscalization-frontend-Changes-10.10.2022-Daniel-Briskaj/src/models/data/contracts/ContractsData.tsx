export interface ContractData {
  id?: number;
  expenditureType: string;
  supplier: {
    id: number;
  };
  branch: {
    id: number;
  };
  budgetCode: string;
  costOwner: {
    id: number;
    code: string;
  };
  contractDescription: string;
  contractCode: string;
  startDate: Date | string;
  endDate: Date | string;
  currency: string;
  automaticRenewal: boolean;
  productDescription: string;
  exitOption: boolean;
  contractAmount: number;
  fixedOrVariable: string;
  prepayment: boolean;
  isVat: boolean;
  vat: number;
  vatValue?: number;
  gl: {
    id: number;
  };
  iban: string;
  isCriticalContract: boolean;
  contractStatus:
    | 'ACTIVE'
    | 'BUDGET'
    | 'FORECAST'
    | 'EXPIRED'
    | 'NEW'
    | 'IN_APPROVAL';
  resolutionClauses: boolean;
  project: string;
  integration: boolean;
  bankContactPerson: string;
  parentContract: any;
  approved: string;
}

interface ContractRead {
  totalItems: number;
  contracts: Array<ContractData>;
  totalPages: number;
  currentPage: number;
}

export interface ContractsData {
  subLoading: boolean;
  contractsData: ContractRead | Object;
  contractData: ContractData | Object;
  subContractsData: Array<ContractData> | Object;
  selectedContract: any;
  files: Array<any>;
}

export interface FilteredExportedContractsProps {
  description: string;
  supplierCompanyName: string;
  costOwnerName: string;
  sort?: any;
  contractStatus?: string;
}
