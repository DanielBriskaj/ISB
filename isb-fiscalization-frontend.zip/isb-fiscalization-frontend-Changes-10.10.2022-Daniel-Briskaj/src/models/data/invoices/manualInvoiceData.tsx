export interface ManualInvoiceData {
  costOwner: Object | any;
  supplier: Object | any;
  invoiceNumber: string;
  receivedDate: Date | string;
  dueDate: Date | string;
  nipt: string;
  currency: any;
  invoiceStatus?: string;
  amount: number;
  vat: number;
  description?: string;
  isManual: boolean;
  po?: Object | any;
  contract?: Object | any;
}
