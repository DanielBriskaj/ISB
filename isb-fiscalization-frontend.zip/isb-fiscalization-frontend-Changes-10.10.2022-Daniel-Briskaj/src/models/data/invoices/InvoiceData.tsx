import { CostOwnerData } from '../costOwners/CostOwnerData';

export interface InvoiceData {
  eic: string;
  invoiceNumber: string;
  importedInvoiceNumber: string;
  receivedDate: Date | string;
  dueDate: Date | string;
  amount: number;
  status: string;
  type: string;
  NIPT: string;
  approved: string;
}

export interface CostOwnerFormInvoiceData {
  po: any;
  contract: any;
  eic: string;
  invoiceNumber: string;
  importedInvoiceNumber: string;
  receivedDate: Date | string;
  dueDate: Date | string;
  amount: number;
  status: string;
  type: string;
  nipt: string;
  invoiceStatus?: string;
  approved: string;
  costOwner: any;
  supplier: Object | any;
}

export interface FormInvoiceData {
  costOwner?: any;
  eic?: string;
  invoiceNumber?: string;
  importedInvoiceNumber?: string;
  receivedDate?: Date | string;
  dueDate?: Date | string;
  amount?: number;
  status?: string;
  type?: string;
  nipt?: string;
  invoiceStatus?: string;
  approved?: string;
  date?: any;
  valueDate?: any;
  invoiceValue?: string;
  currency?: string;
  subject?: string;
}
export interface CoaInvoicesData {
  invoiceNumber?: string;
  eic?: string;
  receivedDate?: string;
  dueDate?: string;
  nipt?: string;
  amount?: number;
  invoiceStatus?: string;
  description?: string;
  isManual?: boolean;
  currency?: string;
  vat?: number;
  contract?: any;
  po?: any;
  costOwner?: any;
  authorizerFeedback?: string;
}

export interface InvoicesData {
  invoicesData: Array<InvoiceData> | any;
  ebillsData: InvoiceData[] | any;
  invoiceData: InvoiceData | any;
  costOwnersOptions: any;
  acceptedInvoicesData: Array<InvoiceData> | any;
  currentTab: 'invoices' | 'pay_invoices';
  loading: boolean;
}

interface InvoiceCustomer {
  address?: string;
  company?: string;
  email: string;
  name: string;
  taxId?: string;
}

interface InvoiceItem {
  id: string;
  currency: string;
  description: string;
  unitAmount: number;
}

export type InvoiceStatus = 'canceled' | 'paid' | 'pending';

export interface Invoice {
  id: string;
  currency: string;
  customer: InvoiceCustomer;
  dueDate?: number;
  issueDate?: number;
  items?: InvoiceItem[];
  number?: string;
  status: InvoiceStatus;
  subtotalAmount?: number;
  taxAmount?: number;
  totalAmount?: number;
}
