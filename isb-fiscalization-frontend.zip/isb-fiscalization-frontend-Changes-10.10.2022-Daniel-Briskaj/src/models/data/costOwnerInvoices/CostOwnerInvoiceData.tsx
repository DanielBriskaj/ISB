export interface CostOwnerInvoiceData {
  eic: string;
  invoiceNumber: string;
  importedInvoiceNumber: string;
  receivedDate: Date | string;
  dueDate: Date | string;
  amount: string;
  status: string;
  type: string;
  NIPT: string;
  approved: string;
}

export interface CostOwnerInvoicesData {
  invoicesData: CostOwnerInvoiceData | any;
  invoiceData: CostOwnerInvoiceData | any;
  costOwnersOptions: Array<any>;
  contractsOptions: Array<any>;
  selectedInvoice: any;
  currentTab: 'co_invoices' | 'co_manual_invoices';
  files: Array<any>;
  file?: any;
}
