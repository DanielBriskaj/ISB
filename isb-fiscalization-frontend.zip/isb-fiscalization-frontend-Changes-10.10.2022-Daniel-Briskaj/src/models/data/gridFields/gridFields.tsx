export type FieldType =
  | 'number'
  | 'text'
  | 'select'
  | 'date'
  | 'textarea'
  | 'label'
  | 'reactSelect'
  | 'checkbox'
  | 'switch'
  | 'reactTimezoneSelect';

export interface GridField {
  type: FieldType;
  label?: string;
  label1?: string;
  md: number;
  xs: number;
  name?: string;
  options?: Array<any>;
  value?: string;
  defaultValue?: any;
  handleOnMenuScrollToBottom?: any;
  handleOnInputChange?: any;
  disabled?: boolean;
  isMulti?: boolean;
  selectedValue?: any;
  step?: number;
  menuHeight?: number;
  handleResetSearch?: any;
  isClearable?: boolean;
}
