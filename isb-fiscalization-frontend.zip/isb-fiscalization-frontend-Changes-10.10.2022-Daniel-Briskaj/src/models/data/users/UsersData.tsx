import { CostOwnerData } from '../costOwners/CostOwnerData';
export interface UserData {
  id?: number;
  name: string;
  surname: string;
  username: string;
  role: string;
  email: string;
  costOwner: CostOwnerData | null;
  active: boolean | null;
}

export interface UsersData {
  usersData: Array<UserData>;
  userData: UserData | Object;
}
