import { BranchData } from '../branches/BranchesData';
import { SupplierDetails } from '../suppliers/SuppliersData';
import { CostOwnerData } from '../costOwners/CostOwnerData';
import { ContractData } from '../contracts/ContractsData';

export interface OptionsData {
  branchesOptions: Array<BranchData> | any;
  suppliersOptions: Array<SupplierDetails> | any;
  costOwnersOptions: Array<CostOwnerData> | any;
  contractsOptions: Array<ContractData> | any;
  poOptions: Array<any> | any;
  error: boolean | any;
  loading: boolean;
}
