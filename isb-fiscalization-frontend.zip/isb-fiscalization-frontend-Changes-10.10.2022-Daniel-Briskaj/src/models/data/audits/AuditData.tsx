export interface AuditData {
  id?: number;
  actionName: string;
  actionType: string;
  dateTime: Date | string | any;
  idActionName: string | any;
  username: string;
}

export interface AuditsData {
  auditsData: Object | AuditData;
}
