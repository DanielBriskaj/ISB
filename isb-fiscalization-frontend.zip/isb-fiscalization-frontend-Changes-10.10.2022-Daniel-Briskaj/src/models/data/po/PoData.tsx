export interface PoItemsList {
  id?: number;
  description: string;
  price: number;
  quantity: number;
}

export interface PurchaseOrderData {
  id?: number;
  date: Date | string;
  poStatus: string;
  poItems?: Array<PoItemsList> | Array<any>;
  deliverAtName: string;
  deliverAtAddress: string;
  deliverAtTelFax: string;
  deliverAtCel: string;
  deliverAtEmail: string;
  transportedVia: string;
  termsOfTransportation: string;
  supplier: { id: number };
  contract: { id: number };
  costOwner: { id: number };
  currency: string;
  description: string;
  authorizerFeedback: string;
}

export interface PoData {
  purchaseOrderData: Array<PurchaseOrderData> | any;
  poData: PurchaseOrderData | any;
  rejectedPo: string;
}
