export interface StatusData {
  loading: boolean;
  error: boolean | any;
  errorMessage: string;
  successMessage: string;
  warningMessage: string;
}
