export interface PrItemsList {
  id?: number;
  description: string;
  unitCost: number;
  quantity: number;
  goodCategory: string;
  deliveryDate: Date | string;
  deliveryPlace: string;
}

interface Supplier {
  id: number;
}
export interface AvailableFundsList {
  id?: number;
  projectName: string;
  currency: string;
  budgetedAmount: string;
  amountExpensedYtd: string;
}
export interface PurchaseRequestData {
  id?: number;
  date: Date | string;
  approved: string;
  prItems?: Array<PrItemsList> | Array<any>;
  subject: string;
  code: string;
  place: string;
  procScopeAsses: boolean;
  unitType: string;
  previousCurrency: string;
  prSuppliers: Array<Supplier>;
  currency: string;
  deliveryDate: string;
  previousValue: number;
  availableFunds?: Array<AvailableFundsList> | Array<any>;
}

export interface PrData {
  purchaseRequestData: Array<PurchaseRequestData> | any;
  prData: PurchaseRequestData | any;
  rejectedPr: string | any;
  files: Array<any>;
}
