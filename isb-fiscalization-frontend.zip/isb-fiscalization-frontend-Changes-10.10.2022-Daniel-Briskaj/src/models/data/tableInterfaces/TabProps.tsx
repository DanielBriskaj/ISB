import { SortDirection } from '@material-ui/core';

interface SearchObject {
  placeholder: string;
  function: (event: any) => void;
  customClass: string;
  disabled?: boolean;
}

export interface TableProps {
  headerFields?: Array<any>;
  isEditModal?: boolean;
  isEditable?: boolean;
  handleDialogOpen?: (id?: any) => void;
  handlePopupOpen?: (id?: any) => void;
  handleProcessOpen?: (id?: any, data?: any) => void;
  handleModalOpen?: (id?: any) => void;
  handleDirectionSorting?: (sortDirection: any) => void;
  handleMultipleDirectionSorting?: (SortDirectionProps: any) => void;
  onPageChange?: (event: any, page: any) => void;
  onChangeRowsPerPage?: (event: any) => void;
  searchArrayOfFunctions?: Array<SearchObject>;
  data?: Array<any>;
  loading?: boolean;
  totalItems?: number;
  currentPage?: number;
  handleDelete?: (id: number) => void;
  limitPerPage?: number;
  setSelected?: (id: number) => void;
  selected?: any;
  buttonData?: Array<any>;
  sortData?: Array<any>;
  dateState?: any;
  setDateState?: any;
  tableFooterData?: any;
  tableType: string;
  hasButton?: boolean;
  canDelete?: boolean;
  setApproved?: any;
  approved?: string;
  sortDirection?: string | string[];
  sortedProps?: any;
  StatusFilterComponent?: any;
  query?: any;
}
