export type ALIGN_POSITION =
  | 'center'
  | 'right'
  | 'left'
  | 'inherit'
  | 'justify';

export interface HeaderFields {
  label: string;
  align: ALIGN_POSITION;
  sort: boolean;
  sx?: any;
}

export interface TabHeader {
  headerFields: Array<HeaderFields>;
  handleDirectionSorting?: (sortDirection: string) => void;
  handleMultipleDirectionSorting?: (sortDirectionProps: any) => void;
  sortedProps?: any;
}
