export interface CostOwnerData {
  id?: number;
  division: string;
  code: string;
  ownerName: string;
  isAuthorizer: boolean;
  approved: string;
}

interface CostOwner {
  totalItems: number;
  costOwners: Array<CostOwnerData>;
  totalPages: number;
  currentPage: number;
}

export interface CostOwnersData {
  costOwnersData: CostOwner | Object;
  costOwnerData: CostOwnerData | Object;
}
