export interface BranchData {
  id?: number;
  branchCode: number;
  cityCode: string;
  description: string;
  approved: string;
}

interface BranchesRead {
  totalItems: number;
  contracts: Array<BranchData>;
  totalPages: number;
  currentPage: number;
}

export interface BranchesData {
  branchesData: BranchesRead | any;
  branchData: BranchData | Object;
}
