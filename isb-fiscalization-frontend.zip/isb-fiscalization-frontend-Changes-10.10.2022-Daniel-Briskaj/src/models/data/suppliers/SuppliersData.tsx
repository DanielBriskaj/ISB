export interface SupplierDetails {
  id?: number;
  userFirstname: string;
  userLastname: string;
  userRole: string;
  userTelephone: string;
  userMobile: string;
  userEmail: string;
  userPreferredLanguage: string;
  userTimeZone: string;
  username: string;
  userCode: string;
  registrationDate: string;
  companyName: string;
  organisationLegalStructure: string;
  companyRegistrationNumber: string;
  euVatNumber: string;
  dunAndBradstreet: string;
  vatNumber: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  state: string;
  mainPhoneNumber: string;
  organizationFaxNumber: string;
  webSite: string;
  bvd9: string;
  sapCode: string;
  alboCode: string;
  supplierAccountId: number;
  isLocal: boolean;
  isBankClient: boolean;
  approved: string;
}

interface SupplierRead {
  totalItems: number;
  suppliers: Array<SupplierDetails>;
  totalPages: number;
  currentPage: number;
}

export interface SuppliersData {
  suppliersData: SupplierRead | Object;
  supplierData: SupplierDetails | Object;
}
