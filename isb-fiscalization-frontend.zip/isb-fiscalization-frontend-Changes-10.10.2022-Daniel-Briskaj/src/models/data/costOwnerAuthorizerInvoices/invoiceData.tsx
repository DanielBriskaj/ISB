export interface CostOwnerAuthorizerInvoiceData {
  eic: string;
  invoiceNumber: string;
  importedInvoiceNumber: string;
  receivedDate: Date | string;
  dueDate: Date | string;
  amount: string;
  status: string;
  type: string;
  NIPT: string;
  approved: string;
}

interface CostOwnerAuthorizerInvoiceRead {
  totalItems: number;
  invoices: Array<CostOwnerAuthorizerInvoiceData>;
  totalPages: number;
  currentPage: number;
}

export interface CostOwnerAuthorizerInvoicesData {
  invoicesData: CostOwnerAuthorizerInvoiceRead | any;
  invoiceData: CostOwnerAuthorizerInvoiceData | any;
  costOwnersAuthorizerOptions: Array<any>;
  contractsAuthorizerOptions: Array<any>;
}
