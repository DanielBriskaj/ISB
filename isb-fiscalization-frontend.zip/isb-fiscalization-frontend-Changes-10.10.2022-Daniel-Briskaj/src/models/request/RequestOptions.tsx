interface StringKeyWithString {
  [key: string]: any;
}

type ResponseType =
  | 'arraybuffer'
  | 'blob'
  | 'document'
  | 'json'
  | 'text'
  | 'stream';

export interface RequestOptions {
  url: string;
  method: 'get' | 'post' | 'put' | 'patch' | 'delete';
  data?: any;
  headers?: StringKeyWithString;
  query?: StringKeyWithString;
  cancelToken?: any;
  responseType?: ResponseType;
}
