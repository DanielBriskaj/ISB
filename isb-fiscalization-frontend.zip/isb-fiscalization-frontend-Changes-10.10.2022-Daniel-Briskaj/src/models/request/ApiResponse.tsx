export interface ApiResponse {
  success: boolean;
  payload: any;
}
