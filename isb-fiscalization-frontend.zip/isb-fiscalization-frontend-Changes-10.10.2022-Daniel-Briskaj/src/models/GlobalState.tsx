import { SuppliersData } from './data/suppliers/SuppliersData';
import { BranchesData } from './data/branches/BranchesData';
import { CostOwnersData } from './data/costOwners/CostOwnerData';
import { CostOwnerInvoicesData } from './data/costOwnerInvoices/CostOwnerInvoiceData';
import { ContractsData } from './data/contracts/ContractsData';
import { InvoicesData } from './data/invoices/InvoiceData';
import { UsersData } from './data/users/UsersData';
import { AuthenticationData } from './data/auth/AuthenticationData';
import { OptionsData } from './data/options/OptionsData';
import { StatusData } from './data/status/StatusData';
import { PrData } from './data/pr/PrData';
import { PoData } from './data/po/PoData';

export interface IGlobalState {
  suppliers: SuppliersData;
  branches: BranchesData;
  costOwners: CostOwnersData;
  costOwnerInvoices: CostOwnerInvoicesData;
  contracts: ContractsData;
  invoices: InvoicesData;
  users: UsersData;
  auth: AuthenticationData;
  options: OptionsData;
  status: StatusData;
  pr: PrData;
  po: PoData;
}
